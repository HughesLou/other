package com.scb.fmsd.adapter.core;

import static org.junit.Assert.assertTrue;

import com.scb.fmsd.adapter.core.channel.AbstractOutChannel;
import com.scb.fmsd.adapter.core.channel.InChannel;
import com.scb.fmsd.adapter.core.channel.OutChannel;
import com.scb.fmsd.adapter.core.channel.direct.DirectChannel;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.common.config.Configuration;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class TestApplication extends RouterApplication {
    private static final Logger LOG = LoggerFactory.getLogger(TestApplication.class);
    

	private final DirectChannel from = new DirectChannel();

	@Override
	protected List<InChannel<?>> buildInChannels(Configuration config, String prefix) throws Exception {
		return Collections.<InChannel<?>>singletonList(from);
	}

	@Override
	protected List<OutChannel<?>> buildErrChannels(Configuration config, String prefix) throws Exception {
		return Collections.<OutChannel<?>>singletonList(new AbstractOutChannel<MessageObject>("ERROR") {
			@Override
			public void send(MessageObject message) throws Exception {
				((TestMessageObject) message).latch.countDown();
			}
		});
	}

	@Override
	protected List<OutChannel<?>> buildOutChannels(Configuration config, String prefix) throws Exception {
		if (!RouterApplication.OPTION_CHANNEL_TO.equals(prefix)) {
			return Collections.emptyList();
		}
		return Collections.<OutChannel<?>>singletonList(new AbstractOutChannel<MessageObject>("TO") {
			@Override
			public void send(MessageObject message) throws Exception {
				TestMessageObject tmo = (TestMessageObject) message.getOriginal();
				tmo.generated = message;
				tmo.latch.countDown();
			}
		});
	}

	public MessageObject testMessage(MessageObject message, boolean success) throws Exception {
		return testMessage(message, success, 1, TimeUnit.SECONDS);
	}
	
	public MessageObject testMessage(MessageObject message, boolean success, int timeout, TimeUnit timeUnit) throws Exception {
	    TestMessageObject tmo = new TestMessageObject(message);
	    try {
	        from.onMessage(tmo);
	        assertTrue("timeout", tmo.awaitForCompletion(timeout, timeUnit));
	    } catch(Exception ignore) {
	    }
	    
	    if (success) {
           Throwable error = message.getError();
            if(error != null){
                if(error instanceof Exception){
                    throw ((Exception)error);
                }else{
                    throw new RuntimeException(error.getMessage(), error);
                }
            }
	        Assert.assertNotNull(tmo.generated);
	        Assert.assertNotSame(message, tmo.generated);
	        return tmo.generated;
	    } else {
	        Assert.assertNotNull(message.getError());
	        return message;
	    }
	}

	@Override
	public void shutdown() {
	    try {
            stop();
            shutdownAllTasks();
            shutdownEventManager();
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
        }
	}

	private static class TestMessageObject implements MessageObject {

		private final MessageObject message;

        private transient Object refObject;

		public TestMessageObject(MessageObject message) {
			this.message = message;
		}

		@Override
		public String getMessageId() {
			return message.getMessageId();
		}

		@Override
		public Object getPayload() {
			return message.getPayload();
		}

		@Override
		public String getText() {
			return message.getText();
		}

		@Override
		public byte[] getBytes() {
			return message.getBytes();
		}

        @Override
        public boolean isBatchMessage() {
            return false;
        }

        @Override
		public Throwable getError() {
			return message.getError();
		}

		@Override
		public void setError(Throwable t) {
			message.setError(t);
		}

		@Override
		public void setOriginal(MessageObject original) {
			message.setOriginal(original);
		}

		@Override
		public MessageObject getOriginal() {
			return message.getOriginal();
		}

		@Override
		public void addProperty(String name, Object value) {
			message.addProperty(name, value);
		}

		@Override
		public Object getProperty(String name) {
			return message.getProperty(name);
		}

		@Override
		public boolean hasProperty(String name) {
			return message.hasProperty(name);
		}

		@Override
		public Map<String, Object> getProperties() {
			return message.getProperties();
		}

		@Override
		public void serialize(DataOutputStream out) throws Exception {
			message.serialize(out);
		}

		@Override
		public MessageObject deserialize(DataInputStream in) throws Exception {
			return message.deserialize(in);
		}

        @Override
        public void setRefObject(Object refObject) {
            this.refObject = refObject;
        }

        @Override
        public Object getRefObject() {
            return refObject;
        }

        private MessageObject generated;

		private final CountDownLatch latch = new CountDownLatch(1);
		public boolean awaitForCompletion(int time, TimeUnit unit) throws InterruptedException {
			return latch.await(time, unit);
		}
	}
}
