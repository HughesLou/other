package com.scb.fmsd.adapter.core.channel.jms;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.scb.fmsd.adapter.core.channel.ChannelFactory;
import com.scb.fmsd.adapter.core.channel.ChannelMessageListener;
import com.scb.fmsd.adapter.core.channel.InChannel;
import com.scb.fmsd.adapter.core.channel.jms.JmsListener;
import com.scb.fmsd.adapter.core.channel.jms.JmsSender;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.model.StringMessageObject;

public class TestJmsSender extends JmsTestBase {

	private JmsSender sender;

	@Before
	public void before() throws Exception {
		config.setProperty("class", JmsSender.class.getName());
		sender = (JmsSender) spy(ChannelFactory.create("TEST", config));
		sender.start();
	}

	@After
	public void after() throws Exception {
		sender.shutdown();
	}

	private void sendMessage(boolean kill) throws Exception {
		final CountDownLatch latch = new CountDownLatch(1);
		final List<MessageObject> got = new ArrayList<>();

		config.setProperty("class", JmsListener.class.getName());
		JmsListener listener = ChannelFactory.create("JMSL", config);
		listener.setChannelMessageListener(new ChannelMessageListener() {
			@Override
			public void onMessage(MessageObject message, InChannel<?> channel) throws Exception {
				got.add(message);
				latch.countDown();
			}
		});
		listener.start();

		if (kill) {
			killConnection();
		}

		try {
			sender.send(new StringMessageObject("TEST-1"));
			assertTrue("timeout", latch.await(20, TimeUnit.SECONDS));
		} finally {
			listener.stop();
		}

		assertEquals("TEST-1", got.get(0).getText());
	}

	@Test
	public void testSendMessage() throws Exception {
		sendMessage(false);
	}

	@Test
	public void testSendAfterReconnect() throws Exception {
		sendMessage(true);
		verify(sender, times(1)).restart();
	}

	@Test
	public void testSendFailAfterReconnect() throws Exception {
		sender.setRetryAttempts(0);
		try {
			sendMessage(true);
			fail("Must fail");
		} catch (Exception e) {
			assertTrue(true);
		}
		verify(sender, times(0)).restart();
	}

}
