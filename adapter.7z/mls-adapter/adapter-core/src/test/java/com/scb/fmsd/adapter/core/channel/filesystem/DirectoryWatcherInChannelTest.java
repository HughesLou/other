package com.scb.fmsd.adapter.core.channel.filesystem;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.scb.fmsd.adapter.core.channel.ChannelMessageListener;
import com.scb.fmsd.adapter.core.channel.InChannel;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.common.config.Configuration;
import com.scb.fmsd.common.config.ConfigurationBuilder;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class DirectoryWatcherInChannelTest {
    private static final String TEMP_DIR = "temp_dir";
    private static final String WATCH_DIR = "watch_dir";
    private static Path tempPath;
    private static Path watchPath;

    DirectoryWatcherInChannel channel;


    @Before
    public void createDirectories() throws URISyntaxException, IOException {
        Path baseDir = Paths.get(DirectoryWatcherInChannelTest.class.getClassLoader().getResource(".").toURI());
        tempPath = baseDir.resolve(TEMP_DIR);
        createDir(tempPath);
        watchPath = baseDir.resolve(WATCH_DIR);
        createDir(watchPath);
    }

    @After
    public void postTestVerificationAndCleanUp() throws Exception {
        channel.doStop();
        TimeUnit.MILLISECONDS.sleep(100);
        assertThat("Directory watcher deleted all files after processing", isEmpty(watchPath), is(true));

        FileUtils.forceDelete(tempPath.toFile());
        FileUtils.forceDelete(watchPath.toFile());
    }

    private static boolean isEmpty(Path dir) {
        File[] files = dir.toFile().listFiles();
        return files.length == 0;
    }

    @Test
    public void should_detect_new_file() throws Exception {
        TestChannelMessageListener listener = new TestChannelMessageListener(1);
        channel = createChannel(listener);

        channel.doStart();

        createFileAndMoveToWatchDir("new_file.xml", "123");

        boolean fileReceived = listener.latch.await(2, TimeUnit.SECONDS);

        assertThat("File received", fileReceived, is(true));
        assertThat(listener.messages.get(0).getText(), containsString("123"));

    }

    @Test
    public void should_detect_new_files_with_delay_between_creation() throws Exception {
        TestChannelMessageListener listener = new TestChannelMessageListener(2);
        channel = createChannel(listener);
        channel.doStart();

        createFileAndMoveToWatchDir("new_file1.xml", "123");
        TimeUnit.MILLISECONDS.sleep(200);
        createFileAndMoveToWatchDir("new_file2.xml", "456");

        boolean filesReceived = listener.latch.await(2, TimeUnit.SECONDS);

        assertThat("Files received", filesReceived, is(true));
        assertThat(listener.messages.get(0).getText(), containsString("123"));
        assertThat(listener.messages.get(1).getText(), containsString("456"));

    }

    @Test
    public void should_detect_already_present_file() throws Exception {
        TestChannelMessageListener listener = new TestChannelMessageListener(1);
        channel = createChannel(listener);

        createFileAndMoveToWatchDir("new_file1.xml", "789");
        channel.doStart();

        boolean fileReceived = listener.latch.await(2, TimeUnit.SECONDS);

        assertThat("File received", fileReceived, is(true));
        assertThat(listener.messages.get(0).getText(), containsString("789"));
    }

    private static Configuration createConfiguration() {
        return ConfigurationBuilder.create()
                .set(DirectoryWatcherInChannel.PROPERTY_FILE_LOCATION, watchPath.toFile().getAbsolutePath())
                .set(DirectoryWatcherInChannel.PROPERTY_INITIAL_WAIT_TIME, 100)
                .set(DirectoryWatcherInChannel.PROPERTY_WAIT_TIME_BETWEEN_POLLING, 100)
                .build();
    }

    private static DirectoryWatcherInChannel createChannel(TestChannelMessageListener listener) {
        DirectoryWatcherInChannel channel = DirectoryWatcherInChannel.create("testDirectoryWatcher", createConfiguration());
        channel.setChannelMessageListener(listener);
        return channel;
    }

    private static void createDir(Path dirPath) throws IOException {
        File dirFile = dirPath.toFile();
        if (dirFile.exists()) {
            FileUtils.deleteDirectory(dirFile);
        }
        Files.createDirectory(dirPath);
    }

    private static void createFileAndMoveToWatchDir(String filename, String contents) throws IOException {
        Path tmpFile = tempPath.resolve(filename);
        Files.write(tmpFile, contents.getBytes());

        Path file = watchPath.resolve(filename);
        Files.move(tmpFile, file);
    }

    private static class TestChannelMessageListener implements ChannelMessageListener {
        final CountDownLatch latch;
        final List<MessageObject> messages;

        public TestChannelMessageListener(int expectedMessageCount) {
            this.latch = new CountDownLatch(expectedMessageCount);
            this.messages = new ArrayList<>(expectedMessageCount);
        }

        @Override
        public void onMessage(MessageObject message, InChannel<?> channel) throws Exception {
            messages.add(message);
            latch.countDown();
        }
    }
}
