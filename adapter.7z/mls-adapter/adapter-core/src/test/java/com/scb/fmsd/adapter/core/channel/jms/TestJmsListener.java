package com.scb.fmsd.adapter.core.channel.jms;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.scb.fmsd.adapter.core.channel.Channel;
import com.scb.fmsd.adapter.core.channel.ChannelFactory;
import com.scb.fmsd.adapter.core.channel.ChannelListener;
import com.scb.fmsd.adapter.core.channel.ChannelMessageListener;
import com.scb.fmsd.adapter.core.channel.InChannel;
import com.scb.fmsd.adapter.core.channel.jms.JmsListener;
import com.scb.fmsd.adapter.core.channel.jms.JmsSender;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.model.StringMessageObject;

public class TestJmsListener extends JmsTestBase {

	protected JmsListener listener;

	@Before
	public void before() throws Exception {
		logger.info("--------------------------------");
		String queue = "Q" + System.currentTimeMillis();
		config.setProperty("jndi.queue." + queue, queue);
		config.setProperty("destinationName", queue);
		config.setProperty("class", JmsListener.class.getName());
		listener = (JmsListener) spy(ChannelFactory.create("TEST", config));
		listener.start();
	}

	@After
	public void after() throws Exception {
		listener.shutdown();
	}

	private void sendAndReceive(boolean kill, boolean error) throws Exception {
		final CountDownLatch latch = new CountDownLatch(1);
		final List<MessageObject> got = new ArrayList<>();

		listener.setChannelMessageListener(new ChannelMessageListener() {
			@Override
			public void onMessage(MessageObject message, InChannel<?> channel) throws Exception {
				logger.info("Message {} received", message.getMessageId());
				assertSame(listener, channel);
				got.add(message);
				latch.countDown();
			}
		});

		if (error) {
			listener.setChannelListener(new ChannelListener() {
				@Override
				public void onException(Throwable t, Channel<?> channel) {
					latch.countDown();
				}
			});
		}

		if (kill) {
			killConnection();
		}

		sendMessage("TEST-1");

		assertTrue("timeout", latch.await(1, TimeUnit.SECONDS));
		if (error) {
			assertEquals(0, got.size());
		} else {
			assertEquals("TEST-1", got.get(0).getText());
		}
	}

	@Test
	public void testReceiveMessage() throws Exception {
		sendAndReceive(false, false);
	}

	@Test
	public void testRecovery() throws Exception {
		sendAndReceive(true, false);
		verify(listener, times(1)).restart();
	}

	@Test
	public void testRecoveryFail() throws Exception {
		listener.setRetryAttempts(0);
		sendAndReceive(true, true);
	}

	private void sendMessage(String string) throws Exception {
		JmsSender sender = JmsSender.create("JMSSender", config);
		sender.start();
		StringMessageObject mo = new StringMessageObject(string);
		sender.send(mo);
		logger.info("Message {} sent", mo.getMessageId());
		sender.stop();
	}

}
