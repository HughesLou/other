package com.scb.fmsd.adapter.core.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.junit.Ignore;
import org.junit.Test;

import com.scb.fmsd.adapter.core.utils.FileUtils;

public class TestFileUtils {
	
	private final static String FILE_PATH = "/com/scb/fmsd/adapter/core/utils/test.txt";

	private void testReadLines(List<String> lines) throws Exception {
		assertNotNull(lines);
		assertEquals(3, lines.size());
		assertEquals("line1", lines.get(0));
		assertEquals("line2", lines.get(1));
		assertEquals("line3", lines.get(2));
	}
	
	@Test
	public void testReadLinesFromClasspath() throws Exception {
		testReadLines(FileUtils.readLines("classpath:" + FILE_PATH, StandardCharsets.ISO_8859_1));
	}
	
	@Test
	@Ignore
	public void testReadLinesFromFile() throws Exception {
		testReadLines(FileUtils.readLines("file:./src/test/resources" + FILE_PATH, StandardCharsets.ISO_8859_1));
	}
	
	@Test
	public void testReadFirstLine() throws Exception {
		String line = FileUtils.readFirstLine("classpath:" + FILE_PATH, StandardCharsets.ISO_8859_1);
		assertNotNull(line);
		assertEquals("line1", line);
	}
	
	@Test
	public void testReadLinesFromStream() throws Exception {
		try (InputStream stream = TestFileUtils.class.getResourceAsStream(FILE_PATH)) {
			assertNotNull(stream);
			testReadLines(FileUtils.readLines(stream, StandardCharsets.UTF_8));
		}
	}
	
	@Test
	public void testreformFileName() {
		assertEquals("File#__________0001", FileUtils.reformFileName("File#<>:\"/\\|?*_0001"));
	}
	
	@Test
	public void testGetFileNameWithoutExt() {
		Path path = Paths.get("./mxml/IRD-FRA-AF/External/Cancel/02_27464214_TBO_PEND.xml");
		assertNotNull(path);
		assertEquals("02_27464214_TBO_PEND", FileUtils.getFileNameWithoutExt(path));
	}
	
}
