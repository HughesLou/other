package com.scb.fmsd.adapter.core.component.sequence;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.concurrent.TimeUnit;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.fmsd.adapter.core.component.sequence.MemSequenceGenerator;
import com.scb.fmsd.adapter.core.component.sequence.PersistedSequenceGenerator;

public class TestPersistedSequenceGenerator {

	private static final Logger logger = LoggerFactory.getLogger(TestPersistedSequenceGenerator.class);

	@Test
	public void testAfterReset() throws Exception {
		File f = Files.createTempFile("TestPersistedSequenceGenerator", "seq").toFile();
		PersistedSequenceGenerator gen = new PersistedSequenceGenerator(f);
		gen.reset(0);

		for (int i = 1; i <= 100; i++) {
			long x = gen.next();
			assertEquals(i, x);
		}

		gen.close();
	}

	@Test
	public void testPersistence() throws Exception {
		File f = Files.createTempFile("TestPersistedSequenceGenerator", "seq").toFile();
		PersistedSequenceGenerator gen = new PersistedSequenceGenerator(f);
		gen.reset(0);

		for (int i = 1; i <= 100; i++) {
			long x = gen.next();
			assertEquals(i, x);
		}

		gen.close();

		gen = new PersistedSequenceGenerator(f);
		assertEquals(101, gen.next());

		gen.close();
	}

	@Test
	public void testPerformance() throws IOException {
		File f = File.createTempFile("TestPersistedSequenceGenerator", "seq");
		PersistedSequenceGenerator gen = new PersistedSequenceGenerator(new MemSequenceGenerator(), f);

		long ONE_SEC_NANO = TimeUnit.SECONDS.toNanos(1);
		long t = System.nanoTime();
		int total = 0;
		while ((System.nanoTime() - t) <= ONE_SEC_NANO) {
			gen.next();
			total++;
		}

		logger.info("{} numbers generated for 1 second", total);

		assertTrue("Must be performant (" + total + " > 100K)", total > 100000);
	}
}
