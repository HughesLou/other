package com.scb.fmsd.adapter.core.processor.impl;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.processor.CorrelationKey;
import com.scb.fmsd.adapter.core.processor.Processor;
import com.scb.fmsd.adapter.core.processor.impl.SetBasedParallelProcessor;

public class TestSetBasedParallelProcessor extends ParallelProcessorTestBase {

	@Override
	public void setUp(Processor processor) throws Exception {
		CorrelationKey serializer = new CorrelationKey() {
			@Override
			public Set<Object> getKeys(MessageObject message) {
				return new HashSet<Object>(Arrays.asList(message.getMessageId().split(",")));
			}
			
			@Override
			public Object getKey(MessageObject message) {
				return null;
			}

			@Override
			public Properties getProperties(MessageObject message) {
				// TODO Auto-generated method stub
				return null;
			}

		};
		
		initialize(new SetBasedParallelProcessor(processor, 2, 2, serializer));
	}
	
}
