package com.scb.fmsd.adapter.core.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import org.junit.BeforeClass;
import org.junit.Test;

import com.scb.fmsd.adapter.core.channel.converters.CompressedMessageConverter;
import com.scb.fmsd.adapter.core.utils.CompressionUtils;

public class CompressedMessageObjectTest {
	
	static CompressedMessageConverter converter;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		converter = new CompressedMessageConverter();
	}

	@Test(expected=RuntimeException.class)
	public void testStringObjectCompress() throws Exception {
		StringMessageObject rawmsg = new StringMessageObject("content1", "msg1");
		MessageObject obj = converter.convert(rawmsg);
	}
	
	@Test
	public void testByteMessageObject() throws Exception{
		String content = "content1";
		BytesMessageObject bytemsg = new BytesMessageObject(getCompressedData(content), "msg1");
		CompressedMessageObject obj = new CompressedMessageObject(bytemsg);
		assertEquals(content,  obj.getText());
	}

	private byte[] getCompressedData(String content) throws IOException {
		return CompressionUtils.compress(content.getBytes());
	}
	
	@Test
	public void testTransactionSerialize() throws Exception{
		String content = "content2";
		BytesMessageObject bytemsg = new BytesMessageObject(getCompressedData(content), "msg2");
		CompressedMessageObject msg1 = new CompressedMessageObject(bytemsg);
		ByteArrayOutputStream data = new ByteArrayOutputStream();
		DataOutputStream ous = new DataOutputStream(data);
		msg1.serialize(ous);
		ous.flush();
		ByteArrayInputStream ins = new ByteArrayInputStream(data.toByteArray());
		CompressedMessageObject msg2 = new CompressedMessageObject();
		MessageObject msg3 = msg2.deserialize(new DataInputStream(ins));
		assertTrue(msg2==msg3);
		assertEquals(msg3.getText(), msg1.getText());
		assertEquals(msg3.getMessageId(), msg1.getMessageId());
		assertEquals(content, msg3.getText());
		
	}
}
