package com.scb.fmsd.adapter.core.model;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

public class StringMessageObjectTest {

	@Test
	public void test() {
		StringMessageObject msg1=new StringMessageObject("content1","id1");
		StringMessageObject msg2=new StringMessageObject("content1","id1");
		assertTrue(msg1.equals(msg2));
		assertEquals(msg1.hashCode(), msg2.hashCode());
	}
}
