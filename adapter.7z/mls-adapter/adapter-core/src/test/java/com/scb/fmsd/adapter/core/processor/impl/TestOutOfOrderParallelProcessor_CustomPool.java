package com.scb.fmsd.adapter.core.processor.impl;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;

import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.processor.Processor;
import com.scb.fmsd.adapter.core.processor.impl.OutOfOrderParallelProcessor_CustomPool;

public class TestOutOfOrderParallelProcessor_CustomPool extends ParallelProcessorTestBase {

	@Override
	public void setUp(Processor processor) throws Exception {
		initialize(new OutOfOrderParallelProcessor_CustomPool(processor, 2, 2));
	}

	@Test @Override
	public void testSerialization() throws Exception {
		assertTrue("Out of order processor", true);
	}

	@Override
	public void assertCorrectSequence(List<MessageObject> processed, List<MessageObject> seq) {
		// Out of order processor
	}

}
