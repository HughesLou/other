package com.scb.fmsd.adapter.core.utils;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

import com.scb.fmsd.adapter.core.utils.CompressionUtils;

public class TestCompressionUtils {

	@Test
	public void testCompressDecompress() throws IOException {
		byte[] original = TestCompressionUtils.class.getName().getBytes();
		byte[] compressed = CompressionUtils.compress(original);
		assertNotNull(compressed);

		byte[] uncompressed = CompressionUtils.decompress(compressed);
		assertNotNull(uncompressed);
		
		assertNotSame(original, uncompressed);
		
		assertArrayEquals(original, uncompressed);
	}
	
}
