package com.scb.fmsd.adapter.core.channel.mail;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import javax.mail.Message.RecipientType;
import javax.mail.internet.MimeMessage;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.icegreen.greenmail.util.GreenMail;
import com.icegreen.greenmail.util.GreenMailUtil;
import com.icegreen.greenmail.util.ServerSetupTest;
import com.scb.fmsd.adapter.core.Application;
import com.scb.fmsd.adapter.core.model.StringMessageObject;
import com.scb.fmsd.adapter.core.utils.NetUtils;
import com.scb.fmsd.common.config.Configuration;
import com.scb.fmsd.common.config.ConfigurationBuilder;

public class TestMailSender {

	static {
		System.setProperty(Application.APP_NAME, "TEST");
	}

	private GreenMail greenMail;
	final static Configuration config = ConfigurationBuilder.create().build();

	@Before
	public void before() {
		greenMail = new GreenMail(ServerSetupTest.SMTP);
	    greenMail.start();

		config.setProperty("subject", "%event [%app/%host] - %msg");
		config.setProperty("from", "from@mail");
		config.setProperty("recipients", "to@mail");
		config.setProperty("mail.smtp.auth", Boolean.FALSE);
		config.setProperty("mail.smtp.host", "localhost");
		config.setProperty("mail.smtp.port", greenMail.getSmtp().getPort());
		config.setProperty("mail.debug", Boolean.TRUE);
	}

	@After
	public void after() {
		greenMail.stop();
	}

	@Test
	public void testSendMessage() throws Exception {
		MailSender mail = MailSender.create("MAIL", config);
		mail.start();

		mail.send(new StringMessageObject("TEST-1"));

		assertTrue("timeout", greenMail.waitForIncomingEmail(1000, 1));
		MimeMessage[] messages = greenMail.getReceivedMessages();
	    assertEquals(1, messages.length);
	    assertEquals("TEST-1", GreenMailUtil.getBody(messages[0]).trim());
	    assertEquals("from@mail", messages[0].getFrom()[0].toString());
	    assertEquals("to@mail", messages[0].getRecipients(RecipientType.TO)[0].toString());
	    assertEquals("INFO [TEST/" + NetUtils.getHostname() + "] - TEST-1", messages[0].getSubject());

		mail.shutdown();
	}

}
