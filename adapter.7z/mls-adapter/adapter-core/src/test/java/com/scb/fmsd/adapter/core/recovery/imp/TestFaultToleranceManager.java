package com.scb.fmsd.adapter.core.recovery.imp;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Properties;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.mockito.Mockito;

import au.com.bytecode.opencsv.CSVReader;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.google.common.collect.Tables;
import com.google.common.collect.TreeBasedTable;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.model.MessageObjectPropertyKey;
import com.scb.fmsd.adapter.core.model.StringMessageObject;
import com.scb.fmsd.adapter.core.processor.CorrelationKey;
import com.scb.fmsd.adapter.core.recovery.FaultToleranceManager;
import com.scb.fmsd.adapter.core.recovery.RecoveryException;
import com.scb.fmsd.adapter.core.recovery.impl.FaultToleranceManagerImpl;
import com.scb.fmsd.adapter.core.recovery.impl.UnprocessedMessageInfo;

public class TestFaultToleranceManager {

	@Rule
	public TemporaryFolder temporaryFolder = new TemporaryFolder();

	private FaultToleranceManagerImpl tm;
	private Path retryLocation;
	private Path errorLocation;
	private CorrelationKey coKey;
	private Path indexLocation;
	private MessageObject message;

	@Before
	public void beforeTest() throws IOException {
		retryLocation = temporaryFolder.newFolder("TestFaultToleranceManagerRecovery").toPath();
		errorLocation = temporaryFolder.newFolder("TestFaultToleranceManagerError").toPath();
		indexLocation = errorLocation.resolve("index.csv");
		message = new StringMessageObject("Msg Content", "1");
		message.addProperty(MessageObjectPropertyKey.ARRIVAL_TIMESTAMP_NAME.getKey(), Long.valueOf("9876"));
		coKey = Mockito.mock(CorrelationKey.class);
		when(coKey.getKeys(message)).thenReturn(com.google.common.collect.Sets.<Object> newHashSet("123", "456"));
		Properties props = new Properties();
		props.put("portfolio", "sampleBook");
		props.put("product", "sampleProd");
		when(coKey.getProperties(message)).thenReturn(props);
	}

	@Test
	public void testInitialize() throws RecoveryException, IOException, InterruptedException {
		tm = new FaultToleranceManagerImpl(retryLocation, errorLocation, indexLocation, ';', coKey);
		tm.initialize();
		assertTrue(Files.exists(indexLocation));
		tm.addFailedMessageToQueue(message);

		// test load
		tm.initialize();
		assertTrue(!tm.getErrorTable().isEmpty());
	}

	@Test
	public void testAddFailedMessageToQueue() throws RecoveryException, IOException {
		tm = new FaultToleranceManagerImpl(retryLocation, errorLocation, indexLocation, ';', coKey);
		tm.initialize();
		assertTrue(Files.exists(indexLocation));
		assertFalse(tm.isFailedMessage(message));
		tm.addFailedMessageToQueue(message);
		TreeBasedTable<String, Long, String> errorTable = tm.getErrorTable();
		assertEquals(2, errorTable.size());
		assertTrue(errorTable.contains("123", Long.valueOf(9876)));
		assertTrue(errorTable.contains("456", Long.valueOf(9876)));
		assertTrue(tm.isFailedMessage(message));
		List<String> readAllLines = Files.readAllLines(indexLocation, Charset.defaultCharset());
		assertEquals(2, readAllLines.size());
	}

	@Test
	public void testWhenKeyIsEmptyAddFailedMessageToQueue() throws RecoveryException, IOException {
		String messageId = "Invalid-Msg" + System.currentTimeMillis();
		StringMessageObject invalidMsg = new StringMessageObject("Poison", messageId);
		invalidMsg.addProperty(MessageObjectPropertyKey.ARRIVAL_TIMESTAMP_NAME.getKey(), Long.valueOf("897866"));
		CorrelationKey key = Mockito.mock(CorrelationKey.class);
		when(key.getKeys(invalidMsg)).thenReturn(Sets.newHashSet());
		Properties props = new Properties();
		props.put("portfolio", "sampleBook");
		props.put("product", "sampleProd");
		when(key.getProperties(invalidMsg)).thenReturn(props);
		FaultToleranceManager<MessageObject> tm = new FaultToleranceManagerImpl(retryLocation, errorLocation, indexLocation, ';', key);
		tm.initialize();
		assertTrue(Files.exists(indexLocation));
		assertFalse(tm.isFailedMessage(invalidMsg));
		tm.addFailedMessageToQueue(invalidMsg);
	}

	@Test
	public void testWhenGetKeysThrowExceptionAddFailedMessageToQueue() throws RecoveryException, IOException {
		StringMessageObject invalidMsg = new StringMessageObject("Poison", "Invalid-Msg");
		invalidMsg.addProperty(MessageObjectPropertyKey.ARRIVAL_TIMESTAMP_NAME.getKey(), Long.valueOf("897866"));
		CorrelationKey key = Mockito.mock(CorrelationKey.class);
		when(key.getKeys(invalidMsg)).thenThrow(new RuntimeException("Invalid Mxml"));
		Properties props = new Properties();
		props.put("portfolio", "sampleBook");
		props.put("product", "sampleProd");
		when(key.getProperties(invalidMsg)).thenReturn(props);
		FaultToleranceManager<MessageObject> tm = new FaultToleranceManagerImpl(retryLocation, errorLocation, indexLocation, ';', key);
		tm.initialize();
		assertTrue(Files.exists(indexLocation));
		assertFalse(tm.isFailedMessage(invalidMsg));
		tm.addFailedMessageToQueue(invalidMsg);
	}

/*	@SuppressWarnings({ "unchecked", "resource" })
	@Test*/
	
	//TODO: 
	public void testRemoveMessageFromTable() throws RecoveryException, IOException {
		tm = new FaultToleranceManagerImpl(retryLocation, errorLocation, indexLocation, ';', coKey);
		tm.initialize();
		assertTrue(Files.exists(retryLocation));
		assertTrue(Files.exists(indexLocation));
		assertFalse(tm.isFailedMessage(message));
		tm.addFailedMessageToQueue(message);
		TreeBasedTable<String, Long, String> errorTable = tm.getErrorTable();
		assertEquals(2, errorTable.size());
		assertTrue(errorTable.contains("123", Long.valueOf(9876)));
		assertTrue(errorTable.contains("456", Long.valueOf(9876)));
		String fileName = errorTable.get("123", Long.valueOf(9876));

		tm.removeMessagesFromErrorQueue(Lists.newArrayList(fileName));

		assertEquals(1, errorTable.size());

		CSVReader csvReader = null;
		csvReader = new CSVReader(Files.newBufferedReader(indexLocation, Charset.defaultCharset()), ';');
		List<String[]> csvTable = csvReader.readAll();
		assertEquals(1, csvTable.size());
		String[] line = csvTable.get(0);
		System.out.println(line);
		assertEquals("456", line[0]);
		assertTrue(Files.exists(retryLocation.resolve(line[2])));
	}
}
