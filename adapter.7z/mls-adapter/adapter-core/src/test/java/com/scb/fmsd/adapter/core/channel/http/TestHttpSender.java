package com.scb.fmsd.adapter.core.channel.http;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.scb.fmsd.adapter.core.channel.http.HttpSender;
import com.scb.fmsd.adapter.core.model.StringMessageObject;
import com.scb.fmsd.adapter.core.utils.StreamUtils;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

@SuppressWarnings("restriction")
public class TestHttpSender {

	private static HttpServer server;

	private static int attempts = 0;

	@BeforeClass
	public static void beforeClass() throws IOException {
		server = HttpServer.create(new InetSocketAddress(0), 0);
		server.createContext("/", new HttpHandler() {
			@Override
			public void handle(HttpExchange t) throws IOException {
				String body = StreamUtils.read(t.getRequestBody());

				if ("TEST-OK".equals(body)) {
					t.sendResponseHeaders(HttpURLConnection.HTTP_OK, 0);
				} else if ("TEST-RETRY".equals(body)) {
					if (++attempts > 3) {
						t.sendResponseHeaders(HttpURLConnection.HTTP_OK, 0);
					} else {
						t.sendResponseHeaders(HttpURLConnection.HTTP_NOT_ACCEPTABLE, 0);
					}
				} else {
					String response = "Bad trade";
					t.sendResponseHeaders(HttpURLConnection.HTTP_NOT_ACCEPTABLE, 0);
					OutputStream os = t.getResponseBody();
					os.write(response.getBytes());
					os.close();
				}
			}
		});
		server.start();
	}

	@AfterClass
	public static void afterClass() {
		server.stop(0);
	}

	private HttpSender sender;

	@Before
	public void before() throws Exception {
		sender = new HttpSender("HTTP", "http://localhost:" + server.getAddress().getPort() + "/");
		sender.setConnectTimeout(1000);
		sender.setRetryWaitTime(100);
		sender.setMethod("POST");
		sender.start();
	}

	@After
	public void after() throws Exception {
		sender.stop();
	}

	@Test
	public void testOkResponse() throws Exception {
		sender.send(new StringMessageObject("TEST-OK"));
	}

	@Test
	public void testErrorResponse() throws Exception {
		try {
			sender.send(new StringMessageObject("TEST-FAIL"));
			fail("Should fail");
		} catch (Exception e) {
			assertTrue(true);
		}
	}

	@Test
	public void testOkAfterNAttempts() throws Exception {
		sender.setRetryAttempts(3);
		sender.send(new StringMessageObject("TEST-RETRY"));
	}
}
