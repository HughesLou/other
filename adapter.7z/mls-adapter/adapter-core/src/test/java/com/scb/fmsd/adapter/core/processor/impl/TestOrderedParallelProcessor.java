package com.scb.fmsd.adapter.core.processor.impl;

import com.scb.fmsd.adapter.core.processor.Processor;
import com.scb.fmsd.adapter.core.processor.impl.OrderedParallelProcessor;


public class TestOrderedParallelProcessor extends ParallelProcessorTestBase {

	@Override
	public void setUp(Processor processor) throws Exception {
		initialize(new OrderedParallelProcessor(processor, 2, 2));
	}
	
}
