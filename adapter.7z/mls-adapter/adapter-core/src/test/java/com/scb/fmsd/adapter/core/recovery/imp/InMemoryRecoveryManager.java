package com.scb.fmsd.adapter.core.recovery.imp;

import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.recovery.RecoveryException;
import com.scb.fmsd.adapter.core.recovery.RecoveryManager;

public class InMemoryRecoveryManager implements RecoveryManager<MessageObject> {
	
	private final ConcurrentMap<MessageObject, Object> mem = new ConcurrentHashMap<>();

	@Override
	public void startTransaction(MessageObject t) throws RecoveryException {
		if (mem.putIfAbsent(t, Boolean.TRUE) != null) {
			throw new RecoveryException("Transaction found for " + t.getMessageId());
		}
	}

	@Override
	public void commit(MessageObject t) throws RecoveryException {
		if (mem.remove(t) == null) {
			throw new RecoveryException("Transaction not found for " + t.getMessageId());
		}
	}

	@Override
	public void rollback(MessageObject t) throws RecoveryException {
		if (mem.remove(t) == null) {
			throw new RecoveryException("Transaction not found for " + t.getMessageId());
		}
	}
	
	@Override
	public boolean isTransacted(MessageObject t) {
		return mem.containsKey(t);
	}

	@Override
	public Iterator<MessageObject> unprocessed() {
		return mem.keySet().iterator();
	}

}
