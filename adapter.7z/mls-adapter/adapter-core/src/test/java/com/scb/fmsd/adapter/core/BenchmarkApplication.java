package com.scb.fmsd.adapter.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

import org.junit.Before;
import org.junit.Test;

import com.scb.fmsd.adapter.core.channel.AbstractOutChannel;
import com.scb.fmsd.adapter.core.channel.InChannel;
import com.scb.fmsd.adapter.core.channel.OutChannel;
import com.scb.fmsd.adapter.core.channel.direct.DirectChannel;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.model.StringMessageObject;
import com.scb.fmsd.common.config.Configuration;
import com.scb.sabre.common.test.benchmark.Benchmark;

public abstract class BenchmarkApplication extends RouterApplication {

	private final DirectChannel from = new DirectChannel();
	private final AtomicLong errors = new AtomicLong(0);

	private final AtomicReference<CountDownLatch> done = new AtomicReference<>();

	private Benchmark benchmark;

	@Override
	protected List<InChannel<?>> buildInChannels(Configuration config, String prefix) throws Exception {
		return Collections.<InChannel<?>>singletonList(from);
	}

	@Override
	protected List<OutChannel<?>> buildErrChannels(Configuration config, String prefix) throws Exception {
		return Collections.<OutChannel<?>>singletonList(new AbstractOutChannel<MessageObject>("ERROR") {
			@Override
			public void send(MessageObject message) throws Exception {
				errors.incrementAndGet();
				done.get().countDown();
			}
		});
	}

	@Override
	protected List<OutChannel<?>> buildOutChannels(Configuration config, String prefix) throws Exception {
		if (!RouterApplication.OPTION_CHANNEL_TO.equals(prefix)) {
			return Collections.emptyList();
		}
		return Collections.<OutChannel<?>>singletonList(new AbstractOutChannel<MessageObject>("TO") {
			@Override
			public void send(MessageObject message) throws Exception {
				TestMessageObject tmo = (TestMessageObject) message.getOriginal();
				assertNotNull(tmo);
				benchmark.collect(System.nanoTime() - tmo.created);
				verify(message);
				done.get().countDown();
			}
		});
	}

	@Before
	public void before() throws Exception {
		start(new String[0]);
	}

	protected abstract String[] getData() throws Exception;

	protected void verify(MessageObject message) throws Exception {
		// do nothing by default
	}

	@Test
	public void benchmark() throws Exception {
		final String[] tests = getData();

		int warmup = getConfig().getInt("warmup", 1000);
		int repeat = getConfig().getInt("repeat", 1000);

		benchmark = new Benchmark(warmup, repeat) {
			@Override
			protected Object doTest(int repeat) throws Exception {
				done.set(new CountDownLatch(repeat));
				int len = tests.length;
				for (int i = 0; i < repeat; i++) {
					StringMessageObject m = new TestMessageObject(tests[i % len], "MSG-" + i, System.nanoTime());
					from.onMessage(m);
				}

				assertTrue("timeout", done.get().await(10, TimeUnit.SECONDS));

				return null;
			}
		};

		benchmark.test();

		assertEquals("There are errors", 0, errors.get());

		System.out.println("Configuration:");
		System.out.println("---------------------------------------------------------");
		Properties p = getConfig().asProperties();
		@SuppressWarnings({ "rawtypes", "unchecked" })
		List<String> keys = new ArrayList(p.keySet());
		Collections.sort(keys);
		for (String key : keys) {
			if (key.startsWith("java.") || key.startsWith("sun.")
					|| key.startsWith("surefire.") || key.startsWith("file.")
					|| key.startsWith("line.") || key.startsWith("os.")
					|| key.startsWith("user.") || key.startsWith("awt.")
					|| key.startsWith("path.")) {
				continue;
			}
			System.out.println(key + "=" + p.getProperty(key));
		}
		System.out.println("---------------------------------------------------------");
		System.out.println();
		System.out.println(benchmark.printResult(TimeUnit.MILLISECONDS));
	}

	private static class TestMessageObject extends StringMessageObject {
		final long created;
		public TestMessageObject(String message, String messageId, long created) {
			super(message, messageId);
			this.created = created;
		}
	}
}
