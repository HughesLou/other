package com.scb.fmsd.adapter.core.processor.impl;

import com.scb.fmsd.adapter.core.processor.Processor;
import com.scb.fmsd.adapter.core.processor.impl.OrderedParallelProcessor_CustomPool;

public class TestOrderedParallelProcessor_CustomPool extends ParallelProcessorTestBase {

	@Override
	public void setUp(Processor processor) throws Exception {
		initialize(new OrderedParallelProcessor_CustomPool(processor, 2, 2));
	}

}
