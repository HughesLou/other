package com.scb.fmsd.adapter.core.channel.mail.sb;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.scb.fmsd.adapter.core.Application;
import com.scb.fmsd.adapter.core.channel.mail.builder.PatternSubjectBuilder;
import com.scb.fmsd.adapter.core.event.EventMessage;
import com.scb.fmsd.adapter.core.utils.NetUtils;

public class TestPatternSubjectBuilder {

	@Test
	public void testIt() throws Exception {
		System.setProperty(Application.APP_NAME, "TEST");

		PatternSubjectBuilder builder = new PatternSubjectBuilder("%event [%app/%host] - %msg").compile();

		EventMessage mo = EventMessage.info("Test event message\nbody");
		mo.setError(new Exception());

		String result = builder.build(mo);
		String expected = "INFO [TEST/" + NetUtils.getHostname() + "] - Test event message";
		assertEquals(expected, result);
	}

}
