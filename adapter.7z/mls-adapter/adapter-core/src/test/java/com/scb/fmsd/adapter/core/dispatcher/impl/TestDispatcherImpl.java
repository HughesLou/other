package com.scb.fmsd.adapter.core.dispatcher.impl;

import java.util.Iterator;
import java.util.concurrent.atomic.AtomicBoolean;

import org.junit.Test;

import com.scb.fmsd.adapter.core.dispatcher.Dispatcher;
import com.scb.fmsd.adapter.core.event.EventManagerImpl;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.model.StringMessageObject;
import com.scb.fmsd.adapter.core.processor.Processor;
import com.scb.fmsd.adapter.core.processor.impl.NoopProcessor;
import com.scb.fmsd.adapter.core.processor.impl.OrderedParallelProcessor;
import com.scb.fmsd.adapter.core.recovery.imp.InMemoryRecoveryManager;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

public class TestDispatcherImpl extends TestRouterImpl {

    private DispatcherImpl dispatcher;


	@Test
	public void testSyncRoute() {
	}

	@Override
	protected Dispatcher createDispatcher() {
        return dispatcher == null ? new DispatcherImpl("DISP", eventManager) : dispatcher;
	}

	@Override
	protected Processor createProcessor(Processor processor) {
		OrderedParallelProcessor pp = new OrderedParallelProcessor(processor, 2, 2);
		pp.initialize();
		return pp;
	}

	@Test @Override
	public void testErrorInProcessor() throws Exception {
		super.testErrorInProcessor();

		Iterator<MessageObject> it = processed.iterator();
		for (int i = 0; i < processed.size(); i++) {
			if (i % 2 == 0) {
				assertEquals(i + "", it.next().getMessageId());
			}
		}
	}

	@Test @Override
	public void testErrorInSender() throws Exception {
		super.testErrorInSender();

		Iterator<MessageObject> it = processed.iterator();
		for (int i = 0; i < processed.size(); i++) {
			if (i % 2 == 0) {
				assertEquals(i + "", it.next().getMessageId());
			}
		}
	}

	@Test
	public void testTransacted() throws Exception {
		transactionManager = new InMemoryRecoveryManager();
		send(10, null, new NoopProcessor() {
			@Override
			public MessageObject process(MessageObject message) throws Exception {
				assertTrue("transacted", transactionManager.isTransacted(message));
				return super.process(message);
			}
		}, true, 10, 0);
		//wait for the transaction to be committed.
		Thread.sleep(300);
		assertFalse("Should not be unprocessed transactions", transactionManager.unprocessed().hasNext());
	}

	@Test
	public void testRecovery() throws Exception {
		transactionManager = new InMemoryRecoveryManager();
		transactionManager.startTransaction(new StringMessageObject("TO_RECOVERY", "RECOVERY-1"));
		assertTrue("Should be unprocessed transaction", transactionManager.unprocessed().hasNext());

		send(1, null, new NoopProcessor(), false, 2, 0);
	}

    @Test
    public void shouldSetCustomMDCFields() throws Exception {
        final AtomicBoolean methodCalled = new AtomicBoolean(false);
        dispatcher = new DispatcherImpl("DISP", new EventManagerImpl()) {
            @Override
            protected void addCustomMDCFields(MessageObject message) {
                methodCalled.set(true);
            }
        };
        send(1, null, new NoopProcessor(), false, 1, 0);
        assertThat("Method called", methodCalled.get(), is(true));
    }
}
