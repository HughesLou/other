package com.scb.fmsd.adapter.core.processor.impl;

import java.util.Map;
import java.util.Properties;
import java.util.Set;

import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.processor.CorrelationKey;
import com.scb.fmsd.adapter.core.processor.Processor;
import com.scb.fmsd.adapter.core.processor.impl.HashBasedParallelProcessor;

public class TestHashBasedParallelProcessor extends ParallelProcessorTestBase {

	@Override
	public void setUp(Processor processor) throws Exception {
		CorrelationKey serializer = new CorrelationKey() {
			@Override
			public Set<Object> getKeys(MessageObject message) {
				return null;
			}
			
			@Override
			public Object getKey(MessageObject message) {
				return message.getPayload();
			}

			@Override
			public Properties getProperties(MessageObject message) {
				return null;
			}
		};
		
		initialize(new HashBasedParallelProcessor(processor, 2, 2, serializer));
	}
	
}
