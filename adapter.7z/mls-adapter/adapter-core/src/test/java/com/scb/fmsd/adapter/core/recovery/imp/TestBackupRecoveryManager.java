package com.scb.fmsd.adapter.core.recovery.imp;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.model.StringMessageObject;
import com.scb.fmsd.adapter.core.recovery.RecoveryException;
import com.scb.fmsd.adapter.core.recovery.impl.BackupRecoveryManager;
import com.scb.fmsd.adapter.core.utils.FileUtils;

public class TestBackupRecoveryManager {

    private BackupRecoveryManager tm;
    private Path location;
    private Path backupLocation;

    @Before
    public void beforeTest() throws IOException {
        location = Files.createTempDirectory("TestBackupRecoveryManager");
        backupLocation = Files.createTempDirectory("TestBackupReoveryManagerBackupFolder");

    }

    @After
    public void afterTest() throws IOException {
        if (tm != null)
            tm.clean();
    }

    @Test
    public void testWhenRollbackMoveToBackupLocation() throws RecoveryException, IOException {
        MessageObject mo = new StringMessageObject("TEST-UNCOMMITTED-TRX", "1");
        tm = new BackupRecoveryManager(location, backupLocation, false);
        tm.startTransaction(mo);
        tm.rollback(mo);
        Path backupMessage = Paths.get(backupLocation.toString(), FileUtils.reformFileName("1"));
        if (!Files.exists(backupMessage)) {
            fail("backup file not exsit");
        } else {
            assertEquals("TEST-UNCOMMITTED-TRX", new String(Files.readAllBytes(backupMessage)));
        }

    }

    @Test
    public void testWhenRollbackDeleteOriginalMessage() throws RecoveryException, IOException {
        MessageObject mo = new StringMessageObject("TEST-UNCOMMITTED-TRX", "1");
        tm = new BackupRecoveryManager(location, backupLocation, true);
        tm.startTransaction(mo);

        tm.rollback(mo);

        Path originalMessage = Paths.get(location.toString(), FileUtils.reformFileName("1"));
        if (Files.exists(originalMessage)) {
            fail("original message should be deleted ");
        }

    }
}
