package com.scb.fmsd.adapter.core.dispatcher.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import org.junit.Test;

import com.scb.fmsd.adapter.core.channel.AbstractOutChannel;
import com.scb.fmsd.adapter.core.channel.InChannel;
import com.scb.fmsd.adapter.core.channel.direct.DirectChannel;
import com.scb.fmsd.adapter.core.channel.direct.QueueChannel;
import com.scb.fmsd.adapter.core.dispatcher.Dispatcher;
import com.scb.fmsd.adapter.core.dispatcher.Route;
import com.scb.fmsd.adapter.core.dispatcher.filters.Filter;
import com.scb.fmsd.adapter.core.dispatcher.impl.RouterImpl;
import com.scb.fmsd.adapter.core.event.EventManagerImpl;
import com.scb.fmsd.adapter.core.model.BatchMesageObject;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.model.StringMessageObject;
import com.scb.fmsd.adapter.core.processor.Processor;
import com.scb.fmsd.adapter.core.processor.impl.NoopProcessor;
import com.scb.fmsd.adapter.core.recovery.Recoverable;
import com.scb.fmsd.adapter.core.recovery.RecoveryManager;

public class TestRouterImpl {

	protected DirectChannel from = new DirectChannel();

	protected CountDownLatch latch;

	protected List<MessageObject> processed = new ArrayList<>();

	protected EventManagerImpl eventManager;

	protected final static Processor NULL_PROCESSOR = new NoopProcessor();

	protected RecoveryManager<MessageObject> transactionManager;

	protected Dispatcher createDispatcher() {
		return new RouterImpl("ROUTER", eventManager);
	}

	protected Processor createProcessor(Processor processor) {
		return processor;
	}

	@SuppressWarnings("unchecked")
	protected void send(int size, Filter condition, Processor processor,
			boolean batch, int success, int failures) throws Exception {
		latch = new CountDownLatch(success + failures);

		QueueChannel errors = new QueueChannel() {
			@Override
			public void send(MessageObject message) throws Exception {
				super.send(message);
				latch.countDown();
			};
		};

		eventManager = new EventManagerImpl();
		eventManager.initialize();

		Dispatcher router = createDispatcher();
		router.setProcessor(createProcessor(processor));
		if (router instanceof Recoverable<?>) {
			((Recoverable<MessageObject>)router).setRecoveryManager(transactionManager);
		}
		router.setFromChannels(Collections.<InChannel<?>>singletonList(from));

		Route simple = new Route(new AbstractOutChannel<String>("TEST") {
			@Override
			public void send(MessageObject message) throws Exception {
				if (message.getProperty("FAIL_TO_SEND") != null) {
					throw new Exception("FAIL_TO_SEND");
				}
				processed.add(message);
				latch.countDown();
			}
		}, condition);
		router.setToChannels(Collections.singletonList(simple));
		router.setErrorChannels(Collections.singletonList(errors));
		router.start();

		if (batch) {
			List<MessageObject> list = new ArrayList<>(size);
			for (int i = 0; i < size; i++) {
				list.add(new StringMessageObject("TEST MESSAGE #" + i, "" + i));
			}
			from.onMessage(new BatchMesageObject(list, "BATCH-1"));
		} else {
			for (int i = 0; i < size; i++) {
				from.onMessage(new StringMessageObject("TEST MESSAGE #" + i, "" + i));
			}
		}

		assertTrue("timeout", latch.await(20, TimeUnit.SECONDS));
		assertEquals("errors", failures, errors.size());
		assertEquals("processed", success, processed.size());
	}

	@Test
	public void testSimpleRoute() throws Exception {
		send(10, null, NULL_PROCESSOR, false, 10, 0);
	}

	@Test
	public void testConditionalRouting() throws Exception {
		send(10, new Filter() {
			@Override
			public boolean accept(MessageObject mo) {
				return Integer.valueOf(mo.getMessageId()) % 2 == 0;
			}
		}, NULL_PROCESSOR, false, 5, 5);
	}

	@Test
	public void testRouteWithProcessor() throws Exception {
		send(10, null, new NoopProcessor() {
			@Override
			public MessageObject process(MessageObject message) {
				message.addProperty("PROPERTY1", System.currentTimeMillis());
				return message;
			}
		}, false, 10, 0);

		for(MessageObject mo : processed) {
			assertNotNull(mo.getProperty("PROPERTY1"));
			assertNull(mo.getProperty("PROPERTY2"));
		}
	}

	@Test
	public void testEnsureSequence() throws Exception {
		send(10, null, NULL_PROCESSOR, false, 10, 0);

		for (int i = 0; i < processed.size(); i++) {
			assertEquals(i + "", processed.get(i).getMessageId());
		}
	}

	@Test
	public void testBatch() throws Exception {
		send(10, null, NULL_PROCESSOR, true, 10, 0);
	}

	@Test
	public void testEnsureSequenceBatch() throws Exception {
		send(10, null, new NoopProcessor() {
			@Override
			public MessageObject process(MessageObject message) {
				try { Thread.sleep(100); } catch (InterruptedException e) {}
				message.addProperty("THREAD", Thread.currentThread().getName());
				return message;
			}
		}, true, 10, 0);

		Set<Object> threads = new HashSet<>();
		for(MessageObject mo : processed) {
			threads.add(mo.getProperty("THREAD"));
		}

		assertNotSame("> 1 thread", 1, threads.size());

		for (int i = 0; i < processed.size(); i++) {
			assertEquals(i + "", processed.get(i).getMessageId());
		}
	}

	@Test(expected=Exception.class)
	public void testErrorInProcessor() throws Exception {
		send(10, null, new NoopProcessor() {
			@Override
			public MessageObject process(MessageObject message) throws Exception {
				boolean odd = Integer.valueOf(message.getMessageId()) % 2 != 0;
				if (odd) {
					throw new Exception("Don't like odd");
				}
				return message;
			}
		}, false, 5, 5);

		Iterator<MessageObject> it = processed.iterator();
		for (int i = 0; i < processed.size(); i++) {
			if (i % 2 == 0) {
				assertEquals(i + "", it.next().getMessageId());
			}
		}
	}

	@Test(expected=Exception.class)
	public void testErrorInSender() throws Exception {
		send(10, null, new NoopProcessor() {
			@Override
			public MessageObject process(MessageObject message) throws Exception {
				boolean odd = Integer.valueOf(message.getMessageId()) % 2 != 0;
				if (odd) {
					message.addProperty("FAIL_TO_SEND", true);
				}
				return message;
			}
		}, false, 5, 5);

		Iterator<MessageObject> it = processed.iterator();
		for (int i = 0; i < processed.size(); i++) {
			if (i % 2 == 0) {
				assertEquals(i + "", it.next().getMessageId());
			}
		}
	}

}
