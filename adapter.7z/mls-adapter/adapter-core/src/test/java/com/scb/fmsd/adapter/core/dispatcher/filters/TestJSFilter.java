package com.scb.fmsd.adapter.core.dispatcher.filters;

import static org.junit.Assert.*;

import javax.script.ScriptException;

import org.junit.Test;

import com.scb.fmsd.adapter.core.dispatcher.filters.JSFilter;
import com.scb.fmsd.adapter.core.model.StringMessageObject;

public class TestJSFilter {

	@Test
	public void testCondition() throws ScriptException {
		JSFilter f = new JSFilter("COMPRESSION==true");
		assertTrue(f.accept(make("COMPRESSION", true)));
		assertFalse(f.accept(make("COMPRESSION", false)));
		assertFalse(f.accept(make("PROPERTY", "VALUE")));
	}
	
	private static StringMessageObject make(String name, Object value) {
		StringMessageObject mo = new StringMessageObject();
		mo.addProperty(name, value);
		return mo;
	}
	
}
