package com.scb.fmsd.adapter.core.processor.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

import org.junit.After;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.model.StringMessageObject;
import com.scb.fmsd.adapter.core.processor.CompletionCallback;
import com.scb.fmsd.adapter.core.processor.CompletionCallbackAdapter;
import com.scb.fmsd.adapter.core.processor.ParallelProcessor;
import com.scb.fmsd.adapter.core.processor.Processor;
import com.scb.sabre.common.test.benchmark.Benchmark;

public abstract class ParallelProcessorTestBase {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	private ParallelProcessor processor;

	@After
	public void tearDown() throws Exception {
		if (processor != null) {
			processor.shutdown();
		}
	}

	protected abstract void setUp(Processor processor) throws Exception;

	protected void initialize(ParallelProcessor processor) throws Exception {
		this.processor = processor;
		this.processor.initialize();
	}

	@Test
	public void testUnprocessedOnShutdown() throws Exception {
		MessageObject[] messages = {
				new StringMessageObject("TEST-1", "1"),
				new StringMessageObject("TEST-1", "1,2"),
				new StringMessageObject("TEST-2", "3"),
				new StringMessageObject("TEST-2", "3,4"),
				new StringMessageObject("TEST-2", "4,5"),
				new StringMessageObject("TEST-3", "6"),
		};

		final CountDownLatch shutdown = new CountDownLatch(1);

		final Queue<MessageObject> list = new ArrayBlockingQueue<>(messages.length);
		final Queue<MessageObject> failed = new ArrayBlockingQueue<>(messages.length);

		setUp(new NoopProcessor() {
			@Override
			public MessageObject process(MessageObject message) throws Exception {
				shutdown.countDown();
				try { Thread.sleep(new Random().nextInt(100)); } catch (Exception ignore) {}
				return message;
			}
		});

		CompletionCallback callback = new CompletionCallbackAdapter() {
			@Override
			public void completed(MessageObject result, MessageObject original) {
				list.add(original);
				logger.debug("onReady: {}", original.getMessageId());
			}
			@Override
			public void failed(Throwable t, MessageObject message) {
				logger.debug("onError: {}, cause: {}", message.getMessageId(), t.getMessage());
				failed.add(message);
			}
		};

		for (MessageObject mo : messages) {
			processor.process(mo, callback);
		}

		assertTrue("timeout", shutdown.await(2, TimeUnit.SECONDS));

		List<MessageObject> unprocessed = processor.shutdownNow();
		assertNotNull(unprocessed);

		logger.info("Processed: {}", list);
		logger.info("Failed: {}", failed);
		logger.info("Unprocessed: {}", unprocessed);

		assertEquals("messages!=processed+unprocessed", messages.length, list.size() + failed.size() + unprocessed.size());
	}

	@Test
	public void testSerialization() throws Exception {
		MessageObject[] messages = {
				new StringMessageObject("TEST-1", "1"),
				new StringMessageObject("TEST-1", "1,2"),
				new StringMessageObject("TEST-1", "2,3")
		};

		final CountDownLatch latch = new CountDownLatch(messages.length);
		final List<MessageObject> processed = new ArrayList<>();

		setUp(new NoopProcessor() {
			@Override
			public MessageObject process(MessageObject message) throws Exception {
				Thread.yield();
//				Thread.sleep(new Random().nextInt(10));
				return message;
			}
		});

		CompletionCallback callback = new CompletionCallbackAdapter() {
			@Override
			public void completed(MessageObject result, MessageObject message) {
				synchronized (processed) {
					processed.add(message);
				}
				latch.countDown();
			}
			@Override
			public void failed(Throwable t, MessageObject message) {
				latch.countDown();
			}
		};

		for (MessageObject mo : messages) {
			processor.process(mo, callback);
		}

		assertTrue(latch.await(1, TimeUnit.SECONDS));
		assertCorrectSequence(processed, Arrays.asList(messages));
	}

	@Test
	public void testParallelization() throws Exception {
		MessageObject[] messages = {
				new StringMessageObject("TEST-1", "1"),
				new StringMessageObject("TEST-1", "1,2"),
				new StringMessageObject("TEST-2", "3"),
				new StringMessageObject("TEST-2", "3,4"),
				new StringMessageObject("TEST-2", "4,5"),
				new StringMessageObject("TEST-3", "6"),
		};

		final CountDownLatch latch = new CountDownLatch(messages.length);

		final List<MessageObject> list = new ArrayList<>();
		final Map<String, List<MessageObject>> map = new HashMap<>();

		setUp(new NoopProcessor() {
			@Override
			public MessageObject process(MessageObject message) throws Exception {
				if (message.getMessageId().equals("1")) {
					Thread.sleep(10);
				} else {
					Thread.yield();
//					Thread.sleep(new Random().nextInt(100));
				}
				message.addProperty("THREAD", Thread.currentThread().getName());
				return message;
			}
		});

		CompletionCallback callback = new CompletionCallbackAdapter() {
			@Override
			public void completed(MessageObject result, MessageObject message) {
				synchronized (list) {
					list.add(message);
					List<MessageObject> list = map.get(message.getText());
					if (list == null) {
						list = new ArrayList<>();
						map.put(message.getText(), list);
					}
					list.add(message);
				}
				latch.countDown();
			}
			@Override
			public void failed(Throwable t, MessageObject message) {
				latch.countDown();
			}
		};

		for (MessageObject mo : messages) {
			processor.process(mo, callback);
		}

		assertTrue("timeout", latch.await(2, TimeUnit.SECONDS));

		Set<Object> threads = new HashSet<>();
		for (MessageObject m : list) {
			threads.add(m.getProperty("THREAD"));
		}
		assertTrue(">1 thread", threads.size() > 1);

		assertCorrectSequence(map.get("TEST-1"), Arrays.asList(messages).subList(0, 2));
		assertCorrectSequence(map.get("TEST-2"), Arrays.asList(messages).subList(2, 5));
		assertCorrectSequence(map.get("TEST-3"), Arrays.asList(messages).subList(5,6));
	}

	private Benchmark benchmark;

	@Test
	public void benchmark() throws Exception {
		int warmup = 100000;
		int repeat = 10000;

		final AtomicInteger errors = new AtomicInteger(0);

		final AtomicReference<CountDownLatch> done = new AtomicReference<>();

		setUp(new NoopProcessor() {
			@Override
			public MessageObject process(MessageObject message) throws Exception {
				return message;
			}
		});

		class TestCallback extends CompletionCallbackAdapter {
			@Override
			public void completed(MessageObject result, MessageObject original) {
				TestMessageObject tmo = (TestMessageObject) original;
				benchmark.collect(System.nanoTime() - tmo.created);
				done.get().countDown();
			}

			@Override
			public void failed(Throwable t, MessageObject message) {
				logger.error(t.getMessage(), t);
				errors.incrementAndGet();
				done.get().countDown();
			}
		};

		final TestCallback callback = new TestCallback();

		benchmark = new Benchmark(warmup, repeat) {
			@Override
			protected Object doTest(int repeat) throws Exception {
				done.set(new CountDownLatch(repeat));
				for (int i = 0; i < repeat; i++) {
					String message = "TEST-" + i;
					final TestMessageObject mo = new TestMessageObject(message, message, System.nanoTime());

					processor.process(mo, callback);
				}

				assertTrue("timeout", done.get().await(10, TimeUnit.SECONDS));

				return null;
			}
		};

		benchmark.test();

		assertEquals("there are errors", 0, errors.get());

		logger.info("\n{}", benchmark.printResult(TimeUnit.NANOSECONDS));
	}

	public void assertCorrectSequence(List<MessageObject> processed, List<MessageObject> seq) {
		List<MessageObject> sequence = new ArrayList<>(seq);
		for (MessageObject m : processed) {
			MessageObject expected = sequence.get(0);
			if (expected == m) {
				sequence.remove(0);
			}
		}

		assertEquals(0, sequence.size());
	}

	private static class TestMessageObject extends StringMessageObject {
		final long created;
		public TestMessageObject(String message, String messageId, long created) {
			super(message, messageId);
			this.created = created;
		}
	}

}
