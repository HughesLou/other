package com.scb.fmsd.adapter.core.recovery.imp;

import static org.junit.Assert.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.scb.fmsd.adapter.core.model.BatchMesageObject;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.model.StringMessageObject;
import com.scb.fmsd.adapter.core.recovery.RecoveryException;
import com.scb.fmsd.adapter.core.recovery.impl.FSRecoveryManager;

public class TestFSRecoveryManager {

	private FSRecoveryManager tm;
	private Path location;

	@Before
	public void beforeTest() throws IOException {
		location = Files.createTempDirectory("TestFSTransactionManager");
		tm = new FSRecoveryManager(location);
	}
	
	@After
	public void afterTest() throws IOException {
		tm.clean();
	}
	
	@Test
	public void testSuccess() throws RecoveryException {
		MessageObject mo = new StringMessageObject("TEST-SUCCESS", "1");
		tm.startTransaction(mo);
		tm.commit(mo);
	}
	
	@Test()
	public void testStartTransactionFailure() {
		MessageObject mo = new StringMessageObject("TEST-START_TRUNSACTION-FAILURE", "2");
		try {
			tm.startTransaction(mo);
		} catch (RecoveryException e) {
			fail(e.getMessage());
		}
		try {
			tm.startTransaction(mo);
			fail("Duplicate transaction for the same message");
		} catch (RecoveryException e) {
			assertTrue(true);
		}
	}
	
	@Test
	public void testCommitFailure() {
		MessageObject mo = new StringMessageObject("TEST-START_TRUNSACTION-FAILURE", "2");
		try {
			tm.commit(mo);
			fail("No transaction for the message");
		} catch (RecoveryException e) {
			assertTrue(true);
		}
	}

	@Test
	public void testLoadUncommittedTransactions() throws RecoveryException {
		MessageObject mo1 = new StringMessageObject("TEST-UNCOMMITTED-TRX", "1");
		MessageObject mo2 = new StringMessageObject("TEST-UNCOMMITTED-TRX", "2");
		
		try {
			tm.startTransaction(mo1);
			tm.startTransaction(mo2);
		} catch (RecoveryException e) {
			fail(e.getMessage());
		}
		
		List<MessageObject> unprocessed = new ArrayList<>(2);
		
		Iterator<MessageObject> it = tm.unprocessed();
		while(it.hasNext()) {
			unprocessed.add(it.next());
		}
		assertEquals(2, unprocessed.size());
		
		Set<String> ids = new HashSet<>();
		for (MessageObject mo : unprocessed) {
			assertEquals(StringMessageObject.class, mo.getClass());
			assertEquals("TEST-UNCOMMITTED-TRX", mo.getText());
			ids.add(mo.getMessageId());
		}
		assertEquals(2, ids.size());
	}
	
	@Test
	public void testBatchMessage() throws RecoveryException {
		List<MessageObject> list = new ArrayList<>();
		list.add(new StringMessageObject("S1", "1"));
		list.add(new StringMessageObject("S2", "2"));
		
		BatchMesageObject batch = new BatchMesageObject(list, "B-1");
		
		tm.startTransaction(batch);
		
		for (MessageObject mo : list) {
			tm.commit(mo);
		}
		
		tm.commit(batch);
		
		assertFalse("all is done", tm.unprocessed().hasNext());
	}

	@Test
	public void testIsTransacted() throws RecoveryException {
		MessageObject m1 = new StringMessageObject("S1", "1");
		MessageObject m2 = new StringMessageObject("S2", "2");		

		assertFalse(tm.isTransacted(m1));
		assertFalse(tm.isTransacted(m2));
		try {
			tm.startTransaction(m1);
			assertTrue(tm.isTransacted(m1));
			assertFalse(tm.isTransacted(m2));
		} finally {
			tm.rollback(m1);
		}

		assertFalse(tm.isTransacted(m1));
		assertFalse(tm.isTransacted(m2));
	}
}
