package com.scb.fmsd.adapter.core.channel.jms;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;

import org.apache.activemq.broker.BrokerService;
import org.apache.activemq.broker.TransportConnection;
import org.apache.activemq.broker.TransportConnector;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.fmsd.common.config.Configuration;
import com.scb.fmsd.common.config.ConfigurationBuilder;

public class JmsTestBase {

    protected final static Configuration config = ConfigurationBuilder.create().build();

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	static BrokerService broker;

	private static String bindAddress;

	static {
		try {
			ServerSocket ss = new ServerSocket();
			ss.bind(new InetSocketAddress(0));
			bindAddress = "tcp://localhost:" + ss.getLocalPort();
			ss.close();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}

		config.setProperty("jndi.java.naming.factory.initial", "org.apache.activemq.jndi.ActiveMQInitialContextFactory");
		config.setProperty("jndi.java.naming.provider.url", bindAddress);
		config.setProperty("connectionFactory", "ConnectionFactory");
		config.setProperty("jndi.queue.MUREX", "MUREX");
		config.setProperty("destinationName", "MUREX");
		config.setProperty("transacted", Boolean.FALSE);
		config.setProperty("retryAttempts", 1);
		config.setProperty("retryWaitTime", "100 ms");
	}

	@BeforeClass
	public static void startBroker() {
		broker = new BrokerService();
		broker.setBrokerName("localhost");
		broker.setPersistent(false);
		broker.setUseJmx(false);
		try {
			broker.addConnector(bindAddress);
			broker.start();
		} catch (Exception e) {
			throw new AssertionError(e);
		}
		broker.waitUntilStarted();
	}

	@AfterClass
	public static void stopBroker() {
		try { broker.stop(); } catch (Exception ignore) { }
	}

	void killConnection() throws Exception {
		TransportConnector c = broker.getTransportConnectors().get(0);
		for (TransportConnection tc : c.getConnections()) {
			tc.stop();
		}
		logger.info("Connection killed");
	}

}
