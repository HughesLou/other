package com.scb.fmsd.adapter.core.recovery;

import java.util.List;

import com.scb.fmsd.adapter.core.model.MessageObject;

public interface FaultTolerable<T> {
	public void setFaultToleranceManager(FaultToleranceManager<T> tm);

	public FaultToleranceManager<MessageObject> getFaultToleranceManager();

	public void retryFailureMessages(List<String> list) throws Exception;
}
