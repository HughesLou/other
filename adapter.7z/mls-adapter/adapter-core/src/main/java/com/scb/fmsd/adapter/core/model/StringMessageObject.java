package com.scb.fmsd.adapter.core.model;

import com.google.common.base.Charsets;

import java.io.DataInputStream;
import java.io.DataOutputStream;

public class StringMessageObject extends AbstractMessageObject<String> {

	private byte[] bytes;

	public StringMessageObject() {
	}

	public StringMessageObject(String message) {
		super(message, "MSG-" + System.currentTimeMillis());
	}

	public StringMessageObject(String message, String messageId) {
		super(message, messageId);
	}

	@Override
	public String getText() {
		return getPayload();
	}

	@Override
	public byte[] getBytes() {
		if (bytes == null) {
			String payload = getPayload();
			bytes = payload != null ? payload.getBytes() : new byte[0];
		}
		return bytes;
	}

    @Override
    public boolean isBatchMessage() {
        return false;
    }

    @Override
	public void serialize(DataOutputStream out) throws Exception {
		super.serialize(out);
		byte[] buffer = getPayload().getBytes(Charsets.UTF_8);
		out.writeInt(buffer.length);
		out.write(buffer);
	}

	@Override
	public MessageObject deserialize(DataInputStream in) throws Exception {
		super.deserialize(in);
		int length = in.readInt();
		byte[] buffer = new byte[length];
		in.read(buffer);
		this.bytes = buffer;
		setPayload(new String(buffer, Charsets.UTF_8));
		return this;
	}
	
	public int hashCode(){
		int code =  getPayload().hashCode()+getMessageId().hashCode()*31;
		return code;
	}
	
	public boolean equals(Object obj){
		if (!(obj instanceof StringMessageObject)) return false;
		StringMessageObject inst  = (StringMessageObject)obj;
		if (!getMessageId().equals(inst.getMessageId())) return false;
		if (getPayload() == inst.getPayload()) return true;
		if (getPayload()==null) return false;
		if (!getPayload().equals(inst.getPayload())) return false;
		return true;
	}

}
