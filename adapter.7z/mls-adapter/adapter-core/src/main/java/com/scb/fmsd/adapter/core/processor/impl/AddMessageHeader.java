package com.scb.fmsd.adapter.core.processor.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.processor.Processor;
import com.scb.fmsd.common.jmx.JMXBeanAttribute;

public abstract class AddMessageHeader implements Processor {

	private static final Logger logger = LoggerFactory.getLogger(AddMessageHeader.class);

	private final String header;

	public AddMessageHeader(String header) {
		this.header = header;
	}

	@Override
	public MessageObject process(MessageObject message) throws Exception {
		Object value = getHeaderValue(message);
		message.addProperty(header, value);
		if (logger.isDebugEnabled()) {
			logger.debug("Property {}={} added to message {}", header, value, message.getMessageId());
		}
		return message;
	}

	@JMXBeanAttribute
	public String getHeader() {
		return header;
	}

	protected abstract Object getHeaderValue(MessageObject message) throws Exception;

	@Override
	public void shutdown() throws Exception {
	}
}
