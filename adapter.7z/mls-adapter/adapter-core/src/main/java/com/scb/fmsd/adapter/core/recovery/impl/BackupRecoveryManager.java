package com.scb.fmsd.adapter.core.recovery.impl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.fmsd.adapter.core.model.BatchMesageObject;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.recovery.RecoveryException;
import com.scb.fmsd.adapter.core.utils.FileUtils;
import com.scb.fmsd.common.config.Configuration;
import com.scb.fmsd.common.jmx.JMXBeanAttribute;

public class BackupRecoveryManager extends FSRecoveryManager {

    private static final Logger logger = LoggerFactory.getLogger(BackupRecoveryManager.class);
    private final Path backupLocation;
    private final boolean deleteMessage;

    public BackupRecoveryManager(Path location, Path backupLocation, boolean deleteMessage) throws IOException {

        super(location);
        this.backupLocation = Files.createDirectories(backupLocation);
        this.deleteMessage = deleteMessage;

    }

    @JMXBeanAttribute
    public Path getBackupLocation() {
        return backupLocation;
    }

    @Override
    public void rollback(MessageObject t) throws RecoveryException {
        if (t instanceof BatchMesageObject) {
            return;
        }
        Path path = getPath(t);
        try {
            Files.write(backupLocation.resolve(path.getFileName()), t.getBytes());
            if (deleteMessage) {
            	FileUtils.deletePath(path);
            }
        } catch (Exception e) {
            throw new RecoveryException("Failed to rollback: messageId=" + t.getMessageId(), e);
        }
        logger.debug("Message {} rollbacked", t.getMessageId());
    }

    public void clean() throws IOException {
        super.clean();
        FileUtils.cleanPath(backupLocation);
    }

    public static BackupRecoveryManager create(String name, Configuration config) throws IOException {
        return new BackupRecoveryManager(Paths.get(config.getString("location")), Paths.get(config.getString("backupLocation")), config
                .getBoolean("deleteMessage", false));
    }

}
