package com.scb.fmsd.adapter.core.channel.converters;

import com.scb.fmsd.adapter.core.channel.MessageConverter;
import com.scb.fmsd.adapter.core.channel.OutChannel;
import com.scb.fmsd.adapter.core.channel.jms.JMSMessageConverter;
import com.scb.fmsd.adapter.core.channel.jms.JmsSender;
import com.scb.fmsd.adapter.core.channel.net.SerializableMessageConverter;
import com.scb.fmsd.adapter.core.channel.net.TCPSender;
import com.scb.fmsd.adapter.core.model.CompressedMessageObject;
import com.scb.fmsd.adapter.core.model.MessageObject;

import java.nio.ByteBuffer;

public class CompressedMessageConverter implements MessageConverter<Object> {

	private final static JMSMessageConverter JMS_CONVERTER = new JMSMessageConverter();
	private final static SerializableMessageConverter BB_CONVERTER = new SerializableMessageConverter();

	@Override
	public MessageObject convert(Object message) throws Exception {
		MessageObject mo = convert0(message);
		if (mo.hasProperty("COMPRESSED")) {
			mo = new CompressedMessageObject(mo);
		}
		return mo;
	}

	private MessageObject convert0(Object message) throws Exception {
		if (message instanceof javax.jms.Message) {
			return JMS_CONVERTER.convert((javax.jms.Message) message);
		} else if (message instanceof ByteBuffer) {
			return BB_CONVERTER.convert((ByteBuffer) message);
		}
		throw new RuntimeException("Unsopprted message type: " + message);
	}


	@Override
	public Object convert(MessageObject message, OutChannel<?> channel) throws Exception {
		if (channel instanceof JmsSender) {
			return JMS_CONVERTER.convert(message, channel);
		} else if (channel instanceof TCPSender) {
			return BB_CONVERTER.convert(message, channel);
		}
		throw new RuntimeException("Unsopprted channel type: " + channel);
	}
}
