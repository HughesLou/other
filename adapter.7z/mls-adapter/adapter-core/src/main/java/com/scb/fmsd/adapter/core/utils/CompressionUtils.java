package com.scb.fmsd.adapter.core.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import org.apache.commons.io.IOUtils;

//TODO: Try to use LZ4 to speed up
public abstract class CompressionUtils {
	private CompressionUtils() {}

	public static byte[] compress(byte[] src) throws IOException {
		if (isGZip(src)) return src;
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		GZIPOutputStream gzip = new GZIPOutputStream(baos);
		gzip.write(src);
		gzip.close();
		return baos.toByteArray();
	}
	
	public static byte[] decompress(byte[] src) throws IOException {
		if (!isGZip(src)) return src;
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		GZIPInputStream gzip = new GZIPInputStream(new ByteArrayInputStream(src));
		IOUtils.copy(gzip, baos);
		gzip.close();
		
		return baos.toByteArray();
	}
    public static boolean isGZip(byte[] inputs) {
        byte [] signature = new byte[2];
        signature[0] = inputs[0];
        signature[1] = inputs[1];
        if( signature[ 0 ] == (byte) 0x1f && signature[ 1 ] == (byte) 0x8b ) //check if matches standard gzip magic number
          return true;
        else 
          return false;
    }
}
