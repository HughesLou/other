package com.scb.fmsd.adapter.core.channel.filesystem;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributes;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.fmsd.adapter.core.channel.AbstractInChannel;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.model.StringMessageObject;
import com.scb.fmsd.common.config.Configuration;

public class FileListenerInChannel extends AbstractInChannel<MessageObject> {
	static Logger logger = LoggerFactory.getLogger(FileListenerInChannel.class);
	
	Path location;
	long waitpermsg;
	Path failureMsgDir;
	long listenerwait;
	boolean stop =false;
	Thread msgThread;

	public FileListenerInChannel(String name) {
		super(name);
	}
	
	public void doStart(){
		msgThread = new Thread(){
			public void run(){
				while (!stop) {
					try {
						sendMessages();
						sleep(listenerwait);
					} catch (InterruptedException e) {
						logger.info("FileSystem listener interrrupted, stop running.");
						break;
					}catch(IOException e){
						logger.error("IOException for fileVisitor.",e);
					}
				}
			}
		};
		msgThread.start();
	}
	
	void sendMessages() throws IOException {
		FileVisitor<Path> v=new MurexFileVisitor();
		Files.walkFileTree(location, v);
	}
	private void initialize(String location, String failureMsgDir, long listenerwait, long messagewait) {
		this.location = Paths.get(location);
		this.waitpermsg = messagewait;
		if (failureMsgDir!=null && failureMsgDir.trim().length()>0)
			this.failureMsgDir = Paths.get(failureMsgDir);
		this.listenerwait = listenerwait;
	}
	
	
	public static FileListenerInChannel create(String name, Configuration conf){
		String location = conf.getString("location");//location
		String failureMsgDir = conf.getString("failureMsgDir");
		long listenerwait = conf.getLong("folderListenerWait", 10000);
		long messagewait = conf.getLong("waitpermsg", 100);
		FileListenerInChannel inst = new FileListenerInChannel(name);
		inst.initialize(location,failureMsgDir,listenerwait,messagewait);
		try {
			inst.initialize();
		} catch (Exception e) {
		}
		return inst;
	}

	public void doStop(){
		this.stop=true;
		msgThread.interrupt();
	}
	class MurexFileVisitor extends SimpleFileVisitor<Path>{
		@Override
	    public FileVisitResult visitFile(Path fpath, BasicFileAttributes attr) {
	        if (attr.isSymbolicLink()) {
	        } else if (attr.isRegularFile()) {
	            logger.info("Vist regular file: "+fpath.toString());
	            if (fpath.getFileName().toString().endsWith("xml")){
	            	try {
	            		String msgstr = new String(Files.readAllBytes(fpath), StandardCharsets.ISO_8859_1);
	            		onMessage(new StringMessageObject(msgstr));
	            		Files.delete(fpath);
						Thread.sleep(waitpermsg);
					} catch (IOException fe) {
						logger.error("IOExcep when visiting "+fpath,fe);
						return FileVisitResult.TERMINATE;
					} catch (InterruptedException ie){
						logger.error("InterruptedException when sending msg for "+fpath, ie);
						return FileVisitResult.TERMINATE;
					} catch (Exception e){
						//move file to recovery folder, delete without configure
						if (failureMsgDir!=null){
							Path destfile = Paths.get(failureMsgDir.toString(),fpath.getFileName().toString()); 
							try {
								if (! Files.exists(destfile.getParent()))
									Files.createDirectories(destfile.getParent());
								Files.move(fpath, destfile, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
							} catch (IOException e1) {
								logger.error("cannot move msg file from "+fpath.toString()+" to "+destfile.toString());
							}
						}
						return FileVisitResult.CONTINUE;
					}
	            }
	        }
	        return FileVisitResult.CONTINUE;
	    }
	    
		@Override
	    public FileVisitResult postVisitDirectory(Path dir, IOException exc) {
	        //System.out.format("Directory: %s \n", dir);
	        return FileVisitResult.CONTINUE;
	    }
	    @Override
	    public FileVisitResult visitFileFailed(Path fpath, IOException exc) {
	        logger.error("Cannot visit file {} due to {}", fpath, exc.toString());
	        return FileVisitResult.CONTINUE;
	    }

	}
}
