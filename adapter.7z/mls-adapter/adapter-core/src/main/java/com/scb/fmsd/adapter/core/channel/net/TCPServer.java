package com.scb.fmsd.adapter.core.channel.net;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;

import com.scb.fmsd.common.config.Configuration;

/**
 * Simple TCPServer implementation. Uses ThreadPerConnection pattern.
 *
 */
public class TCPServer extends AbstractTCPServer {

	public TCPServer(String name, SocketAddress address) {
		super(name, address);
	}

	@Override
	protected IServer createServer(SocketAddress address) throws IOException {
		return new Server(address);
	}

	private class Server extends Thread implements IServer {

		private volatile boolean stopped = false;

		private final ServerSocketChannel channel;

		public Server(SocketAddress address) throws IOException {
			super("TCPListener");
			setDaemon(true);

			channel = ServerSocketChannel.open();
			channel.configureBlocking(true);
			channel.bind(address, 1);
			logger.info("{} started at {}", getName(), address);
		}

		@Override
		public void run() {
			while (!stopped) {
	        	try {
        			logger.info("Waiting for a connection");
	        		final SocketChannel sc = channel.accept();
        			logger.info("Accepted new connection {}", sc);

        			try {
        				while(!stopped) {
        					ByteBuffer header = ByteBuffer.allocate(Integer.SIZE / 8 + 1);
        					int read = sc.read(header);
        					if (read != -1) {
        						if (read != header.capacity()) {
        							throw new RuntimeException("Invalid package header expected "
        									+ header.capacity() + " but got "
        									+ read + " bytes");
        						}

        						header.flip();
        						boolean compressed = header.get() == TCPSender.COMPRESSED_FLAG;
        						ByteBuffer buffer = ByteBuffer.allocate(header.getInt());
        						while (read != -1 && buffer.hasRemaining()) {
        							read = sc.read(buffer);
        						}

        						if (read != -1) {
        							onMessage(buffer.array(), compressed, sc);
        						}
        					}

        					if (read == -1) {
        						closeChannel(sc);
        					}
        				}
        			} catch (IOException ioe) {
        				closeChannel(sc);
        			} catch (Exception e) {
        				logger.error("An exception occured", e);
        			}

        			try { sc.close(); } catch (IOException ignore) { }
        		} catch (Exception e) {
        			logger.error("An exception occured", e);
        		}
			}

			try {
				channel.close();
			} catch (IOException e) {
				logger.error("Failed to close channel", e);
			}
			logger.info("{} stopped", getName());
		}

		@Override
		public void shutdown() {
			this.stopped = true;
			try {
				if (channel != null) {
					channel.close();
				}
			} catch (IOException e) {
				logger.error(e.getMessage(), e);
			}
			super.interrupt();
		}
	}

	public static TCPServer create(String name, Configuration config) throws Exception {
		TCPServer channel = new TCPServer(name, new InetSocketAddress(
				config.getString("hostname", "localhost"),
				config.getInt("port")));
		return channel;
	}

}
