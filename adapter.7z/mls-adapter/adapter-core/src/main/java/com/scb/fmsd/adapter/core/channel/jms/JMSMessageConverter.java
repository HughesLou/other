package com.scb.fmsd.adapter.core.channel.jms;

import java.util.Collections;
import java.util.Enumeration;
import java.util.Map;

import javax.jms.BytesMessage;
import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.Session;
import javax.jms.StreamMessage;
import javax.jms.TextMessage;

import com.scb.fmsd.adapter.core.channel.MessageConverter;
import com.scb.fmsd.adapter.core.channel.OutChannel;
import com.scb.fmsd.adapter.core.model.BytesMessageObject;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.model.MessageObjectPropertyKey;
import com.scb.fmsd.adapter.core.model.StringMessageObject;

public class JMSMessageConverter implements MessageConverter<Message> {

    private final String outputDataFormat;

    public JMSMessageConverter() {
        this(null);
    }

    // provide a way to enforce message data format via configuration
    public JMSMessageConverter(String outputDataFormat) {
        this.outputDataFormat = outputDataFormat;
    }

    @Override
    public MessageObject convert(Message message) throws Exception {
        String messageId;
        if (message.propertyExists(MessageObjectPropertyKey.MESSAGE_ID.getKey())) {
            messageId = message.getObjectProperty(MessageObjectPropertyKey.MESSAGE_ID.getKey()).toString();
        } else {
            messageId = message.getJMSMessageID();
        }

        MessageObject mo;
        if (message instanceof TextMessage) {
            TextMessage tm = (TextMessage) message;
            mo = new StringMessageObject(tm.getText(), messageId);
        } else if (message instanceof BytesMessage) {
            BytesMessage bm = (BytesMessage) message;
            byte[] bytes = new byte[(int) bm.getBodyLength()];
            bm.readBytes(bytes);
            mo = new BytesMessageObject(bytes, messageId);
        } else {
            throw new RuntimeException("Unsupported JMS message " + message);
        }

        // Some JMS properties are predefined and read-only (e.g., JMSXDeliveryCount)
        // According to http://docs.oracle.com/javaee/6/api/javax/jms/Message.html
        // Any name beginning with 'JMSX' is a JMS defined property name.
        // Any name beginning with 'JMS_' is a provider-specific property name.
        // Any name that does not begin with 'JMS' is an application-specific property name.
        // For predefined properties, add a prefix "ORIG_" to carry the value over
        // to the new message
        @SuppressWarnings("unchecked")
        Enumeration<String> names = message.getPropertyNames();
        for (String name : Collections.list(names)) {
            if (name != null && name.startsWith("JMS")) {
                name = "ORIG_" + name;
            }
            mo.addProperty(name, message.getObjectProperty(name));
        }

        mo.setRefObject(message);

        return mo;
    }

    @Override
    public Message convert(MessageObject message, OutChannel<?> channel) throws Exception {
        JmsSender jms = (JmsSender) channel;
        Message msg;

        String tmp = outputDataFormat;

        if (outputDataFormat == null) {
            if (message instanceof StringMessageObject) {
                tmp = "TEXT";
            } else if (message instanceof BytesMessageObject) {
                tmp = "BINARY";
            }
        }

        if (message.getPayload() instanceof Message) {
            Message orig = (Message) message.getPayload();
            msg = clone(orig, jms.getSession());
            cloneHeaders(orig, msg);
        } else if ("TEXT".equals(tmp)) {
            msg = jms.getSession().createTextMessage(message.getText());
        } else if ("BINARY".equals(tmp)) {
            BytesMessage bm = jms.getSession().createBytesMessage();
            bm.writeBytes(message.getBytes());
            msg = bm;
        } else {
            throw new UnsupportedOperationException("How to handle " + message.getClass() + "?");
        }

        if (message.getRefObject() != null && message.getRefObject() instanceof Message) {
            cloneHeaders((Message) message.getRefObject(), msg);
        }

        Map<String, Object> props = message.getProperties();
        if (props != null) {
            for (Map.Entry<String, Object> e : props.entrySet()) {
                msg.setObjectProperty(e.getKey(), e.getValue());
            }
        }

        if (message.getError() != null) {
            msg.setStringProperty("ERROR", message.getError().getMessage());
        }

        msg.setStringProperty(MessageObjectPropertyKey.MESSAGE_ID.getKey(), message.getMessageId());

        if (message.getOriginal() != null) {
            msg.setStringProperty(MessageObjectPropertyKey.ORIGINAL_MESSAGE_ID.getKey(), message.getOriginal().getMessageId());
        }
        return msg;
    }

    private static Message clone(Message message, Session session) throws JMSException {
        if (message instanceof TextMessage) {
            return session.createTextMessage(((TextMessage) message).getText());
        } else if (message instanceof BytesMessage) {
            BytesMessage oldM = (BytesMessage) message;
            BytesMessage newM = session.createBytesMessage();
            byte[] bytes = new byte[1024];
            int len;
            while ((len = oldM.readBytes(bytes)) != -1) {
                newM.writeBytes(bytes, 0, len);
            }
            newM.writeBytes(bytes);
            return newM;
        } else if (message instanceof MapMessage) {
            MapMessage oldM = (MapMessage) message;
            MapMessage newM = session.createMapMessage();
            @SuppressWarnings("unchecked")
            Enumeration<String> names = oldM.getPropertyNames();
            while (names.hasMoreElements()) {
                String name = names.nextElement();
                newM.setObject(name, oldM.getObject(name));
            }
            return newM;
        } else if (message instanceof StreamMessage) {
            StreamMessage oldM = (StreamMessage) message;
            StreamMessage newM = session.createStreamMessage();
            byte[] bytes = new byte[1024];
            int len;
            while ((len = oldM.readBytes(bytes)) != -1) {
                newM.writeBytes(bytes, 0, len);
            }
            return newM;
        } else {
            return session.createObjectMessage(((ObjectMessage) message).getObject());
        }
    }

    private static void cloneHeaders(Message orig, Message msg) throws JMSException {
        msg.setJMSCorrelationID(orig.getJMSCorrelationID());
        msg.setJMSExpiration(orig.getJMSExpiration());
        msg.setJMSMessageID(orig.getJMSMessageID());
        msg.setJMSPriority(orig.getJMSPriority());
        msg.setJMSRedelivered(orig.getJMSRedelivered());
        msg.setJMSReplyTo(orig.getJMSReplyTo());
        msg.setJMSTimestamp(orig.getJMSTimestamp());
        msg.setJMSType(orig.getJMSType());
    }

}
