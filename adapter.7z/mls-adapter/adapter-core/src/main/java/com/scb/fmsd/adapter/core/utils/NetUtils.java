package com.scb.fmsd.adapter.core.utils;

import java.net.InetAddress;
import java.net.UnknownHostException;

public abstract class NetUtils {

	private NetUtils() { }

	public static String getHostname() {
		try {
			return InetAddress.getLocalHost().getCanonicalHostName();
		} catch (UnknownHostException e) {
			throw new AssertionError(e);
		}
	}

}
