package com.scb.fmsd.adapter.core;

import java.io.File;
import java.io.IOException;
import java.lang.Thread.UncaughtExceptionHandler;
import java.lang.management.ManagementFactory;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.management.MBeanServer;
import javax.management.ObjectName;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ch.qos.logback.classic.LoggerContext;

import com.scb.fmsd.adapter.core.channel.ChannelFactory;
import com.scb.fmsd.adapter.core.channel.InChannel;
import com.scb.fmsd.adapter.core.channel.OutChannel;
import com.scb.fmsd.adapter.core.dispatcher.Route;
import com.scb.fmsd.adapter.core.dispatcher.filters.JSFilter;
import com.scb.fmsd.adapter.core.event.EventManagerImpl;
import com.scb.fmsd.adapter.core.event.EventMessage;
import com.scb.fmsd.adapter.core.utils.NamedThreadFactory;
import com.scb.fmsd.common.config.Configuration;
import com.scb.fmsd.common.config.ConfigurationBuilder;
import com.scb.fmsd.common.ft.MembershipListenerAdapter;
import com.scb.fmsd.common.ft.MembershipMonitor;
import com.scb.fmsd.common.ft.MembershipState;
import com.scb.fmsd.common.ft.jgroups.FTMonitor;
import com.scb.fmsd.common.jmx.JMXBeanAttribute;
import com.scb.fmsd.common.jmx.JMXBeanOperation;
import com.scb.fmsd.common.jmx.JMXBeanWrapper;
import com.scb.fmsd.common.jmx.JMXMBean;

public abstract class Application extends MembershipListenerAdapter implements JMXMBean {

	public static final String JMX_ENABLED = "jmx.enabled";

    public static final String APP_NAME = "appName";

	static {
		String appName = System.getProperty(APP_NAME);
		if (appName == null) {
			String command = System.getProperty("sun.java.command");
			if (command != null) {
				System.setProperty(APP_NAME, command.substring(command.lastIndexOf('.') + 1));
			}
		}
	}

	private final Logger logger = LoggerFactory.getLogger(getClass());

	private Configuration config;

	private final String appName;

	private EventManagerImpl eventManager;

	public Application() {
        this.appName = setUpAppName();
        this.config = buildConfig();		
	}

    public Application(String appName, Configuration config) {
        this.appName = appName;
        this.config = config;
    }
	       
    private String setUpAppName() {
        String x = System.getProperty(APP_NAME);
		if (x == null) {
			System.setProperty(APP_NAME, getClass().getSimpleName());
		}
		return System.getProperty(APP_NAME);
    }

    private Configuration buildConfig() {
        String configFiles = System.getProperty("appProp", appName + ".properties");
        ConfigurationBuilder cbuilder = ConfigurationBuilder.create();
        for (String fileName : configFiles.split(",")) {
            try {
                cbuilder.add(new File(fileName), getClass().getClassLoader());
            } catch (IOException e) {
                logger.error(e.getMessage(), e);
            }
        }
        return cbuilder.addSystem().build();
    }
	

	public Configuration getConfig() {
		return config;
	}

	private final List<ShutdownAware> shutdownSeq = new ArrayList<ShutdownAware>();

	final public void start(String[] args) throws Exception {
		eventManager = new EventManagerImpl();
		eventManager.setChannels(buildOutChannels(config, "events"));
		eventManager.initialize();

		Thread.setDefaultUncaughtExceptionHandler(new UncaughtExceptionHandler() {
			@Override
			public void uncaughtException(Thread t, Throwable e) {
				eventManager.onEvent(EventMessage.error("Uncaught exception", e));
			}
		});

		Runtime.getRuntime().addShutdownHook(new Thread("ApplicationShutdownHook") {
			@Override
			public void run() {
				logger.info("Shutting down {}...", appName);
				shutdownAllTasks();
				shutdownEventManager();

				LoggerContext loggerContext = (LoggerContext) LoggerFactory.getILoggerFactory();
				loggerContext.stop();
			}
		});

		registerMBeans(this, "Application");

		logger.info("Starting {}", appName);
		try {
			initialize(config);
			registerMembershipMonitor(config.subset("ft"));
		} catch(Exception e) {
			logger.error("Failed to start", e);
			shutdown();
			throw e;
		}
	}

	public EventManagerImpl getEventManager() {
		return eventManager;
	}

	private void registerMembershipMonitor(Configuration config) {
		String clusterName = config.getString("clusterName", "");
		if (!"".equals(clusterName)) {
			final MembershipMonitor monitor = new FTMonitor(
					config.getString("clusterName"),
					config.getString("configFile", FTMonitor.DEFAULT_CONFIG));

			registerShutdownTask(new ShutdownAware() {
				@Override
				public void shutdown() throws Exception {
					monitor.stop();
				}
			});

			monitor.addMembershipListener(this);
			try {
				logger.info("{} starting...", monitor);
				monitor.start();
				logger.info("{} started", monitor);
			} catch (Exception e) {
				logger.error("Failed to start FT monitor", e);
				shutdown();
			}
		} else {
			logger.error("FT monitor disabled");
			onMembershipState(MembershipState.ACTIVE);
		}
	}

	private final ExecutorService lifeCycleExecutor =
			Executors.newSingleThreadExecutor(new NamedThreadFactory("ApplicationLifeCycle"));

	@Override
	public void onMembershipState(MembershipState state) {
		switch (state) {
		case ACTIVE:
			try {
				start();
				eventManager.onEvent(EventMessage.info(appName + " started"));
			} catch (Exception e) {
				logger.error("Failed to start", e);
				shutdown();
			}
			break;
		case INACTIVE:
			try {
				stop();
				eventManager.onEvent(EventMessage.info(appName + " stopped"));
			} catch (Exception e) {
				logger.error("Failed to stop", e);
				shutdown();
			}
			break;
		default:
			logger.warn("Unsupported membership state: {}", state);
		}
	}

	public void registerMBeans(JMXMBean mbean, String type, String name) throws Exception {
		if (!config.getBoolean(JMX_ENABLED, true)) {
			return;
		}
		JMXBeanWrapper jmx = new JMXBeanWrapper(mbean);
		if (jmx != null) {
			MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();
			ObjectName on;
			if (type == null) {
				on = new ObjectName(getClass().getPackage().getName() + ":name=" + name);
			} else {
				on = new ObjectName(getClass().getPackage().getName() + ":type=" + type + ",name=" + name);
			}
			try {
				mbs.registerMBean(jmx, on);
				logger.info("MBean {} registered", on);
			} catch (Exception e) {
				logger.info("Failed to register MBean " + on, e);
				throw e;
			}
		}
	}

	public void registerMBeans(JMXMBean mbean, String name) throws Exception {
		registerMBeans(mbean, null, name);
	}

	public void registerShutdownTask(ShutdownAware task) {
		shutdownSeq.add(task);
	}

	protected abstract void initialize(Configuration config) throws Exception;
	protected abstract void start() throws Exception;
	protected abstract void stop() throws Exception;

	@JMXBeanAttribute
	public String getAppName() {
		return appName;
	}

	@JMXBeanOperation
	public void shutdown() {
		lifeCycleExecutor.execute(new Runnable() {
			@Override
			public void run() {
				System.exit(1);
			}
		});
		lifeCycleExecutor.shutdown();
	}

	protected List<OutChannel<?>> buildErrChannels(Configuration config, String prefix) throws Exception {
		return buildOutChannels(config, prefix);
	}

	protected List<OutChannel<?>> buildOutChannels(Configuration config, String prefix) throws Exception {
		final List<OutChannel<?>> channels = new ArrayList<>();
		for (String name : config.getArray(prefix, new String[0])) {
			Configuration subset = config.subset(prefix + "." + name);
			OutChannel<?> ch = ChannelFactory.create(name, subset);
			ch.initialize();

			registerMBeans(ch, prefix, name);

			if (subset.exists("when")) {
				logger.info("Build Output Router for {} with condition: {}", name, Arrays.toString(subset.getArray("when")));
				channels.add(new Route(ch, new JSFilter(subset.getString("when"))));
			} else {
				channels.add(ch);
			}
		}
		return channels;
	}

	protected List<InChannel<?>> buildInChannels(Configuration config, String prefix) throws Exception {
		final List<InChannel<?>> channels = new ArrayList<>();
		for (String name : config.getArray(prefix, new String[0])) {
			InChannel<?> ch = ChannelFactory.create(name, config.subset(prefix + "." + name));
			ch.initialize();

			registerMBeans(ch, prefix, name);

			channels.add(ch);
		}
		return channels;
	}

    protected final void shutdownEventManager() {
        if(eventManager != null){
            eventManager.onEvent(EventMessage.info(appName + " has been shutdown"));
            eventManager.shutdown();
        }
    }
    
    protected final void shutdownAllTasks() {
        for (ShutdownAware task : shutdownSeq) {
        	try {
        		task.shutdown();
        	} catch (Exception e) {
        		logger.error("Shutdown task failed", e);
        	}
        }
    }

}
