package com.scb.fmsd.adapter.core.channel.net;

import java.io.IOException;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

import com.scb.fmsd.adapter.core.channel.AbstractInChannel;
import com.scb.fmsd.adapter.core.utils.CompressionUtils;
import com.scb.fmsd.common.jmx.JMXBeanAttribute;

public abstract class AbstractTCPServer  extends AbstractInChannel<ByteBuffer> {

	private final SocketAddress address;

	private IServer server;

	public AbstractTCPServer(String name, SocketAddress address) {
		super(name);
		setMessageConverter(new SerializableMessageConverter());
		this.address = address;
	}

	@JMXBeanAttribute(useToString = true)
	public SocketAddress getAddress() {
		return address;
	}

	@Override
	protected void doStart() throws Exception {
		assert server == null;
		server = createServer(address);
		server.start();
	}

	protected abstract IServer createServer(SocketAddress address) throws Exception;

	@Override
	protected void doStop() {
		assert server != null;
		server.shutdown();
		server = null;
	}

	protected void closeChannel(SocketChannel sc) {
		logger.info("Channel {} closed", sc);
		if (sc.isOpen()) {
			try { sc.close(); } catch (IOException ignore) {}
		}
	}

	protected void onMessage(byte[] bytes, boolean compressed, SocketChannel sc) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("Received {} {} bytes from {}", compressed ? "compressed" : "", bytes.length, sc);
		}

		if (compressed) {
			bytes = decompress(bytes);
		}

		onMessage(convert(ByteBuffer.wrap(bytes)));
	}

	protected static byte[] decompress(byte[] buffer) throws IOException {
		return CompressionUtils.decompress(buffer);
	}

	interface IServer {
		public void start();
		public void shutdown();
	}

}
