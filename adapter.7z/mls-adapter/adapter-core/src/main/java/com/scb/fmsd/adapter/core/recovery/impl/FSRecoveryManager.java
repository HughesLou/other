package com.scb.fmsd.adapter.core.recovery.impl;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.fmsd.adapter.core.model.BatchMesageObject;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.model.Serializer;
import com.scb.fmsd.adapter.core.recovery.RecoveryException;
import com.scb.fmsd.adapter.core.recovery.RecoveryManager;
import com.scb.fmsd.adapter.core.utils.FileUtils;
import com.scb.fmsd.common.config.Configuration;
import com.scb.fmsd.common.jmx.JMXBeanAttribute;

public class FSRecoveryManager implements RecoveryManager<MessageObject> {

    private static final Logger logger = LoggerFactory.getLogger(FSRecoveryManager.class);

    private final Path location;

    public FSRecoveryManager(Path location) throws IOException {
        this.location = Files.createDirectories(location);
    }

    @JMXBeanAttribute
    public Path getLocation() {
        return location;
    }

    @Override
    public void startTransaction(MessageObject t) throws RecoveryException {
        if (t instanceof BatchMesageObject) {
            BatchMesageObject batch = (BatchMesageObject) t;
            for (MessageObject m : batch) {
                persist(m);
            }
        } else {
            persist(t);
        }
    }

    @Override
    public boolean isTransacted(MessageObject t) {
        Path path = getPath(t);
        return Files.exists(path);
    }

    private Path persist(MessageObject t) throws RecoveryException {
        Path path = getPath(t);
        if (Files.exists(path)) {
            throw new RecoveryException("Unprocessed transaction found: " + path + ", messageId=" + t.getMessageId());
        }
        try {
            marshall(path, t);
        } catch (Exception e) {
            throw new RecoveryException("Failed to start transaction: " + path + ", messageId=" + t.getMessageId(), e);
        }
        logger.debug("Message {} pesisted to {}", t.getMessageId(), path);
        return path;
    }

    protected Path getPath(MessageObject t) {
        return Paths.get(location.toString(), FileUtils.reformFileName(t.getMessageId()));
    }

    @Override
    public void commit(MessageObject t) throws RecoveryException {
        if (t instanceof BatchMesageObject) {
            return;
        }
        Path path = getPath(t);
        try {
        	FileUtils.deletePath(path);
        } catch (IOException e) {
            throw new RecoveryException("Failed to commit: messageId=" + t.getMessageId(), e);
        }
        logger.debug("Message {} committed", t.getMessageId());
    }

    @Override
    public void rollback(MessageObject t) throws RecoveryException {
        if (t instanceof BatchMesageObject) {
            return;
        }
        Path path = getPath(t);
        try {
            FileUtils.deletePath(path);
        } catch (IOException e) {
            throw new RecoveryException("Failed to rollback: messageId=" + t.getMessageId(), e);
        }
        logger.debug("Message {} rollbacked", t.getMessageId());
    }

    @Override
    public Iterator<MessageObject> unprocessed() throws RecoveryException {
        List<Path> files = new ArrayList<>();
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(location)) {
            for (Path p : ds) {
                files.add(p);
            }
        } catch (IOException e) {
            throw new RecoveryException(e);
        }
        logger.info("Found {} unprocessed transaction", files.size());
        return new UnprocessedIterator(files.iterator());
    }

    private MessageObject unmarshall(Path path) throws Exception {
        try (BufferedInputStream bis = new BufferedInputStream(Files.newInputStream(path))) {
            return Serializer.deserialize(bis);
        }
    }

    private void marshall(Path path, MessageObject mo) throws Exception {
        OutputStream newOutputStream = createOutputStream(path);
        BufferedOutputStream out = new BufferedOutputStream(newOutputStream);
        Serializer.serialize(mo, out);
        out.close();
    }

    protected OutputStream createOutputStream(Path path) throws InterruptedException, FileNotFoundException {
        OutputStream newOutputStream = null;
        boolean created = false;
        for (int i = 0; i < 10; i++) {
            try {
                newOutputStream = Files.newOutputStream(path);
                created = true;
                break;
            } catch (Exception e) {
                logger.error("Can't create " + path.toString());
                Thread.sleep(100);
            }
        }
        if (created == false) {
            throw new FileNotFoundException(path.toString());
        }
        return newOutputStream;
    }
    

    private class UnprocessedIterator implements Iterator<MessageObject> {

        private final Iterator<Path> files;

        public UnprocessedIterator(Iterator<Path> files) {
            this.files = files;
        }

        @Override
        public boolean hasNext() {
            return files.hasNext();
        }

        @Override
        public MessageObject next() {
            Path path = files.next();
            try {
                return unmarshall(path);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }
    }

    public void clean() throws IOException {
    	FileUtils.cleanPath(location);
    }

    public static FSRecoveryManager create(String name, Configuration config) throws IOException {
        return new FSRecoveryManager(Paths.get(config.getString("location")));
    }
}
