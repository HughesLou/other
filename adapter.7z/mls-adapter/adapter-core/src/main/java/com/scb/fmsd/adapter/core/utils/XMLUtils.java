package com.scb.fmsd.adapter.core.utils;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import org.w3c.dom.Document;

public abstract class XMLUtils {

	private XMLUtils() {
	}
	
	public static void print(Document document, Writer out) {
		OutputFormat format = new OutputFormat(document);
        format.setLineWidth(65);
        format.setIndenting(true);
        format.setIndent(2);
        XMLSerializer serializer = new XMLSerializer(out, format);
        try {
			serializer.serialize(document);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static String print(Document document) {
		Writer out = new StringWriter();
		print(document, out);
		return out.toString();
	}
}
