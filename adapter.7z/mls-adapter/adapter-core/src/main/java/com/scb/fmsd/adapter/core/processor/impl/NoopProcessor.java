package com.scb.fmsd.adapter.core.processor.impl;

import com.scb.fmsd.adapter.core.processor.ProcessorAdapter;
import com.scb.fmsd.common.config.Configuration;

public class NoopProcessor extends ProcessorAdapter {

	public static NoopProcessor create(String name, Configuration config) {
		return new NoopProcessor();
	}

}
