package com.scb.fmsd.adapter.core.model;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class BatchMesageObject extends AbstractMessageObject<List<MessageObject>> implements Iterable<MessageObject> {

	public BatchMesageObject() {
	}

	public BatchMesageObject(List<MessageObject> payload, String messageId) {
		super(payload, messageId);
	}

	public BatchMesageObject(List<MessageObject> payload, String messageId, Map<String, Object> props) {
		super(payload, messageId, props);
	}

	@Override
	public String getText() {
		throw new UnsupportedOperationException();
	}

	@Override
	public byte[] getBytes() {
		throw new UnsupportedOperationException();
	}

    @Override
    public boolean isBatchMessage() {
        return true;
    }

    public int size() {
		return getPayload().size();
	}

	@Override
	public Iterator<MessageObject> iterator() {
		return getPayload().iterator();
	}

	@Override
	public void serialize(DataOutputStream out) throws Exception {
		super.serialize(out);
		List<MessageObject> list = getPayload();
		out.writeInt(list.size());
		for (MessageObject mo : list) {
			out.writeUTF(mo.getClass().getName());
			mo.serialize(out);
		}
	}

	@Override
	public MessageObject deserialize(DataInputStream in) throws Exception {
		super.deserialize(in);
		int size = in.readInt();
		List<MessageObject> list = new ArrayList<>(size);
		for (int i = 0; i < size; i++) {
			String className = in.readUTF();
			MessageObject mo = (MessageObject) Class.forName(className).newInstance();
			mo.deserialize(in);
			list.add(mo);
		}
		setPayload(list);
		return this;
	}

}
