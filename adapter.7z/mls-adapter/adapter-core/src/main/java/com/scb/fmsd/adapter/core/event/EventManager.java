package com.scb.fmsd.adapter.core.event;

public interface EventManager {
	public void onEvent(EventMessage event);
}
