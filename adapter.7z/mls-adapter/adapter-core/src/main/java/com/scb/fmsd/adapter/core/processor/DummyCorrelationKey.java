package com.scb.fmsd.adapter.core.processor;

import java.util.Properties;
import java.util.Set;

import com.google.common.collect.Sets;
import com.scb.fmsd.adapter.core.model.MessageObject;

public class DummyCorrelationKey implements CorrelationKey {

	@Override
	public Object getKey(MessageObject message) {
		return "";
	}

	@Override
	public Set<Object> getKeys(MessageObject message) {
		return Sets.newHashSet();
	}

	@Override
	public Properties getProperties(MessageObject message) {
		return new Properties();
	}

}
