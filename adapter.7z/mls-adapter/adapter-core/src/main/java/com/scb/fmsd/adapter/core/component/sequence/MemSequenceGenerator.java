package com.scb.fmsd.adapter.core.component.sequence;

import java.util.concurrent.atomic.AtomicLong;

public class MemSequenceGenerator implements SequenceGenerator {
	
	private final AtomicLong seq;
	
	public MemSequenceGenerator() {
		this(0);
	}
	
	public MemSequenceGenerator(long start) {
		seq = new AtomicLong(start);
	}
	
	@Override
	public void reset(long value) {
		seq.set(value);
	}
	
	@Override
	public long next() {
		return seq.incrementAndGet();
	}
}
