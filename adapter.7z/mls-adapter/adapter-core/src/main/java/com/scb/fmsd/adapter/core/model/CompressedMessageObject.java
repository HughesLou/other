package com.scb.fmsd.adapter.core.model;

import com.scb.fmsd.adapter.core.utils.CompressionUtils;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Map;

public class CompressedMessageObject implements MessageObject {

	private MessageObject message;
	private String text;
	
    private transient Object refObject;

    public CompressedMessageObject() {
    	message = null;
    }
    
	public CompressedMessageObject(MessageObject message) {
		if (message == null) {
			throw new NullPointerException("message is NULL");
		}
		this.message = message;
	}

	@Override
	public String getMessageId() {
		return message.getMessageId();
	}

	@Override
	public Object getPayload() {
		return message.getPayload();
	}

	@Override
	public String getText() {
		if (text==null){
			text =  new String(getBytes());
		}
		return text;
	}

	@Override
	public byte[] getBytes() {
	    try {
	        return CompressionUtils.decompress(message.getBytes());
	    } catch (IOException e) {
	        throw new RuntimeException("Failed to decompress", e);
	    }
	}

    @Override
    public boolean isBatchMessage() {
        return false;
    }

    @Override
	public Throwable getError() {
		return message.getError();
	}

	@Override
	public void setError(Throwable t) {
		message.setError(t);
	}

	@Override
	public void setOriginal(MessageObject original) {
		message.setOriginal(original);
	}

	@Override
	public MessageObject getOriginal() {
		return message.getOriginal();
	}

	@Override
	public void addProperty(String name, Object value) {
		message.addProperty(name, value);
	}

	@Override
	public Object getProperty(String name) {
		return message.getProperty(name);
	}

	@Override
	public boolean hasProperty(String name) {
		return message.hasProperty(name);
	}

	@Override
	public Map<String, Object> getProperties() {
		return message.getProperties();
	}

	@Override
	public void serialize(DataOutputStream out) throws Exception {
		Serializer.writeStringASCII(message.getClass().getName(), out);
		message.serialize(out);
	}

	@Override
	public MessageObject deserialize(DataInputStream in) throws Exception {
		String type = Serializer.readStringASCII(in);
		MessageObject mo = (MessageObject) Class.forName(type).newInstance();
		mo.deserialize(in);
		this.message = mo;
		return this;
	}

    @Override
    public void setRefObject(Object refObject) {
        this.refObject = refObject;
    }

    @Override
    public Object getRefObject() {
        return refObject;
    }
}
