package com.scb.fmsd.adapter.core.dispatcher.filters;

import com.scb.fmsd.adapter.core.model.MessageObject;

public interface Filter {
	public boolean accept(MessageObject mo);
}
