package com.scb.fmsd.adapter.core.processor;

import com.scb.fmsd.adapter.core.model.MessageObject;

public class CompletionCallbackAdapter implements CompletionCallback {

	@Override
	public void completed(MessageObject result, MessageObject original) {
	}

	@Override
	public void failed(Throwable t, MessageObject message) {
	}

}
