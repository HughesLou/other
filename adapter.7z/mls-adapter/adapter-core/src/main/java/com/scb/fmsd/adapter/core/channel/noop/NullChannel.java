package com.scb.fmsd.adapter.core.channel.noop;

import com.scb.fmsd.adapter.core.channel.AbstractInOutChannel;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.common.config.Configuration;

public class NullChannel extends AbstractInOutChannel<Object> {

	public static final NullChannel INSTANCE = new NullChannel();

	private NullChannel() {
		super("NULL");
	}

	public static NullChannel create(String name, Configuration config) {
		return NullChannel.INSTANCE;
	}

	@Override
	public void send(MessageObject message) throws Exception {
	}

}
