package com.scb.fmsd.adapter.core.dispatcher.impl;

import com.scb.fmsd.adapter.core.channel.*;
import com.scb.fmsd.adapter.core.dispatcher.Dispatcher;
import com.scb.fmsd.adapter.core.dispatcher.NoRouteFoundException;
import com.scb.fmsd.adapter.core.dispatcher.Route;
import com.scb.fmsd.adapter.core.dispatcher.UnprocessedException;
import com.scb.fmsd.adapter.core.event.EventManager;
import com.scb.fmsd.adapter.core.event.EventMessage;
import com.scb.fmsd.adapter.core.model.BatchMesageObject;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.processor.ParallelProcessor;
import com.scb.fmsd.adapter.core.processor.Processor;
import com.scb.fmsd.adapter.core.utils.NamedThreadFactory;
import com.scb.fmsd.common.jmx.JMXBeanAttribute;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.*;
import java.util.concurrent.ThreadPoolExecutor.CallerRunsPolicy;
import java.util.concurrent.atomic.AtomicLong;

public class RouterImpl implements Dispatcher, ChannelMessageListener, ChannelListener {

	private final static Logger logger = LoggerFactory.getLogger(RouterImpl.class);

	protected Processor processor;

	protected final EventManager eventManager;

	protected final List<Route> outgoing = new ArrayList<>();

	protected final List<InChannel<?>> sources = new ArrayList<>();

	protected final List<OutChannel<?>> errors = new ArrayList<>();

	private final ThreadPoolExecutor executor;

	public RouterImpl(String name, EventManager eventManager) {
		this(name, eventManager, new SynchronousQueue<Runnable>());
	}

	public RouterImpl(String name, EventManager eventManager, BlockingQueue<Runnable> queue) {
		Objects.requireNonNull(eventManager, "EventManager is null");
		this.eventManager = eventManager;
		this.executor = new ThreadPoolExecutor(
				1, Runtime.getRuntime().availableProcessors(),
				60L, TimeUnit.SECONDS,
				queue,
				new NamedThreadFactory("RouterProcessor"),
				new CallerRunsPolicy()) {
			@SuppressWarnings("unchecked")
			@Override
			protected <T> RunnableFuture<T> newTaskFor(Callable<T> callable) {
				return (RunnableFuture<T>) new FutureTaskEx((Task) callable);
			}
		};
	}

	@Override
	public void setErrorChannels(List<? extends OutChannel<?>> errors) {
		this.errors.addAll(errors);
	}

	@Override
	public void setFromChannels(Collection<? extends InChannel<?>> sources) {
		this.sources.addAll(sources);
	}

	@Override
	public void setToChannels(List<? extends OutChannel<?>> routes) {
		for (OutChannel<?> route : routes) {
			if (route instanceof Route) {
				outgoing.add((Route) route);
			} else {
				outgoing.add(new Route(route));
			}
		}
	}

	@JMXBeanAttribute
	public Processor getProcessor() {
		return processor;
	}

	@Override
	public void setProcessor(Processor processor) {
		this.processor = processor;
	}

	private final AtomicLong processed = new AtomicLong();
	private final AtomicLong lastProcessingTime = new AtomicLong();

	@Override
	public void onMessage(MessageObject message, InChannel<?> channel) throws Exception {
		Objects.requireNonNull(message, "message is NULL");
		Objects.requireNonNull(channel, "channel is NULL");

		long t = System.nanoTime();
		try {
			if (message instanceof BatchMesageObject) {
				BatchMesageObject batch = (BatchMesageObject) message;
				if (batch.size() == 0) {
					logger.warn("Batch {} is empty", message.getMessageId());
					return;
				}
				if (batch.size() == 1) {
					handleMessage(batch.iterator().next());
				} else {
					List<FutureTaskEx> futures = new ArrayList<>(batch.size());
					for (MessageObject m : batch) {
						futures.add((FutureTaskEx) executor.submit(new Task(m)));
					}

					for (FutureTaskEx f : futures) {
						try {
							dispatch(f.get(), f.task.message);
						} catch (Exception e) {
							handleException(e, f.task.message);
							throw e;
						}
					}
				}
			} else {
				handleMessage(message);
			}
			if (channel instanceof TransactionSupport) {
				((TransactionSupport) channel).commit();
			}
		} finally {
			lastProcessingTime.set(System.nanoTime() - t);
			processed.incrementAndGet();
		}
	}

	@Override
	public void onException(Throwable t, Channel<?> channel) {
		eventManager.onEvent(EventMessage.error(t.getMessage(), t));
	}

	protected void sendToErrorChannel(Throwable t, MessageObject message) throws Exception {
		for (OutChannel<?> ch : errors) {
			message.setError(t);
			ch.send(message);
		}
	}

	protected void handleException(Throwable t, MessageObject message) {
		try {
			sendToErrorChannel(t, message);
		} catch (Exception e) {
			logger.error("Failed to send to error channel", e);
		}
		if (t != null) {
			eventManager.onEvent(EventMessage.error(t.getMessage(), t, message));
		}
	}

	private void handleMessage(MessageObject message) throws Exception {
		try {
			dispatch(processor.process(message), message);
		} catch (Exception e) {
			handleException(e, message);
			throw e;
		}
	}

	private static class FutureTaskEx extends FutureTask<MessageObject> {
		private final Task task;
		public FutureTaskEx(Task task) {
			super(task);
			this.task = task;
		}

	}

	private class Task implements Callable<MessageObject> {
		private final MessageObject message;
		public Task(MessageObject m) {
			this.message = m;
		}

		@Override
		public MessageObject call() throws Exception {
			return processor.process(message);
		}
	}

	protected void dispatch(MessageObject message, MessageObject original) throws Exception {
		boolean routed = false;
		message.setOriginal(original);
		for (Route r : outgoing) {
			if (r.accept(message)) {
				if (logger.isInfoEnabled()) {
					logger.info("message is sending to {}", r.getTo().getName());
				}
				r.send(message);
				routed = true;
            } else {
                if (logger.isDebugEnabled()) {
                    logger.debug("message is filtered by {}", r.getTo().getName());
                }
            }
        }

		if (!routed) {
			handleException(new NoRouteFoundException("Routing not found for message: " + message.getMessageId()), message);
		}
	}

	@Override
	public void start() throws Exception {
		Objects.requireNonNull(processor);
		for (OutChannel<?> ch : errors) {
			ch.start();
		}
		for (Route r : outgoing) {
			r.start();
		}
		for (InChannel<?> ch : sources) {
			ch.setChannelListener(this);
			ch.setChannelMessageListener(this);
			ch.start();
		}
	}

	@Override
	public void stop() throws Exception {
		for (InChannel<?> ch : sources) {
			ch.stop();
		}
	}

	@Override
	public void shutdown() throws Exception {
		for (InChannel<?> ch : sources) {
			ch.shutdown();
		}
		if (processor instanceof ParallelProcessor) {
			ParallelProcessor pp = (ParallelProcessor) processor;
			for (MessageObject message : pp.shutdownNow()) {
				try {
					handleException(new UnprocessedException("shutdown"), message);
				} catch (Exception e) {
					logger.error(e.getMessage(), e);
				}
			}
		} else {
			processor.shutdown();
		}
		for (Route r : outgoing) {
			r.shutdown();
		}
		for (OutChannel<?> ch : errors) {
			ch.shutdown();
		}
	}

}
