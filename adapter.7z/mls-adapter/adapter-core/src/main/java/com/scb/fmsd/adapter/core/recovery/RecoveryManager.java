package com.scb.fmsd.adapter.core.recovery;

import java.util.Iterator;

import com.scb.fmsd.common.jmx.JMXMBean;

public interface RecoveryManager<T> extends JMXMBean {
	
	public boolean isTransacted(T t);
	
	public void startTransaction(T t) throws RecoveryException;

	public void commit(T t) throws RecoveryException;
	
	public void rollback(T t) throws RecoveryException;

	public Iterator<T> unprocessed() throws RecoveryException;
}
