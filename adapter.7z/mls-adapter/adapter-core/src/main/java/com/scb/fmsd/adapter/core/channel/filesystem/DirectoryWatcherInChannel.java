package com.scb.fmsd.adapter.core.channel.filesystem;


import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.StandardCopyOption;
import java.nio.file.WatchService;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.fmsd.adapter.core.channel.AbstractInChannel;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.model.StringMessageObject;
import com.scb.fmsd.common.config.Configuration;

/**
 * Refactored to no longer use {@link WatchService} as it does not cope well with large numbers of events
 */
public class DirectoryWatcherInChannel extends AbstractInChannel<MessageObject> {
    private static final Logger LOG = LoggerFactory.getLogger(DirectoryWatcherInChannel.class);

    // Using the same property file keys as other file channels, but they are not very intuitive
    public static final String PROPERTY_INITIAL_WAIT_TIME = "folderListenerWait";
    public static final String PROPERTY_WAIT_TIME_BETWEEN_POLLING = "waitpermsg";
    public static final String PROPERTY_FILE_LOCATION = "location";
    public static final String PROPERTY_WATCH_STRATEGY = "strategy";

    protected static final long DEFAULT_INITIAL_WAIT_TIME_MILLIS = 10_000;
    protected static final long DEFAULT_WAIT_TIME_MILLIS = 10_000;

    private final Path watchPath;
    private final long initialWaitTimeMillis;
    private final long waitTimeMillis;
    private final WatchStrategy watchStrategy;
    private volatile boolean stop = false;

    public DirectoryWatcherInChannel(String name, String location, WatchStrategy watchStrategy, long initialWaitTimeMillis, long waitTimeMillis) {
        super(name);
        Objects.requireNonNull(location, "name argument must not be null");
        Objects.requireNonNull(watchStrategy, "watchStrategy argument must not be null");
        Objects.requireNonNull(location, "location argument must not be null");
        this.watchPath = Paths.get(location);
        this.watchStrategy = watchStrategy;
        this.initialWaitTimeMillis = initialWaitTimeMillis;
        this.waitTimeMillis = waitTimeMillis;
    }

    public static DirectoryWatcherInChannel create(String name, Configuration conf) {
        String location = conf.getString(PROPERTY_FILE_LOCATION);
        String strategyClass = conf.getString(PROPERTY_WATCH_STRATEGY, DefaultWatchStrategy.class.getName());
        WatchStrategy strategy;
        try {
            Class clazz = Class.forName(strategyClass);
            strategy = (WatchStrategy) clazz.getDeclaredConstructor(Path.class).newInstance(Paths.get(location));
        } catch (Exception e) {
            throw new RuntimeException("Unable to create strategy for " + strategyClass, e);
        }
        return create(name, conf, strategy);
    }

    public static DirectoryWatcherInChannel create(String name, Configuration conf, WatchStrategy watchStrategy) {
        String location = conf.getString(PROPERTY_FILE_LOCATION);
        long initialWaitTime = conf.getLong(PROPERTY_INITIAL_WAIT_TIME, DEFAULT_INITIAL_WAIT_TIME_MILLIS);
        long pollingWaitTime = conf.getLong(PROPERTY_WAIT_TIME_BETWEEN_POLLING, DEFAULT_WAIT_TIME_MILLIS);
        return new DirectoryWatcherInChannel(name, location, watchStrategy, initialWaitTime, pollingWaitTime);
    }

    @Override
    protected void doStart() throws Exception {
        LOG.info("Started watching {}", watchPath);
        DirectoryWatcher directoryWatcher = new DirectoryWatcher(watchStrategy);

        try {
            TimeUnit.MILLISECONDS.sleep(initialWaitTimeMillis);
        } catch (InterruptedException e) {
            LOG.warn("Initial wait time interrupted");
        }

        directoryWatcher.initialize();
        ExecutorService executorService = Executors.newFixedThreadPool(1);
        executorService.submit(directoryWatcher);
    }

    @Override
    protected void doStop() {
        this.stop = true;
    }

    private class DirectoryWatcher implements Runnable {
        private final WatchStrategy watchStrategy;

        public DirectoryWatcher(WatchStrategy watchStrategy) throws IOException {
            this.watchStrategy = watchStrategy;
        }

        public void initialize() {
            watchStrategy.initialize();
        }

        @Override
        public void run() {
            try {
                while (!stop) {
                    handleFiles(watchStrategy.getFiles());
                    try {
                        LOG.debug("Waiting for {}ms", waitTimeMillis);
                        TimeUnit.MILLISECONDS.sleep(waitTimeMillis);
                    } catch (InterruptedException e) {
                        LOG.info("Wait between directory polling attempts has been interrupted");
                        break;
                    } catch (Exception e) {
                        LOG.error("File processing failed", e);
                    }
                }
            } catch (Exception e) {
                LOG.error("Watch thread failed", e);
                throw new RuntimeException(e);
            } finally {
                LOG.info("Stopped");
            }
        }

        private void handleFiles(List<Path> files) {
            if (files.isEmpty()) {
                return;
            }

            for (Path file : files) {
                MessageObject message = null;
                try {
                    message = watchStrategy.createMessage(file);
                } catch (Exception e) {
                    watchStrategy.handleError(file, e);
                    continue;
                }

                try {
                    handleMessage(message);
                    Files.delete(file);
                } catch (Exception e) {
                    LOG.error("Unable to process message {}", message.getText(), e);
                    watchStrategy.handleError(file, e);
                }
            }
        }

        private void handleMessage(MessageObject message) throws Exception {
            if (message != null) {
                onMessage(message);
            }
        }
    }


    public interface WatchStrategy {
        /**
         * Perform any actions required before polling starts
         */
        void initialize();

        /**
         * Returns new files detected in the directory since it was last polled.
         */
        List<Path> getFiles();

        /**
         * Parses the contents of the file into a message object
         */
        MessageObject createMessage(Path file);

        /**
         * How to handle files that cannot be processed
         */
        void handleError(Path file, Exception e);
    }

    /**
     * Default strategy that returns files in an unspecified order
     */
    private static class DefaultWatchStrategy implements WatchStrategy {
        private static final Logger LOG = LoggerFactory.getLogger(DefaultWatchStrategy.class);
        private static final Pattern DEFAULT_FILE_REGEX = Pattern.compile(".*\\.xml$");
        private static final String ERROR_FILE_SUFFIX = ".error";
        private final Path watchPath;
        private final Pattern filePattern;

        public DefaultWatchStrategy(Path watchPath) {
            this(watchPath, DEFAULT_FILE_REGEX);
        }

        public DefaultWatchStrategy(Path watchPath, Pattern filePattern) {
            this.watchPath = watchPath;
            this.filePattern = filePattern;
        }

        @Override
        public void initialize() {}

        @Override
        public List<Path> getFiles() {
            final List<Path> files = new ArrayList<>();
            try {
                Files.walkFileTree(watchPath, new SimpleFileVisitor<Path>() {
                    @Override
                    public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                        if (filePattern.matcher(file.getFileName().toString()).matches()) {
                            LOG.info("Found file {}", file);
                            files.add(watchPath.resolve(file));
                        } else {
                            LOG.debug("Ignoring file {}", file);
                        }
                        return FileVisitResult.CONTINUE;
                    }
                });
            } catch (IOException e) {
                LOG.error("Unable to process files in {}", watchPath, e);
            }

            if (files.isEmpty()) {
                LOG.debug("No matching files found in {}", watchPath);
            }

            return files;
        }

        @Override
        public MessageObject createMessage(Path filename) {
            MessageObject messageObject;
            try {
                String msg = new String(Files.readAllBytes(filename), StandardCharsets.ISO_8859_1);
                messageObject = new StringMessageObject(msg);
            } catch (Exception e) {
                LOG.error("Unable to read file {}", filename, e);
                messageObject = new StringMessageObject("", filename.toString());
                messageObject.setError(e);
            }
            return messageObject;
        }

        @Override
        public void handleError(Path file, Exception e) {
            LOG.error("Unable to process file {}", file, e);
            Path renamedFile = null;
            try {
                renamedFile = file.resolveSibling(file.getFileName() + ERROR_FILE_SUFFIX);
                Files.move(file, file.resolveSibling(renamedFile), StandardCopyOption.REPLACE_EXISTING);
                LOG.info("Moved {} to {}", file, renamedFile);
            } catch (IOException e1) {
                LOG.error("Unable to move file {} to {}", file, renamedFile, e1);
            }
        }
    }
}
