package com.scb.fmsd.adapter.core.recovery;

public interface Recoverable<T> {
	public void setRecoveryManager(RecoveryManager<T> tm);
}
