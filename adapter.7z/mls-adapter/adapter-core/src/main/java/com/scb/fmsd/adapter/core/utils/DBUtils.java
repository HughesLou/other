package com.scb.fmsd.adapter.core.utils;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

public final class DBUtils {

	private DBUtils() {}
	
	public static String dumpTable(ResultSet rs) throws SQLException {
		ResultSetMetaData md = rs.getMetaData();
		
		int[] columns = new int[md.getColumnCount()]; 
		for (int i = 0, n = md.getColumnCount(); i < n; i++) {
			String name = md.getColumnName(i + 1);
			columns[i] = name.length();
		}
		
		List<List<String>> data = new ArrayList<>();
		
		while (rs.next()) {
			List<String> row = new ArrayList<>(columns.length);
			for (int i = 1; i <= columns.length; i++) {
				Object value = rs.getObject(i);
				String str = value == null ? "" : value.toString();
				int len = str.length(); ;
				if (len > columns[i - 1]) {
					columns[i - 1] = len;
				}
				row.add(str);
			}
			data.add(row);
		}
		
		StringBuilder sb = new StringBuilder(1024);
		sb.append('\n');
		for (int i = 0, n = md.getColumnCount(); i < n; i++) {
			String name = md.getColumnName(i + 1);
			sb.append(StringUtils.center(name, columns[i])).append('|');
		}
		sb.append('\n');
		for (int i = 0; i < columns.length; i++) {
			sb.append(StringUtils.repeat('-', columns[i])).append('+');
		}
		sb.append('\n');
		for (List<String> row : data) {
			for (int i = 0; i < columns.length; i++) {
				sb.append(StringUtils.rightPad(row.get(i), columns[i])).append('|');
			}
			sb.append('\n');
		}
		
		return sb.toString();
	}
	
}
