package com.scb.fmsd.adapter.core.dispatcher;

import java.util.Collection;
import java.util.List;

import com.scb.fmsd.adapter.core.Service;
import com.scb.fmsd.adapter.core.ShutdownAware;
import com.scb.fmsd.adapter.core.channel.InChannel;
import com.scb.fmsd.adapter.core.channel.OutChannel;
import com.scb.fmsd.adapter.core.processor.Processor;
import com.scb.fmsd.common.jmx.JMXMBean;

public interface Dispatcher extends ShutdownAware, JMXMBean, Service {
	public void setErrorChannels(List<? extends OutChannel<?>> errors);
	public void setFromChannels(Collection<? extends InChannel<?>> sources);
	public void setToChannels(List<? extends OutChannel<?>> routes);
	public void setProcessor(Processor processor);

	public void start() throws Exception;
	public void stop() throws Exception;
}
