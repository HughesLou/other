package com.scb.fmsd.adapter.core.channel;

import com.scb.fmsd.adapter.core.model.MessageObject;

public interface ChannelMessageListener {
	public void onMessage(MessageObject message, InChannel<?> channel) throws Exception;
}
