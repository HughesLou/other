package com.scb.fmsd.adapter.core.processor.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.processor.AbstractParallelProcessor;
import com.scb.fmsd.adapter.core.processor.CompletionCallback;
import com.scb.fmsd.adapter.core.processor.CorrelationKey;
import com.scb.fmsd.adapter.core.processor.Processor;
import com.scb.fmsd.common.config.Configuration;
import com.scb.fmsd.common.jmx.JMXBeanAttribute;

public class HashBasedParallelProcessor extends AbstractParallelProcessor {

	private static final Logger logger = LoggerFactory.getLogger(HashBasedParallelProcessor.class);

	private final CorrelationKey correlationKey;

	private final Worker[] workers;

	public HashBasedParallelProcessor(Processor processor, int threads, int size, CorrelationKey correlationKey) {
		super(processor, threads, size);
		this.workers = new Worker[threads];
		this.correlationKey = correlationKey;
	}

	@Override
	public int getWorkingQueueSize(){
		int size = 0;
		for (Worker w: workers){
			size += w.getQueueSize();
		}
		return size;
	}
	
	
	@Override
	public void process(MessageObject message, CompletionCallback callback) throws Exception {
		logger.info("Processing {} ", message.getMessageId());
		Object key = correlationKey.getKey(message);
		logger.debug("Correlation key is {}", key);
		int no = key == null ? 0 : Math.abs(key.hashCode() % workers.length);
		logger.debug("Queue # is {}", no);
		workers[no].enqueue(new Wrapper(message, callback));
		logger.debug("Processed {}", message.getMessageId());
	}

	@Override
	public List<MessageObject> shutdownNow() {
		List<MessageObject> list = new ArrayList<>();
		for (int i = 0; i < workers.length; i++) {
			Worker w = workers[i];
			try {
				if (!w.shutdown(1, TimeUnit.SECONDS)) {
					logger.info("{} was not shutdown successfully", w);
				}
			} catch (InterruptedException ex) {
				logger.info("{} was not shutdown successfully: {}", w, ex);
			};
			Wrapper wrap;
			while ((wrap = w.queue.poll()) != null) {
				list.add(wrap.message);
			}
		}
		return list;
	}

	@Override
	public void initialize() {
		int queueSize = size / threads;
		for (int i = 0; i < threads; i++) {
			workers[i] = new Worker(processor, i + 1, queueSize);
			workers[i].start();
		}
	}

	@JMXBeanAttribute(useToString = true)
	public CorrelationKey getCorrelationKey() {
		return correlationKey;
	}

	private static class Worker extends Thread {

		private final Processor processor;

		private volatile boolean stopped;

		private final BlockingQueue<Wrapper> queue;

		private final CountDownLatch shutdown = new CountDownLatch(1);

		public Worker(Processor processor, int no, int size) {
			super("ParallelProcessor-" + no);
			this.processor = processor;
			this.queue = new ArrayBlockingQueue<Wrapper>(size);
		}

		public int getQueueSize() {
			return queue.size();
		}

		public void enqueue(Wrapper message) throws InterruptedException {
			queue.put(message);
		}

		public boolean shutdown(long timeout, TimeUnit unit) throws InterruptedException {
			stopped = true;
			interrupt();
			return shutdown.await(timeout, unit);
		}
		
		@Override
		public void run() {
			logger.info("{} started", getName());
			while (!stopped) {
				Wrapper wrap = null;
				try {
					wrap = queue.take();
					logger.debug("Dequeued message {} ", wrap.message);
					MessageObject result = processor.process(wrap.message);
					wrap.callback.completed(result, wrap.message);
				} catch (InterruptedException ignore) {
					Thread.currentThread().interrupt();
				} catch (Exception e) {
					logger.error("Unexpected exception", e);
					if (wrap != null) {
						wrap.callback.failed(e, wrap.message);
					}
				}
			}
			logger.info("{} stopped", getName());
			shutdown.countDown();
		}
	}

	private static class Wrapper {
		private final MessageObject message;
		private final CompletionCallback callback;
		public Wrapper(MessageObject message, CompletionCallback callback) {
			this.message = message;
			this.callback = callback;
		}
	}

	public static HashBasedParallelProcessor create(String name, Configuration config, Processor processor) throws Exception {
		int workers = config.getInt("threads", Runtime.getRuntime().availableProcessors());
		int queueSize = config.getInt("queueSize", 10);
		String correlationKeyClass = config.getString("correlationKeyClass");
		CorrelationKey key = (CorrelationKey) Class.forName(correlationKeyClass).newInstance();
		return new HashBasedParallelProcessor(processor, workers, queueSize, key);
	}

}
