package com.scb.fmsd.adapter.core.utils;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.fmsd.adapter.core.recovery.impl.FSRecoveryManager;

public abstract class FileUtils {

	private static final Logger logger = LoggerFactory.getLogger(FileUtils.class);
	private static final String classpath_prefix = "classpath:";
	private FileUtils() {
	}

	public static void deletePath(Path path) throws IOException, FileNotFoundException {
        boolean deleted = false;
        for (int i = 0; i < 10; i++) {
            deleted = Files.deleteIfExists(path);
            if (deleted == false) {
                logger.error("Can't delete " + path.toString());
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {

                }
            } else {
                deleted = true;
                break;
            }
        }

        if (deleted == false) {
            throw new FileNotFoundException(path.toString());
        }
    }
    
    public static void cleanPath(Path location) throws IOException {
        Files.walkFileTree(location, new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                Files.delete(file);
                return FileVisitResult.CONTINUE;
            }
        });
        Files.delete(location);
    }
    
	public static List<String> readLines(String uri, Charset charset) throws IOException {
		if (uri.startsWith(classpath_prefix)) {
			uri = uri.substring(classpath_prefix.length());	// "classpath:".length == 10
			if (uri.charAt(0) == '/') {
				URL resurl = FileUtils.class.getClassLoader().getResource(uri);
				if (resurl==null)
					resurl = FileUtils.class.getClassLoader().getResource(uri.substring(1));
				return readLines(resurl, charset);
			} else {
				String className = FileUtils.class.getName();
				StackTraceElement[] stack = Thread.currentThread().getStackTrace();
				for (int i = 2; i < stack.length; i++) {
					if (!className.equals(stack[i].getClassName())) {
						className = stack[i].getClassName();
						break;
					}
				}
				try {
					return readLines(Class.forName(className).getResource(uri), charset);
				} catch (ClassNotFoundException e) {
					throw new AssertionError(e);
				}
			}
		} else if (uri.startsWith("file:")) {
			return readLines(new URL(uri), charset);
		} else {
			throw new RuntimeException("How to handle this? " + uri);
		}
	}

	public static List<String> readLines(URL url, Charset charset) throws IOException {
		try (InputStream stream = url.openStream()) {
			return readLines(stream, charset);
		}
	}

	public static List<String> readLines(InputStream stream, Charset charset) throws IOException {
		Objects.requireNonNull(stream, "'stream' is null");
		BufferedReader reader = new BufferedReader(new InputStreamReader(stream, charset));
		List<String> lines = new ArrayList<>();
		String line;
		while ((line = reader.readLine()) != null) {
			lines.add(line);
		}
		return lines;
	}

	public static String getFileNameWithoutExt(Path path) {
		if (path == null) {
			return null;
		}
		String fn = path.getFileName().toString();
		int index = fn.lastIndexOf('.');
		return index != -1 ? fn.substring(0, index) : fn;
	}

	public static String readFirstLine(String uri, Charset charset) throws IOException {
		List<String> lines = readLines(uri, charset);
		return lines == null || lines.size() == 0 ? null : lines.get(0);
	}

	// http://msdn.microsoft.com/en-us/library/aa365247%28v=vs.85%29.aspx#file_and_directory_names
	public static String reformFileName(String fileName) {
		if (fileName != null) {
			char[] chars = fileName.toCharArray();
			boolean fixed = false;
			for (int i = 0, n = chars.length; i < n; i++) {
				char ch = chars[i];
				if (ch == '<' || ch == '>' || ch == ':' || ch == '"' || ch == '/' || ch == '\\' || ch == '|' || ch == '?' || ch == '*') {
					chars[i] = '_';
					fixed = true;
				}
			}
			return fixed ? new String(chars) : fileName;
		}
		return fileName;
	}

	public static String reformFileName(String fileName, char replacement) {
		if (fileName != null) {
			char[] chars = fileName.toCharArray();
			boolean fixed = false;
			for (int i = 0, n = chars.length; i < n; i++) {
				char ch = chars[i];
				if (ch == '<' || ch == '>' || ch == ':' || ch == '"' || ch == '/' || ch == '\\' || ch == '|' || ch == '?' || ch == '*') {
					chars[i] = replacement;
					fixed = true;
				}
			}
			return fixed ? new String(chars) : fileName;
		}
		return fileName;
	}
	
}

