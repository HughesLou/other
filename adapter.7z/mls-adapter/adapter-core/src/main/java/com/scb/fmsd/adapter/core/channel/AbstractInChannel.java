package com.scb.fmsd.adapter.core.channel;

import com.scb.fmsd.adapter.core.model.MessageObject;

public abstract class AbstractInChannel<T> extends AbstractChannel<T> implements InChannel<T> {

	private ChannelMessageListener listener;

	public AbstractInChannel(String name) {
		super(name);
	}

	@Override
	public void setChannelMessageListener(ChannelMessageListener listener) {
		this.listener = listener;
	}

	public void onMessage(MessageObject message) throws Exception {
		if (listener != null) {
			listener.onMessage(message, this);
		}
	}

	protected MessageObject convert(T message) throws Exception {
		if (converter != null) {
			return converter.convert(message);
		} else {
			throw new UnsupportedOperationException("Convertor not specified for [" + getName() + "] channel");
		}
	}

}
