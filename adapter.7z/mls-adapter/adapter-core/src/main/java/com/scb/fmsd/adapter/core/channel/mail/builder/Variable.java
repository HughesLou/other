package com.scb.fmsd.adapter.core.channel.mail.builder;

import com.scb.fmsd.adapter.core.model.MessageObject;

public interface Variable {
	public String resolve(MessageObject mo);
}
