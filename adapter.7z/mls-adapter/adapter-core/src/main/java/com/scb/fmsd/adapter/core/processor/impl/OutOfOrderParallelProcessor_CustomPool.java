package com.scb.fmsd.adapter.core.processor.impl;

import java.util.concurrent.ArrayBlockingQueue;

import com.scb.fmsd.adapter.core.processor.Processor;
import com.scb.fmsd.adapter.core.utils.NamedThreadFactory;
import com.scb.fmsd.common.config.Configuration;

public class OutOfOrderParallelProcessor_CustomPool extends OutOfOrderParallelProcessor {

	public OutOfOrderParallelProcessor_CustomPool(Processor processor, int threads, int size) {
		super(processor, threads, size, new CustomerExecutorService(threads,
				new ArrayBlockingQueue<Runnable>(size),
				new NamedThreadFactory("ParallelProcessor")));
	}

	@Override
	public void initialize() {
		super.initialize();
		((CustomerExecutorService) executor).prestartAllCoreThreads();
	}

	public static OutOfOrderParallelProcessor_CustomPool create(String name, Configuration config, Processor processor) throws Exception {
		int workers = config.getInt("threads", Runtime.getRuntime().availableProcessors());
		int queueSize = config.getInt("queueSize", 1);
		return new OutOfOrderParallelProcessor_CustomPool(processor, workers, queueSize);
	}
}
