package com.scb.fmsd.adapter.core.dispatcher.impl;

import com.scb.fmsd.adapter.core.channel.InChannel;
import com.scb.fmsd.adapter.core.channel.TransactionSupport;
import com.scb.fmsd.adapter.core.dispatcher.recovery.RecoveryChannel;
import com.scb.fmsd.adapter.core.event.EventManager;
import com.scb.fmsd.adapter.core.model.BatchMesageObject;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.model.MessageObjectPropertyKey;
import com.scb.fmsd.adapter.core.processor.CompletionCallback;
import com.scb.fmsd.adapter.core.processor.ParallelProcessor;
import com.scb.fmsd.adapter.core.recovery.*;
import com.scb.fmsd.common.jmx.JMXBeanOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.util.List;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.SortedMap;

public class DispatcherImpl extends RouterImpl implements CompletionCallback, Recoverable<MessageObject>, FaultTolerable<MessageObject> {

	private final static Logger logger = LoggerFactory.getLogger(DispatcherImpl.class);

	private RecoveryManager<MessageObject> recoveryManager;
	private FaultToleranceManager<MessageObject> faultToleranceManager;

	public DispatcherImpl(String name, EventManager eventManager) {

		super(name, eventManager);
	}

	public FaultToleranceManager<MessageObject> getFaultToleranceManager() {
		return faultToleranceManager;
	}

	public RecoveryManager<MessageObject> getRecoveryManager() {
		return recoveryManager;
	}

	@Override
	public void setFaultToleranceManager(FaultToleranceManager<MessageObject> faultToleranceManager) {
		this.faultToleranceManager = faultToleranceManager;
	}

	@Override
	public void setRecoveryManager(RecoveryManager<MessageObject> recoveryManager) {
		this.recoveryManager = recoveryManager;
		if (recoveryManager != null) {
			sources.add(0, new RecoveryChannel(recoveryManager));
		}
	}

	@Override
	public void onMessage(MessageObject message, InChannel<?> channel) throws Exception {
		Objects.requireNonNull(channel, "channel is NULL");
		if (logger.isDebugEnabled()) {
			logger.debug("Got {} from {}", message.getMessageId(), channel.getName());
		}
		processMessage(message);
		if (channel instanceof TransactionSupport) {
			((TransactionSupport) channel).commit();
		}
	}

	private void processMessage(MessageObject message) throws Exception {
		Objects.requireNonNull(message, "message is NULL");
		long timestamp = System.currentTimeMillis();
		MDC.clear();
		MDC.put(MessageObjectPropertyKey.MESSAGE_ID.getKey(), message.getMessageId());
		MDC.put(MessageObjectPropertyKey.ARRIVAL_TIMESTAMP_NAME.getKey(), timestamp + "");
		message.addProperty(MessageObjectPropertyKey.ARRIVAL_TIMESTAMP_NAME.getKey(), timestamp);
		if (message instanceof BatchMesageObject) {
			BatchMesageObject batch = (BatchMesageObject) message;
			for (MessageObject m : batch) {
				handleMessage(m);
			}
		} else {
			handleMessage(message);
		}
	}

	protected void addCustomMDCFields(MessageObject message) {
	}

	protected void handleMessage(MessageObject message) throws Exception {
        addCustomMDCFields(message);
        if (!isFailedMessage(message)) {
			try {
				if (processor instanceof ParallelProcessor) {
					if (startTransaction(message)) {
						((ParallelProcessor) processor).process(message, this);
					} else {
						String msg = "The transcation already started, skip processing.";
						logger.error(msg);
						// handling as an error, but won't add it to fail queue
						handleException(new Exception(msg), message);
					}
				} else {
					onReadyToDispatch(processor.process(message), message);
				}
			} catch (Exception e) {
				failed(e, message);
			}
		} else {
			logger.info("Message {} will be put into unprocessed queue, due to previous msg failed. ", message.getMessageId());
			addToFailedMsgQueue(message);
			handleException(new Exception("Unprocessed Message"), message);
		}
	}

	private void addToFailedMsgQueue(MessageObject message) {
		if (faultToleranceManager != null) {
			try {
				faultToleranceManager.addFailedMessageToQueue(message);
			} catch (Exception e) {
				logger.error("Message {} was failed to added to error queue, ", message.getMessageId(), e);
				throw new RuntimeException(e);
			}
		}
	}

	private boolean isFailedMessage(MessageObject message) {
		if (faultToleranceManager != null) {
			return faultToleranceManager.isFailedMessage(message);
		}
		return false;
	}

	@Override
	public void failed(Throwable e, MessageObject message) {
		addToFailedMsgQueue(message);
		rollbackTransaction(message);
		handleException(e, message);
	}

	protected void onReadyToDispatch(MessageObject result, MessageObject original) throws Exception {
		dispatch(result, original);
	}

	/*
	 * Due to fault tolerance, even if the message have been processed
	 * successfullly, will not dispatch result to outputChannel, message will be
	 * added to unprocessed queue.
	 * 
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.scb.fmsd.adapter.core.processor.CompletionCallback#completed(com.
	 * scb.fmsd.adapter.core.model.MessageObject,
	 * com.scb.fmsd.adapter.core.model.MessageObject)
	 */
	@Override
	public void completed(MessageObject result, MessageObject original) {
		if (!isFailedMessage(original)) {
			try {
				onReadyToDispatch(result, original);
				commitTransaction(original);
			} catch (Exception e) {
				failed(e, original);
			}
		} else {
			logger.info("Processed message {} will be put into error queue, due to previous msg failed. ", original.getMessageId());
			failed(new Exception("Unprocessed Message"), original);
		}
	}

	protected boolean startTransaction(MessageObject message) throws RecoveryException {
		if (recoveryManager != null) {
			if (!recoveryManager.isTransacted(message)) {
				recoveryManager.startTransaction(message);
				return true;
			} else {
				// recover from Recovery, will not check its transaction status.
				Object recovered = message.getProperty("RECOVERY");
				if (recovered != null && recovered.toString().equals("true")) {
					MDC.put("FROM_RECOVERY", "yes");
					return true;
				}
				;
				logger.error("The transaction had already started.");
				return false;
			}
		}
		return true;
	}

	private void commitTransaction(MessageObject message) throws RecoveryException {
		if (recoveryManager != null) {
			recoveryManager.commit(message);
		}
	}

	private void rollbackTransaction(MessageObject message) {
		if (recoveryManager != null) {
			try {
				recoveryManager.rollback(message);
			} catch (RecoveryException te) {
				logger.error("Rollback failed, messageId={} ", message.getMessageId(), te);
			}
		}
	}

	@JMXBeanOperation
	@Override
	public void retryFailureMessages(List<String> messageIgnoreList) throws Exception {
		if (faultToleranceManager != null) {
			try {
				faultToleranceManager.removeMessagesFromErrorQueue(messageIgnoreList);
				
				SortedMap<Long, String> map = faultToleranceManager.getAllMessageFileMapping();
				for (Entry<Long, String> entry : map.entrySet()) {
					MessageObject retrMsg = faultToleranceManager.getAndRemoveMessageFromErrorQueue(entry.getKey(), entry.getValue());
					if (retrMsg != null) {
						retrMsg.addProperty(MessageObjectPropertyKey.RETRY.getKey(), true);
						processMessage(retrMsg);
					}
				}
			} finally {
				faultToleranceManager.refreshAllToIndexFile();
			}
		}
	}

}
