package com.scb.fmsd.adapter.core.processor;

import java.util.Properties;
import java.util.Set;

import com.scb.fmsd.adapter.core.model.MessageObject;

public interface CorrelationKey {
	Object getKey(MessageObject message);
	Set<Object> getKeys(MessageObject message);
	Properties getProperties(MessageObject message);
}
