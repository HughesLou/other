package com.scb.fmsd.adapter.core.channel;

import com.scb.fmsd.adapter.core.model.MessageObject;

public interface MessageConverter<T> {
	public MessageObject convert(T message) throws Exception;
	public T convert(MessageObject message, OutChannel<?> channel) throws Exception;
}
