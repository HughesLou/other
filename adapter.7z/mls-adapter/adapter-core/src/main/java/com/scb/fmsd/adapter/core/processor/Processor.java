package com.scb.fmsd.adapter.core.processor;

import com.scb.fmsd.adapter.core.ShutdownAware;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.common.jmx.JMXMBean;

public interface Processor extends JMXMBean, ShutdownAware {
	public MessageObject process(MessageObject message) throws Exception;
	public void initialize() throws Exception;
}
