package com.scb.fmsd.adapter.core.dispatcher.filters;

import com.scb.fmsd.adapter.core.model.MessageObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.script.*;

public class JSFilter implements Filter {

    private static final Logger logger = LoggerFactory.getLogger(JSFilter.class);

    private final ScriptEngine engine;

    private final CompiledScript script;

    private final String expression;

    public JSFilter(String expression) throws ScriptException {
        this.expression = expression;
        engine = new ScriptEngineManager().getEngineByName("javascript");
        if (engine instanceof Compilable) {
            script = ((Compilable) engine).compile(expression);
        } else {
            script = null;
        }
    }

    @Override
    public boolean accept(MessageObject mo) {
        SimpleBindings bindings = new SimpleBindings();
        bindings.putAll(mo.getProperties());
        boolean accepted = false;
        try {
            accepted = (boolean) (script == null ? engine.eval(expression, bindings) : script.eval(bindings));
        } catch (ScriptException e) {
            logger.warn(e.getMessage());
        }
        // when message is filtered, print out message properties to help diagnosis
        if (!accepted) {
            logger.debug("expression: {}; bindings: {}", expression, mo.getProperties());
        }
        return accepted;
    }
}
