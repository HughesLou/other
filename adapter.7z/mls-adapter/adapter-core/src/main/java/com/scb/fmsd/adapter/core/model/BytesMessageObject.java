package com.scb.fmsd.adapter.core.model;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.Map;

public class BytesMessageObject extends AbstractMessageObject<byte[]> {

	private String message;

	public BytesMessageObject() {
	}

	public BytesMessageObject(byte[] payload) {
		super(payload, "MSG-" + System.currentTimeMillis());
	}

	public BytesMessageObject(byte[] payload, String messageId) {
		super(payload, messageId);
	}

	public BytesMessageObject(byte[] payload, String messageId, Map<String, Object> props) {
		super(payload, messageId, props);
	}

	@Override
	public String getText() {
		if (message == null) {
			message = new String(getPayload());
		}
		return message;
	}

	@Override
	public byte[] getBytes() {
		return getPayload();
	}

    @Override
    public boolean isBatchMessage() {
        return false;
    }

    @Override
	public void serialize(DataOutputStream out) throws Exception {
		super.serialize(out);
		byte[] buffer = getPayload();
		out.writeInt(buffer.length);
		out.write(buffer);
	}

	@Override
	public MessageObject deserialize(DataInputStream in) throws Exception {
		super.deserialize(in);
		int len = in.readInt();
		byte[] payload = new byte[len];
		in.read(payload);
		setPayload(payload);
		return this;
	}

}
