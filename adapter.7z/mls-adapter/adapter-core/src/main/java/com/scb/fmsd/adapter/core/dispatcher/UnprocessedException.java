package com.scb.fmsd.adapter.core.dispatcher;

public class UnprocessedException extends Exception {

	private static final long serialVersionUID = 1L;

	public UnprocessedException() {
	}

	public UnprocessedException(String message) {
		super(message);
	}

	public UnprocessedException(Throwable cause) {
		super(cause);
	}

	public UnprocessedException(String message, Throwable cause) {
		super(message, cause);
	}

}
