package com.scb.fmsd.adapter.core.channel.direct;

import com.scb.fmsd.adapter.core.channel.AbstractInChannel;
import com.scb.fmsd.adapter.core.model.MessageObject;

public class DirectChannel extends AbstractInChannel<MessageObject> {

	public DirectChannel() {
		super("Direct");
	}

	public void send(MessageObject message) throws Exception {
		onMessage(message);
	}

}
