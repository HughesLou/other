package com.scb.fmsd.adapter.core.channel.log;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.PatternLayout;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.rolling.DefaultTimeBasedFileNamingAndTriggeringPolicy;
import ch.qos.logback.core.rolling.RollingFileAppender;
import ch.qos.logback.core.rolling.TimeBasedRollingPolicy;

import com.scb.fmsd.adapter.core.channel.AbstractOutChannel;
import com.scb.fmsd.adapter.core.model.CompressedMessageObject;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.common.config.Configuration;
import com.scb.fmsd.common.jmx.JMXBeanAttribute;

public class LogChannel extends AbstractOutChannel<Object> {

	protected final Logger logger;

	private String fileName;

	public LogChannel(String name) {
		super(name);
		this.logger = LoggerFactory.getLogger(name);
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	@JMXBeanAttribute
	public String getFileName() {
		return fileName;
	}

	@Override
	public void send(MessageObject message) throws Exception {
        if (message.hasProperty("COMPRESSED")) {
            message = new CompressedMessageObject(message);
        }
        if (logger.isDebugEnabled()) {
            logger.debug("{}", message.getPayload().toString());
        } else {
            logger.info("Logging");
        }
	}

	@Override
	protected void doInitialize() throws Exception {
		if (fileName == null) {
			return;
		}

		LoggerContext context = (LoggerContext) LoggerFactory.getILoggerFactory();

		PatternLayout layout = new PatternLayout();
		layout.setContext(context);
		layout.setPattern("%d{HH:mm:ss.SSS} [%thread] %-5level %logger{16} %X{MESSAGE_ID} %X{TRADES} - %msg%n");

		TimeBasedRollingPolicy<ILoggingEvent> rollingPolicy = new TimeBasedRollingPolicy<>();
		rollingPolicy.setContext(context);
		rollingPolicy.setFileNamePattern(fileName + ".%d{yyyy-MM-dd}.gz");
		rollingPolicy.setMaxHistory(7);

		DefaultTimeBasedFileNamingAndTriggeringPolicy<ILoggingEvent> triggeringPolicy = new DefaultTimeBasedFileNamingAndTriggeringPolicy<ILoggingEvent>();
		triggeringPolicy.setContext(context);
		triggeringPolicy.setTimeBasedRollingPolicy(rollingPolicy);

		RollingFileAppender<ILoggingEvent> appender = new RollingFileAppender<>();
		appender.setContext(context);
		appender.setFile(fileName);
		appender.setAppend(true);
		appender.setLayout(layout);
		appender.setRollingPolicy(rollingPolicy);
		appender.setTriggeringPolicy(triggeringPolicy);

		rollingPolicy.setParent(appender);

		layout.start();
        rollingPolicy.start();
        triggeringPolicy.start();

        appender.start();

        ch.qos.logback.classic.Logger logbackLogger = (ch.qos.logback.classic.Logger) logger;
        logbackLogger.setAdditive(false);
        logbackLogger.addAppender(appender);
	}

	public static LogChannel create(String name, Configuration config) {
		LogChannel channel = new LogChannel(name);
		channel.setFileName(config.getString("fileName", null));
		return channel;
	}

}
