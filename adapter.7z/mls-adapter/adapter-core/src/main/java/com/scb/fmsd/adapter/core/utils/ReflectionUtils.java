package com.scb.fmsd.adapter.core.utils;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Set;

import org.reflections.Reflections;
import org.reflections.util.ClasspathHelper;
import org.reflections.util.ConfigurationBuilder;

import com.scb.fmsd.common.config.Configuration;

public abstract class ReflectionUtils {

	private ReflectionUtils() {
	}

	public static <E, T> Set<Class<? extends T>> getSubTypesOf(Class<T> type) {
		Reflections r = new Reflections(new ConfigurationBuilder().setUrls(ClasspathHelper.forClass(type)));
		return r.getSubTypesOf(type);
	}
	
	public static boolean isAbstract(Class<?> type) {
		return Modifier.isAbstract(type.getModifiers());
	}

	@SuppressWarnings("unchecked")
	public static <T> T newInstance(String className, String name, Configuration config) throws Exception {
		Class<?> type = Class.forName(className);
		Method create = type.getMethod("create", String.class, Configuration.class);
		return (T) create.invoke(null, name, config);
	}

	@SuppressWarnings("unchecked")
	public static <T> T newInstance(Class<T> type, String name, Configuration config) throws Exception {
		Method create = type.getMethod("create", String.class, Configuration.class);
		return (T) create.invoke(null, name, config);
	}
	
	public static <T> void setProperties(T bean, Configuration config) throws Exception {
		for (Method m : bean.getClass().getMethods()) {
			String name = m.getName();
			if (name.startsWith("set") && m.getParameterTypes().length == 1) {
				name = Character.toLowerCase(name.charAt(3)) + name.substring(4);
				if (config.exists(name)) {
					Class<?> param = m.getParameterTypes()[0];
					if (param.equals(String.class)) {
						m.invoke(bean, config.getString(name));
					} else if (param.equals(int.class)) {
						m.invoke(bean, config.getInt(name));
					} else if (param.equals(long.class)) {
						m.invoke(bean, config.getLong(name));
					} else if (param.equals(boolean.class)) {
						m.invoke(bean, config.getBoolean(name));
					} else {
						throw new UnsupportedOperationException(m.getName());
					}
				}
			}
		}
	}
}
