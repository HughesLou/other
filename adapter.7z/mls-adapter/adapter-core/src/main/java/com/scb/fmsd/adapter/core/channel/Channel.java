package com.scb.fmsd.adapter.core.channel;

import com.scb.fmsd.adapter.core.Service;
import com.scb.fmsd.adapter.core.ShutdownAware;
import com.scb.fmsd.common.jmx.JMXBeanAttribute;
import com.scb.fmsd.common.jmx.JMXBeanOperation;
import com.scb.fmsd.common.jmx.JMXMBean;

public interface Channel<T> extends ShutdownAware, JMXMBean, Service {

	public void setMessageConverter(MessageConverter<T> converter);
	public void setChannelListener(ChannelListener listener);

	@JMXBeanAttribute
	public String getName();

	public void initialize() throws Exception;

	@JMXBeanOperation
	public void start() throws Exception;

	@JMXBeanOperation
	public void stop();
}
