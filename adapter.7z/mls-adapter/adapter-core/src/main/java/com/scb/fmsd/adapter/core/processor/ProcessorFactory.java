package com.scb.fmsd.adapter.core.processor;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.fmsd.adapter.core.utils.ReflectionUtils;
import com.scb.fmsd.common.config.Configuration;

public final class ProcessorFactory {

    public static final String PROCESSOR_CONFIG_KEY = "processor";

    public static final String PROCESSOR_CLASS = "class";

    public static final String PROCESSOR_TYPE = "type";

    private static final Logger logger = LoggerFactory.getLogger(ProcessorFactory.class);

	private static final Map<String, Class<? extends Processor>> types = new HashMap<>();

	static {
		Set<Class<? extends Processor>> set = ReflectionUtils.getSubTypesOf(Processor.class);
		for (Class<? extends Processor> type : set) {
			if (!ReflectionUtils.isAbstract(type)) {
				registerProcessor(type);
			}
		}
	}

	public static void registerProcessor(Class<? extends Processor> type) {
		types.put(type.getSimpleName(), type);
		logger.debug("Processor registered: {}", type.getSimpleName());
	}

	private ProcessorFactory() {}

	@SuppressWarnings("unchecked")
	public static Processor create(String name, Configuration config) throws Exception {
		Configuration subset = config.subset("processor." + name);
		String type = subset.getString(PROCESSOR_TYPE, "");
		Class<? extends Processor> claz = types.get(type);
		if (claz == null) {
			claz = (Class<? extends Processor>) Class.forName(subset.getString(PROCESSOR_CLASS));
		}

		if (subset.exists(PROCESSOR_CONFIG_KEY)) {
			name = subset.getString(PROCESSOR_CONFIG_KEY);
			Processor p = create(name, config);
			Method create = claz.getMethod("create", String.class, Configuration.class, Processor.class);
			return (Processor) create.invoke(null, name, subset, p);
		} else {
			return ReflectionUtils.newInstance(claz, name, subset);
		}
	}

}
