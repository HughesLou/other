package com.scb.fmsd.adapter.core.recovery.impl;

import com.google.common.collect.ComparisonChain;


public class UnprocessedMessageInfo  implements Comparable<UnprocessedMessageInfo> {
	private Long arrivalTime;
	private String messageName;
	
	public UnprocessedMessageInfo(Long arrivalTime, String messageName) {
		this.arrivalTime = arrivalTime;
		this.messageName = messageName;
	}

	public Long getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(Long arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public String getMessageName() {
		return messageName;
	}

	public void setMessageName(String messageName) {
		this.messageName = messageName;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((arrivalTime == null) ? 0 : arrivalTime.hashCode());
		result = prime * result + ((messageName == null) ? 0 : messageName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof UnprocessedMessageInfo))
			return false;
		UnprocessedMessageInfo other = (UnprocessedMessageInfo) obj;
		if (arrivalTime == null) {
			if (other.arrivalTime != null)
				return false;
		} else if (!arrivalTime.equals(other.arrivalTime))
			return false;
		if (messageName == null) {
			if (other.messageName != null)
				return false;
		} else if (!messageName.equals(other.messageName))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "UnprocessedMessageInfo [arrivalTime=" + arrivalTime + ", messageName=" + messageName + "]";
	}
	
	@Override
	public int compareTo(UnprocessedMessageInfo other) {
		if (this == other) {
			return 0;
		}
		return ComparisonChain.start().compare(arrivalTime, other.arrivalTime).result();
	}	
	
}
