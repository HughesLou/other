package com.scb.fmsd.adapter.core.channel.jms;

import java.util.Objects;
import java.util.Properties;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.ExceptionListener;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.Session;
import javax.jms.Topic;
import javax.naming.InitialContext;

import org.apache.commons.lang3.StringUtils;

import com.scb.fmsd.adapter.core.channel.AbstractInChannel;
import com.scb.fmsd.adapter.core.channel.MessageConverter;
import com.scb.fmsd.adapter.core.channel.TransactionSupport;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.utils.Decryptor;
import com.scb.fmsd.common.config.Configuration;
import com.scb.fmsd.common.jmx.JMXBeanAttribute;

public class JmsListener extends AbstractInChannel<Message>
	implements MessageListener, ExceptionListener, TransactionSupport {

    public static final String PASSWORD = "password";

    public static final String USERNAME = "username";
    
    public static final String DECRYPTOR = "decryptor";

    public static final String TRANSACTED = "transacted";

    public static final String SELECTOR = "selector";

    public static final String SUBSCRIPTION_NAME = "subscriptionName";

    public static final String CLIENT_ID = "clientId";

    public static final String DESTINATION_NAME = "destinationName";

    public static final String CONNECTION_FACTORY = "connectionFactory";

    public static final String JNDI_KEY = "jndi";
    
    public static final String SOURCE_TAG = "sourceTag";

    private String clientId;

	private String subscriptionName;

	private String selector;

    private String username;

    private String password;

	private boolean transacted = Boolean.FALSE;

	private ConnectionFactory connectionFactory;

	private Destination destination;

	private volatile Connection connection;

	private volatile Session session;

	private volatile MessageConsumer messageConsumer;
	
	private String sourceTag;

    public JmsListener(String name) {
        this(name, new JMSMessageConverter());
    }

    public JmsListener(String name, MessageConverter<Message> messageConverter) {
        super(name);
        setMessageConverter(messageConverter);
    }

	public ConnectionFactory getConnectionFactory() {
		return connectionFactory;
	}

	public void setConnectionFactory(ConnectionFactory connectionFactory) {
		this.connectionFactory = connectionFactory;
	}

	@JMXBeanAttribute(useToString = true)
	public Destination getDestination() {
		return destination;
	}

	public void setDestination(Destination destination) {
		this.destination = destination;
	}

	@JMXBeanAttribute
	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	@JMXBeanAttribute
	public String getSubscriptionName() {
		return subscriptionName;
	}

	public void setSubscriptionName(String subscriptionName) {
		this.subscriptionName = subscriptionName;
	}

	@Override
	public boolean isTransacted() {
		return transacted;
	}

	public void setTransacted(boolean transacted) {
		this.transacted = transacted;
	}

	@JMXBeanAttribute
	public String getSelector() {
		return selector;
	}

	public void setSelector(String selector) {
		this.selector = selector;
	}

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	public Session getSession() {
		return session;
	}

	public void setSession(Session session) {
		this.session = session;
	}

	public MessageConsumer getMessageConsumer() {
		return messageConsumer;
	}

	public void setMessageConsumer(MessageConsumer messageConsumer) {
		this.messageConsumer = messageConsumer;
	}

	private static boolean isSubscription(String clientId, String subscriptionName) {
		return clientId != null && !"".equals(clientId)
				&& subscriptionName != null && !"".equals(subscriptionName);
	}

	private static boolean isTopic(Destination destination) {
		return destination instanceof Topic;
	}
	
	public String getSourceTag() {
        return sourceTag;
    }

    public void setSourceTag(String sourceTag) {
        this.sourceTag = sourceTag;
    }

	@Override
	public void commit() throws JMSException {
		Objects.requireNonNull(session, "JMS session is NULL");
		if (session.getTransacted()) {
			session.commit();
		}
	}

	@Override
	public void rollback() throws JMSException {
		Objects.requireNonNull(session, "JMS session is NULL");
		if (session.getTransacted()) {
			session.rollback();
		}
	}

	@Override
	protected void doInitialize() {
		Objects.requireNonNull(getConnectionFactory(), "'connectionFactory' is null!");
		Objects.requireNonNull(getDestination(), "'destination' is null!");
	}

    @Override
    protected void doStart() throws JMSException {
        try{
            // add support for username and password
            if (username != null && password != null) {
                connection = connectionFactory.createConnection(username, password);
            } else {
                connection = connectionFactory.createConnection();
            }
    
            if(!StringUtils.isEmpty(connection.getClientID())){
                logger.warn("Connection factory was built implicitely with client id " + connection.getClientID());
            }
    
            // clinetId must be set first
            if (!StringUtils.isEmpty(clientId) && StringUtils.isEmpty(connection.getClientID())) {
                connection.setClientID(clientId);
            }

    
            connection.setExceptionListener(this);
            session = connection.createSession(transacted, Session.AUTO_ACKNOWLEDGE);
    
            if (isTopic(destination) && isSubscription(clientId, subscriptionName)) {
                messageConsumer = session.createDurableSubscriber((Topic) destination, subscriptionName, selector, false);
            } else {
                messageConsumer = session.createConsumer(destination, selector, false);
            }
            
            messageConsumer.setMessageListener(this);
            connection.start();
        } catch (JMSException e) {
            if(e.getLinkedException() != null){
                logger.error(e.getLinkedException().getMessage(), e.getLinkedException());
            }
            throw e;
        }
    }

	@Override
	protected void doStop() {
		if (connection != null) {
			try { connection.close(); } catch (JMSException ignore) {}
			connection = null;
		}
	}

	@Override
	public void onMessage(Message msg) {
		logger.debug("Got {}", msg);
		try {
			MessageObject msgObj = convert(msg);
			if (sourceTag != null){
				msgObj.addProperty("SOURCETAG", sourceTag);
			}
			onMessage(msgObj);
		} catch (Exception e) {
			try { rollback(); } catch (JMSException ignore) {}
			throw new RuntimeException("Failed to process message\n" + msg, e);
		}
	}

	@Override
	public void onException(JMSException ex) {
		int attempt = 0;
		Exception error = ex;
		logger.error("An exception occured, trying to (re)connect", ex);
		while (!shutdown && nextRetryAttempt(attempt++)) {
			waitRetryAttemp();
			try {
				restart();
				return;
			} catch (Exception e) {
				error = e;
			}
		}

		if (!shutdown) {
			if (getRetryAttempts() != 0) {
				logger.error("Failed to (re)connect after {} attempts, error={}", attempt, error);
			}
			onException(error);
			try { stop(); } catch (Exception ignore) {}
		}
	}

	@Override
	public String toString() {
		return "JmsListener [connection=" + connection
				+ ", destination=" + destination
				+ ", clientId=" + clientId
				+ ", subscriptionName=" + subscriptionName
				+ ", transacted=" + transacted
				+ ", selector=" + selector
				+ ", converter=" + converter + "]";
	}

	public static JmsListener create(String name, Configuration config) throws Exception {
		return create(JmsListener.class, name, config);
	}

	public static <T extends JmsListener> T create(Class<T> claz, String name, Configuration config) throws Exception {
		return configure(claz.getConstructor(String.class).newInstance(name), config);
	}

	public static <T extends JmsListener> T configure(T listener, Configuration config) throws Exception {
        listener.init(config);
		return listener;
	}

    protected final void init(Configuration config) throws Exception {
        Properties props = config.subset(JNDI_KEY).asProperties();
        javax.naming.Context ctx = new InitialContext(props);

        setUsername(config.getString(USERNAME, null));          
        if(config.getString(DECRYPTOR, null) != null){
        	Decryptor decryptor = (Decryptor) Class.forName(config.getString(DECRYPTOR)).newInstance();
        	setPassword(decryptor.decrypt(config.getString(PASSWORD, null)));
        }else{
        	setPassword(config.getString(PASSWORD, null));
        }
        
        setConnectionFactory((ConnectionFactory) ctx.lookup(config.getString(CONNECTION_FACTORY)));
        setDestination((Destination) ctx.lookup(config.getString(DESTINATION_NAME)));
        setClientId(config.getString(CLIENT_ID, null));
        setSubscriptionName(config.getString(SUBSCRIPTION_NAME, null));
        setSelector(config.getString(SELECTOR, null));
        setTransacted(config.getBoolean(TRANSACTED, Boolean.FALSE));
        setSourceTag(config.getString(SOURCE_TAG,null));
    }

}
