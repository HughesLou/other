package com.scb.fmsd.adapter.core.processor.impl;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.FutureTask;
import java.util.concurrent.RunnableFuture;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.processor.AbstractParallelProcessor;
import com.scb.fmsd.adapter.core.processor.CompletionCallback;
import com.scb.fmsd.adapter.core.processor.Processor;
import com.scb.fmsd.adapter.core.utils.NamedThreadFactory;
import com.scb.fmsd.common.config.Configuration;

/**
 * This parallel processor preserves ordering, that's the messages
 * go out in the arrival order but processed in parallel
 *
 */
public class OrderedParallelProcessor extends AbstractParallelProcessor {

	private static final Logger logger = LoggerFactory.getLogger(OrderedParallelProcessor.class);

	final ExecutorService executor;

	final BlockingQueue<FutureTaskEx> futures;

	final Ordering ordering;

	public OrderedParallelProcessor(Processor processor, int threads, int size) {
		this(processor, threads, size, new ThreadPoolExecutor(
				threads, threads, 0L, TimeUnit.SECONDS,
				new ArrayBlockingQueue<Runnable>(size),
				new NamedThreadFactory("ParallelProcessor"),
				new AbortIfShutdownPolicy()) {
			@SuppressWarnings("unchecked")
			@Override
			protected <T> RunnableFuture<T> newTaskFor(Callable<T> callable) {
				return (RunnableFuture<T>) new FutureTaskEx((Task) callable);
			}
		});
	}

	public OrderedParallelProcessor(Processor processor, int threads, int size, ExecutorService executor) {
		super(processor, threads, size);
		this.futures = new ArrayBlockingQueue<>(size + threads);
		this.ordering = new Ordering(futures);
		this.executor = executor;
	}
	
	@Override
	public int getWorkingQueueSize(){
		return futures.size();
	}
	
	@Override
	public void initialize() {
		Objects.requireNonNull(processor);
		if (executor instanceof ThreadPoolExecutor) {
			((ThreadPoolExecutor) executor).prestartAllCoreThreads();
		}
		ordering.start();
	}

	@Override
	//@Statistic(type={Throughput,Latency,CurrentQueueSize})
	public void process(final MessageObject message, final CompletionCallback callback) throws Exception {
        logger.info("Processing {} ", message.getMessageId() );
	    Task t = new Task(processor, message, callback);
		futures.put((FutureTaskEx) executor.submit(t));
	}

	static class FutureTaskEx extends FutureTask<MessageObject> {
		final Task task;
		public FutureTaskEx(Task task) {
			super(task);
			this.task = task;
		}
	}

	static class Task implements Callable<MessageObject> {
		final MessageObject message;
		final CompletionCallback callback;
		final Processor processor;

		public Task(Processor processor, MessageObject message, CompletionCallback callback) {
			this.processor = processor;
			this.message = message;
			this.callback = callback;
		}

		@Override
		public MessageObject call() throws Exception {
			return processor.process(message);
		}
	}

	@Override
	public List<MessageObject> shutdownNow() {
		executor.shutdownNow();
		try {
			if (!executor.awaitTermination(10, TimeUnit.SECONDS)) {
				logger.info("Executor shutdown timeout");
			}
		} catch (InterruptedException e) {
			logger.info("Executor shutdown interrupted");
		}
		try {
			if (!ordering.shutdown(10, TimeUnit.SECONDS)) {
				logger.info("Ordering shutdown timeout");
			}
		} catch (InterruptedException e) {
			logger.info("Ordering shutdown interrupted");
		}

		Map<String, MessageObject> map = new LinkedHashMap<>();
		FutureTaskEx f;
		while ((f = futures.poll()) != null) {
			MessageObject mo = f.task.message;
			map.put(mo.getMessageId(), mo);
			logger.warn("Unprocessed message: {}", mo.getMessageId());
		}

		return new ArrayList<>(map.values());
	}

	static class Ordering extends Thread {
		private volatile boolean stopped = false;
		private final CountDownLatch isStopped = new CountDownLatch(1);
		private final BlockingQueue<FutureTaskEx> futures;

		public Ordering(BlockingQueue<FutureTaskEx> futures) {
			super("Reorderer");
			this.futures = futures;
		}

		@Override
		public void run() {
			logger.info("{} started", getName());
			while(!stopped) {
				try {
					FutureTaskEx f = futures.take();
					try {
						MessageObject mo = f.get();
						f.task.callback.completed(mo, f.task.message);
					} catch (Exception e) {
						f.task.callback.failed(e, f.task.message);
					}
					logger.debug("{} sent", f.task.message.getMessageId());
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
				}
			}
			isStopped.countDown();
			logger.info("{} stopped", getName());
		}

		public boolean shutdown(long time, TimeUnit unit) throws InterruptedException {
			stopped = true;
			interrupt();
			return isStopped.await(time, unit);
		}
	}

	public static OrderedParallelProcessor create(String name, Configuration config, Processor processor) {
		int workers = config.getInt("threads", Runtime.getRuntime().availableProcessors());
		int queueSize = config.getInt("queueSize", 1);
		return new OrderedParallelProcessor(processor, workers, queueSize);
	}
}
