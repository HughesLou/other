package com.scb.fmsd.adapter.core.channel.mail;

import java.util.Objects;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.scb.fmsd.adapter.core.channel.AbstractChannel;
import com.scb.fmsd.adapter.core.channel.OutChannel;
import com.scb.fmsd.adapter.core.channel.mail.builder.PatternSubjectBuilder;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.common.config.Configuration;
import com.scb.fmsd.common.jmx.JMXBeanAttribute;

public class MailSender extends AbstractChannel<MessageObject> implements OutChannel<MessageObject> {

	private Session session;

	private InternetAddress from;

	private InternetAddress[] recipients;

	private SubjectBuilder subjectBuilder;

	private final Configuration config;

	public MailSender(String name, Configuration config) {
		super(name);
		this.config = config;
	}

	@JMXBeanAttribute(useToString = true)
	public InternetAddress getFrom() {
		return from;
	}

	public void setFrom(InternetAddress from) {
		this.from = from;
	}

	@JMXBeanAttribute(useToString = true)
	public InternetAddress[] getRecipients() {
		return recipients;
	}

	public void setRecipients(InternetAddress[] recipients) {
		this.recipients = recipients;
	}

	public void setSubjectBuilder(SubjectBuilder subjectBuilder) {
		this.subjectBuilder = subjectBuilder;
	}

	public SubjectBuilder getSubjectBuilder() {
		return subjectBuilder;
	}

	@Override
	public void send(MessageObject mo) throws Exception {
		Objects.requireNonNull(session, "session is NULL");

		MimeMessage message = new MimeMessage(session);
		try {
			message.setFrom(from);
			message.setRecipients(Message.RecipientType.TO, recipients);
			message.setSubject(buildSubject(mo));
			message.setText(mo.getText());

			Transport.send(message);
		} catch (MessagingException e) {
			logger.error("Failed to send email\n" + message, e);
		}
	}

	protected String buildSubject(MessageObject mo) {
		return subjectBuilder.build(mo);
	}

	@Override
	protected void doInitialize() throws Exception {
		boolean auth = config.getBoolean("mail.smtp.auth", false);

		if (auth) {
			final String username = config.getString("username");
			final String password = config.getString("password");
			session = Session.getInstance(config.asProperties(), new javax.mail.Authenticator() {
				@Override
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(username, password);
				}
			});
		} else {
			session = Session.getInstance(config.asProperties());
		}
	}

	public static MailSender create(String name, Configuration config) throws Exception {
		PatternSubjectBuilder subjectBuilder = new PatternSubjectBuilder(config.getString("subject")) .compile();

		MailSender ms = new MailSender(name, config);
		ms.setSubjectBuilder(subjectBuilder);
		ms.setFrom(new InternetAddress(config.getString("from")));
		ms.setRecipients(InternetAddress.parse(config.getString("recipients")));
		return ms;
	}

}
