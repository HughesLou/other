package com.scb.fmsd.adapter.core.channel;

public interface InChannel<T> extends Channel<T> {
	public void setChannelMessageListener(ChannelMessageListener l);
}
