package com.scb.fmsd.adapter.core.dispatcher.recovery;

import java.util.Iterator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.fmsd.adapter.core.channel.AbstractInChannel;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.recovery.RecoveryManager;

public class RecoveryChannel extends AbstractInChannel<MessageObject> {

	private final static Logger logger = LoggerFactory.getLogger(RecoveryChannel.class);

	private final RecoveryManager<MessageObject> transactionManager;

	public RecoveryChannel(RecoveryManager<MessageObject> transactionManager) {
		super("RECOVERY");
		this.transactionManager = transactionManager;
	}

	@Override
	protected void doStart() throws Exception {
		if (transactionManager != null) {
			logger.info("Recovery strated");
			Iterator<MessageObject> it = transactionManager.unprocessed();
			while (it.hasNext()) {
				try {
					MessageObject message = it.next();
					message.addProperty("RECOVERY", true);
					message.addProperty("RECOVERY_STARTED", System.currentTimeMillis());
					logger.info("Recovering {}", message.getMessageId());
					onMessage(message);
				} catch (Exception e) {
					logger.error("Failed to recovery", e);
				}
			}
			logger.info("Recovery finished");
		}
	}

}
