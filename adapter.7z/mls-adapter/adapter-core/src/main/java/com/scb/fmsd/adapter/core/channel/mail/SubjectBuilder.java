package com.scb.fmsd.adapter.core.channel.mail;

import com.scb.fmsd.adapter.core.model.MessageObject;

public interface SubjectBuilder {
	public String build(MessageObject mo);
}
