package com.scb.fmsd.adapter.core.channel.log;

import com.scb.fmsd.adapter.core.model.CompressedMessageObject;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.common.config.Configuration;

public class ErrorLogChannel extends LogChannel {

	public ErrorLogChannel(String name) {
		super(name);
	}
	
	@Override
	public void send(MessageObject message) throws Exception {
		Throwable t = message.getError();
        if (message.hasProperty("COMPRESSED")) {
            message = new CompressedMessageObject(message);
        }
		if (t!=null){
			logger.error("ERROR: {}",  t.getMessage(), t);
			logger.debug("{}", message.getText());
		}
	}
	@Override
	protected void doInitialize() throws Exception {
		super.doInitialize();
	}
	
	public static ErrorLogChannel create(String name, Configuration config) {
		ErrorLogChannel channel = new ErrorLogChannel(name);
		channel.setFileName(config.getString("fileName", null));
		return channel;
	}
}
