package com.scb.fmsd.adapter.core.processor.impl;

import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.ThreadPoolExecutor.AbortPolicy;

class AbortIfShutdownPolicy extends AbortPolicy {
	@Override
	public void rejectedExecution(Runnable r, ThreadPoolExecutor e) {
		if (!e.isShutdown()) {
			r.run();
		} else {
			super.rejectedExecution(r, e);
		}
	}
}
