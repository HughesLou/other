package com.scb.fmsd.adapter.core;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.fmsd.adapter.core.channel.InChannel;
import com.scb.fmsd.adapter.core.channel.OutChannel;
import com.scb.fmsd.adapter.core.dispatcher.Dispatcher;
import com.scb.fmsd.adapter.core.event.EventManager;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.processor.ParallelProcessor;
import com.scb.fmsd.adapter.core.processor.Processor;
import com.scb.fmsd.adapter.core.processor.ProcessorFactory;
import com.scb.fmsd.adapter.core.recovery.FaultTolerable;
import com.scb.fmsd.adapter.core.recovery.FaultToleranceManager;
import com.scb.fmsd.adapter.core.recovery.Recoverable;
import com.scb.fmsd.adapter.core.recovery.RecoveryManager;
import com.scb.fmsd.adapter.core.utils.ReflectionUtils;
import com.scb.fmsd.common.config.Configuration;

public abstract class RouterApplication extends Application {

    public static final String ROUTER_DISPATCHER_CLASS = "class";

    public static final String ROUTER_DISPATCHER_KEY = "dispatcher";

    public static final String ROUTER_PROCESSOR_KEY = "processor";

    private final Logger logger = LoggerFactory.getLogger(getClass());

	private final List<OutChannel<?>> destinations = new ArrayList<>();

	private final List<InChannel<?>> sources = new ArrayList<>();

	public static final String OPTION_CHANNEL_FROM = "channel.from";
	public static final String OPTION_CHANNEL_TO = "channel.to";
	public static final String OPTION_CHANNEL_ERROR = "channel.error";

    public RouterApplication() {
        super();
    }

    public RouterApplication(String appName, Configuration config) {
        super(appName, config);
    }
	    
	public List<OutChannel<?>> getDestinations() {
		return destinations;
	}

	public List<InChannel<?>> getSources() {
		return sources;
	}
	
	public void addDestination(OutChannel<?> outChannel){
	    destinations.add(outChannel);
	}

	private Dispatcher dispatcher;

	public Dispatcher getDispatcher() {
		return dispatcher;
	}

	@Override
	protected void initialize(Configuration config) throws Exception {
		logger.info("Initializing outgoing channels");
		destinations.addAll(buildOutChannels(config, OPTION_CHANNEL_TO));
		if (destinations.size() == 0) {
			throw new IllegalStateException("No destination spedified");
		}
		logger.info("Outgoing channels initialized");

		logger.info("Initializing incoming channels");
		sources.addAll(buildInChannels(config, OPTION_CHANNEL_FROM));
		logger.info("Incoming channels initialized");

		logger.info("Initializing router");
        dispatcher = createDispatcher(config);
        dispatcher.setProcessor(createProcessor(config));
		dispatcher.setFromChannels(getSources());
		dispatcher.setToChannels(getDestinations());
		dispatcher.setErrorChannels(buildErrChannels(config, OPTION_CHANNEL_ERROR));
        registerMBeans(dispatcher, "Dispatcher");
        setRecoveryManager(config, dispatcher);
        setFaultToleranceManager(config, dispatcher);


		registerShutdownTask(dispatcher);
		logger.info("Router initialized");
	}

	@Override
	protected void start() throws Exception {
		dispatcher.start();
		logger.info("Dispatcher started");
	}

	@Override
	protected void stop() throws Exception {
	    if(dispatcher != null){
    		dispatcher.stop();
    		logger.info("Dispatcher stopped");
	    }
	}

	@SuppressWarnings("unchecked")
	protected Dispatcher createDispatcher(Configuration config) throws Exception {
		String name = config.getString(ROUTER_DISPATCHER_KEY);
		Configuration subset = config.subset("dispatcher." + name);
		Dispatcher disp = (Dispatcher) Class.forName(subset.getString(ROUTER_DISPATCHER_CLASS))
				.getConstructor(String.class, EventManager.class)
				.newInstance(name, getEventManager());
        return disp;
	}

    protected void setFaultToleranceManager(Configuration config, Dispatcher disp) throws Exception {
        if (disp instanceof FaultTolerable) {
			String tmName = config.getString("faultTolerance", "");
			if ("".equals(tmName)) {
				logger.warn("Fault Tolerable IS DISABLED!!!!");
			} else {
				logger.info("Initializing Fault Tolerable Manager");
				Configuration tmCfg = config.subset("faultTolerance." + tmName);
				final FaultToleranceManager<MessageObject> ftm = ReflectionUtils.newInstance(tmCfg.getString(ROUTER_DISPATCHER_CLASS), tmName, tmCfg);
				registerMBeans(ftm, "FaultTolerableManager");
				logger.info("Fault Tolerable Manager initialized: {}", ftm);
				((FaultTolerable<MessageObject>)disp).setFaultToleranceManager(ftm);
			}
		}
    }

    protected void setRecoveryManager(Configuration config, Dispatcher disp) throws Exception {
        if (disp instanceof Recoverable) {
            String tmName = config.getString("recovery", "");
            if ("".equals(tmName)) {
                logger.warn("RECOVERY IS DISABLED!!!!");
            } else {
                logger.info("Initializing transaction manager");
                Configuration tmCfg = config.subset("recovery." + tmName);
                final RecoveryManager<MessageObject> tm = ReflectionUtils.newInstance(tmCfg.getString(ROUTER_DISPATCHER_CLASS), tmName, tmCfg);
                registerMBeans(tm, "TransactionManager");
                logger.info("Transaction manager initialized: {}", tm);
                ((Recoverable<MessageObject>) disp).setRecoveryManager(tm);
            }
        }
    }

    protected Processor createProcessor(Configuration config) throws Exception {
		String processor = config.getString(ROUTER_PROCESSOR_KEY);
		Processor proc = ProcessorFactory.create(processor, config);
		proc.initialize();

		registerMBeans(proc, "ParallelProcessor");

		if (proc instanceof ParallelProcessor) {
			registerMBeans(((ParallelProcessor) proc).getProcessor(), "Processor");
		}

		return proc;
	}

}
