package com.scb.fmsd.adapter.core.channel;

import com.scb.fmsd.adapter.core.model.MessageObject;

public interface OutChannel<T> extends Channel<T> {
	public void send(MessageObject message) throws Exception;
}
