package com.scb.fmsd.adapter.core.processor.impl;

import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.model.MessageObjectPropertyKey;
import com.scb.fmsd.adapter.core.processor.CompletionCallback;
import com.scb.fmsd.adapter.core.processor.CorrelationKey;
import com.scb.fmsd.adapter.core.processor.Processor;
import com.scb.fmsd.common.config.Configuration;

public class BlockingSetBasedParallelProcessor extends SetBasedParallelProcessor {
	private static final Logger logger = LoggerFactory.getLogger(BlockingSetBasedParallelProcessor.class);
	
	public BlockingSetBasedParallelProcessor(Processor processor, int threads, int size, CorrelationKey correlationKey) {
		super(processor, threads, size, correlationKey);
	}
	
	@Override
	public void process(MessageObject message, CompletionCallback callback) throws Exception {
		Set<Object> key = correlationKey.getKeys(message);
		MDC.put(MessageObjectPropertyKey.CORRELATION_KEYS.getKey(), key.toString());
		int no = -1;
		int count=0; 
		long start=System.currentTimeMillis();
		while (true){
			for (int i = 0; i < workers.length; i++) {
				if (workers[i].isProcessing(key)) { 
					no = i;
					count ++;
				}
			}
			if (count<2) break;
			Thread.sleep(13);
			count = 0;
		}
		long totalwait = System.currentTimeMillis()-start;
		if (no == -1) {
			no = nextWorker++ % workers.length;
		}
		
		logger.info("Totally wait {} ms to enqueue message to worker #{}, with correlation key: {}", totalwait, no, key);
		
		workers[no].enqueue(new Wrapper(message, key, callback, MDC.getCopyOfContextMap()));
	}
	
	public static BlockingSetBasedParallelProcessor create(String name, Configuration config, Processor processor) throws Exception {
		int workers = config.getInt(THREADS_COUNT, Runtime.getRuntime().availableProcessors());
		int queueSize = config.getInt("queueSize", 10);
		String correlationKeyClass = config.getString(CORRELATION_KEY_CLASS);
		CorrelationKey key = (CorrelationKey) Class.forName(correlationKeyClass).newInstance();
		return new BlockingSetBasedParallelProcessor(processor, workers, queueSize, key);
	}

}
