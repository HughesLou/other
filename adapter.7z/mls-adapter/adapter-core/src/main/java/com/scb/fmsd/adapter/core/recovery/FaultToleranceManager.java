package com.scb.fmsd.adapter.core.recovery;

import java.io.IOException;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;

import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.recovery.impl.UnprocessedMessageInfo;
import com.scb.fmsd.common.jmx.JMXMBean;


public interface FaultToleranceManager<T> extends JMXMBean {
	
	public void initialize() throws RecoveryException;
	
	public boolean isFailedMessage(T t);
	
	public void addFailedMessageToQueue(T t) throws RecoveryException;

	public void removeMessagesFromErrorQueue(List<String> removeList) throws IOException;

	public void refreshAllToIndexFile() throws IOException;

	public SortedMap<Long, String> getAllMessageFileMapping();

	public MessageObject getAndRemoveMessageFromErrorQueue(Long timestamp, String fileName) throws IOException;

	public Map<UnprocessedMessageInfo, Collection<String>> getUnprocessedMessageList() throws IOException;

}
