package com.scb.fmsd.adapter.core.utils;

public interface Decryptor {
	public String decrypt(String password);
}
