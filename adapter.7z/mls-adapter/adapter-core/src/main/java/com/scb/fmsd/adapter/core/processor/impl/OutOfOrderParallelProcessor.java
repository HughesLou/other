package com.scb.fmsd.adapter.core.processor.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.processor.AbstractParallelProcessor;
import com.scb.fmsd.adapter.core.processor.CompletionCallback;
import com.scb.fmsd.adapter.core.processor.Processor;
import com.scb.fmsd.adapter.core.utils.NamedThreadFactory;
import com.scb.fmsd.common.config.Configuration;

public class OutOfOrderParallelProcessor extends AbstractParallelProcessor {

	private final static Logger logger = LoggerFactory.getLogger(OutOfOrderParallelProcessor.class);

	final ExecutorService executor;

	public OutOfOrderParallelProcessor(Processor processor, int threads, int size) {
		this(processor, threads, size, new ThreadPoolExecutor(
				threads, threads, 0L, TimeUnit.SECONDS,
				new ArrayBlockingQueue<Runnable>(size),
				new NamedThreadFactory("ParallelProcessor"),
				new AbortIfShutdownPolicy()));
	}

	public OutOfOrderParallelProcessor(Processor processor, int threads, int size, ExecutorService executor) {
		super(processor, threads, size);
		this.executor = executor;
	}
	@Override
	public int getWorkingQueueSize(){
		if (executor instanceof ThreadPoolExecutor){
			return new Long(((ThreadPoolExecutor) executor).getTaskCount()).intValue();
		}else{
			return -1;
		}
	}
	
	@Override
	public void process(final MessageObject message, final CompletionCallback callback) {
		executor.execute(new Task(processor, message, callback));
	}

	@Override
	public List<MessageObject> shutdownNow() {
		List<Runnable> unprocessed = executor.shutdownNow();
		List<MessageObject> list = new ArrayList<>(unprocessed.size());
		for(Runnable r : unprocessed) {
			Task t = (Task) r;
			list.add(t.message);
			logger.warn("Unprocessed message: {}", t.message.getMessageId());
		}
		try {
			if (!executor.awaitTermination(10, TimeUnit.SECONDS)) {
				logger.info("Shutdown timeout");
			}
		} catch (InterruptedException ignore) {
			logger.info("Shutdown interrupted");
		}
		return list;
	}

	@Override
	public void initialize() {
		Objects.requireNonNull(processor);
		if (executor instanceof ThreadPoolExecutor) {
			((ThreadPoolExecutor) executor).prestartAllCoreThreads();
		}
	}

	static class Task implements Runnable {
		final Processor processor;
		final MessageObject message;
		final CompletionCallback callback;

		public Task(Processor processor, MessageObject message, CompletionCallback callback) {
			this.processor = processor;
			this.message = message;
			this.callback = callback;
		}

		@Override
		public void run() {
			try {
				MessageObject result = processor.process(message);
				callback.completed(result, message);
			} catch (Exception e) {
				callback.failed(e, message);
			}
		}
	}

	public static OutOfOrderParallelProcessor create(String name, Configuration config, Processor processor) throws Exception {
		int workers = config.getInt("threads", Runtime.getRuntime().availableProcessors());
		int queueSize = config.getInt("queueSize", 1);
		return new OutOfOrderParallelProcessor(processor, workers, queueSize);
	}
}
