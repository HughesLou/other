package com.scb.fmsd.adapter.core.channel.mail.builder;

import com.scb.fmsd.adapter.core.event.EventMessage;
import com.scb.fmsd.adapter.core.event.EventMessage.Type;
import com.scb.fmsd.adapter.core.model.MessageObject;

public class EventVariable implements Variable {

	@Override
	public String resolve(MessageObject mo) {
		Type event = (mo instanceof EventMessage) ? ((EventMessage) mo).getEvent() : null;
		return event != null ? event.name() : "INFO";
	}
}
