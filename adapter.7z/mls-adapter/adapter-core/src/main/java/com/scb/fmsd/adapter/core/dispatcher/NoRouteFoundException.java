package com.scb.fmsd.adapter.core.dispatcher;

public class NoRouteFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	public NoRouteFoundException() {
	}

	public NoRouteFoundException(String message) {
		super(message);
	}

	public NoRouteFoundException(Throwable cause) {
		super(cause);
	}

	public NoRouteFoundException(String message, Throwable cause) {
		super(message, cause);
	}

}
