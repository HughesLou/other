package com.scb.fmsd.adapter.core.model;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.Map;

public interface MessageObject {

	public String getMessageId();

	public Object getPayload();
	public String getText();
	public byte[] getBytes();

    /**
     To avoid UnsupportedOperation exceptions when calling methods not supported by batch messages. Done this way for
     backward compatibility, but would be better if interfaces were implemented for capturing supported message behaviours
     */
    public boolean isBatchMessage();

	public Throwable getError();
	public void setError(Throwable t);

	public void addProperty(String name, Object value);
	public Object getProperty(String name);
	public boolean hasProperty(String name);
	public Map<String, Object> getProperties();

	public void serialize(DataOutputStream out) throws Exception;
	public MessageObject deserialize(DataInputStream in) throws Exception;

	public void setOriginal(MessageObject original);
	public MessageObject getOriginal();

    public void setRefObject(Object refObject);
    public Object getRefObject();
}
