/** 
 * Copyright (c) 2013, Standard Chartered Bank. All rights reserved.
 *
 * Date: Dec 10, 2013 5:39:07 PM 
 * 
 */
package com.scb.fmsd.adapter.core;

/**
 * TODO: Briefly explain what this class does
 * 
 * @author: 1467965
 */
public interface Service
{
    void start() throws Exception;

    void stop() throws Exception;
}
