package com.scb.fmsd.adapter.core.event;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.fmsd.adapter.core.channel.OutChannel;
import com.scb.fmsd.adapter.core.dispatcher.Route;

public class EventManagerImpl implements EventManager {

	private static final Logger logger = LoggerFactory.getLogger(EventManagerImpl.class);

	private final List<Route> channels = new ArrayList<>();

	public EventManagerImpl() {
	}

	public void setChannels(List<OutChannel<?>> channels) {
		for (OutChannel<?> ch : channels) {
			if (ch instanceof Route) {
				this.channels.add((Route) ch);
			} else {
				this.channels.add(new Route(ch));
			}
		}
	}

	@Override
	public void onEvent(EventMessage event) {
		if (event == null) {
			return;
		}
		switch (event.type) {
		case INFO:
			logger.info(event.getText(), event.getError());
			break;
		case WARN:
			logger.warn(event.getText(), event.getError());
			break;
		case ERROR:
			logger.error(event.getText(), event.getError());
			break;
		}

		for (Route route : channels) {
			if (route.accept(event)) {
				try {
					route.getTo().send(event);
				} catch (Exception e) {
					logger.error("Failed to send event " + event.getMessageId(), e);
				}
			}
		}
	}

	public void initialize() throws Exception {
		for (Route route : channels) {
			route.start();
		}
		logger.info("initialized");
	}

	public void shutdown() {
		for (Route route : channels) {
			route.shutdown();
		}
		logger.info("shutdown");
	}

}
