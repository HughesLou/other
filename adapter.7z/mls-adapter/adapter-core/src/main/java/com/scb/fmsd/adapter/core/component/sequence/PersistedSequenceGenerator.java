package com.scb.fmsd.adapter.core.component.sequence;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel.MapMode;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.fmsd.common.config.Configuration;

public class PersistedSequenceGenerator implements SequenceGenerator {
	
	private static final Logger logger = LoggerFactory.getLogger(PersistedSequenceGenerator.class);

	private final MappedByteBuffer mmb;
	
	private final SequenceGenerator generator;
	
	private final RandomAccessFile raf;
	
	public PersistedSequenceGenerator(File f) throws IOException {
		this(new MemSequenceGenerator(), f);
		logger.info("{} created, file={}", this.getClass().getName(), f);
	}
	
	public PersistedSequenceGenerator(SequenceGenerator generator, final File f) throws IOException {
		this.generator = generator;
		this.raf = new RandomAccessFile(f, "rw");
		Runtime.getRuntime().addShutdownHook(new Thread() {
			@Override
			public void run() {
				try { 
					raf.close(); 
				} catch(Exception e) {
					logger.error("Error while closing " + f, e);
				}
			}
		});
		this.mmb = raf.getChannel().map(MapMode.READ_WRITE, 0, Long.SIZE / 8);
		generator.reset(mmb.getLong());
	}
	
	@Override
	public synchronized long next() {
		long value = generator.next();
		this.mmb.clear();
		this.mmb.putLong(value);
		return value;
	}

	@Override
	public synchronized void reset(long value) {
		generator.reset(value);
	}
	
	public void close() throws IOException {
		if (raf != null) {
			raf.close();
		}	
	}
	
	public static PersistedSequenceGenerator create(String name, Configuration config) throws IOException {
		return new PersistedSequenceGenerator(new File(config.getString("file", "router.seq")));
	}

}
