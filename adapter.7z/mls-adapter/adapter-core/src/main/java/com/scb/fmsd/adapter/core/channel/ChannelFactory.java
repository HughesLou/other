package com.scb.fmsd.adapter.core.channel;

import static com.scb.fmsd.adapter.core.channel.AbstractChannel.DEFAULT_RETRY_WAIT_TIME;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import com.scb.fmsd.adapter.core.utils.ReflectionUtils;
import com.scb.fmsd.common.config.Configuration;

@SuppressWarnings("rawtypes")
public abstract class ChannelFactory {

    public static final String CONNECT_WAIT_TIME = "connectWaitTime";
    public static final String CONNECT_ATTEMPTS = "connectAttempts";
    public static final String RETRY_WAIT_TIME = "retryWaitTime";
    public static final String RETRY_ATTEMPTS = "retryAttempts";
    public static final String CHANNEL_CONVERTER = "converter";
    public static final String CHANNEL_CLASS = "class";
    public static final String CHANNEL_TYPE = "type";
    private static final Map<String, Class<? extends Channel>> types = new HashMap<>();

	static {
		Set<Class<? extends Channel>> subTypes = ReflectionUtils.getSubTypesOf(Channel.class);
		for (Class<? extends Channel> type : subTypes) {
			if (!ReflectionUtils.isAbstract(type)) {
				registerChannelType(type);
			}
		}
	}

	public static void registerChannelType(Class<? extends Channel> type) {
		types.put(type.getSimpleName(), type);
	}

	private ChannelFactory() {}

	@SuppressWarnings("unchecked")
	public static <T extends Channel<?>> T create(String name, Configuration config) throws Exception {
		Class<T> type = null;
		if (config.exists(CHANNEL_TYPE)) {
			type = (Class<T>) types.get(config.getString(CHANNEL_TYPE));
		}

		if (type == null && config.exists(CHANNEL_CLASS)) {
			type = (Class<T>) Class.forName(config.getString(CHANNEL_CLASS));
		}

		if (type == null) {
			throw new RuntimeException("Channel " + name + " class/type not found");
		}

		T channel = ReflectionUtils.newInstance(type, name, config);
		String converterType = config.getString(CHANNEL_CONVERTER, "");
		if (!"".equals(converterType)) {
			channel.setMessageConverter((MessageConverter) Class.forName(converterType).newInstance());
		}

		if (channel instanceof AbstractChannel) {
			AbstractChannel ac = (AbstractChannel) channel;
			ac.setRetryAttempts(config.getInt(RETRY_ATTEMPTS, 0));
			ac.setRetryWaitTime(config.getDuration(RETRY_WAIT_TIME, TimeUnit.MILLISECONDS, DEFAULT_RETRY_WAIT_TIME));

			ac.setConnectAttempts(config.getInt(CONNECT_ATTEMPTS, 1));
			ac.setConnectWaitTime(config.getDuration(CONNECT_WAIT_TIME, TimeUnit.MILLISECONDS, DEFAULT_RETRY_WAIT_TIME));
		}

		return channel;
	}

}
