package com.scb.fmsd.adapter.core.model;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public final class Serializer {

	private Serializer() {
	}

	public static void serialize(MessageObject message, OutputStream to) throws Exception {
		DataOutputStream out = new DataOutputStream(to);
		writeStringASCII(message.getClass().getName(), out);
		message.serialize(out);
	}

	public static MessageObject deserialize(InputStream from) throws Exception {
		DataInputStream in = new DataInputStream(from);
		String className = readStringASCII(in);
		MessageObject message = (MessageObject) Class.forName(className).newInstance();
		return message.deserialize(in);
	}

	public static void writeStringASCII(String string, DataOutputStream out) throws IOException {
		char[] chars = string.toCharArray();
		int len = chars.length;
		out.writeInt(len);
        for (int i = 0; i < len; i++) {
            out.write(chars[i] & 0xFF);
        }
	}

	public static String readStringASCII(DataInputStream in) throws IOException {
		int len = in.readInt();
		char[] chars = new char[len];
		for (int i = 0; i < len; i++) {
			chars[i] = (char) in.read();
		}
		return new String(chars);
	}
}
