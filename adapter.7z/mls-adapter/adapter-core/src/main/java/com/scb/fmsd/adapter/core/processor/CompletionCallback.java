package com.scb.fmsd.adapter.core.processor;

import com.scb.fmsd.adapter.core.model.MessageObject;

public interface CompletionCallback {
	public void completed(MessageObject result, MessageObject original);
	public void failed(Throwable t, MessageObject message);
}
