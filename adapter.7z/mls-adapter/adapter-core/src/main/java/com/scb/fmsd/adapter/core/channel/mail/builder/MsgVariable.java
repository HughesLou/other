package com.scb.fmsd.adapter.core.channel.mail.builder;

import com.scb.fmsd.adapter.core.model.MessageObject;

public class MsgVariable implements Variable {

	@Override
	public String resolve(MessageObject mo) {
		String text = mo.getText();
		int eol = text.indexOf('\n');
		if (eol != -1) {
			text = text.substring(0, eol);
		}
		return text.length() > 100 ? text.substring(0, 100) : text;
	}

}
