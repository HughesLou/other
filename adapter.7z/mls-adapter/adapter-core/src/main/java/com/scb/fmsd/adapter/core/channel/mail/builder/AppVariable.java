package com.scb.fmsd.adapter.core.channel.mail.builder;

import com.scb.fmsd.adapter.core.Application;

public class AppVariable extends StringVariable {

	public AppVariable() {
		super(System.getProperty(Application.APP_NAME));
	}
	
	public AppVariable(String appName) {
		super(appName);
	}
	
}
