package com.scb.fmsd.adapter.core.event;

import com.scb.fmsd.adapter.core.model.StringMessageObject;

public class EventMessage extends StringMessageObject {

	public static enum Type { INFO, WARN, ERROR; }

	final Type type;

	final Object data;

	private EventMessage(Type type, String message, Throwable error, Object data) {
		super(message, type + "-" + System.currentTimeMillis());
		this.type = type;
		setError(error);
		this.data = data;
	}

	public Type getEvent() {
		return type;
	}

	public Object getData() {
		return data;
	}

	public static EventMessage error(String message, Throwable e) {
		return new EventMessage(Type.ERROR, message, e, null);
	}

	public static EventMessage error(String message, Throwable e, Object data) {
		return new EventMessage(Type.ERROR, message, e, data);
	}

	public static EventMessage info(String message) {
		return new EventMessage(Type.INFO, message, null, null);
	}
}
