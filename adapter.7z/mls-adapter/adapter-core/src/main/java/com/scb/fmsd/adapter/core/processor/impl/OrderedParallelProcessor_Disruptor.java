package com.scb.fmsd.adapter.core.processor.impl;

import java.util.List;

import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.processor.AbstractParallelProcessor;
import com.scb.fmsd.adapter.core.processor.CompletionCallback;
import com.scb.fmsd.adapter.core.processor.Processor;
import com.scb.fmsd.common.config.Configuration;

public class OrderedParallelProcessor_Disruptor extends AbstractParallelProcessor {

	public OrderedParallelProcessor_Disruptor(Processor processor, int threads, int size) {
		super(processor, threads, size);
	}

	@Override
	public void process(MessageObject message, CompletionCallback callback) throws Exception {
	}

	@Override
	public List<MessageObject> shutdownNow() {
		return null;
	}

	public static OrderedParallelProcessor_Disruptor create(String name, Configuration config, Processor processor) {
		int workers = config.getInt("threads", Runtime.getRuntime().availableProcessors());
		int queueSize = config.getInt("queueSize", 1);
		return new OrderedParallelProcessor_Disruptor(processor, workers, queueSize);
	}
	
	public int getWorkingQueueSize(){
		return -1;
	}
}
