package com.scb.fmsd.adapter.core.processor;

import com.scb.fmsd.adapter.core.model.MessageObject;

public class ProcessorAdapter implements Processor {

	@Override
	public MessageObject process(MessageObject message) throws Exception {
		return message;
	}

	@Override
	public void initialize() throws Exception {
	}

	@Override
	public void shutdown() throws Exception {
	}

}
