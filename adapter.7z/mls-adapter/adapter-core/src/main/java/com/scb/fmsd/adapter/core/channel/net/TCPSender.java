package com.scb.fmsd.adapter.core.channel.net;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

import com.scb.fmsd.adapter.core.channel.AbstractOutChannel;
import com.scb.fmsd.adapter.core.channel.MessageConverter;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.utils.CompressionUtils;
import com.scb.fmsd.common.config.Configuration;
import com.scb.fmsd.common.jmx.JMXBeanAttribute;

public class TCPSender extends AbstractOutChannel<ByteBuffer> {

	private final SocketAddress address;

	private SocketChannel channel;

	private int timeout;

	private long compressionThreshold = 0;

	public TCPSender(String name, SocketAddress address) {
		super(name);
		setMessageConverter(new SerializableMessageConverter());
		this.address = address;
	}

	@JMXBeanAttribute
	public int getTimeout() {
		return timeout;
	}

	public void setTimeout(int timeout) {
		this.timeout = timeout;
	}

	@JMXBeanAttribute
	public long getCompressionThreshold() {
		return compressionThreshold;
	}

	public void setCompressionThreshold(long compressionThreshold) {
		this.compressionThreshold = compressionThreshold;
	}

	@Override
	protected void doStart() throws IOException {
		assert channel == null;
		channel = SocketChannel.open();
		channel.configureBlocking(true);
		channel.socket().setSoTimeout(timeout);
		channel.connect(address);
		logger.info("{} connected to {}", getName(), address);
	}

	@Override
	protected void doStop() {
		assert channel != null;
		try { channel.close(); } catch (IOException ignore) {}
		channel = null;
	}

	@Override
	public void send(MessageObject message) throws Exception {
		send(converter.convert(message, this));
	}

	private byte[] compress(byte[] buffer) throws IOException {
		return CompressionUtils.compress(buffer);
	}

	public static final byte UNCOMPRESSED_FLAG = 0x0;
	public static final byte COMPRESSED_FLAG = 0x1;

	public void send(ByteBuffer data) throws Exception {
		byte[] buffer = data.array();
		boolean compressed = compressionThreshold > 0 && buffer.length > compressionThreshold;
		if (compressed) {
			buffer = compress(buffer);
		}

		ByteBuffer bb = ByteBuffer.allocate(Integer.SIZE / 8 + 1 + buffer.length);
		bb.put(compressed ? COMPRESSED_FLAG : UNCOMPRESSED_FLAG);
		bb.putInt(buffer.length);
		bb.put(buffer);
		try {
			bb.rewind();
			while (bb.remaining() > 0) {
				channel.write(bb);
			}
		} catch (Exception e) {
			logger.error("An exception occured, trying to (re)send", e);
			int attempt = 0;
			while (nextRetryAttempt(attempt++)) {
				waitRetryAttemp();
				try {
					restart();

					bb.rewind();
					while (bb.remaining() > 0) {
						channel.write(bb);
					}
					logger.info("Message sent after {} attempt!", attempt);
					return;
				} catch (Exception e1) {
					e = e1;
					logger.error("Failed to send at {} attempt, error={}", attempt, e);
				}
			}
			logger.error("Failed to send after {} attempts, error={}", attempt, e);
			throw e;
		}
	}

	@Override
	public String toString() {
		return "TCPSender[address=" + address + ", timeout=" + timeout + "]";
	}

	@SuppressWarnings("unchecked")
	public static TCPSender create(String name, Configuration config) throws Exception {
		TCPSender channel = new TCPSender(name, new InetSocketAddress(config.getString("hostname"), config.getInt("port")));
		channel.setTimeout(config.getInt("timeout", 0));
		channel.setCompressionThreshold(config.getLong("compressionThreshold", 0L));
		String converter = config.getString("converter", "");
		if (!"".equals(converter)) {
			channel.setMessageConverter((MessageConverter<ByteBuffer>) Class.forName(converter).newInstance());
		}
		return channel;
	}

}
