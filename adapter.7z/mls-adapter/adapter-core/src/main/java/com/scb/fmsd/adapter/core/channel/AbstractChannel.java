package com.scb.fmsd.adapter.core.channel;

import java.util.concurrent.atomic.AtomicBoolean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.fmsd.common.jmx.JMXBeanAttribute;

public abstract class AbstractChannel<T> implements Channel<T> {

	public static final long DEFAULT_RETRY_WAIT_TIME = 1000 * 60; // 1 minute

	protected final Logger logger;

	private final String name;

	private long retryWaitTime = DEFAULT_RETRY_WAIT_TIME;

	private int retryAttempts = 0;	// no retry attempts by default

	private long connectWaitTime = DEFAULT_RETRY_WAIT_TIME;

	private int connectAttempts = 0;

	protected MessageConverter<T> converter;

	private ChannelListener listener;

	protected volatile boolean shutdown = false;

	public AbstractChannel(String name) {
		this.name = name;
		this.logger = LoggerFactory.getLogger(getClass() + "_" + name);
	}

	public MessageConverter<T> getMessageConverter() {
		return converter;
	}

	@Override
	public void setChannelListener(ChannelListener listener) {
		this.listener = listener;
	}

	public void onException(Throwable t) {
		if (listener != null) {
			listener.onException(t, this);
		}
	}

	@Override
	public void setMessageConverter(MessageConverter<T> converter) {
		this.converter = converter;
	}

	@JMXBeanAttribute
	public long getRetryWaitTime() {
		return retryWaitTime;
	}

	public void setRetryWaitTime(long retryWaitTime) {
		this.retryWaitTime = retryWaitTime;
	}

	@JMXBeanAttribute
	public int getRetryAttempts() {
		return retryAttempts;
	}

	public void setRetryAttempts(int retryAttempts) {
		this.retryAttempts = retryAttempts;
	}

	@JMXBeanAttribute
	public int getConnectAttempts() {
		return connectAttempts;
	}

	public void setConnectAttempts(int connectAttempts) {
		this.connectAttempts = connectAttempts;
	}

	@JMXBeanAttribute
	public long getConnectWaitTime() {
		return connectWaitTime;
	}

	public void setConnectWaitTime(long connectWaitTime) {
		this.connectWaitTime = connectWaitTime;
	}
	protected boolean nextRetryAttempt(int attempt) {
		return retryAttempts == -1 || attempt < retryAttempts;
	}

	protected void waitRetryAttemp() {
		if (retryWaitTime > 0) {
			try {
				Thread.sleep(retryWaitTime);
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
			}
		}
	}

	@Override
	final public void shutdown() {
		shutdown = true;
		try {
			stop();
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}

	@Override @JMXBeanAttribute
	public String getName() {
		return name;
	}

	private final AtomicBoolean initialized = new AtomicBoolean(false);
	private final AtomicBoolean started = new AtomicBoolean(false);

	@Override
	final public void initialize() throws Exception {
		if (initialized.compareAndSet(false, true)) {
			logger.info("initializing...");
			try {
				doInitialize();
			} catch (Exception e) {
				initialized.set(false);
				throw e;
			}
			logger.info("initialized");
		}
	}
	protected void doInitialize() throws Exception {}

	@Override
	final public void start() throws Exception {
		try {
			start0();
		} catch (Exception e) {
			int attempt = 1;
			while (connectAttempts == -1 || ++attempt <= connectAttempts) {
				if (connectWaitTime > 0) {
					Thread.sleep(connectWaitTime);
				}
				try {
					start0();
					return;
				} catch (Exception ignore) {
				}
			}
			logger.info("Failed to start after {} attempts", attempt);
			throw e;
		}
	}

	private void start0() throws Exception {
		if (started.compareAndSet(false, true)) {
			initialize();
			logger.info("starting...");
			try {
				doStart();
			} catch (Exception e) {
				started.set(false);
				throw e;
			}
			logger.info("started");
		}
	}

	protected void doStart() throws Exception {}

	@Override
	final public void stop() {
		if (started.compareAndSet(true, false)) {
			logger.info("stopping...");
			try {
				doStop();
			} catch (RuntimeException e) {
				started.set(false);
				throw e;
			}
			logger.info("stopped");
		}
	}
	protected void doStop() {}

	final public void restart() throws Exception {
		try { stop(); } catch (Exception ignore) {}
		start();
	}

	@Override
	public String toString() {
		return getClass().getSimpleName() + "{" + name + "}";
	}

}
