package com.scb.fmsd.adapter.core.channel.net;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;

import com.scb.fmsd.adapter.core.channel.MessageConverter;
import com.scb.fmsd.common.config.Configuration;

public class TCPAsyncServer extends AbstractTCPServer {

	public TCPAsyncServer(String name, SocketAddress address) {
		super(name, address);
	}

	@Override
	protected IServer createServer(SocketAddress address) throws Exception {
		return new NIOServer(address);
	}

	private class NIOServer extends Thread implements IServer {

		private volatile boolean stopped = false;

		private final ServerSocketChannel channel;
		private final Selector selector;

		public NIOServer(SocketAddress address) throws IOException {
			super("NIOListener");
			setDaemon(true);

			selector = Selector.open();
			channel = ServerSocketChannel.open();
			channel.configureBlocking(false);
			channel.bind(address);
			channel.register(selector, SelectionKey.OP_ACCEPT);
			logger.info("{} started at {} in blocking mode?{}", getName(), address, channel.isBlocking());
		}

		@Override
		public void run() {
			while (!stopped) {
	        	try {
	        		int num = selector.select();
	        		if (num == 0) {
	        			continue;
	        		}

	        		Set<SelectionKey> selectedKeys = selector.selectedKeys();
	        		Iterator<SelectionKey> it = selectedKeys.iterator();

	        		while (it.hasNext()) {
		        		SelectionKey key = it.next();
		        		if ((key.readyOps() & SelectionKey.OP_ACCEPT) == SelectionKey.OP_ACCEPT) {
		        			ServerSocketChannel ssc = (ServerSocketChannel) key.channel();
		        			SocketChannel sc = ssc.accept();
		        			sc.configureBlocking(false);
		        			SelectionKey k = sc.register(selector, SelectionKey.OP_READ);
		        			k.attach(new Attachement());
		        			logger.info("Accepted new connection {}", sc);
		        		} else if ((key.readyOps() & SelectionKey.OP_READ) == SelectionKey.OP_READ) {
		        			SocketChannel sc = (SocketChannel) key.channel();
		        			Attachement att = (Attachement) key.attachment();

		        			try {
		        				int read = 1;
		        				while (read > 0) {
		        					if (att.body == null) {
		        						// header
		        						if (att.header.hasRemaining()) {
		        							read = sc.read(att.header);
		        						}

		        						if (read != -1 && !att.header.hasRemaining()) {
		        							att.header.flip();
		        							att.compressed = att.header.get() == TCPSender.COMPRESSED_FLAG;
		        							att.body = ByteBuffer.allocate(att.header.getInt());
		        						}
		        					} else {
		        						// body
		        						if (att.body.hasRemaining()) {
		        							read = sc.read(att.body);
		        						}

		        						if (read != -1 && !att.body.hasRemaining()) {
		        							onMessage(att.body.array(), att.compressed, sc);
		        							att.header.clear();
		        							att.body = null;
		        						}
		        					}
		        				}
			        			if (read == -1) {
			        				closeChannel(sc);
			        			}
		        			} catch (IOException ioe) {
		        				closeChannel(sc);
		        			}
		        		}
		        		it.remove();
	        		}
        		} catch (Exception e) {
        			logger.error("An exception occured", e);
        		}
			}

			try {
				selector.close();
			} catch (IOException e) {
				logger.error("Failed to close selector", e);
			}
			try {
				channel.close();
			} catch (IOException e) {
				logger.error("Failed to close channel", e);
			}
			logger.info("{} stopped", getName());
		}

		@Override
		public void shutdown() {
			this.stopped = true;
			if (channel != null) {
				try {
					channel.close();
				} catch (IOException e) {
					logger.error(e.getMessage(), e);
				}
			}
			super.interrupt();
		}
	}

	private class Attachement {
		private final ByteBuffer header = ByteBuffer.allocate(Integer.SIZE / 8 + 1);
		private ByteBuffer body;
		public boolean compressed;
	}

	@SuppressWarnings("unchecked")
	public static TCPAsyncServer create(String name, Configuration config) throws Exception {
		TCPAsyncServer channel = new TCPAsyncServer(name, new InetSocketAddress(config.getString("hostname"), config.getInt("port")));
		String converter = config.getString("converter", "");
		if (!"".equals(converter)) {
			channel.setMessageConverter((MessageConverter<ByteBuffer>) Class.forName(converter).newInstance());
		}
		return channel;
	}

}
