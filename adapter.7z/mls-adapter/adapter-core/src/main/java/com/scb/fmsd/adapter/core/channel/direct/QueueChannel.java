package com.scb.fmsd.adapter.core.channel.direct;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import com.scb.fmsd.adapter.core.channel.AbstractOutChannel;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.common.jmx.JMXBeanAttribute;

public class QueueChannel extends AbstractOutChannel<MessageObject> {

	private final BlockingQueue<MessageObject> queue;

	public QueueChannel() {
		this(new LinkedBlockingQueue<MessageObject>());
	}

	public QueueChannel(BlockingQueue<MessageObject> queue) {
		super("Queue");
		this.queue = queue;
	}

	@Override
	public void send(MessageObject message) throws Exception {
		queue.put(message);
	}

	public MessageObject take() throws Exception {
		return queue.take();
	}

	@JMXBeanAttribute
	public int size() {
		return queue.size();
	}

}
