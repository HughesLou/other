package com.scb.fmsd.adapter.core.channel.jms.utils;

import javax.jms.JMSException;
import javax.jms.TextMessage;

public class TextMessageImpl extends MessageImpl implements TextMessage {

	private String text;
	
	@Override
	public String getText() throws JMSException {
		return text;
	}

	@Override
	public void setText(String text) throws JMSException {
		this.text = text;
	}
}
