package com.scb.fmsd.adapter.core.channel;

public abstract class AbstractOutChannel<E> extends AbstractChannel<E> implements OutChannel<E> {

	public AbstractOutChannel(String name) {
		super(name);
	}

}
