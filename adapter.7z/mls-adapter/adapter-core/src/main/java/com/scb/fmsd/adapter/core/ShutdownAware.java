package com.scb.fmsd.adapter.core;

public interface ShutdownAware {
	public void shutdown() throws Exception;
}
