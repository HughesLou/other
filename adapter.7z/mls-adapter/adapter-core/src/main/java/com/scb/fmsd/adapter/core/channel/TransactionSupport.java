package com.scb.fmsd.adapter.core.channel;

import com.scb.fmsd.common.jmx.JMXBeanAttribute;

public interface TransactionSupport {
	@JMXBeanAttribute
	public boolean isTransacted();
	public void commit() throws Exception;
	public void rollback() throws Exception;
}
