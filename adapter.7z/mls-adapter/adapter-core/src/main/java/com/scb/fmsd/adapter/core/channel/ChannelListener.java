package com.scb.fmsd.adapter.core.channel;

public interface ChannelListener {
	public void onException(Throwable t, Channel<?> channel);
}
