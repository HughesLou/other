package com.scb.fmsd.adapter.core.processor.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.AbstractExecutorService;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.RunnableFuture;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.fmsd.adapter.core.processor.impl.OrderedParallelProcessor.FutureTaskEx;
import com.scb.fmsd.adapter.core.processor.impl.OrderedParallelProcessor.Task;

class CustomerExecutorService extends AbstractExecutorService implements Runnable {
	private static final Logger logger = LoggerFactory.getLogger(CustomerExecutorService.class);

	private final Thread[] workers;
	private final BlockingQueue<Runnable> queue;

	private volatile boolean stopped;

	private final CountDownLatch terminated;

	public CustomerExecutorService(int threads,
			BlockingQueue<Runnable> queue,
			ThreadFactory threadFactory) {
		this.queue = queue;
		this.workers = new Thread[threads];
		for (int i = 0; i < threads; i++) {
			workers[i] = threadFactory.newThread(this);
		}
		this.terminated = new CountDownLatch(threads);
	}

	public void prestartAllCoreThreads() {
		for (int i = 0; i < workers.length; i++) {
			workers[i].start();
		}
	}

	@Override
	public void run() {
		logger.info("{} started", Thread.currentThread().getName());
		while (!stopped) {
			try {
				queue.take().run();
			} catch (InterruptedException e) {
				logger.error("InterruptedException on queue", e);
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		}
		logger.info("{} stopped", Thread.currentThread().getName());
		terminated.countDown();
	}

	@Override
	public void shutdown() {
		this.stopped = true;
		for (int i = 0; i < workers.length; i++) {
			workers[i].interrupt();
		}
		try {
			terminated.await();
		} catch (InterruptedException e) {
			throw new RuntimeException("Failed to shutdown", e);
		}
	}

	@Override
	public List<Runnable> shutdownNow() {
		shutdown();
		List<Runnable> list = new ArrayList<>(queue.size());
		Runnable r;
		while ((r = queue.poll()) != null) {
			list.add(r);
		}
		return list;
	}

	@Override
	public boolean isShutdown() {
		return stopped;
	}

	@Override
	public boolean isTerminated() {
		return stopped;
	}

	@Override
	public boolean awaitTermination(long timeout, TimeUnit unit) throws InterruptedException {
		return terminated.await(timeout, unit);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected <T> RunnableFuture<T> newTaskFor(Callable<T> callable) {
		return (RunnableFuture<T>) new FutureTaskEx((Task) callable);
	}

	@Override
	public void execute(Runnable command) {
		try {
			queue.put(command);
		} catch (InterruptedException e) {
			throw new RuntimeException(e);
		}
	}
}

