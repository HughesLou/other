package com.scb.fmsd.adapter.core.dispatcher;

import com.scb.fmsd.adapter.core.channel.AbstractOutChannel;
import com.scb.fmsd.adapter.core.channel.OutChannel;
import com.scb.fmsd.adapter.core.dispatcher.filters.Filter;
import com.scb.fmsd.adapter.core.model.MessageObject;

public class Route extends AbstractOutChannel<MessageObject> {
	private final OutChannel<?> to;
	private final Filter condition;

	public Route(OutChannel<?> to) {
		this(to, null);
	}

	public Route(OutChannel<?> to, Filter condition) {
		super(to.getName());
		this.to = to;
		this.condition = condition;
	}

	public boolean accept(MessageObject message) {
		return condition == null || condition.accept(message);
	}

	@Override
	public void send(MessageObject message) throws Exception {
		to.send(message);
	}

	@Override
	protected void doStop() {
		to.stop();
	}

	@Override
	protected void doStart() throws Exception {
		to.start();
	}

	public OutChannel<?> getTo() {
		return to;
	}

	@Override
	public String toString() {
		return "route to=" + to.getName() + " when " + (condition == null ? "true" : condition);
	}

}
