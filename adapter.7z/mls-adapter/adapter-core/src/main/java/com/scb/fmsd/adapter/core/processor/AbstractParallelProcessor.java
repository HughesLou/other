package com.scb.fmsd.adapter.core.processor;

import java.util.Objects;

import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.common.jmx.JMXBeanAttribute;
import com.scb.fmsd.common.jmx.JMXBeanOperation;

public abstract class AbstractParallelProcessor implements ParallelProcessor {

	protected final Processor processor;

	protected final int threads;

	protected final int size;

	public AbstractParallelProcessor(Processor processor, int threads, int size) {
		this.threads = threads;
		this.processor = processor;
		this.size = size;
	}

	@Override
	@JMXBeanAttribute
	public Processor getProcessor() {
		return processor;
	}

	@Override @JMXBeanAttribute
	public int getThreads() {
		return threads;
	}

	@JMXBeanAttribute
	public int getSize() {
		return size;
	}
	
	@JMXBeanOperation
	public int getWorkingSize(){
		return getWorkingQueueSize();
	}
	
	@Override
	public MessageObject process(MessageObject message) throws Exception {
		throw new UnsupportedOperationException();
	}

	@Override
	public void shutdown() throws Exception {
		shutdownNow();
	}

	@Override
	public void initialize() throws Exception {
		Objects.requireNonNull(processor);
	}

}
