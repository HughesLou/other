package com.scb.fmsd.adapter.core.processor;

import java.util.AbstractQueue;
import java.util.Iterator;
import java.util.concurrent.BlockingQueue;

public class MonitoredBlockingQueue<E> extends AbstractQueue<E> {
	
	private final BlockingQueue<E> queue;
	
	public MonitoredBlockingQueue(BlockingQueue<E> queue) {
		this.queue = queue;
	}

	@Override
	public boolean offer(E e) {
		return queue.offer(e);
	}

	@Override
	public E poll() {
		return queue.poll();
	}

	@Override
	public E peek() {
		return queue.peek();
	}

	@Override
	public Iterator<E> iterator() {
		return queue.iterator();
	}

	@Override
	public int size() {
		return queue.size();
	}

}
