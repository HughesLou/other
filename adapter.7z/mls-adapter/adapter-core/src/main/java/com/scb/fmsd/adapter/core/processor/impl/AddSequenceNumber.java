package com.scb.fmsd.adapter.core.processor.impl;

import java.io.IOException;

import com.scb.fmsd.adapter.core.component.sequence.PersistedSequenceGenerator;
import com.scb.fmsd.adapter.core.component.sequence.SequenceGenerator;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.common.config.Configuration;
import com.scb.fmsd.common.jmx.JMXBeanAttribute;

public class AddSequenceNumber extends AddMessageHeader {

	public static final String HEADER = "SEQUENCE";

	private final SequenceGenerator generator;

	public AddSequenceNumber(SequenceGenerator generator) {
		super(HEADER);
		this.generator = generator;
	}

	@JMXBeanAttribute
	public SequenceGenerator getGenerator() {
		return generator;
	}

	@Override
	protected Object getHeaderValue(MessageObject message) {
		return generator.next();
	}

	public static AddSequenceNumber create(String name, Configuration config) throws IOException {
		return new AddSequenceNumber(PersistedSequenceGenerator.create(name, config.subset("sequence")));
	}

	@Override
	public void initialize() throws Exception {
	}

}
