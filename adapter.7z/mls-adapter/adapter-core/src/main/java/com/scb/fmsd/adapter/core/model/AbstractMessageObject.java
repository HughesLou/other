package com.scb.fmsd.adapter.core.model;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public abstract class AbstractMessageObject<T> implements MessageObject {

	private String messageId;

	private T payload;

	private Map<String, Object> props;

	transient private Throwable error;

	transient private MessageObject original;

    transient private Object refObject;

	public AbstractMessageObject() {
		this(null);
	}

	public AbstractMessageObject(T payload) {
		this(payload, "MSG-" + System.currentTimeMillis());
	}

	public AbstractMessageObject(T payload, String messageId) {
		this.messageId = messageId;
		this.payload = payload;
		this.props = new HashMap<String, Object>();
	}

	public AbstractMessageObject(T payload, String messageId, Map<String, Object> props) {
		this.messageId = messageId;
		this.payload = payload;
		this.props = new HashMap<>(props);
	}

	@Override
	public String getMessageId() {
		return messageId;
	}

	@Override
	public T getPayload() {
		return payload;
	}

	protected void setPayload(T payload) {
		this.payload = payload;
	}

	@Override
	public Throwable getError() {
		return error;
	}

	@Override
	public void setError(Throwable error) {
		this.error = error;
	}

	@Override
	public void setOriginal(MessageObject original) {
		this.original = original;
	}

	@Override
	public MessageObject getOriginal() {
		return original;
	}

	@Override
	public void addProperty(String name, Object value) {
		props.put(name, value);
	}

	@Override
	public Object getProperty(String name) {
		return props.get(name);
	}

	@Override
	public boolean hasProperty(String name) {
		return props.containsKey(name);
	}

	@Override
	public Map<String, Object> getProperties() {
		return Collections.unmodifiableMap(props);
	}

	@Override
	public void serialize(DataOutputStream out) throws Exception {
		Serializer.writeStringASCII(messageId, out);
		MarshallingSupport.marshalPrimitiveMap(props, out);
	}

	@Override
	public MessageObject deserialize(DataInputStream in) throws Exception {
		messageId = Serializer.readStringASCII(in);
		props = MarshallingSupport.unmarshalPrimitiveMap(in);
		return this;
	}

	@Override
	public String toString() {
		return getClass().getSimpleName() + "[id=" + getMessageId() + "]";
	}

    @Override
    public void setRefObject(Object refObject) {
        this.refObject = refObject;
    }

    @Override
    public Object getRefObject() {
        return refObject;
    }
}
