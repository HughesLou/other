package com.scb.fmsd.adapter.core.channel;

public abstract class AbstractInOutChannel<T> extends AbstractInChannel<T> implements OutChannel<T> {

	public AbstractInOutChannel(String name) {
		super(name);
	}

}
