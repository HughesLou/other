package com.scb.fmsd.adapter.core.channel.filesystem;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.fmsd.adapter.core.channel.AbstractInChannel;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.model.StringMessageObject;
import com.scb.fmsd.common.config.Configuration;

public class FileInChannel extends AbstractInChannel<MessageObject> {
	static Logger logger = LoggerFactory.getLogger(FileInChannel.class);
	
	Path location;
	String dirSelectedPattern;
	long waitpermsg;

	public FileInChannel(String name) {
		super(name);
	}
	
	public void doStart(){
		new Thread(){
			public void run(){
				try {
					sendMessages();
				} catch (Exception e) {
					logger.error("Cannot send message.",e);
				}
			}
		}.start();
	}
	
	void sendMessages() throws Exception {
		DirectoryStream<Path> dirs=Files.newDirectoryStream(location,new DirectoryStream.Filter<Path>(){
			@Override
			public boolean accept(Path entry) throws IOException {
				if (Files.isDirectory(entry)){
					return true;
				}
				return false;
			}
		});
		for (Path dir:dirs){
			String dname=dir.getName(dir.getNameCount()-1).toString();
			if (dirSelectedPattern==null || dirSelectedPattern.trim().length()==0 || dname.matches(dirSelectedPattern)){//just debug for com_asian_null
				FileVisitor<Path> v=new SimpleFileVisitor<Path>(){
					@Override
				    public FileVisitResult visitFile(Path fpath, BasicFileAttributes attr) {
				        if (attr.isSymbolicLink()) {
				        } else if (attr.isRegularFile()) {
				            logger.info("Vist regular file: "+fpath.toString());
				            if (fpath.getFileName().toString().endsWith("xml")){
				            	try {
				            		String msgstr = new String(Files.readAllBytes(fpath), StandardCharsets.ISO_8859_1);
				            		onMessage(new StringMessageObject(msgstr));
									Thread.sleep(waitpermsg);
								} catch (Exception e) {
									logger.error("Cannot continue sending msg for "+fpath,e);
									return FileVisitResult.TERMINATE;
								}
				            }
				        }
				        return FileVisitResult.CONTINUE;
				    }
				    
					@Override
				    public FileVisitResult postVisitDirectory(Path dir, IOException exc) {
				        //System.out.format("Directory: %s \n", dir);
				        return FileVisitResult.CONTINUE;
				    }
				    @Override
				    public FileVisitResult visitFileFailed(Path fpath, IOException exc) {
				        logger.error("Cannot visit file: %s\n", fpath);
				        return FileVisitResult.CONTINUE;
				    }

				};
				
				Files.walkFileTree(dir, v);
			}
		}
		
	}
	private void initialize(String location, String dirSelectedPattern, long messagewait) {
		this.location = Paths.get(location);
		this.dirSelectedPattern = dirSelectedPattern;
		this.waitpermsg = messagewait;
	}
	
	
	public static FileInChannel create(String name, Configuration conf){
		String location = conf.getString("location");//location
		String subpath  = conf.getString("dirSelectedPattern");//subpath
		long messagewait = conf.getLong("waitpermsg");
		FileInChannel inst = new FileInChannel(name);
		inst.initialize(location,subpath,messagewait);
		try {
			inst.initialize();
		} catch (Exception e) {
		}
		return inst;
	}


}
