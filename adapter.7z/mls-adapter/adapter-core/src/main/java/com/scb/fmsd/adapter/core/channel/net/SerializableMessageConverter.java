package com.scb.fmsd.adapter.core.channel.net;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;

import com.scb.fmsd.adapter.core.channel.MessageConverter;
import com.scb.fmsd.adapter.core.channel.OutChannel;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.model.Serializer;

public class SerializableMessageConverter implements MessageConverter<ByteBuffer> {

	@Override
	public MessageObject convert(ByteBuffer message) throws Exception {
		return Serializer.deserialize(new ByteArrayInputStream(message.array()));
	}

	@Override
	public ByteBuffer convert(MessageObject message, OutChannel<?> channel) throws Exception {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		Serializer.serialize(message, baos);
		return ByteBuffer.wrap(baos.toByteArray());
	}

}
