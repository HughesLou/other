package com.scb.fmsd.adapter.core.channel.mail.builder;

import com.scb.fmsd.adapter.core.model.MessageObject;

public class StringVariable implements Variable {
	
	private final String str;
	
	public StringVariable(String str) {
		this.str = str;
	}
	
	@Override
	public String resolve(MessageObject mo) {
		return str;
	}
	
}
