package com.scb.fmsd.adapter.core.recovery.impl;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import com.google.common.collect.Sets;
import com.google.common.collect.Table.Cell;
import com.google.common.collect.TreeBasedTable;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.model.MessageObjectPropertyKey;
import com.scb.fmsd.adapter.core.model.StringMessageObject;
import com.scb.fmsd.adapter.core.processor.CorrelationKey;
import com.scb.fmsd.adapter.core.recovery.FaultToleranceManager;
import com.scb.fmsd.adapter.core.recovery.RecoveryException;
import com.scb.fmsd.adapter.core.utils.FileUtils;
import com.scb.fmsd.common.config.Configuration;
import com.scb.fmsd.common.jmx.JMXBeanAttribute;

/**
 * When start the adapter need load index file
 * 
 * Manage the error queue folder, index, cache of index, should be thread-safe ,
 * use the read write lock.
 * 
 * when have exception add external id as key, timestamp portfolio, trade type,
 * source system, main action, package trade? as value
 * 
 * every time add/delete new key or change the value , and also will persist the
 * index file.
 * 
 * Rest service need transfer index content to TMS2, TMS2 replay the trade, then
 * ask Adapter to remove the external ID from Index and file
 * 
 */
public class FaultToleranceManagerImpl implements FaultToleranceManager<MessageObject> {

	private static final String CORRELATION_KEY_CLASS = "correlationKeyClass";

	private static final Logger logger = LoggerFactory.getLogger(FaultToleranceManagerImpl.class);

	private Path indexFileLocation;
	private Path errorFolderLocation;
	private char indexSeparator = ';';

	private final CorrelationKey correlationKey;

	public FaultToleranceManagerImpl(Path retryFolderLocation, Path errorFolderLocation, Path indexFileLocation, char indexSeparator, CorrelationKey correlationKey) throws IOException,
			RecoveryException {
		this.correlationKey = correlationKey;
		this.errorFolderLocation = Files.createDirectories(errorFolderLocation);
		this.indexFileLocation = indexFileLocation;
		this.indexSeparator = indexSeparator;
		initialize();
	}

	public static FaultToleranceManager<MessageObject> create(String name, Configuration config) throws Exception {
		String correlationKeyClass = config.getString(CORRELATION_KEY_CLASS);
		CorrelationKey key = (CorrelationKey) Class.forName(correlationKeyClass).newInstance();
		return new FaultToleranceManagerImpl(Paths.get(config.getString("retryFolderLocation")), Paths.get(config.getString("errorFolderLocation")), Paths.get(config.getString("indexFileLocation")),
				config.getString("indexSeparator").charAt(0), key);
	}

	/**
	 * externalId, timestamp, fileName
	 */
	private final TreeBasedTable<String, Long, String> errorTable = TreeBasedTable.create();

	private final ReentrantReadWriteLock readWriteLock = new ReentrantReadWriteLock();

	public void initialize() throws RecoveryException {
		try {
			if (Files.notExists(errorFolderLocation)) {
				Files.createDirectories(errorFolderLocation);
			}
			if (Files.exists(indexFileLocation)) {
				loadIndexFile();
			} else {
				if (Files.notExists(indexFileLocation.getParent())) {
					Files.createDirectories(indexFileLocation.getParent());
				}
				Files.createFile(indexFileLocation);
				logger.info("Error queue index file {} not existed, have been created!", indexSeparator);
			}
		} catch (IOException e) {
			throw new RecoveryException("FaultToleranceManager initialize failed, due to", e);
		}
	}

	private void loadIndexFile() throws IOException {
		CSVReader csvReader = null;
		try {
			readWriteLock.writeLock().lock();
			logger.info("Start to load error queue index file {}", indexFileLocation);
			csvReader = new CSVReader(Files.newBufferedReader(indexFileLocation, Charset.defaultCharset()), indexSeparator);
			List<String[]> csvTable = csvReader.readAll();
			for (String[] line : csvTable) {
				try {
					errorTable.put(line[0], Long.valueOf(line[1]), line[2]);
				} catch (Exception e) {
					logger.error("Failed to load line: {} , due to ", line, e);
				}
			}
			logger.info("load index file {} completed!", indexFileLocation);
		} finally {
			csvReader.close();
			readWriteLock.writeLock().unlock();
		}
	}

	@Override
	public void addFailedMessageToQueue(MessageObject message) throws RecoveryException {

		try {
			Long arrivalTimestamp = (Long) message.getProperty(MessageObjectPropertyKey.ARRIVAL_TIMESTAMP_NAME.getKey());
			Set<Object> keys = Sets.newHashSet();
			try {
				keys = correlationKey.getKeys(message);
				if (keys == null || keys.isEmpty() || arrivalTimestamp == null) {
					throw new IllegalArgumentException(String.format("Message keys / arrivalTimestamp is null, invalid message %s !", message.getMessageId()));
				}
			} catch (Exception e) {
				logger.error("Failed to get keys from message {} .!", message.getMessageId(), e);
				persistMsgToFile(message, message.getMessageId() + "_error_message_missing_keys");
				return;// invalid message will not be store to error queue
			}
			Properties properties = correlationKey.getProperties(message);
			String fileName = buildMessageFileName(message.getMessageId(), keys.toString(), properties);
			logger.info("Error queue adding failed message {} , keys {}", message.getMessageId(), keys.toString());
			persistMsgToFile(message, fileName);

			List<String[]> newArrayListForCsv = Lists.newArrayList();
			readWriteLock.writeLock().lock();
			for (Object key : keys) {
				errorTable.put(key.toString(), arrivalTimestamp, fileName);
				newArrayListForCsv.add(new String[] { key.toString(), Long.toString(arrivalTimestamp), fileName });
			}
			// to avoid incidence, refresh the index to disk
			if (Files.notExists(indexFileLocation)) {
				refreshAllToIndexFile();
			}
			appendMsgToIndexFile(newArrayListForCsv);

		} catch (Exception e) {
			persistMsgToFile(message, (message.getMessageId() + "_error_message_to_check"));
			throw new RecoveryException(e);
		} finally {
			if (readWriteLock.isWriteLocked()) {
				readWriteLock.writeLock().unlock();
			}
		}
	}

	private void appendMsgToIndexFile(List<String[]> msgList) throws IOException {
		CSVWriter csvWriter = new CSVWriter(Files.newBufferedWriter(indexFileLocation, Charset.defaultCharset(), StandardOpenOption.WRITE, StandardOpenOption.APPEND), indexSeparator);
		for (String[] line : msgList) {
			csvWriter.writeNext(new String[] { line[0], line[1], line[2] });
		}
		csvWriter.close();
	}

	@Override
	public boolean isFailedMessage(MessageObject message) {
		try {
			Object retryFlag = message.getProperty(MessageObjectPropertyKey.RETRY.getKey());
			if (retryFlag != null) {
				Boolean isRetry = (Boolean) retryFlag;
				return isRetry.booleanValue() == true ? false : true;
			}
			Set<Object> keys = correlationKey.getKeys(message);
			if (keys == null || keys.isEmpty()) {
				return false;
			}
			boolean result = false;
			try {
				readWriteLock.readLock().lock();
				for (Object key : keys) {
					if (errorTable.containsRow(key)) {
						result = true;
						break;
					}
				}
			} finally {
				readWriteLock.readLock().unlock();
			}
			return result;
		} catch (Exception e) {
			logger.error("Invalid message {}", message.getMessageId(), e);
			return false;
		}
	}

	private void persistMsgToFile(MessageObject m, String fileName) {
		Path file = errorFolderLocation.resolve(FileUtils.reformFileName(fileName));
		logger.info("save unprocessed/failed message {} to {}", m.getMessageId(), file.toString());
		try {
			Files.write(file, m.getBytes());
		} catch (IOException e) {
			logger.error("Failed to save unprocessed/failed {} to file {}", m.getMessageId(), file.toString());
		}
	}

	private String buildMessageFileName(String messageId, String keys, Properties props) {
		StringBuffer buffer = new StringBuffer();
		buffer.append(messageId).append("_").append("keys").append(keys).append("_");
		for (Object key : props.keySet()) {
			buffer.append(props.get(key)).append("_");
		}
		return FileUtils.reformFileName(StringUtils.chop(buffer.toString()), '-');
	}

	@Override
	public void removeMessagesFromErrorQueue(List<String> ignoreList) throws IOException {
		try {
			readWriteLock.writeLock().lock();
			for (String msgFileName : ignoreList) {
				if (errorTable.containsValue(msgFileName)) {
					for (Cell<String, Long, String> cell : Sets.newHashSet(errorTable.cellSet())) {
						if (cell.getValue().equals(msgFileName)) {
							logger.info("Removing error message {} {} {} from error queue.", cell.getRowKey(), cell.getColumnKey(), msgFileName);
							errorTable.remove(cell.getRowKey(), cell.getColumnKey());
						}
					}
					Path msgPath = errorFolderLocation.resolve(msgFileName);
					if (Files.exists(msgPath)) {
						FileUtils.deletePath(msgPath);
					}
				}
			}
		} catch (IOException e) {
			logger.error("Message file {} was failed to remove message from table ", ignoreList.toArray(), e);
		} finally {
			readWriteLock.writeLock().unlock();
		}
	}

	@Override
	public SortedMap<Long, String> getAllMessageFileMapping() {
		SortedMap<Long, String> result = new TreeMap<Long, String>();
		try {
			readWriteLock.readLock().lock();
			SortedMap<String, Map<Long, String>> rowMap = errorTable.rowMap();
			for (Map<Long, String> map : rowMap.values()) {
				result.putAll(map);
			}
			return result;
		} finally {
			readWriteLock.readLock().unlock();
		}
	}

	@Override
	public MessageObject getAndRemoveMessageFromErrorQueue(Long timestamp, String messageName) throws IOException {
		MessageObject messageObject = null;
		try {
			readWriteLock.writeLock().lock();
			Path filePath = errorFolderLocation.resolve(messageName);
			if (errorTable.containsValue(messageName)) {
				try {
					Path msgPath = errorFolderLocation.resolve(messageName);
					String txt = new String(Files.readAllBytes(msgPath), StandardCharsets.ISO_8859_1);
					messageObject = new StringMessageObject(txt);
					FileUtils.deletePath(filePath);
					Map<String, String> columnMap = errorTable.column(Long.valueOf(timestamp));
					for (String key : Sets.newHashSet(columnMap.keySet())) {
						errorTable.remove(key, Long.valueOf(timestamp));
					}
				} catch (Exception e) {
					logger.error("Failed to retry message {} - {} , due to ", timestamp, messageName, e);
				}
			} else {
				if (Files.exists(filePath)) {
					FileUtils.deletePath(filePath);
				}
			}
		} finally {
			readWriteLock.writeLock().unlock();
		}
		return messageObject;
	}

	/**
	 * Refresh index file from memory
	 * 
	 * @throws IOException
	 */
	@Override
	public void refreshAllToIndexFile() throws IOException {
		CSVWriter csvWriter = null;
		try {
			readWriteLock.writeLock().lock();
			logger.info("Save all error queue to index file {} .", indexFileLocation);
			csvWriter = new CSVWriter(Files.newBufferedWriter(indexFileLocation, Charset.defaultCharset()), indexSeparator);
			for (Cell<String, Long, String> cell : errorTable.cellSet()) {
				csvWriter.writeNext(new String[] { cell.getRowKey(), String.valueOf(cell.getColumnKey()), cell.getValue() });
			}
		} finally {
			readWriteLock.writeLock().unlock();
			if (csvWriter != null) {
				csvWriter.close();
			}
		}
	}

	public Map<UnprocessedMessageInfo, Collection<String>> getUnprocessedMessageList() throws IOException {
		if (getErrorTable().isEmpty()) {
			loadIndexFile();
		}
		try {
			readWriteLock.readLock().lock();
			Multimap<UnprocessedMessageInfo, String> multiMap = HashMultimap.create();
			ImmutableSet<Cell<String, Long, String>> newHashSet = ImmutableSet.copyOf(errorTable.cellSet());
			for (Cell<String, Long, String> cell : newHashSet) {
				multiMap.put(new UnprocessedMessageInfo(cell.getColumnKey(), cell.getValue()), cell.getRowKey());
			}
			return multiMap.asMap();
		} finally {
			readWriteLock.readLock().unlock();
		}
	}

	public CorrelationKey getCorrelationKey() {
		return correlationKey;
	}

	public TreeBasedTable<String, Long, String> getErrorTable() {
		return errorTable;
	}

	@JMXBeanAttribute
	public Path getErrorFolderLocation() {
		return errorFolderLocation;
	}

	@JMXBeanAttribute
	public Path getIndexFileLocation() {
		return indexFileLocation;
	}
}
