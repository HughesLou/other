package com.scb.fmsd.adapter.core.channel.mail.builder;

import com.scb.fmsd.adapter.core.utils.NetUtils;

public class HostVariable extends StringVariable {
	
	public HostVariable() {
		super(NetUtils.getHostname());
	}

}
