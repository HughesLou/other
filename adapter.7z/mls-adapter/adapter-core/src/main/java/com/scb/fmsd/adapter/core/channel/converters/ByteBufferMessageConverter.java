package com.scb.fmsd.adapter.core.channel.converters;

import java.nio.ByteBuffer;

import com.scb.fmsd.adapter.core.channel.MessageConverter;
import com.scb.fmsd.adapter.core.channel.OutChannel;
import com.scb.fmsd.adapter.core.model.BytesMessageObject;
import com.scb.fmsd.adapter.core.model.MessageObject;

public class ByteBufferMessageConverter implements MessageConverter<ByteBuffer> {

	@Override
	public MessageObject convert(ByteBuffer message) throws Exception {
		return new BytesMessageObject(message.array());
	}

	@Override
	public ByteBuffer convert(MessageObject message, OutChannel<?> channel) throws Exception {
		byte[] bytes = message.getBytes();
		return ByteBuffer.wrap(bytes);
	}

}
