package com.scb.fmsd.adapter.core.processor.impl;

import java.io.ByteArrayOutputStream;
import java.io.StringReader;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Templates;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.fmsd.adapter.core.model.BytesMessageObject;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.processor.Processor;
import com.scb.fmsd.adapter.core.utils.FileUtils;
import com.scb.fmsd.common.config.Configuration;

public class XSLTTransformer implements Processor {

	private final static Logger logger = LoggerFactory.getLogger(XSLTTransformer.class);

	private final  TransformerFactory factory;

	private final Map<String, Templates> templates = new HashMap<>();

	public static final String TEMPLATE_KEY = "TEMPLATE";

	private Properties parameters;

	private Properties outputProperties;

	public XSLTTransformer() throws Exception {
		factory = TransformerFactory.newInstance();
		logger.info("Using {} XSLT Transformation factory", factory);
	}

	public void setParameters(Properties parameters) {
		this.parameters = parameters;
	}

	public Properties getParameters() {
		return parameters;
	}

	public void setOutputProperties(Properties outputProperties) {
		this.outputProperties = outputProperties;
	}

	public Properties getOutputProperties() {
		return outputProperties;
	}

	public void registerTemplate(String name, StreamSource source) throws Exception {
		if (!templates.containsKey(name)) {
			Templates t = factory.newTemplates(source);
			templates.put(name, t);
			logger.info("XSLT template {} created {}", name, t);
		}
	}

	public void registerTemplates(Path location) throws Exception {
		logger.info("Search for templates in {}", location);
		try (DirectoryStream<Path> dir = Files.newDirectoryStream(location, "*.xsl")) {
			for (Path file : dir) {
				registerTemplate(FileUtils.getFileNameWithoutExt(file), new StreamSource(file.toFile()));
			}
		}
	}

	@Override
	public MessageObject process(MessageObject message) throws Exception {
		logger.info("Got {}", message.getText());

		Templates template = null;
		Object templateName = message.getProperty(TEMPLATE_KEY);
		if (templateName instanceof String) {
			template = templates.get(templateName);
		}

		if (template == null) {
			throw new IllegalStateException("[" + templateName + "] template not found");
		}

		Transformer transformer = template.newTransformer();

		if (parameters  != null) {
			for (Map.Entry<Object, Object> e: parameters.entrySet()) {
				transformer.setParameter((String) e.getKey(), e.getValue());
			}
		}

		if (outputProperties != null) {
			transformer.setOutputProperties(outputProperties);
		}

		Source input = new StreamSource(new StringReader(message.getText()));

		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		Result result = new StreamResult(baos);
		transformer.transform(input, result);

		return new BytesMessageObject(baos.toByteArray(), message.getMessageId());
	}

	@Override
	public void initialize() throws Exception {
	}

	@Override
	public void shutdown() throws Exception {
	}

	public static XSLTTransformer create(String name, Configuration config) throws Exception {
		XSLTTransformer t = new XSLTTransformer();
		t.registerTemplates(Paths.get(config.getString("xslt.location")));
		t.setParameters(config.subset("params").asProperties());
		t.setOutputProperties(config.subset("output").asProperties());
		return t;
	}
}
