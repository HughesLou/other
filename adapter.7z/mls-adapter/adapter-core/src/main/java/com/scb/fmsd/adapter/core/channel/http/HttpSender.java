package com.scb.fmsd.adapter.core.channel.http;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.zip.GZIPOutputStream;

import com.scb.fmsd.adapter.core.channel.AbstractOutChannel;
import com.scb.fmsd.adapter.core.channel.converters.StringMessageConverter;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.common.config.Configuration;
import com.scb.fmsd.common.jmx.JMXBeanAttribute;

public class HttpSender extends AbstractOutChannel<String> {

    public static final String ORIGINAL_MESSAGE_ID = "ORIGINAL_MESSAGE_ID";

    public static final String MESSAGE_ID = "MESSAGE_ID";

    public static final String URL = "url";

	public static final String HEADER = "header";

    public static final String READ_TIMEOUT = "readTimeout";

    public static final String CONNECT_TIMEOUT = "connectTimeout";
    
    public static final String VALIDATE_ON_START = "validateOnStart";
    
    public static final String COMPRESS_REQUEST = "compressRequest";
    
    public static final String METHOD = "method";

    private final URL url;

	private int connectTimeout;

	private int readTimeout;

	private boolean validateOnStart = false;
	
	private boolean compressRequest = false;
	
	private String method;
	
	private final Map<String, String> headers = new HashMap<>();


	public HttpSender(String name, String url) throws MalformedURLException {
		super(name);
		this.url = new URL(url);
		this.validateOnStart = true;
		setMessageConverter(new StringMessageConverter());
	}

	public void addHeader(String name, String value) {
		this.headers.put(name, value);
	}

	public void removeHeader(String name) {
		this.headers.remove(name);
	}

	public Map<String, String> getHeaders() {
		return Collections.unmodifiableMap(headers);
	}

	@JMXBeanAttribute
	public URL getUrl() {
		return url;
	}

    public void setMethod(String method) {
        this.method = method;
    }

    @JMXBeanAttribute
	public int getReadTimeout() {
		return readTimeout;
	}

	public void setReadTimeout(int readTimeout) {
		this.readTimeout = readTimeout;
	}
	
	public void setValidateOnStart(boolean validateOnStart) {
	    this.validateOnStart = validateOnStart;
	}
	public void setCompressRequest(boolean compressRequest){
		this.compressRequest = compressRequest;
	}

	@JMXBeanAttribute
	public int getConnectTimeout() {
		return connectTimeout;
	}

	public void setConnectTimeout(int connectTimeout) {
		this.connectTimeout = connectTimeout;
	}

	private HttpURLConnection createConnection() throws IOException {
		HttpURLConnection con = (HttpURLConnection) url.openConnection();
		con.setConnectTimeout(connectTimeout);
		con.setReadTimeout(readTimeout);
		return con;
	}

	private void send0(MessageObject message, int attemp) throws Exception {
		long start = System.currentTimeMillis();
		HttpURLConnection con = createConnection();
		con.setRequestMethod(method);
		con.setDoOutput(true);
		byte[] data = compress(message.getBytes());
		con.setFixedLengthStreamingMode(data.length);
		if (headers != null) {
			for (Map.Entry<String, String> e : headers.entrySet()) {
				con.addRequestProperty(e.getKey(), e.getValue());
			}
		}
		if (compressRequest){
			con.addRequestProperty("Content-Encoding", "gzip");
		}
		con.addRequestProperty(MESSAGE_ID, message.getMessageId());
		if (message.getOriginal() != null) {
			con.addRequestProperty(ORIGINAL_MESSAGE_ID, message.getOriginal().getMessageId());
		}

		for (Map.Entry<String, Object> e : message.getProperties().entrySet()) {
			Object value = e.getValue();
			con.addRequestProperty(e.getKey(), value != null ? value.toString() : null);
		}
		OutputStream ous = null;
		InputStream ins=null;
		int responseCode = -1;
		try {
			ous = con.getOutputStream();
			ous.write(data);
			ous.flush();
			ins = con.getInputStream();
			responseCode = con.getResponseCode();
			long totalcost = System.currentTimeMillis() -start;
			if (responseCode / 100 == 2){
				logger.info("Message send successfully, attempts: {}, Cost: {}", attemp, totalcost);
			}else{
				logger.error("Server response code: {}, timeSpend: {}", responseCode, totalcost);
				throw new IOException("Bad response code: "+responseCode);
			}
		}catch(IOException e){
			String output = consumeStream(ins);
			logger.error("HTTP response body: {}",output);
			throw new IOException("HTTP response code: " + responseCode + ", response message: " + con.getResponseMessage());
		} finally {
			try{
				if (ous!=null) ous.close();
			}catch(Exception e){
				logger.error("Can't close outputStream");
			}
			try{
				if (ins!=null) ins.close();
			}catch(Exception e){
				logger.error("Can't close inputStream");
			}
			con.disconnect();
		}
	}
	private byte[] compress(byte[] bytes) throws IOException{
		if (compressRequest){
			ByteArrayOutputStream compressData = new ByteArrayOutputStream(bytes.length/2);
			GZIPOutputStream ous = new GZIPOutputStream(compressData);
			ous.write(bytes);
			ous.flush();
			ous.close();
			return compressData.toByteArray();
		}
		return bytes;
	}

	private String consumeStream(InputStream ins){
		if (ins==null) return "Null Stream";
		BufferedInputStream bins = null;
		try{
			bins = new BufferedInputStream(ins);
			ByteArrayOutputStream ous = new ByteArrayOutputStream(2048);
			byte[] buff = new byte[1024];
			int rleng = 0;
			while ((rleng=bins.read(buff))!=-1){
				ous.write(buff, 0, rleng);
			}
			ous.flush();
			byte[] res = ous.toByteArray();
			ous.close();
			return new String(res);
		}catch(IOException e){
			return "ERROR when reading stream: "+e.getMessage();
		}
	}
	@Override
	public void send(MessageObject message) throws Exception {
		int attempt = 0;
		try {
			send0(message,attempt);
		} catch (Exception e) {
			logger.error("An exception occured, trying to (re)send "+e.getMessage(), e);
			
			while (nextRetryAttempt(attempt++)) {
				waitRetryAttemp();
				try {
					send0(message, attempt);
					return;
				} catch (Exception e1) {
					e = e1;
					logger.error("Failed to send message at {} attempt, error={}", attempt, e1);
				}
			}
			logger.error("Failed to send message after {} attempts, error={}", attempt, e);
			throw e;
		}
	}

	@Override
	protected void doStart() throws IOException {
	    if(validateOnStart){
	        validate(createConnection());
	    }
	}

	protected void validate(HttpURLConnection con) throws IOException {
		int responseCode = con.getResponseCode();
		logger.info("Connected: responseCode={}", responseCode);
	}

	@Override
	public String toString() {
		return "HttpSender [URL=" + url + "]";
	}

	public static HttpSender create(String name, Configuration config) throws Exception {
		HttpSender channel = new HttpSender(name, config.getString(URL));
		configure(channel, config);
		return channel;
	}

	public static <T extends HttpSender> T configure(T channel, Configuration config) {
		channel.setConnectTimeout((int) config.getDuration(CONNECT_TIMEOUT, TimeUnit.MILLISECONDS, 10000));
		channel.setReadTimeout((int) config.getDuration(READ_TIMEOUT, TimeUnit.MILLISECONDS, 10000));
		channel.setValidateOnStart(config.getBoolean(VALIDATE_ON_START, true));
		channel.setCompressRequest(config.getBoolean(COMPRESS_REQUEST, false));
		channel.setMethod(config.getString(METHOD, "POST"));
		Configuration headers = config.subset(HEADER);
		for (Map.Entry<Object, Object> header : headers.asProperties().entrySet()) {
			channel.addHeader((String) header.getKey(), (String) header.getValue());
		}
		return channel;
	}

}
