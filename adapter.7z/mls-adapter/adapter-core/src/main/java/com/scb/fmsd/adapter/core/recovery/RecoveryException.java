package com.scb.fmsd.adapter.core.recovery;

public class RecoveryException extends Exception {

	private static final long serialVersionUID = 1L;

	public RecoveryException() {
	}

	public RecoveryException(String message) {
		super(message);
	}

	public RecoveryException(Throwable cause) {
		super(cause);
	}

	public RecoveryException(String message, Throwable cause) {
		super(message, cause);
	}

}
