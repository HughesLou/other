package com.scb.fmsd.adapter.core.processor.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantLock;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.model.MessageObjectPropertyKey;
import com.scb.fmsd.adapter.core.processor.AbstractParallelProcessor;
import com.scb.fmsd.adapter.core.processor.CompletionCallback;
import com.scb.fmsd.adapter.core.processor.CorrelationKey;
import com.scb.fmsd.adapter.core.processor.Processor;
import com.scb.fmsd.common.config.Configuration;
import com.scb.fmsd.common.jmx.JMXBeanAttribute;

public class SetBasedParallelProcessor extends AbstractParallelProcessor {

    public static final String THREADS_COUNT = "threads";

    public static final String CORRELATION_KEY_CLASS = "correlationKeyClass";

    private static final Logger logger = LoggerFactory.getLogger(SetBasedParallelProcessor.class);

	protected final CorrelationKey correlationKey;

	protected Worker[] workers;
	
	protected int nextWorker = 0;

	public SetBasedParallelProcessor(Processor processor, int threads, int size, CorrelationKey correlationKey) {
		super(processor, threads, size);
		this.workers = new Worker[threads];
		this.correlationKey = correlationKey;
	}
	
	public int getWorkingQueueSize(){
		int size = 0;
		for (Worker w: workers){
			size += w.getQueueSize();
		}
		return size;
	}
	
	@JMXBeanAttribute(useToString = true)
	public CorrelationKey getCorrelationKey() {
		return correlationKey;
	}
	

	@Override
	public void process(MessageObject message, CompletionCallback callback) throws Exception {
		Set<Object> key = correlationKey.getKeys(message);
		MDC.put(MessageObjectPropertyKey.CORRELATION_KEYS.getKey(), key.toString());
		logger.info("Processing {} - {}", message.getMessageId() , key);

		int no = -1;
		for (int i = 0; i < workers.length; i++) {
			if (workers[i].isProcessing(key)) {
				no = i;
				break;
			}
		}

		if (no == -1) {
			no = nextWorker++ % workers.length;
		}

		if (logger.isDebugEnabled()) {
			logger.debug("Enqueue {} to #{}, key={}", message.getMessageId(), no, key);
		}
		workers[no].enqueue(new Wrapper(message, key, callback, MDC.getCopyOfContextMap()));
		logger.debug("Processed {}", message.getMessageId());
	}

	@Override
	public List<MessageObject> shutdownNow() {
		List<MessageObject> list = new ArrayList<>();
		for (int i = 0; i < workers.length; i++) {
			Worker w = workers[i];
			try {
				if (!w.shutdown(1, TimeUnit.SECONDS)) {
					logger.info("{} was not shutdown successfully", w);
				}
			} catch (InterruptedException ex) {
				logger.info("{} was not shutdown successfully: {}", w, ex);
			};
			Wrapper wrap;
			while ((wrap = w.queue.poll()) != null) {
				list.add(wrap.message);
			}
		}
		return list;
	}

	@Override
	public void initialize() {
		for (int i = 0; i < threads; i++) {
			workers[i] = new Worker(processor, i + 1, size);
			workers[i].start();
		}
	}

	protected static class Worker extends Thread {

		private final Processor processor;

		private volatile boolean stopped;

		private final BlockingQueue<Wrapper> queue;

		private final ConcurrentMap<Object, AtomicInteger> keys = new ConcurrentHashMap<>(16, 0.75f, 1);
		private final ReentrantLock keylock = new ReentrantLock();

		private final CountDownLatch shutdown = new CountDownLatch(1);

		public Worker(Processor processor, int no, int size) {
			super("ParallelProcessor-" + no);
			this.processor = processor;
			this.queue = new ArrayBlockingQueue<>(size);
		}
		
		public int getQueueSize(){
			return queue.size();
		}
		
		public boolean isProcessing(Set<Object> keys) {
			for (Object k : keys) {
				AtomicInteger refs = this.keys.get(k);
				if (refs != null) {
					return true;
				}
			}
			return false;
		}

		public void enqueue(Wrapper message) throws InterruptedException {
			try{
				keylock.lock();
				for (Object k : message.key) {
					AtomicInteger refs = keys.get(k);
					if (refs == null) {
						refs = keys.putIfAbsent(k, new AtomicInteger(0));
						if (refs == null) {
							refs = keys.get(k);
						}
					}
					refs.incrementAndGet();
				}
			}finally{
				keylock.unlock();
			}
			queue.put(message);


		}

		public boolean shutdown(long timeout, TimeUnit unit) throws InterruptedException {
			stopped = true;
			interrupt();
			return shutdown.await(timeout, unit);
		}

		@Override
		public void run() {
			logger.info("{} started", getName());
			while (!stopped) {
				Wrapper wrap = null;
				try {
					wrap = queue.take();
					if(wrap.mdcMap != null){
					    MDC.setContextMap(wrap.mdcMap );
					}
					logger.debug("Dequeued message {} ", wrap.message);
					MessageObject result = processor.process(wrap.message);
					
					wrap.callback.completed(result, wrap.message);
				} catch (InterruptedException ignore) {
					Thread.currentThread().interrupt();
				} catch (Exception e) {
					logger.error("Unexpected exception", e);
					if (wrap != null) {
						wrap.callback.failed(e, wrap.message);
					}
				}finally{
					//for failure or success, the key will be deleted.
					if (wrap!=null){
					    decreaseAndRemove(wrap.key);
	                    if(wrap.mdcMap != null){
	                        MDC.clear();
	                    }
					}
				}
			}
			logger.info("{} stopped", getName());
			shutdown.countDown();
		}

		private void decreaseAndRemove(Set<Object> msgkeys) {
			try{
				keylock.lock();
				List<Object> rmKeyList=new ArrayList<Object>();
			    for (Object k : msgkeys) {
			    	AtomicInteger refs = keys.get(k); 
			    	if (refs==null){
			    		logger.error("Can't find COUNT for key " + k.toString());
			    		continue;
			    	}
			        int count = refs.decrementAndGet();
			        if (count<=0){
			        	rmKeyList.add(k);
			        }
			    }
				for (Object k: rmKeyList){
					keys.remove(k);
				}
			}finally{
				keylock.unlock();
			}
		}
	}

	protected static class Wrapper {
		private final MessageObject message;
		private final CompletionCallback callback;
		private final Set<Object> key;
        private final Map<?,?> mdcMap;
		public Wrapper(MessageObject message, Set<Object> key, CompletionCallback callback, Map<?,?> mdcMap) {
			this.message = message;
			this.callback = callback;
			this.key = key;
            this.mdcMap = mdcMap;
		}
	}

	public static SetBasedParallelProcessor create(String name, Configuration config, Processor processor) throws Exception {
		int workers = config.getInt(THREADS_COUNT, Runtime.getRuntime().availableProcessors());
		int queueSize = config.getInt("queueSize", 10);
		String correlationKeyClass = config.getString(CORRELATION_KEY_CLASS);
		CorrelationKey key = (CorrelationKey) Class.forName(correlationKeyClass).newInstance();
		return new SetBasedParallelProcessor(processor, workers, queueSize, key);
	}

}
