package com.scb.fmsd.adapter.core.channel.mail.builder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.reflections.Reflections;
import org.reflections.util.ClasspathHelper;
import org.reflections.util.ConfigurationBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.fmsd.adapter.core.channel.mail.SubjectBuilder;
import com.scb.fmsd.adapter.core.model.MessageObject;

public class PatternSubjectBuilder implements SubjectBuilder {
	
	private static final Logger logger = LoggerFactory.getLogger(PatternSubjectBuilder.class);
	
	private final String subject;
	
	private Map<String, Variable> variables = new HashMap<>();
	
	private List<Variable> builder = new ArrayList<>();
	
	public PatternSubjectBuilder(String subject) throws Exception {
		this.subject = subject;
		
		Reflections r = new Reflections(new ConfigurationBuilder()
        	.setUrls(ClasspathHelper.forClass(Variable.class)));
		
		Set<Class<? extends Variable>> set = r.getSubTypesOf(Variable.class);
		for (Class<? extends Variable> cl : set) {
			String name = cl.getSimpleName();
			try {
				variables.put(name.substring(0, name.length() - 8).toLowerCase(), cl.newInstance());
			} catch (InstantiationException ignore) {
			}
		}
	}
	
	public PatternSubjectBuilder addVariable(String var, Variable variable) {
		variables.put(var, variable);
		return this;
	}
	
	public PatternSubjectBuilder compile() {
		logger.info("Precompile subject builder for [{}]", subject);
		
		char[] chars = subject.toCharArray();
		int i = 0, j = 0, start = 0, n = chars.length;
		while (i < n) {
			char ch = chars[i];
			if (ch == '%') {
				j = i + 1;
				boolean var = false;
				while (j < n) {
					char ch2 = chars[j];
					if (ch2 == '%') {
						break;
					}
					if (!Character.isLetter(ch2)) {
						break;
					}
					var = true;
					j++;
				}
				if (var) {
					if (start < i) {
						builder.add(new StringVariable(subject.substring(start, i)));
					}
					String varName = subject.substring(i + 1, j);
					if (!variables.containsKey(varName)) {
						throw new IllegalStateException("No resolver for [" + varName + "] found");
					}
					builder.add(variables.get(varName));
					start = j;
				}
				i = j + 1;
			} else {
				i++;
			}
		}
		if (start < n) {
			builder.add(new StringVariable(subject.substring(start, n)));
		}
		
		logger.info("Subject builder compiled [{}]", builder);
		return this;
	}

	@Override
	public String build(MessageObject mo) {
		StringBuilder sb = new StringBuilder();
		for (Variable r : builder) {
			sb.append(r.resolve(mo));
		}
		return sb.toString();
	}
	
}
