package com.scb.fmsd.adapter.core.channel.jms;

import java.util.Objects;
import java.util.Properties;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.naming.InitialContext;

import org.apache.commons.lang3.StringUtils;

import com.scb.fmsd.adapter.core.channel.AbstractChannel;
import com.scb.fmsd.adapter.core.channel.MessageConverter;
import com.scb.fmsd.adapter.core.channel.OutChannel;
import com.scb.fmsd.adapter.core.channel.TransactionSupport;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.common.config.Configuration;
import com.scb.fmsd.common.jmx.JMXBeanAttribute;

public class JmsSender extends AbstractChannel<Message>
	implements OutChannel<Message>, TransactionSupport {

	private ConnectionFactory connectionFactory;

	private Destination destination;

	private Connection connection;

    private String username;

    private String password;

    private MessageProducer producer;

	private Session session;

	private boolean transacted = Boolean.FALSE;

	private int deliveryMode = DeliveryMode.NON_PERSISTENT;

	private int timeToLive = 0;	// zero is unlimited

	private boolean validateOnStart;
	
	private boolean firstStart = true;

    public JmsSender(String name) {
        this(name, new JMSMessageConverter());
    }

    public JmsSender(String name, MessageConverter<Message> messageConverter) {
        super(name);
        setMessageConverter(messageConverter);
    }

	public ConnectionFactory getConnectionFactory() {
		return connectionFactory;
	}

	public void setConnectionFactory(ConnectionFactory connectionFactory) {
		this.connectionFactory = connectionFactory;
	}

	@JMXBeanAttribute(useToString = true)
	public Destination getDestination() {
		return destination;
	}

	public void setDestination(Destination destination) {
		this.destination = destination;
	}

	@Override
	public boolean isTransacted() {
		return transacted;
	}

	public void setTransacted(boolean transacted) {
		this.transacted = transacted;
	}

	@JMXBeanAttribute
	public int getDeliveryMode() {
		return deliveryMode;
	}

	public void setDeliveryMode(int deliveryMode) {
		this.deliveryMode = deliveryMode;
	}

	@JMXBeanAttribute
	public int getTimeToLive() {
		return timeToLive;
	}

	public void setTimeToLive(int timeToLive) {
		this.timeToLive = timeToLive;
	}

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	public MessageProducer getProducer() {
		return producer;
	}

	public void setProducer(MessageProducer producer) {
		this.producer = producer;
	}

	public void setSession(Session session) {
		this.session = session;
	}

	@Override
	protected void doInitialize() {
		Objects.requireNonNull(getConnectionFactory(), "'connectionFactory' is null!");
		Objects.requireNonNull(getDestination(), "'destination' is null!");
	}

	@Override
	protected void doStart() throws JMSException {
		try {
			// add support for username and password
			if (!StringUtils.isEmpty(username)
					&& !StringUtils.isEmpty(password)) {
				connection = connectionFactory.createConnection(username,
						password);
			} else {
				connection = connectionFactory.createConnection();
			}

			session = connection.createSession(transacted,
					Session.AUTO_ACKNOWLEDGE);

			producer = session.createProducer(destination);
			producer.setDeliveryMode(deliveryMode);
			producer.setTimeToLive(timeToLive);
		} catch (JMSException e) {
			if ( firstStart==true && validateOnStart!=true){
				logger.error("Cannot start " + connection + " during startup, will retry later\n", e);
			}
			else {
				throw e;
			}
		} finally {
			firstStart = false;
		}
	}

	@Override
	protected void doStop() {
		if (connection != null) {
			try { connection.close(); } catch (JMSException ignore) {}
			connection = null;
		}
	}

	public void send(Message message) throws Exception {
		producer.send(message);
	}
	
	public void setValidateOnStart(boolean validateOnStart) {
	    this.validateOnStart = validateOnStart;
	}


	@Override
	public void send(MessageObject message) throws Exception {
		try {
			send(converter.convert(message, this));
		} catch (Exception e) {
			logger.error("Failed to send message " + message.getMessageId() + ", trying to (re)send\n", e);
			int attempt = 0;
			while (nextRetryAttempt(attempt++)) {
				waitRetryAttemp();
				try {
					restart();
					send(converter.convert(message, this));
					logger.info("Message {} sent after {} attempts!", message.getMessageId(), attempt);
					return;
				} catch (Exception e1) {
					e = e1;
					logger.error("Failed to send message at {} attempt, error={}", attempt, e);
				}
			}
			logger.error("Failed to send message {} after {} attempts, error={}", message.getMessageId(), attempt, e);
			throw e;
		}
	}

	@Override
	public void commit() throws JMSException {
		Objects.requireNonNull(session, "JMS session is NULL");
		if (session.getTransacted()) {
			session.commit();
		}
	}

	@Override
	public void rollback() throws JMSException {
		Objects.requireNonNull(session, "JMS session is NULL");
		if (session.getTransacted()) {
			session.rollback();
		}
	}

	public Session getSession() {
		return session;
	}

	@Override
	public String toString() {
		return "JmsSender [connection=" + connection
				+ ", destination=" + destination
				+ ", deliveryMode=" + (deliveryMode == DeliveryMode.NON_PERSISTENT ? "NON_PERSISTENT" : "PERSISTENT")
				+ ", timeToLive=" + timeToLive
				+ ", transacted=" + transacted + "]";
	}

	public static JmsSender create(String name, Configuration config) throws Exception {
		return create(JmsSender.class, name, config);
	}

	public static <T extends JmsSender> T create(Class<T> claz, String name, Configuration config) throws Exception {
		return configure(claz.getConstructor(String.class).newInstance(name), config);
	}

	public static <T extends JmsSender> T configure(T channel, Configuration config) throws Exception {
		Properties props = config.subset("jndi").asProperties();
		javax.naming.Context ctx = new InitialContext(props);
		channel.setConnectionFactory((ConnectionFactory) ctx.lookup(config.getString("connectionFactory")));
		channel.setDestination((Destination) ctx.lookup(config.getString("destinationName")));
		channel.setTransacted(config.getBoolean("transacted", Boolean.FALSE));
		channel.setDeliveryMode(config.getInt("deliveryMode", DeliveryMode.NON_PERSISTENT));
		channel.setTimeToLive(config.getInt("timeToLive", 0));
		channel.setValidateOnStart(config.getBoolean("validateOnStart", true));

		return channel;
	}

}
