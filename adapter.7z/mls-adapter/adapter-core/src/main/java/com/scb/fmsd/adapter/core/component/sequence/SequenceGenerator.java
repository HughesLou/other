package com.scb.fmsd.adapter.core.component.sequence;

public interface SequenceGenerator {
	public long next();
	public void reset(long value);
}
