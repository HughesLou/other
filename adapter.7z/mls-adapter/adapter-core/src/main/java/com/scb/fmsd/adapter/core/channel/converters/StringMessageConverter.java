package com.scb.fmsd.adapter.core.channel.converters;

import com.scb.fmsd.adapter.core.channel.MessageConverter;
import com.scb.fmsd.adapter.core.channel.OutChannel;
import com.scb.fmsd.adapter.core.model.MessageObject;
import com.scb.fmsd.adapter.core.model.StringMessageObject;

public class StringMessageConverter implements MessageConverter<String> {

	@Override
	public MessageObject convert(String message) throws Exception {
		return new StringMessageObject(message, "MSG-" + System.currentTimeMillis());
	}

	@Override
	public String convert(MessageObject message, OutChannel<?> channel) throws Exception {
		return message.getText();
	}

}
