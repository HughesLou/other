package com.scb.fmsd.adapter.core.processor;

import java.util.List;

import com.scb.fmsd.adapter.core.ShutdownAware;
import com.scb.fmsd.adapter.core.model.MessageObject;

public interface ParallelProcessor extends Processor, ShutdownAware {
	public Processor getProcessor();
	public void process(MessageObject message, CompletionCallback callback) throws Exception;
	public List<MessageObject> shutdownNow();

	public int getThreads();

	public int getWorkingQueueSize();
}
