package com.scb.fmsd.adapter.core.model;

import java.util.Properties;

public enum MessageObjectPropertyKey {
	ARRIVAL_TIMESTAMP_NAME("arrivalTimestamp", Long.class), 
	KEYS_NAME("keys", String.class),
	TRADE_PROPERTIES("tradeProperties", Properties.class),
	MESSAGE_ID("MESSAGE_ID", String.class),
	ORIGINAL_MESSAGE_ID("ORIGINAL_MESSAGE_ID",String.class),
	CORRELATION_KEYS("CORRELATION_KEYS",String.class),
	AUDIT_COMMENT("AUDIT_COMMENT",String.class),
	RETRY("RETRY",Boolean.class);
	
	private String key;
	private Class<?> valueType;

	public String getKey() {
		return key;
	}

	public Class<?> getValueType() {
		return valueType;
	}

	private MessageObjectPropertyKey(String key, Class<?> valueType) {
		this.key = key;
		this.valueType = valueType;
	}

}
