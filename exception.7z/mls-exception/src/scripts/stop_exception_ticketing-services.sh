#!/bin/bash
kill -9 $(ps -ef | grep "exception-ticketing-services" | grep -v grep | awk '{print $2}')