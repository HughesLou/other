/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.sabre.exceptionTicketing.jms;

import com.scb.sabre.ticketing.configuration.JMSSecurityConfiguration;
import com.scb.sabre.ticketing.jms.JMSConnection;
import com.webmethods.jms.WmJMSFactory;
import com.webmethods.jms.impl.WmTextMessageImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jms.*;
import java.util.Map;

public class ExceptionPublisher {

    private static final Logger log = LoggerFactory.getLogger(ExceptionPublisher.class);
    private final JMSSecurityConfiguration configuration;
    private final String destinationName;
    private MessageProducer messageProducer;
    public ExceptionPublisher(JMSSecurityConfiguration configuration, String destinationName) {
        this.configuration = configuration;
        this.destinationName = destinationName;
    }

    public void init() {
        log.info(String.format("Initialising topic of exception message publisher that is set to: %s", destinationName));
        Connection connection = null;
        try {
            connection = getConnection(configuration);
            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            Destination destination= WmJMSFactory.getTopic(destinationName);
            messageProducer = session.createProducer(destination);
            /*
            JMSConnection jmsConnection = new JMSConnection();
            connection = jmsConnection.getTopicConnection(exceptionConfigurationData, sslConfiguration, false);

            Topic topic = WmJMSFactory.getTopic(topicName);
            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            messageProducer = session.createProducer(topic);
            */
            log.info("Exception message publisher is now live.");
        } catch (Exception e) {
            if(connection!=null)
                try {
                    connection.close();
                } catch (JMSException e1) {
                    e1.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                }
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    public void publishMessage(String messageType, String message, Map<String, String> jmsProperties) {
        try {
            log.info("Publishing message: " + message);
            sendMessage(messageType, message, jmsProperties);
            log.info("Publishing message successfully!");
        } catch (JMSException e) {
            throw new RuntimeException("Unable to publish message", e);
        }
    }

    private void sendMessage(String messageType, String messageContents,
                             Map<String, String> jmsProperties) throws JMSException {
        WmTextMessageImpl message = new WmTextMessageImpl();
        message.setText(messageContents);
        message.setJMSType(messageType);
        if (jmsProperties != null && !jmsProperties.isEmpty()) {
            for (Map.Entry<String, String> property : jmsProperties.entrySet()) {
                message.setStringProperty(property.getKey(), property.getValue());
            }
        }
        messageProducer.send(message);
    }

    private Connection getConnection(final JMSSecurityConfiguration config)
            throws JMSException {
        JMSConnection jmsConnection = getJmsConnection();

        return jmsConnection.getTopicConnection(config, config.getSslConfiguration(), false);
    }

    JMSConnection getJmsConnection() {
        return new JMSConnection();
    }
}
