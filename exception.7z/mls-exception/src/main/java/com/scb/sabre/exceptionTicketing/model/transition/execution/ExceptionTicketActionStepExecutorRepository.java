package com.scb.sabre.exceptionTicketing.model.transition.execution;

import com.scb.sabre.ticketing.model.transition.ActionStep;
import com.scb.sabre.ticketing.model.transition.TicketReplay;
import com.scb.sabre.ticketing.model.transition.execution.ActionStepExecutor;
import com.scb.sabre.ticketing.model.transition.execution.ActionStepExecutorRepository;

import java.util.AbstractMap;

public class ExceptionTicketActionStepExecutorRepository extends ActionStepExecutorRepository {

    @SuppressWarnings("unchecked")
    public ExceptionTicketActionStepExecutorRepository(TicketReplayExecutor ticketReplayExecutor) {
        super(getMappingFor(TicketReplay.class, ticketReplayExecutor));
    }

    @SuppressWarnings("rawtypes")
    private static <TExecutor extends ActionStepExecutor> AbstractMap.SimpleEntry<Class<? extends ActionStep>, ActionStepExecutor> getMappingFor(
            Class<? extends ActionStep> actionStep, TExecutor executor) {
        return new AbstractMap.SimpleEntry<Class<? extends ActionStep>, ActionStepExecutor>(actionStep, executor);
    }
}
