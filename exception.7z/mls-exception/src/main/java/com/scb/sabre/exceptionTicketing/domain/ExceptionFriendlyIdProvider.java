package com.scb.sabre.exceptionTicketing.domain;

import com.scb.sabre.ticketing.domain.FriendlyIdProvider;
import com.scb.sabre.ticketing.domain.TicketDM;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

@Component
public class ExceptionFriendlyIdProvider implements FriendlyIdProvider {

    @Override
    public String createId(final TicketDM ticket) {
        if (ticket != null)
            return String.format("MLS-%s", ticket.getId());
        else
            throw new IllegalArgumentException("Ticket cannot be null!!");
    }

    @Override
    public int parseId(final String friendlyId) {

        final String[] idParts = friendlyId.split("-");
        final String numericIdPart = idParts[idParts.length - 1];

        if (!StringUtils.isNumeric(numericIdPart))
            return -1;

        return Integer.parseInt(numericIdPart);
    }
}
