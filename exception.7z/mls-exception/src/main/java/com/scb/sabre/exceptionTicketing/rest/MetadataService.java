package com.scb.sabre.exceptionTicketing.rest;

import com.scb.fm.canonical.generated.types.ExceptionMessage;
import com.scb.sabre.exceptionTicketing.utils.ExceptionConstants;
import com.scb.sabre.ticketing.domain.TicketDM;
import com.scb.sabre.ticketing.domain.repository.TicketRepository;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.zip.DataFormatException;

import static com.scb.sabre.exceptionTicketing.utils.ExceptionConstants.EMPTYCONTEXTDETAILS;

@Path("/Ticket/Attachment")
@Component
public class MetadataService {

    @Resource
    private TicketRepository ticketRepository = null;

    /**
     * response the request getting the detail of exception
     *
     * @param guid         the exception id
     * @param attachmentId the attachment id
     * @return the response contains the detail information
     * @throws DataFormatException
     */
    @GET
    @Transactional
    public Response getAttachment(@QueryParam("guid") final String guid,
                                  @QueryParam("attachmentId") final String attachmentId)
            throws DataFormatException {

        TicketDM ticket = ticketRepository.get(guid);

        if ("root".equals(attachmentId)) {
            try {
                JAXBContext jaxbContext = JAXBContext.newInstance(ExceptionMessage.class);
                Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
                InputStream inputStream = new ByteArrayInputStream(ticket.getMetaData().getContent().getBytes());
                ExceptionMessage message = (ExceptionMessage) jaxbUnmarshaller.unmarshal(inputStream);

                if (StringUtils.isEmpty(message.getExceptionDetails().getContext().getContextDetails())) {
                    return Response.ok().type(MediaType.APPLICATION_JSON).entity(
                            new MetadataWrapper(EMPTYCONTEXTDETAILS)).build();
                } else {
                    String contextDetails = message.getExceptionDetails().getContext().getContextDetails().trim();
                    return Response.ok().type(MediaType.APPLICATION_JSON).entity(
                            new MetadataWrapper(formatXML(contextDetails,
                                    String.valueOf(ExceptionConstants.INDENT_SIZE), false))).build();
                }
            } catch (JAXBException e) {
                e.printStackTrace();
            }
        }

        throw new IllegalArgumentException(String.format(
                "The Attachment type %s is not valid. Only root is supported.", attachmentId));
    }

    /**
     * format the input string which contains the xml elements
     *
     * @param input       string which contains the xml elements
     * @param indent      the tab size
     * @param declaration the file head declaration
     * @return the formatted xml content
     */
    private String formatXML(String input, String indent, boolean declaration) {
        if (null == input)
            return null;
        try {
            Source xmlInput = new StreamSource(new StringReader(input));
            StreamResult xmlOutput = new StreamResult(new StringWriter());
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, null != indent ? "yes" : "no");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", indent);
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, declaration ? "yes" : "no");
            transformer.transform(xmlInput, xmlOutput);
            return xmlOutput.getWriter().toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * inner class which is used to handle the string
     */
    public static class MetadataWrapper {

        private String metaData;

        public MetadataWrapper(String metaData) {
            this.metaData = metaData;
        }

        public String getMetaData() {
            return metaData;
        }
    }
}
