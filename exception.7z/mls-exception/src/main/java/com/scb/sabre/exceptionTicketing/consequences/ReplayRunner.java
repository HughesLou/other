package com.scb.sabre.exceptionTicketing.consequences;

import com.scb.fm.canonical.generated.types.ExceptionMessage;
import com.scb.razor.mls.common.exception.ExceptionContextItemKey;
import com.scb.sabre.exceptionTicketing.jms.ExceptionPublisher;
import com.scb.sabre.exceptionTicketing.utils.MyBeanUtils;
import com.scb.sabre.ticketing.domain.TicketDM;
import com.scb.sabre.ticketing.domain.TicketMetadataDM;
import com.scb.sabre.ticketing.domain.TicketTagDM;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class ReplayRunner implements Runnable {

    private static final Logger log = LoggerFactory.getLogger(ReplayRunner.class);
    private final TicketDM ticket;

    public ReplayRunner(TicketDM ticket) {
        this.ticket = ticket;
    }

    @Override
    public void run() {
        log.info("Starting with replay original message");
        Set<TicketTagDM> ticketTags = ticket.getTicketTags();
        Map<String, String> jmsProperties = new HashMap<>();
        for (TicketTagDM ticketTag : ticketTags) {
            String tagName = ticketTag.getTagName();
            if (tagName != null && tagName.startsWith(ExceptionContextItemKey.JMS_PROPERTY_PREFIX.getKey())) {
                jmsProperties.put(tagName.substring(4), ticketTag.getTagValue());
            }
        }
        TicketMetadataDM metaDataDM = ticket.getMetaData();
        String metaData = metaDataDM.getContent();
        ExceptionMessage exceptionMessage = null;
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance(ExceptionMessage.class);
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            InputStream inputStream = new ByteArrayInputStream(metaData.getBytes());
            exceptionMessage = (ExceptionMessage) jaxbUnmarshaller.unmarshal(inputStream);
        } catch (JAXBException e) {
            e.printStackTrace();
        }
        String contextDetails = exceptionMessage.getExceptionDetails().getContext().getContextDetails().trim();

        ExceptionPublisher replayPublisher = getReplayPublisher();

        replayPublisher.publishMessage("", contextDetails, jmsProperties);
    }

    ExceptionPublisher getReplayPublisher() {
        return (ExceptionPublisher) MyBeanUtils.getBean("replayPublisher");
    }
}
