/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.sabre.exceptionTicketing.utils;

/**
 * Description:
 * Author: 1466811
 * Date:   11:50 AM 5/6/14
 */
public class ExceptionConstants {

    public static final String ExceptionMessage = "ExceptionMessage";
    public static final String MetaDataTag = "Trade ID";
    //    public static final String ExceptionBrokerHostPort = "exceptionBrokerHostPort";
//    public static final String ExceptionBrokerName = "exceptionBrokerName";
//    public static final String ExceptionTopicName = "exceptionTopicName";
//    public static final String ExceptionDurableSubscriberName = "exceptionDurableSubscriberName";
    public static final String ACTOR_GROUP = "PSS";
    public static final String VIEW_GROUP = "PSS";
    public static final int INDENT_SIZE = 4;

    public static String EMPTYCONTEXTDETAILS = "No original message attached, please contact pss team if you needed.";
//    public static final String TicketingUserId = "userId";
}
