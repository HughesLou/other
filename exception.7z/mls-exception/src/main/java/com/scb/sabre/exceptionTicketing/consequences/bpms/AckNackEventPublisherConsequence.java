package com.scb.sabre.exceptionTicketing.consequences.bpms;

import com.scb.fm.canonical.generated.types.ExceptionMessage;
import com.scb.razor.mls.common.exception.ExceptionContextItemKey;
import com.scb.razor.mls.common.utils.JaxbUtils;
import com.scb.razor.mls.common.xml.NackResponseBuilder;
import com.scb.razor.mls.common.xml.sr.ErrorType;
import com.scb.razor.mls.common.xml.sr.MessageSubTypeEnum;
import com.scb.razor.mls.common.xml.sr.MessageTypeEnum;
import com.scb.razor.mls.common.xml.sr.NackSystem;
import com.scb.sabre.exceptionTicketing.jms.ExceptionPublisher;
import com.scb.sabre.ticketing.domain.TicketActionDM;
import com.scb.sabre.ticketing.domain.TicketDM;
import com.scb.sabre.ticketing.domain.TicketTagDM;
import com.scb.sabre.ticketing.domain.consequences.ConsequenceType;
import com.scb.sabre.ticketing.domain.consequences.IConsequence;
import com.scb.sabre.ticketing.messaging.TicketingMessagePublisher;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamResult;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@Component
public class AckNackEventPublisherConsequence implements IConsequence {

    public static final Logger logger = Logger.getLogger(AckNackEventPublisherConsequence.class);
    @Resource
    private TicketingMessagePublisher ticketingMessagePublisher = null;
    @Resource
    private ExceptionPublisher ackPublisher = null;

    @Override
    public ConsequenceType getConsequenceType() {
        return ConsequenceType.AfterSave;
    }

    @Override
    public void execute(final TicketActionDM action) {
        logger.info("Starting with executing ack/nack event publisher consequence");
        TicketDM ticket = action.getTicket();
        Set<TicketTagDM> ticketTags = ticket.getTicketTags();
        Map<String, String> jmsProperties = new HashMap<>();
        for (TicketTagDM ticketTag : ticketTags) {
            String tagName = ticketTag.getTagName();
            if (tagName != null && tagName.startsWith(ExceptionContextItemKey.JMS_PROPERTY_PREFIX.getKey())) {
                jmsProperties.put(tagName.substring(4), ticketTag.getTagValue());
            }
        }

        String ticketId = ticket.getGuid();
        ticketingMessagePublisher.publishTicketEvent(ticketId);

        // TODO message content need to be defined. See NackResponseBuilder.
        String messageConent = generate(ticket, ticketTags, jmsProperties);
        if (messageConent != null) {
            ackPublisher.publishMessage("Nack", messageConent, jmsProperties);
        } else {
            logger.info("Do not support to publish this NACK message");
        }
    }

    @Override
    public void execute(TicketActionDM action, String additionalInfo) {
        execute(action);
    }

    private String generate(TicketDM ticket, Set<TicketTagDM> ticketTags, Map<String, String> jmsProperties) {


        MessageTypeEnum msgType;
        MessageSubTypeEnum msgSubType = null;

        String originSystem;
        String originSystemRef = null;

        String targetSystem;
        String targetSystemRef = null;

        String description;
        String detailMessage = null;

        ErrorType errorType;
        String errorCode;

        String orgMessage;

        NackSystem.MessageSystemEnum ms = null;
        String nackSystemId = null;

        for (TicketTagDM ticketTag : ticketTags) {

            String tagName = ticketTag.getTagName();
            if (tagName != null && ("Interface ID").equals(tagName)) {
                nackSystemId = ticketTag.getTagValue();

                //Special case for FRTP and CTPY
                if (!NackSystem.MessageSystemEnum.names().contains(nackSystemId)) {

                    if (nackSystemId.equals("CTPY")) {

                        if ((jmsProperties.get("AckDestination").contains("fx"))) {
                            nackSystemId = "FX_" + nackSystemId;
                        } else if ((jmsProperties.get("AckDestination").contains("alm"))) {
                            nackSystemId = "ALM_" + nackSystemId;
                        }
                    } else if (nackSystemId.equals("FRTP")) {
                        if ("true".equals(jmsProperties.get("IsFXTradeInser")) || "true".equals(jmsProperties.get("IsFXTradeEvent"))) {
                            nackSystemId = "FX_" + nackSystemId;
                        } else if (("true".equals(jmsProperties.get("IsALMTradeInser")) || "true".equals(jmsProperties.get("IsALMTradeEvent")))) {
                            nackSystemId = "ALM_" + nackSystemId;
                        }
                    } else {
                        return null;
                    }
                }
                ms = NackSystem.MessageSystemEnum.valueOf(nackSystemId);
                break;
            }

        }

        if (ms == null) {
            return null;
        }

        msgType = MessageTypeEnum.valueOf(ms.getType());
        if (ms.getSubtype() != null) {
            msgSubType = MessageSubTypeEnum.valueOf(ms.getSubtype());
        }

        originSystem = ms.getOriginSystem();
        targetSystem = ms.getTargetSystem();


        String metaData = ticket.getMetaData().getContent();
        ExceptionMessage exceptionMessage = null;
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance(ExceptionMessage.class);
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            InputStream inputStream = new ByteArrayInputStream(metaData.getBytes());
            exceptionMessage = (ExceptionMessage) jaxbUnmarshaller.unmarshal(inputStream);
        } catch (JAXBException e) {
            e.printStackTrace();
        }
        orgMessage = exceptionMessage.getExceptionDetails().getContext().getContextDetails().trim();

        if (msgType.name().equals("Deals")) {
            originSystemRef = jmsProperties.get("trackingId");
            targetSystemRef = null;
        } else if (msgType.name().equals("STATIC") && msgSubType.name().equals("COUNTERPARTY")) {
            originSystemRef = StringUtils.substringBetween(orgMessage, "<fmProfileSysGenId>", "</fmProfileSysGenId>");
            targetSystemRef = jmsProperties.get("trackingId");
        } else if (msgType.name().equals("STATIC") && msgSubType.name().equals("SI")) {
            originSystemRef = jmsProperties.get("trackingId");
            targetSystemRef = jmsProperties.get("trackingId");
        }

        description = ticket.getDescription();

        errorType = ErrorType.UNCLASSIFIED;
        errorCode = null;


        NackResponseBuilder nrb = new NackResponseBuilder(msgType, msgSubType)
                .timestamp(new Date())
                .origin(originSystem, originSystemRef)
                .target(targetSystem, targetSystemRef)
                .errorType(errorType)
                .errorCode(errorCode)
                .description(description);

        if (msgType.name().equals("Deals")) {

            for (TicketTagDM ticketTag : ticketTags) {
                if (ticketTag.getTagName().equals("Stack Trace")) {
                    detailMessage = ticketTag.getTagValue();
                    break;
                }
            }
            nrb.detailMessage(detailMessage);
            nrb.orgMessage(orgMessage);
        }

        StringWriter sw = new StringWriter();
        JaxbUtils.marshallXmlType(nrb.build(), new StreamResult(sw), true, true);
        return sw.toString();
    }
}
