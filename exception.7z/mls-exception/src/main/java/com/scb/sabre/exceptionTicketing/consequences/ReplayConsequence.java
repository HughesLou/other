package com.scb.sabre.exceptionTicketing.consequences;

import com.scb.sabre.ticketing.domain.TicketActionDM;
import com.scb.sabre.ticketing.domain.TicketDM;
import com.scb.sabre.ticketing.domain.consequences.ConsequenceType;
import com.scb.sabre.ticketing.domain.consequences.IConsequence;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ReplayConsequence implements IConsequence {

    private static final Logger log = LoggerFactory.getLogger(ReplayConsequence.class);

    @Override
    public ConsequenceType getConsequenceType() {
        return ConsequenceType.AfterSave;
    }

    @Override
    public void execute(TicketActionDM action) {
        final TicketDM ticket = action.getTicket();
        executeReplay(ticket);
    }

    @Override
    public void execute(TicketActionDM action, String additionalInfo) {
        execute(action);
    }

    private void executeReplay(TicketDM ticket) {
        Runnable replayRunner = createRunner(ticket);
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        log.info("Replaying ticket with id: " + ticket.getId() + " with metaDataTag: "
                + ticket.getMetaDataTag());
        executorService.execute(replayRunner);
    }

    Runnable createRunner(TicketDM ticket) {
        return new ReplayRunner(ticket);
    }
}