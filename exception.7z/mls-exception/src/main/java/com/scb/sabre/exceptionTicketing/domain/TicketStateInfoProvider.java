package com.scb.sabre.exceptionTicketing.domain;

import com.scb.sabre.ticketing.domain.IStateInfoProvider;
import com.scb.sabre.ticketing.domain.TicketDM;
import org.springframework.stereotype.Component;

@Component
public class TicketStateInfoProvider implements IStateInfoProvider {

    @Override
    public String getStateInformation(TicketDM ticketDM, String userId) {
        return ticketDM.getCurrentStatus();
    }
}
