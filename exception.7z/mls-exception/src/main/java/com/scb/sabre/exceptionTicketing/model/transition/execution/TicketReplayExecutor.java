package com.scb.sabre.exceptionTicketing.model.transition.execution;

import com.scb.sabre.exceptionTicketing.consequences.ReplayConsequence;
import com.scb.sabre.ticketing.domain.TicketActionDM;
import com.scb.sabre.ticketing.model.transition.TicketReplay;
import com.scb.sabre.ticketing.model.transition.execution.ActionStepExecutor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
public class TicketReplayExecutor implements ActionStepExecutor<TicketReplay> {

    @Override
    public boolean canExecute(String userId, String action, List<TicketActionDM> history,
                              Map<String, String[]> parameters) {
        return true;
    }

    @Override
    public void execute(TicketReplay actionStep, String userId, String action, List<TicketActionDM> history,
                        Map<String, String[]> parameters, TicketActionDM returnedTicketAction) {
        returnedTicketAction.addConsequenceToExecute(new ReplayConsequence());
    }
}
