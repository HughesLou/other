/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.exception.utils;

/**
 * Description:
 * Author: 1466811
 * Date:   11:50 AM 5/6/14
 */
public class ExceptionConstants {

    public static final String ExceptionMessage = "ExceptionMessage";
    public static final int INDENT_SIZE = 4;

    public static String EMPTYCONTEXTDETAILS = "No original message attached, " +
            "please contact pss team if you needed.";

    public static final String XML_FILE = ".xml";
    public static final char CHAR_SPACE = ' ';
    public static final String DATE_FORMAT = "yyyyMMddHHmmssSSS";

    public static final String FILESYSTEM = "FS";
    public static final String DATABASE = "DB";
}
