/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.exception.jms;

import com.scb.razor.exception.service.MessageService;
import com.scb.sabre.sag.is.jms.JMSConfiguration;
import com.scb.sabre.ticketing.configuration.SslConfiguration;
import com.scb.sabre.ticketing.jms.JMSConnection;
import com.scb.sabre.ws.messaging.MessagePublisher;
import com.scb.sabre.ws.messaging.annotation.MessageProducer;
import com.scb.sabre.ws.messaging.annotation.OnInit;
import com.webmethods.jms.WmJMSFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.jms.*;

import static com.scb.sabre.ticketing.util.Constants.TICKETING_ERROR;
import static com.scb.sabre.ticketing.util.Constants.TICKETING_EVENT;

/**
 * Description:
 * Author: 1466811
 * Date:   11:34 AM 4/22/14
 */

@Component
@MessageProducer("TicketNotification")
public class ExceptionEventSubscriber {

    private static final Logger log = LoggerFactory.getLogger(ExceptionEventSubscriber.class);
    private TopicConnection connection;
    private MessagePublisher<String> messagePublisher = null;
    @Resource
    private JMSConfiguration exceptionConfigurationData = null;
    @Resource
    private SslConfiguration sslConfiguration = null;
    @Value("${middlewareTopic}")
    private String middlewareTopic = null;
    private JMSConnection jmsConnection;

    @OnInit
    public void init() {
        try {
            log.info(String.format("Initialising topic that is set to: %s", middlewareTopic));
            Topic topic = WmJMSFactory.getTopic(middlewareTopic);

            log.info("Establishing JMS connection to " + exceptionConfigurationData.toString());
            connection = getJmsConnection().getTopicConnection(exceptionConfigurationData, sslConfiguration, false);

            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

            MessageConsumer consumer = session.createConsumer(topic);

            consumer.setMessageListener(new MessageListener() {
                @Override
                public void onMessage(final Message message) {
                    ExceptionEventSubscriber.this.onMessage(message);
                }
            });

            log.info("Starting JMS connection {} ..", middlewareTopic);
            connection.start();
            log.info("JMS subscription for {} is now live.", middlewareTopic);
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    @Override
    protected void finalize() throws Throwable {
        connection.stop();
    }

    void onMessage(final Message message) {
        try {
            if (MessageService.messageIs(TICKETING_EVENT, message)) {

                String ticketId = MessageService.getMessageTextFrom(message);

                if (ticketId == null) {
                    log.warn("Ignoring jms message of type " + message.getClass());
                    return;
                }

                log.info(String.format("publishing ticket id:[%1$s] to message router", ticketId));
                messagePublisher.publish(ticketId);

                log.info("Event handled for ticket " + ticketId);
            } else if (MessageService.messageIs(TICKETING_ERROR, message)) {
                final String deSerialisedError = MessageService.getMessageTextFrom(message);

                messagePublisher.publish(deSerialisedError);

                log.info("Published ticket error to message router. Serialised error message: {}",
                        deSerialisedError);
            }
        } catch (Exception e) {
            log.error("Error occurred whilst handling notification for ticket", e);
            throw new RuntimeException("Unable to interpret message " + message);
        }
    }

    public JMSConnection getJmsConnection() {
        if (jmsConnection == null) {
            jmsConnection = new JMSConnection();
        }
        return jmsConnection;
    }
}

