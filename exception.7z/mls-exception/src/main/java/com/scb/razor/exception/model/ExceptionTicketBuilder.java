package com.scb.razor.exception.model;

import com.scb.sabre.ticketing.domain.TicketDM;
import com.scb.sabre.ticketing.domain.TicketMetadataDM;
import com.scb.sabre.ticketing.domain.TicketTagDM;
import com.scb.sabre.ticketing.model.transition.Transition;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Iterator;
import java.util.Set;
import java.util.UUID;

@Component
public class ExceptionTicketBuilder {
    @Value("${actor.group}")
    private String actorGroup = null;
    @Value("${viewer.group}")
    private String viewerGroup = null;

    public TicketDM buildExceptionTicket(final String payload, final String subTradeId, String ticketType,
                                         String userId, String description, Set<TicketTagDM> ticketTags) {

        TicketDM ticket = new TicketDM();

        ticket.setGuid(UUID.randomUUID().toString());
        ticket.setActor(userId);
        ticket.setAuditTimestamp(new Date());
        ticket.setCreatedTimestamp(ticket.getAuditTimestamp());
        ticket.setCreator(userId);
        ticket.setDescription(description);
        ticket.setType(ticketType);

        TicketMetadataDM metadata = new TicketMetadataDM();
        metadata.setContent(payload);
        metadata.setTicket(ticket);

        // add ticket tags
        if (ticketTags.size() > 0) {

            Iterator<TicketTagDM> iterator = ticketTags.iterator();
            while (iterator.hasNext()) {
                TicketTagDM tag = iterator.next();
                tag.setTicket(ticket);
                tag.setCreatedTimestamp(new Date());
            }

            ticket.setTicketTags(ticketTags);
        }

        ticket.setMetaData(metadata);
        ticket.setMetaDataTag(subTradeId);
        ticket.setMetaDataType("application/json");
        ticket.setAvailableActions(StringUtils.join(Transition.instance().allPossibleActions(), "|"));
        ticket.setIsComplete(false);
        ticket.setActorGroup(actorGroup); // TODO: Don't believe this is necessary
        ticket.setViewGroup(viewerGroup); // TODO: Don't believe this is necessary

        return ticket;
    }
}
