package com.scb.razor.exception.jms;

import com.scb.razor.exception.service.MessageService;
import com.scb.sabre.sag.is.jms.JMSConfiguration;
import com.scb.sabre.ticketing.configuration.SslConfiguration;
import com.scb.sabre.ticketing.jms.JMSConnection;
import com.webmethods.jms.WmJMSFactory;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.jms.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import static com.scb.razor.exception.utils.ExceptionConstants.*;

@Component
public class ExceptionMessageSubscriber {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionMessageSubscriber.class);
    @Resource
    private MessageService messageService = null;
    @Resource
    private JMSConfiguration exceptionConfigurationData = null;
    @Resource
    private SslConfiguration sslConfiguration = null;
    @Value("${exceptionTopicName}")
    private String exceptionTopicName = null;
    @Value("${exceptionBrokerName}")
    private String exceptionBrokerName = null;
    @Value("${exceptionBrokerHostPort}")
    private String exceptionBrokerHostPort = null;
    @Value("${exceptionDurableSubscriberName}")
    private String exceptionDurableSubscriberName = null;
    @Value("${mls.exception.needEntitlement}")
    private boolean needEntitlement = true;
    @Value("${id.prefix}")
    private String idPrefix = null;
    @Value("${max.retry.times}")
    private int maxRetryTimes;
    @Value("${thread.pool.size}")
    private int threadPoolSize;
    @Value("${exception.message.location}")
    private String exceptionMessageLocation = null;
    private AtomicInteger index = new AtomicInteger(0);

    private AtomicInteger retryTimes = new AtomicInteger(0);
    private ConcurrentHashMap<String, AtomicInteger> retryMessageMap = new ConcurrentHashMap<>();
    private ConcurrentHashMap<String, Map<String, AtomicInteger>> retryMap = new ConcurrentHashMap<>();

    private TopicConnection connection;
    private JMSConnection jmsConnection;
    private static ExecutorService executorService;
    private static final String startTime = new SimpleDateFormat(DATE_FORMAT).format(new Date());

    /**
     * the main entry, start the JMS connection
     */
    @PostConstruct
    public void init() {
        try {
            executorService = Executors.newFixedThreadPool(threadPoolSize);
            retryMap.put(FILESYSTEM, new HashMap<String, AtomicInteger>());
            retryMap.put(DATABASE, new HashMap<String, AtomicInteger>());

            // process the existed exception message files, the thread should start before the listener
            new Thread(new Runnable() {
                public void run() {
                    LOGGER.debug("Exception message location is : {}", exceptionMessageLocation);
                    File directory = new File(exceptionMessageLocation);
                    if (directory == null || !directory.isDirectory()) {
                        LOGGER.error("The given directory {} is invalid.", exceptionMessageLocation);
                        return;
                    }
                    File[] exceptionMessageFiles = directory.listFiles();
                    for (File exceptionMessageFile : exceptionMessageFiles) {
                        final String fileName = exceptionMessageFile.getName();
                        if (exceptionMessageFile.isFile() && fileName.endsWith(XML_FILE)
                                && exceptionMessageFile.length() > 0) {
                            StringBuilder sb = new StringBuilder();
                            try (BufferedReader br = new BufferedReader(new FileReader(exceptionMessageFile))) {
                                String currentLine;
                                while ((currentLine = br.readLine()) != null) {
                                    sb.append(currentLine);
                                }
                                br.close();
                            } catch (IOException e) {
                                LOGGER.error(String.format("Exception happened when try to read failed " +
                                        "exception file : %s ", exceptionMessageFile), e);
                                continue;
                            }

                            LOGGER.info("Reprocess the failure exception message {}.", exceptionMessageFile);
                            saveDBThenDeleteFile(fileName, exceptionMessageFile, sb.toString());
                        } else {
                            LOGGER.warn("The file {} is not supported.", exceptionMessageFile);
                        }
                    }
                    LOGGER.info("Reprocess the failure exception message completed");
                }
            }).start();

            LOGGER.info("Initialising topic {}", exceptionTopicName);
            Topic topic = WmJMSFactory.getTopic(exceptionTopicName);
            connection = getJmsConnection().getTopicConnection(exceptionConfigurationData,
                    exceptionBrokerHostPort, exceptionBrokerName, sslConfiguration, true);
            final Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

            MessageConsumer consumer = session.createDurableSubscriber(topic, exceptionDurableSubscriberName);

            consumer.setMessageListener(new MessageListener() {
                @Override
                public void onMessage(final Message message) {
                    if (MessageService.messageIs(ExceptionMessage, message)) {
                        LOGGER.info("Processing Exception Message at: " + new Date());
                        long start = System.currentTimeMillis();
                        final String messageId = getMessageId(message);

                        String messageText = null;

                        try {
                            messageText = MessageService.getMessageTextFrom(message).replace('\001', CHAR_SPACE);
                        } catch (JMSException e) {
                            LOGGER.error(e.getClass().toString(), e);
                        } catch (IllegalArgumentException e) {
                            LOGGER.error(e.getMessage());
                        }

                        if (StringUtils.isNotEmpty(messageText)) {
                            final File file = new File(exceptionMessageLocation, messageId + XML_FILE);
                            while (!saveMessageToDisk(file, messageText)) {
                                retry(messageId, retryMap.get(FILESYSTEM), maxRetryTimes);
                            }

                            LOGGER.info("Save/Discard Exception Message {} in {} ms.", messageId,
                                    (System.currentTimeMillis() - start));

                            final String finalMessageText = messageText;
                            saveDBThenDeleteFile(messageId, file, finalMessageText);
                        }
                        LOGGER.info("End processing Exception Message {} in {} ms.", messageId,
                                (System.currentTimeMillis() - start));
                    }
                }
            });

            LOGGER.info("Starting JMS connection {}", exceptionTopicName);
            connection.start();
            LOGGER.info("JMS subscription {} is now live", exceptionDurableSubscriberName);

            Runtime.getRuntime().addShutdownHook(new Thread("JMS-cleaning-thread-" + getClass().getSimpleName()) {
                public void run() {
                    LOGGER.info("Cleaning JMS resources before terminating..");
                    close();
                }
            });

        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    private void retry(String messageId, Map<String, AtomicInteger> map, int maxRetryTimes) {
        AtomicInteger retryTimes;
        if (map.containsKey(messageId)) {
            retryTimes = map.get(messageId);
            if (retryTimes.intValue() < maxRetryTimes - 1) {
                retryTimes.getAndAdd(1);
                map.put(messageId, retryTimes);
            } else {
                map.remove(messageId);
                throw new Error(String.format("Still error after retry %s times", maxRetryTimes));
            }
        } else {
            retryTimes = new AtomicInteger(1);
            map.put(messageId, retryTimes);
        }

        try {
            LOGGER.info("Failed, then sleep {} minutes before retry", retryTimes.intValue());
            TimeUnit.MINUTES.sleep(retryTimes.longValue());
        } catch (InterruptedException e) {
            LOGGER.warn("Thread interrupted exception.");
        }
    }

    private String getMessageId(Message message) {
        String messageId;
        try {
            messageId = message.getJMSMessageID();
            if (messageId.startsWith(idPrefix)) {
                messageId = messageId.substring(idPrefix.length(), messageId.length());
            }
        } catch (JMSException e) {
            LOGGER.error("Exception happened during getting message id.");
            messageId = ExceptionMessage + startTime + index.addAndGet(1);
        }
        return messageId;
    }

    private void saveDBThenDeleteFile(final String messageId, final File file,
                                      final String finalMessageText) {
        executorService.submit(new Runnable() {
                                   @Override
                                   public void run() {
                                       while (isDatabaseConnectionException(finalMessageText, file)) {
                                           retry(messageId, retryMap.get(DATABASE), maxRetryTimes);
                                       }
                /*if (null != messageService.save(finalMessageText)) {
                    file.delete();
                    LOGGER.info("Delete the exception message file {}", file);
                } else {
                    LOGGER.warn("Exception happened when save exception message %s to DB", file);
                }*/
                                   }
                               }

        );
    }

    private boolean isDatabaseConnectionException(String finalMessageText, File file) {
        boolean isIOException = false;
        boolean isDataAccessException = false;
        try {
            if (null != messageService.save(finalMessageText)) {
                file.delete();
                LOGGER.info("Delete the exception message file {}", file);
            }
        } catch (Exception e) {
            Throwable current = e;
            while (current != null) {
                if (current instanceof IOException) {
                    isIOException = true;
                }
                if (current instanceof DataAccessException) {
                    isDataAccessException = true;
                }
                current = current.getCause();
            }
        }
        return isIOException && isDataAccessException;
    }

    @Override
    protected void finalize() throws Throwable {
        connection.stop();
    }

    protected void close() {
        try {
            //Close the Connection as it is a TCP/IP connection to the JMS server
            if (connection != null) {
                LOGGER.info("Closing JMS connection... ");
                connection.stop();
                connection.close();
                connection = null;
            }
        } catch (JMSException e) {
            LOGGER.warn("Failed to close JMS connection.");
        }
    }

    protected boolean saveMessageToDisk(File file, String messageText) {
        try (FileWriter fileWriter = new FileWriter(file)) {
            Writer br = new BufferedWriter(fileWriter);
            br.write(messageText);
            br.flush();
            LOGGER.info("Save the failed exception message to {} successfully", file);
        } catch (IOException e) {
            LOGGER.error("Error happened when try to save the failed exception message to {}", file, e);
            file.delete();
            return false;
        }
        return true;
    }

    public JMSConnection getJmsConnection() {
        if (jmsConnection == null) {
            jmsConnection = new JMSConnection();
        }
        return jmsConnection;
    }
}
