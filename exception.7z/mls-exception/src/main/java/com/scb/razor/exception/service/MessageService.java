package com.scb.razor.exception.service;

import com.scb.fm.canonical.generated.types.ExceptionMessage;
import com.scb.razor.exception.model.ExceptionTicketBuilder;
import com.scb.sabre.ticketing.domain.FriendlyIdProvider;
import com.scb.sabre.ticketing.domain.TicketDM;
import com.scb.sabre.ticketing.domain.TicketTagDM;
import com.scb.sabre.ticketing.domain.consequences.ConsequenceExecutor;
import com.scb.sabre.ticketing.domain.repository.TicketRepository;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import javax.annotation.Resource;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.StringReader;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static com.scb.sabre.ticketing.util.Constants.SUBMIT_USER_ID;

/**
 * Created by 1466811 on 4/15/2016.
 */
@Service
public class MessageService {
    private static final Logger LOGGER = LoggerFactory.getLogger(MessageService.class);
    @Resource
    private PlatformTransactionManager transactionManager = null;
    @Resource
    private TicketRepository ticketRepository = null;
    @Resource
    private ExceptionTicketBuilder exceptionTicketBuilder = null;
    @Resource
    private FriendlyIdProvider exceptionFriendlyIdProvider = null;
    @Resource
    private ConsequenceExecutor consequenceExecutor = null;
    @Value("${meta.data.tag}")
    private String metaDataTag = null;
    @Value("${mls.exception.needEntitlement}")
    private boolean needEntitlement = true;
    @Value("${max.description.length}")
    private int maxDescriptionLength = 2000;

    public static boolean messageIs(String eventType, Message message) {
        try {
            return eventType.equalsIgnoreCase(message.getJMSType());
        } catch (JMSException e) {
            LOGGER.error("Getting JMS type error.", e);
        }
        return false;
    }

    /**
     * get the message text
     *
     * @param message the input message
     * @return the message text
     * @throws javax.jms.JMSException
     * @throws java.io.IOException
     */
    public static String getMessageTextFrom(final Message message) throws JMSException {
        if (message instanceof TextMessage)
            return ((TextMessage) message).getText();

        throw new IllegalArgumentException(String.format("The message type %s is not supported.",
                message.getClass().toString()));
    }

    public String save(final String messageText) {
        final ExceptionMessage exceptionMessage;
        long start = System.currentTimeMillis();

        try {
            exceptionMessage = getExceptionMessage(messageText);
        } catch (JAXBException e) {
            LOGGER.error("Error during unmarshal exception message", e);
            return null;
        }

        if (exceptionMessage == null) {
            LOGGER.warn("NULL exception message");
            return null;
        }

        final String tag = getValueWithKey(exceptionMessage, metaDataTag);
        if (StringUtils.isEmpty(tag)) {
            LOGGER.error("Invalid message without meta data tag " + exceptionMessage.toString());
            return null;
        }

        TransactionTemplate transactionTemplate = getTransactionTemplate();

        String description = exceptionMessage.getExceptionDetails().getDescription();

        final String finalDescription;
        if (description.length() > maxDescriptionLength) {
            LOGGER.warn("The length of message description is larger than {}", maxDescriptionLength);
            finalDescription = description.substring(0, maxDescriptionLength);
        } else {
            finalDescription = description;
        }

        transactionTemplate.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        TicketDM latestTicket = transactionTemplate.execute(new TransactionCallback<TicketDM>() {
            @Override
            public TicketDM doInTransaction(final TransactionStatus status) {

                TicketDM newTicket = exceptionTicketBuilder.buildExceptionTicket(messageText,
                        tag, exceptionMessage.getExceptionDetails().getExceptionType(),
                        SUBMIT_USER_ID, finalDescription, getTicketTags(exceptionMessage));
                newTicket.performFirstAction(SUBMIT_USER_ID, "Exception ticket posted", needEntitlement);
                ticketRepository.save(newTicket);
                LOGGER.info("Save ticket {} successfully", newTicket.getGuid());
                return newTicket;
            }
        });

        latestTicket.executeConsequences(consequenceExecutor);

        String id = exceptionFriendlyIdProvider.createId(latestTicket);
        LOGGER.info("Save message successfully with ID: {} in {} ms", id, System.currentTimeMillis() - start);
        return id;
    }

    private ExceptionMessage getExceptionMessage(String messageText) throws JAXBException {
        Unmarshaller unMarshaller = JAXBContext.newInstance(ExceptionMessage.class).createUnmarshaller();
        ExceptionMessage msgObj = (ExceptionMessage) unMarshaller.unmarshal(new StringReader(messageText));
        return msgObj;
    }

    private String getValueWithKey(ExceptionMessage message, String key) {
        List<ExceptionMessage.ExceptionDetails.Context.ContextParticulars.Items.Item> items = message
                .getExceptionDetails().getContext().getContextParticulars().getItems().getItem();

        for (ExceptionMessage.ExceptionDetails.Context.ContextParticulars.Items.Item item : items) {
            if (item.getKey().equalsIgnoreCase(key))
                return item.getValue();
        }

        return null;
    }

    private Set<TicketTagDM> getTicketTags(ExceptionMessage message) {

        HashSet<TicketTagDM> ticketTags = new HashSet<>();

        List<ExceptionMessage.ExceptionDetails.Context.ContextParticulars.Items.Item> items = message
                .getExceptionDetails().getContext().getContextParticulars().getItems().getItem();

        for (ExceptionMessage.ExceptionDetails.Context.ContextParticulars.Items.Item item : items) {
            TicketTagDM tag = new TicketTagDM();
            tag.setTagName(item.getKey());
            tag.setTagValue(item.getValue());
            ticketTags.add(tag);
        }

        return ticketTags;
    }

    private TransactionTemplate getTransactionTemplate() {
        return new TransactionTemplate(transactionManager);
    }
}
