/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.sabre.exceptionTicketing.domain

import com.scb.sabre.ticketing.domain.TicketDM
import spock.lang.Specification

/**
 * Description:
 * Author: 1466811
 * Date:   8:08 PM 7/21/14
 */
public class TicketStateInfoProviderTest extends Specification {
    /**
     * Test method for getStateInformation()
     */
    def "get the state information of TicketDM"() {
        given:
        def ticketStateInfoProvider = new TicketStateInfoProvider();
        def ticketDM = new TicketDM();
        def status = "test";
        ticketDM.setState(status);

        expect:
        status.equals(ticketStateInfoProvider.getStateInformation(ticketDM, null))
    }
}
