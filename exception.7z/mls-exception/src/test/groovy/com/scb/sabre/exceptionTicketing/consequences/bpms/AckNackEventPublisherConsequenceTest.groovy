/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.sabre.exceptionTicketing.consequences.bpms

import com.scb.sabre.exceptionTicketing.jms.ExceptionPublisher
import com.scb.sabre.ticketing.domain.TicketActionDM
import com.scb.sabre.ticketing.domain.TicketDM
import com.scb.sabre.ticketing.domain.TicketMetadataDM
import com.scb.sabre.ticketing.domain.TicketTagDM
import com.scb.sabre.ticketing.domain.consequences.ConsequenceType
import com.scb.sabre.ticketing.messaging.TicketingMessagePublisher
import org.junit.Ignore
import org.springframework.jms.core.JmsTemplate
import org.springframework.jms.core.MessageCreator
import spock.lang.Specification

import static org.mockito.Matchers.any
import static org.mockito.Matchers.anyString
import static org.mockito.Mockito.*

/**
 * Description:
 * Author: 1466811
 * Date:   5:26 PM 7/22/14
 */
@Ignore
class AckNackEventPublisherConsequenceTest extends Specification {

    def "test method getConsequenceType"() {
        given:
        def ackNackEventPublisherConsequence = new AckNackEventPublisherConsequence()

        expect:
        ackNackEventPublisherConsequence.getConsequenceType().equals(ConsequenceType.AfterSave)

    }

    def "test method execute"() {
        given:
        def content = "<ExceptionMessage>\n" +
                "    <ExceptionDetails>\n" +
                "        <Context>\n" +
                "            <ContextDetails>\n" +
                "                &lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;&lt;tests&gt;&lt;test&gt;TEST&lt;/test&gt;&lt;/tests&gt;\n" +
                "            </ContextDetails>\n" +
/*                "            <ReplayDetails>\n" +
                "                <TransportMethod>\n" +
                "                    <Details>\n" +
                "                        <Detail>\n" +
                "                            <Key>AckChannelBrokerHostPort</Key>\n" +
                "                            <Value>uklpaurzr08a.uk:6859</Value>\n" +
                "                        </Detail>\n" +
                "                        <Detail>\n" +
                "                            <Key>AckChannelBroker</Key>\n" +
                "                            <Value>MLSBroker</Value>\n" +
                "                        </Detail>\n" +
                "                        <Detail>\n" +
                "                            <Key>AckChannelName</Key>\n" +
                "                            <Value>T_FMEDMI_CTPY_MLS_REPLAY</Value>\n" +
                "                        </Detail>\n" +
                "                        <Detail>\n" +
                "                            <Key>AckChannelSslEnable</Key>\n" +
                "                            <Value>true</Value>\n" +
                "                        </Detail>\n" +
                "                        <Detail>\n" +
                "                            <Key>AckChannelUsername</Key>\n" +
                "                            <Value>EMAILADDRESS=FM_BPMS.Infra@sc.com, CN=uklpaurzr08a.uk.standardchartered.com, OU=FMSD,\n" +
                "                                O=Standard Chartered Bank, L=TEDA, ST=Tianjin, C=CN\n" +
                "                            </Value>\n" +
                "                        </Detail>\n" +
                "                        <Detail>\n" +
                "                            <Key>AckChannelPassword</Key>\n" +
                "                            <Value>rsecure123</Value>\n" +
                "                        </Detail>\n" +
                "                        <Detail>\n" +
                "                            <Key>AckChannelKeystore</Key>\n" +
                "                            <Value>BrokerKeyStore.p12</Value>\n" +
                "                        </Detail>\n" +
                "                        <Detail>\n" +
                "                            <Key>AckChannelKeyStoreType</Key>\n" +
                "                            <Value>PKCS12</Value>\n" +
                "                        </Detail>\n" +
                "                        <Detail>\n" +
                "                            <Key>AckChannelTruststore</Key>\n" +
                "                            <Value>BrokerTrustStore.jks</Value>\n" +
                "                        </Detail>\n" +
                "                        <Detail>\n" +
                "                            <Key>AckChannelTruststoreType</Key>\n" +
                "                            <Value>JKS</Value>\n" +
                "                        </Detail>\n" +
                "                        <Detail>\n" +
                "                            <Key>AckChannelEncrypted</Key>\n" +
                "                            <Value>true</Value>\n" +
                "                        </Detail>\n" +
                "                    </Details>\n" +
                "                </TransportMethod>\n" +
                "            </ReplayDetails>\n" +*/
                "        </Context>\n" +
                "    </ExceptionDetails>\n" +
                "</ExceptionMessage>"
        /*def content0 = "<ExceptionMessage>\n" +
                "    <ExceptionDetails>\n" +
                "        <Context>\n" +
                "            <ContextDetails>\n" +
                "                &lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;&lt;tests&gt;&lt;test&gt;TEST&lt;/test&gt;&lt;/tests&gt;\n" +
                "            </ContextDetails>\n" +
                "            <ReplayDetails>\n" +
                "                <TransportMethod>\n" +
                "                    <Details>\n" +
                "                        <Detail>\n" +
                "                            <Key>AckChannelName</Key>\n" +
                "                            <Value>T_FMEDMI_CTPY_MLS_REPLAY</Value>\n" +
                "                        </Detail>\n" +
                "                        <Detail>\n" +
                "                            <Key>AckChannelBroker</Key>\n" +
                "                            <Value>MLSBroker</Value>\n" +
                "                        </Detail>\n" +
                "                    </Details>\n" +
                "                </TransportMethod>\n" +
                "            </ReplayDetails>\n" +
                "        </Context>\n" +
                "    </ExceptionDetails>\n" +
                "</ExceptionMessage>"*/
        def ticketTags = new HashSet<TicketTagDM>()
        def ticketTag = new TicketTagDM()
        ticketTag.setTagName("JPP_TEST")
        ticketTag.setTagValue("TEST")
        ticketTags.add(ticketTag)
        def metaData = new TicketMetadataDM()
        metaData.setContent(content)
        def ticket = new TicketDM()
        ticket.setTicketTags(ticketTags)
        ticket.setGuid("1000")
        ticket.setMetaData(metaData)
        def action = new TicketActionDM()
        action.setTicket(ticket)

        def ackPublisher = spy(new ExceptionPublisher(null, null))
        def consequence = spy(new AckNackEventPublisherConsequence())
        def ticketingMessagePublisher = spy(new TicketingMessagePublisher())

        def field0 = AckNackEventPublisherConsequence.class.getDeclaredField("ticketingMessagePublisher");
        field0.setAccessible(true);
        field0.set(consequence, ticketingMessagePublisher);

        def field1 = AckNackEventPublisherConsequence.class.getDeclaredField("ackPublisher");
        field1.setAccessible(true);
        field1.set(consequence, ackPublisher);

        when:
        doNothing().when(ticketingMessagePublisher).publishTicketEvent(anyString())
        doNothing().when(ackPublisher).publishMessage(anyString(), anyString(), anyMap())

        consequence.execute(action, "test")
        /*def metaData0 = new TicketMetadataDM()
        metaData0.setContent(content0)
        def ticket0 = new TicketDM()
        ticket0.setTicketTags(ticketTags)
        ticket0.setGuid("1000")
        ticket0.setMetaData(metaData0)
        def action0 = new TicketActionDM()
        action0.setTicket(ticket0)
        consequence.execute(action0, "test")*/

        then:
        verify(ticketingMessagePublisher).publishTicketEvent(anyString())
        verify(ackPublisher).publishMessage(anyString(), anyString(), anyMap())
//        def captor0 = ArgumentCaptor.forClass(String.class)
//        def captor1 = ArgumentCaptor.forClass(Map.class)
//        def captor2 = ArgumentCaptor.forClass(Boolean.class)
//        verify(publisher, times(2)).publishExceptionMessage(captor0.capture(), captor1.capture(), captor2.capture())
//        def params0 = (List<String>) captor0.getAllValues()
//        def params2 = (List<Boolean>) captor2.getAllValues()
//        params0.get(0).equals("NackTest")
//        params2.get(0).equals(false)
    }
}
