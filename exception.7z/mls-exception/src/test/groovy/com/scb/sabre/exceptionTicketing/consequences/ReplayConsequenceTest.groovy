/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.sabre.exceptionTicketing.consequences

import com.scb.sabre.exceptionTicketing.jms.ExceptionPublisher
import com.scb.sabre.ticketing.domain.TicketActionDM
import com.scb.sabre.ticketing.domain.TicketDM
import com.scb.sabre.ticketing.domain.consequences.ConsequenceType
import org.mockito.ArgumentCaptor
import spock.lang.Specification

import static org.mockito.Mockito.*

/**
 * Description:
 * Author: 1466811
 * Date:   10:36 AM 7/22/14
 */
class ReplayConsequenceTest extends Specification {

    def "test execute"() {
        given:
        def action = new TicketActionDM()
        def ticket = new TicketDM()
        ticket.setId(100)
        action.setTicket(ticket)
        def replayRunner = spy(new ReplayRunner(ticket))
        def replayConsequence = spy(new ReplayConsequence())

        when:
        doNothing().when(replayRunner).run()
        when(replayConsequence.createRunner(ticket)).thenReturn(replayRunner)

        then:
        replayConsequence.execute(action, "test")

        then:
        def captor = ArgumentCaptor.forClass(TicketActionDM.class)
        verify(replayConsequence).execute(captor.capture())
    }

    def "test get consequence type"() {
        given:
        def replayConsequence = new ReplayConsequence()
        def consequenceType = replayConsequence.getConsequenceType()

        expect:
        consequenceType.equals(ConsequenceType.AfterSave)
    }
}
