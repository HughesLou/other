/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.sabre.exceptionTicketing.domain

import com.scb.sabre.ticketing.domain.TicketDM
import spock.lang.Specification

public class ExceptionFriendlyIdProviderTest extends Specification {

    private ExceptionFriendlyIdProvider provider = new ExceptionFriendlyIdProvider();

    def "test createId"() {
        given:
        def ticket = new TicketDM();
        ticket.setId(1);

        expect:
        "MLS-1".equals(provider.createId(ticket))
        123 == provider.parseId("MLS-123")
        -1 == provider.parseId("MLS-")

        try {
            provider.createId(null)
        }
        catch (Exception exception) {
            IllegalArgumentException.isInstance(exception)
        }
    }
}
