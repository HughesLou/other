/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */



package com.scb.sabre.exceptionTicketing.jms

import com.scb.sabre.sag.is.jms.JMSConfiguration
import com.scb.sabre.ticketing.configuration.JMSSecurityConfiguration
import com.scb.sabre.ticketing.configuration.SslConfiguration
import com.scb.sabre.ticketing.jms.JMSConnection
import com.webmethods.jms.WmJMSFactory
import com.webmethods.jms.impl.WmTextMessageImpl
import org.mockito.ArgumentCaptor
import spock.lang.Specification

import javax.jms.*

import static org.mockito.Matchers.*
import static org.mockito.Mockito.*

/**
 * Description:
 * Author: 1466811
 * Date:   10:19 AM 7/23/14
 */
class ExceptionPublisherTest extends Specification {
    def "test the method publishMessage"() {
        given:
        def sslConfig = new SslConfiguration()
        def configuration = new JMSSecurityConfiguration()
        def destinationName = "test_destination"
        sslConfig.setSslEnable(false)
        sslConfig.setSslKeyStore("")
        sslConfig.setSslKeyStoreType("")
        sslConfig.setSslTrustStore("")
        sslConfig.setSslTrustStoreType("")
        sslConfig.setSslEncrypted(false)
        sslConfig.setSslUsername("")
        sslConfig.setSslPassword("")
        configuration.setSslConfiguration(sslConfig)
        def publisher = spy(new ExceptionPublisher(configuration, destinationName))
        def message = "test_message"
        def jmsProperties = new HashMap<String, String>()
        jmsProperties.put("test_key", "test_value")
        def session = mock(Session.class)
        def messageProducer = mock(MessageProducer.class)
        def jmsConnection = spy(new JMSConnection())
        def topicConnection = mock(TopicConnection.class)

        when:
        when(publisher.getJmsConnection()).thenReturn(jmsConnection)
        doReturn(topicConnection).when(jmsConnection).getTopicConnection(any(JMSConfiguration.class),
                any(SslConfiguration.class), anyBoolean())
        doReturn(session).when(topicConnection).createSession(anyBoolean(), anyInt())
        doReturn(messageProducer).when(session).createProducer(any(Destination.class))
        doNothing().when(messageProducer).send(any(WmTextMessageImpl.class))

        publisher.init()
        publisher.publishMessage("TEST", message, jmsProperties)

        then:
        def captor = ArgumentCaptor.forClass(WmTextMessageImpl.class)
        verify(messageProducer).send(captor.capture())
        def params = (List<WmTextMessageImpl>) captor.getAllValues()
        params.get(0).getText().equals(String.valueOf(message))
    }
}
