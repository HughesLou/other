/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.sabre.exceptionTicketing.consequences

import com.scb.sabre.exceptionTicketing.jms.ExceptionPublisher
import com.scb.sabre.ticketing.domain.TicketDM
import com.scb.sabre.ticketing.domain.TicketMetadataDM
import com.scb.sabre.ticketing.domain.TicketTagDM
import spock.lang.Specification

import static org.mockito.Matchers.anyMap
import static org.mockito.Matchers.anyString
import static org.mockito.Mockito.*

/**
 * Description:
 * Author: 1466811
 * Date:   11:16 AM 7/22/14
 */
class ReplayRunnerTest extends Specification {

    def "test run method"() {
        given:
        def ticketTag = new TicketTagDM()
        ticketTag.setTagName("JPP_Test")
        ticketTag.setTagValue("Value_Test")
        def ticketTags = new HashSet<TicketTagDM>()
        ticketTags.add(ticketTag)
//        def ticketTags0 = new HashSet<TicketTagDM>()
//        ticketTags0.add(new TicketTagDM())

        def content = "<ExceptionMessage>\n" +
                "    <ExceptionDetails>\n" +
                "        <Context>\n" +
                "            <ContextDetails>\n" +
                "                &lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;&lt;test&gt;TEST&lt;/test&gt;\n" +
                "            </ContextDetails>\n" +
/*                "            <ReplayDetails>\n" +
                "                <TransportMethod>\n" +
                "                    <Details>\n" +
                "                        <Detail>\n" +
                "                            <Key>ReplayChannelBrokerHostPort</Key>\n" +
                "                            <Value>uklpaurzr08a.uk:6859</Value>\n" +
                "                        </Detail>\n" +
                "                        <Detail>\n" +
                "                            <Key>ReplayChannelSslEnable</Key>\n" +
                "                            <Value>true</Value>\n" +
                "                        </Detail>\n" +
                "                        <Detail>\n" +
                "                            <Key>ReplayChannelBroker</Key>\n" +
                "                            <Value>MLSBroker</Value>\n" +
                "                        </Detail>\n" +
                "                        <Detail>\n" +
                "                            <Key>ReplayChannelName</Key>\n" +
                "                            <Value>T_FMEDMI_CTPY_MLS_REPLAY</Value>\n" +
                "                        </Detail>\n" +
                "                        <Detail>\n" +
                "                            <Key>ReplayChannelUsername</Key>\n" +
                "                            <Value>EMAILADDRESS=FM_BPMS.Infra@sc.com, CN=uklpaurzr08a.uk." +
                "standardchartered.com, OU=FMSD, O=Standard Chartered Bank, L=TEDA, ST=Tianjin, C=CN\n" +
                "                            </Value>\n" +
                "                        </Detail>\n" +
                "                        <Detail>\n" +
                "                            <Key>ReplayChannelPassword</Key>\n" +
                "                            <Value>rsecure123</Value>\n" +
                "                        </Detail>\n" +
                "                        <Detail>\n" +
                "                            <Key>ReplayChannelKeystore</Key>\n" +
                "                            <Value>RazorBrokerKeyStore.p12</Value>\n" +
                "                        </Detail>\n" +
                "                        <Detail>\n" +
                "                            <Key>ReplayChannelKeyStoreType</Key>\n" +
                "                            <Value>PKCS12</Value>\n" +
                "                        </Detail>\n" +
                "                        <Detail>\n" +
                "                            <Key>ReplayChannelTruststore</Key>\n" +
                "                            <Value>RazorTrustStore.jks</Value>\n" +
                "                        </Detail>\n" +
                "                        <Detail>\n" +
                "                            <Key>ReplayChannelTruststoreType</Key>\n" +
                "                            <Value>JKS</Value>\n" +
                "                        </Detail>\n" +
                "                        <Detail>\n" +
                "                            <Key>ReplayChannelEncrypted</Key>\n" +
                "                            <Value>true</Value>\n" +
                "                        </Detail>\n" +
                "                    </Details>\n" +
                "                </TransportMethod>\n" +
                "            </ReplayDetails>\n" +*/
                "        </Context>\n" +
                "    </ExceptionDetails>\n" +
                "</ExceptionMessage>"
        /*def content0 = "<ExceptionMessage>\n" +
                "    <ExceptionDetails>\n" +
                "        <Context>\n" +
                "            <ContextDetails>\n" +
                "                &lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;&lt;test&gt;TEST&lt;/test&gt;\n" +
                "            </ContextDetails>\n" +
                "            <ReplayDetails>\n" +
                "                <TransportMethod>\n" +
                "                    <Details>\n" +
                "                        <Detail>\n" +
                "                            <Key>ReplayChannelName</Key>\n" +
                "                            <Value>Q_FMEDMI_CTPY_MLS_REPLAY</Value>\n" +
                "                        </Detail>\n" +
                "                    </Details>\n" +
                "                </TransportMethod>\n" +
                "            </ReplayDetails>\n" +
                "        </Context>\n" +
                "    </ExceptionDetails>\n" +
                "</ExceptionMessage>"*/
        def ticketMetadata = new TicketMetadataDM()
//        def ticketMetadata0 = new TicketMetadataDM()

        ticketMetadata.setContent(content)
//        ticketMetadata0.setContent(content0)

        def ticket = new TicketDM()
        ticket.setTicketTags(ticketTags)
        ticket.setMetaData(ticketMetadata)

//        def ticket0 = new TicketDM()
//        ticket0.setTicketTags(ticketTags0)
//        ticket0.setMetaData(ticketMetadata0)


        def replayPublisher = spy(new ExceptionPublisher(null, null))
        def rRunner = spy(new ReplayRunner(ticket))
//        def rRunner0 = spy(new ReplayRunner(ticket0))

        when:
        doReturn(replayPublisher).when(rRunner).getReplayPublisher()
        doNothing().when(replayPublisher).publishMessage(anyString(), anyString(), anyMap())
//        when(rRunner.createPublisher(any(JMSSecurityConfiguration.class), anyString())).thenReturn(publisher)
//        when(rRunner0.createPublisher(any(JMSSecurityConfiguration.class), anyString())).thenReturn(publisher)
//        doNothing().when(publisher).publishExceptionMessage(anyString(), anyMap(), anyBoolean())

        rRunner.run()
//        rRunner0.run()

        then:
        verify(replayPublisher).publishMessage(anyString(), anyString(), anyMap())
//        def c0 = ArgumentCaptor.forClass(String.class)
//        def c1 = ArgumentCaptor.forClass(Map.class)
//        def c2 = ArgumentCaptor.forClass(Boolean.class)
//        verify(publisher, times(2)).publishExceptionMessage(c0.capture(), c1.capture(), c2.capture())
    }
}
