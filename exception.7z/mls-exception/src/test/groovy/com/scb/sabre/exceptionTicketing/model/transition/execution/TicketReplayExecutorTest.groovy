/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.sabre.exceptionTicketing.model.transition.execution

import com.scb.sabre.exceptionTicketing.consequences.ReplayConsequence
import com.scb.sabre.ticketing.domain.TicketActionDM
import com.scb.sabre.ticketing.domain.consequences.IConsequence
import org.mockito.ArgumentCaptor
import spock.lang.Shared
import spock.lang.Specification

import static org.mockito.Matchers.any
import static org.mockito.Mockito.*

/**
 * Description:
 * Author: 1466811
 * Date:   5:21 PM 7/22/14
 */
class TicketReplayExecutorTest extends Specification {
    @Shared ticketReplayExecutor

    def "test method canExecute"() {
        given:
        ticketReplayExecutor = new TicketReplayExecutor()

        expect:
        ticketReplayExecutor.canExecute(null, null, null, null).equals(true)
    }

    def "test method execute"() {
        given:
        def returnedTicketAction = spy(new TicketActionDM())
        ticketReplayExecutor = new TicketReplayExecutor()

        when:
        doNothing().when(returnedTicketAction).addConsequenceToExecute(any(IConsequence.class))

        ticketReplayExecutor.execute(null, null, null, null, null, returnedTicketAction)

        then:
        def captor = ArgumentCaptor.forClass(ReplayConsequence.class)
        verify(returnedTicketAction).addConsequenceToExecute(captor.capture())
    }
}
