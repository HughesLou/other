/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.sabre.exceptionTicketing.model.transition.execution

import spock.lang.Specification

/**
 * Description:
 * Author: 1466811
 * Date:   3:53 PM 7/23/14
 */
class ExceptionTicketActionStepExecutorRepositoryTest extends Specification {
    def "test the constructor"() {
        given:
        def repository = new ExceptionTicketActionStepExecutorRepository(null)

        expect:
        null != repository
    }
}
