/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.sabre.exceptionTicketing.rest

import com.scb.sabre.ticketing.domain.TicketDM
import com.scb.sabre.ticketing.domain.TicketMetadataDM
import com.scb.sabre.ticketing.domain.repository.TicketRepository
import spock.lang.Specification

import static org.mockito.Mockito.mock
import static org.mockito.Mockito.when

/**
 * Description:
 * Author: 1466811
 * Date:   8:35 PM 7/21/14
 */
class MetadataServiceTest extends Specification {

    def "get attachment"() {
        given:
        def metadataService = new MetadataService();
        def guid = 100;
        def attachmentId = "root";
        def content = "<ExceptionMessage><ExceptionDetails><Context><ContextDetails>&lt;?xml version=\"1.0\" " +
                "encoding=\"UTF-8\"?&gt;&lt;tests&gt;&lt;test&gt;TEST&lt;/test&gt;&lt;/tests&gt;" +
                "</ContextDetails></Context></ExceptionDetails></ExceptionMessage>"
        def ticketDM = new TicketDM();
        ticketDM.setId(guid)
        def ticketMetadataDM = new TicketMetadataDM();
        ticketMetadataDM.setContent(content)
        ticketDM.setMetaData(ticketMetadataDM)

        def ticketRepository = mock(TicketRepository.class);
        when(ticketRepository.get(String.valueOf(guid))).thenReturn(ticketDM);

        def field = MetadataService.class.getDeclaredField("ticketRepository");
        field.setAccessible(true);
        field.set(metadataService, ticketRepository);

        def method = MetadataService.class.getDeclaredMethod("formatXML", String.class, String.class, boolean.class);
        method.setAccessible(true);

        def input = "<test>TEST</test>"

        when:
        def response = metadataService.getAttachment(String.valueOf(guid), String.valueOf(attachmentId));
        def formatString0 = (String) method.invoke(metadataService, input, "4", true)
        def formatString1 = (String) method.invoke(metadataService, null, "4", true)

        then:
        response.getEntity() != null;
        response.getStatus() == 200;
        ((MetadataService.MetadataWrapper) response.getEntity()).getMetaData() != null;
        null != formatString0
        null == formatString1
    }
}
