package com.scb.razor.exception.jms

import com.scb.razor.exception.service.MessageService
import com.scb.sabre.sag.is.jms.JMSConfiguration
import com.scb.sabre.ticketing.configuration.SslConfiguration
import com.scb.sabre.ticketing.jms.JMSConnection
import org.apache.commons.io.FileUtils
import org.apache.commons.lang3.SystemUtils
import org.junit.Rule
import org.junit.rules.TemporaryFolder
import org.mockito.ArgumentCaptor
import spock.lang.Shared
import spock.lang.Specification

import javax.jms.*
import java.util.concurrent.TimeUnit

import static com.scb.razor.exception.utils.ExceptionConstants.ExceptionMessage
import static com.scb.razor.exception.utils.ExceptionConstants.XML_FILE
import static org.mockito.Matchers.*
import static org.mockito.Mockito.*

/**
 * Created by 1466811 on 4/18/2016.
 */
class ExceptionMessageSubscriberTest extends Specification {

    @Shared
    ExceptionMessageSubscriber exceptionMessageSubscriber
    @Rule
    TemporaryFolder folder = new TemporaryFolder()
    @Shared
    String content
    @Shared
    MessageConsumer consumer


    void setup() {
        content = "<ExceptionMessage><ExceptionDetails><ExceptionType>StaticMappingDataMissing" +
                "</ExceptionType><Description>StaticMappingDataMissing</Description><Context>" +
                "<ContextParticulars><Items><Item><Key>Trade ID</Key><Value>Razor2014072414</Value>" +
                "</Item></Items></ContextParticulars></Context></ExceptionDetails></ExceptionMessage>"

        exceptionMessageSubscriber = new ExceptionMessageSubscriber(
                messageService: mock(MessageService.class),
                exceptionConfigurationData: mock(JMSConfiguration.class),
                sslConfiguration: mock(SslConfiguration.class),
                exceptionTopicName: "exception topic name",
                exceptionBrokerName: "exception broker name",
                exceptionBrokerHostPort: "exception broker host port",
                exceptionDurableSubscriberName: "subscriber name",
                needEntitlement: false,
                idPrefix: "ID:",
                maxRetryTimes: 2,
                threadPoolSize: 3,
                exceptionMessageLocation: folder.getRoot().path,
                jmsConnection: mock(JMSConnection.class)
        )
        consumer = mock(TopicSubscriber.class)

        def topicConnection = mock(TopicConnection.class)
        def session = mock(Session.class)

        doReturn(topicConnection).when(exceptionMessageSubscriber.@jmsConnection)
                .getTopicConnection(any(JMSConfiguration.class), anyString(),
                anyString(), any(SslConfiguration.class), anyBoolean())
        doReturn(session).when(topicConnection).createSession(anyBoolean(), anyInt())
        doReturn(consumer).when(session).createDurableSubscriber(any(Topic.class), anyString())
    }

    def "Init"() {
        given:
        def fileName1 = "file1"
        def fileName2 = "file2"
        def fileName3 = "file3"
        File file1 = new File(folder.getRoot().path, fileName1 + XML_FILE)
        File file2 = new File(folder.getRoot().path, fileName2 + XML_FILE)
        File file3 = new File(folder.getRoot().path, fileName3)
        FileUtils.writeStringToFile(file1, "test")
        FileUtils.writeStringToFile(file2, "")
        file3.mkdir()
        def captor = ArgumentCaptor.forClass(MessageListener.class)

        when:
        doReturn("ID").when(exceptionMessageSubscriber.@messageService).save(anyString())
        exceptionMessageSubscriber.init()
        TimeUnit.MINUTES.sleep(1L)

        then:
        verify(consumer).setMessageListener(captor.capture())
        !file1.exists()
        file2.exists()
        file3.exists()
    }

    def "test when saving file successfully"() {
        given:
        def captor = ArgumentCaptor.forClass(MessageListener.class)
        def id = "123"
        exceptionMessageSubscriber.init()

        when:
        doReturn("").when(exceptionMessageSubscriber.@messageService).save(anyString())
        verify(consumer).setMessageListener(captor.capture())
        def listener = captor.getValue()
        listener.onMessage([getJMSMessageID: { return id },
                            getText        : { return content },
                            getJMSType     : { return ExceptionMessage }] as TextMessage)

        then:
        !exceptionMessageSubscriber.@retryMessageMap.keySet().contains(id)
    }

    def "test when error during saving file"() {
        given:
        def captor = ArgumentCaptor.forClass(MessageListener.class)
        def id = "ID:123"
        def fileName = id.substring(exceptionMessageSubscriber.@idPrefix.length(), id.length())
        exceptionMessageSubscriber.init()

        when:
        exceptionMessageSubscriber.@exceptionMessageLocation =
                new File(SystemUtils.getUserHome().getParentFile(), "mls").getAbsolutePath()
        doReturn("").when(exceptionMessageSubscriber.@messageService).save(anyString())
        verify(consumer).setMessageListener(captor.capture())
        def listener = captor.getValue()
        listener.onMessage([getJMSMessageID: { return id },
                            getText        : { return content },
                            getJMSType     : { return ExceptionMessage }] as TextMessage)

        then:
        Error error = thrown()
        error.message.contains((exceptionMessageSubscriber.@maxRetryTimes).toString())
        !exceptionMessageSubscriber.@retryMessageMap.keySet().contains(fileName)
        !new File(folder.getRoot().path, fileName + XML_FILE).exists()
    }

    def "SaveMessageToDisk"() {
        given:
        File file = new File(folder.getRoot().path, "123.xml")

        expect:
        exceptionMessageSubscriber.saveMessageToDisk(file, content)
    }
}
