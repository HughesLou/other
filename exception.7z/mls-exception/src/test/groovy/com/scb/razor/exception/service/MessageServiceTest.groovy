package com.scb.razor.exception.service

import com.scb.razor.exception.model.ExceptionTicketBuilder
import com.scb.sabre.exceptionTicketing.domain.ExceptionFriendlyIdProvider
import com.scb.sabre.ticketing.domain.TicketDM
import com.scb.sabre.ticketing.domain.consequences.ConsequenceExecutor
import com.scb.sabre.ticketing.domain.repository.TicketRepository
import org.springframework.transaction.PlatformTransactionManager
import spock.lang.Shared
import spock.lang.Specification

import javax.jms.Message
import javax.jms.TextMessage

import static org.mockito.Mockito.*

/**
 * Created by 1466811 on 4/18/2016.
 */
class MessageServiceTest extends Specification {

    @Shared
    MessageService messageService;
    @Shared
    Message message;
    @Shared
    String content;

    void setup() {
        content = "<ExceptionMessage><ExceptionDetails><ExceptionType>StaticMappingDataMissing" +
                "</ExceptionType><Description>StaticMappingDataMissing</Description><Context>" +
                "<ContextParticulars><Items><Item><Key>Trade ID</Key><Value>Razor2014072414</Value>" +
                "</Item></Items></ContextParticulars></Context></ExceptionDetails></ExceptionMessage>"
        messageService = new MessageService(
                transactionManager: mock(PlatformTransactionManager.class),
                ticketRepository: mock(TicketRepository.class),
                exceptionTicketBuilder: mock(ExceptionTicketBuilder.class),
                exceptionFriendlyIdProvider: new ExceptionFriendlyIdProvider(),
                consequenceExecutor: mock(ConsequenceExecutor.class),
                metaDataTag: "Trade ID",
                needEntitlement: false,
                maxDescriptionLength: 2000
        )
        message = mock(TextMessage.class)
        doReturn(content).when(message).getText()
    }

    def "MessageIs"() {
        given:
        def test = "TEST"

        when:
        doReturn(test).when(message).getJMSType()

        then:
        true == MessageService.messageIs(test, message)
    }

    def "GetMessageTextFrom"() {
        given:
        def text = MessageService.getMessageTextFrom(message)

        expect:
        content.equals(text)
    }

    def "Save"() {
        given:
        def ticketDM = mock(TicketDM.class)
        def id = 110

        when:
//        doNothing().when(messageService.@transactionTemplate).execute(any(TransactionCallback.class))
        doReturn(id).when(ticketDM).getId()
        when(messageService.@exceptionTicketBuilder.buildExceptionTicket(anyString(), anyString(),
                anyString(), anyString(), anyString(), any(Set.class))).thenReturn(ticketDM)
        doNothing().when(ticketDM).performFirstAction(anyString(), anyString(), anyBoolean())
        doNothing().when(messageService.@ticketRepository).save(any(TicketDM.class))
        doNothing().when(ticketDM).executeConsequences(any(ConsequenceExecutor.class))

        then:
        messageService.save(content).endsWith(id.toString())
    }
}
