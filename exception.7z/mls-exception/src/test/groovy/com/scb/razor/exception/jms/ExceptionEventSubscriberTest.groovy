/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.exception.jms

import com.scb.sabre.sag.is.jms.JMSConfiguration
import com.scb.sabre.ticketing.configuration.SslConfiguration
import com.scb.sabre.ticketing.jms.JMSConnection
import com.scb.sabre.ticketing.util.Constants
import com.scb.sabre.ws.messaging.MessagePublisher
import org.mockito.ArgumentCaptor
import spock.lang.Specification

import javax.jms.*

import static org.mockito.Matchers.*
import static org.mockito.Mockito.*

/**
 * Description:
 * Author: 1466811
 * Date:   4:57 PM 7/23/14
 */
class ExceptionEventSubscriberTest extends Specification {

    def "test the method init"() {
        given:
        def exceptionEventSubscriber = spy(new ExceptionEventSubscriber())
        def jmsConnection = spy(new JMSConnection())
        def exceptionConfigurationData = spy(new JMSConfiguration())
        def field0 = ExceptionEventSubscriber.class.getDeclaredField("middlewareTopic");
        field0.setAccessible(true);
        field0.set(exceptionEventSubscriber, "TEST_TOPIC");
        def field1 = ExceptionEventSubscriber.class.getDeclaredField("exceptionConfigurationData");
        field1.setAccessible(true);
        field1.set(exceptionEventSubscriber, exceptionConfigurationData);

        def sslConfig = new SslConfiguration()
        sslConfig.setSslEnable(false)
        sslConfig.setSslKeyStore("")
        sslConfig.setSslKeyStoreType("")
        sslConfig.setSslTrustStore("")
        sslConfig.setSslTrustStoreType("")
        sslConfig.setSslEncrypted(false)
        sslConfig.setSslUsername("")
        sslConfig.setSslPassword("")
        def field2 = ExceptionEventSubscriber.class.getDeclaredField("sslConfiguration");
        field2.setAccessible(true);
        field2.set(exceptionEventSubscriber, sslConfig);
//        def field3 = ExceptionEventSubscriber.class.getDeclaredField("exceptionBrokerHostPort");
//        field3.setAccessible(true);
//        field3.set(exceptionEventSubscriber, "www.sc.com:9999");
        def topicConnection = mock(TopicConnection.class)
        def session = mock(Session.class)
        def consumer = mock(TopicSubscriber.class)
        def listener = mock(MessageListener.class)

        when:
        doReturn("test").when(exceptionConfigurationData).toString()
        when(exceptionEventSubscriber.getJmsConnection()).thenReturn(jmsConnection)
        doReturn(topicConnection).when(jmsConnection).getTopicConnection(any(JMSConfiguration.class),
                any(SslConfiguration.class), anyBoolean())
        doReturn(session).when(topicConnection).createSession(anyBoolean(), anyInt())
        when(session.createConsumer(any(Topic.class))).thenReturn(consumer)
        doNothing().when(consumer).setMessageListener(any(MessageListener.class))
        doNothing().when(listener).onMessage(any(Message.class))
        doNothing().when(topicConnection).start()

        exceptionEventSubscriber.init()

        then:
        def captor0 = ArgumentCaptor.forClass(MessageListener.class)
        verify(consumer).setMessageListener(captor0.capture())
    }

    def "test the method onMessage"() {
        given:
        def exceptionEventSubscriber = spy(new ExceptionEventSubscriber())
        def message0 = mock(TextMessage.class)
        def message1 = mock(TextMessage.class)
        def message2 = mock(TextMessage.class)
        def content = "1001"
        def messagePublisher = mock(MessagePublisher.class)
        def field0 = ExceptionEventSubscriber.class.getDeclaredField("messagePublisher");
        field0.setAccessible(true);
        field0.set(exceptionEventSubscriber, messagePublisher);

        when:
        doReturn(Constants.TICKETING_EVENT).when(message0).getJMSType()
        doReturn(content).when(message0).getText()
        doReturn(Constants.TICKETING_ERROR).when(message1).getJMSType()
        doReturn(content).when(message1).getText()
        doReturn(Constants.TICKETING_EVENT).when(message2).getJMSType()
        doNothing().when(messagePublisher).publish(anyString())

        exceptionEventSubscriber.onMessage(message0)
        exceptionEventSubscriber.onMessage(message1)
        exceptionEventSubscriber.onMessage(message2)

        then:
        def captor = ArgumentCaptor.forClass(String.class)
        verify(messagePublisher, times(2)).publish(captor.capture())
    }
}
