package com.scb.razor.exception.model

import com.scb.sabre.ticketing.domain.TicketTagDM
import spock.lang.Specification

/**
 * Created by 1466811 on 4/19/2016.
 */
class ExceptionTicketBuilderTest extends Specification {
    def "test build exception ticket"() {
        given:
        def payload = "test_payload"
        def subTradeId = "test_subTradeId"
        def ticketType = "test_ticketType"
        def userId = "1466811"
        def description = "test_description"
        def ticketTags = new HashSet<TicketTagDM>()
        TicketTagDM ticketTagDM = new TicketTagDM()
        ticketTags.add(ticketTagDM)
        def stpTicketBuilder = new ExceptionTicketBuilder()

        when:
        def ticketDM = stpTicketBuilder.buildExceptionTicket(payload, subTradeId, ticketType,
                userId, description, ticketTags)

        then:
        null != ticketDM
        subTradeId.equals(ticketDM.getMetaDataTag())
        payload.equals(ticketDM.getMetaData().getContent())
        userId.equals(ticketDM.getCreator())
        ticketType.equals(ticketDM.getType())
    }
}
