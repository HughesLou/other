#MLS-EXCEPTION


##Description:


##Build:


##Nice features:



##History
    Date        Version     Feature
    Mar 2016    2.0.0       apply the pipeline
    Apr 2016    2.0.1       refactor the Error Topic subscriber