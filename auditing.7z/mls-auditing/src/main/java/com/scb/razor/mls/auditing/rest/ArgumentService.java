/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.rest;

import com.scb.razor.mls.persistent.dao.LoggingEventDao;
import com.scb.razor.mls.persistent.model.LoggingEvent;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.zip.DataFormatException;

@Path("/Auditing/Argument")
@Component
public class ArgumentService {

    @Autowired
    private LoggingEventDao loggingEventDaoImpl = null;

    public static String EMPTYCONTEXTDETAILS = "No original message attached, please contact pss team if you needed.";

    /**
     * the response of getting the argument of a loggingEvent
     *
     * @param id the id of the loggingEvent
     *
     * @return the response to the client
     *
     * @throws DataFormatException
     */
    @GET
    @Transactional
    public Response getContent(@QueryParam("id") final String id)
            throws DataFormatException {

        LoggingEvent loggingEvent = loggingEventDaoImpl.findById(Long.parseLong(id));

        if (null != loggingEvent) {
            if (StringUtils.isEmpty(loggingEvent.getArg1())) {
                return Response.ok().type(MediaType.APPLICATION_JSON).entity(
                        new ContentWrapper(EMPTYCONTEXTDETAILS)).build();
            } else {
                StringBuilder argument = new StringBuilder(loggingEvent.getArg1())
                        .append(null != loggingEvent.getArg2() ? loggingEvent.getArg2() : "")
                        .append(null != loggingEvent.getArg3() ? loggingEvent.getArg2() : "");

                return Response.ok().type(MediaType.APPLICATION_JSON).entity(
                        new ContentWrapper(argument.toString())).build();
            }
        }

        throw new IllegalArgumentException(String.format("The Logging Event %s is not valid.", id));
    }

    public static class ContentWrapper {

        private String content;

        public ContentWrapper(String content) {
            this.content = content;
        }

        public String getContent() {
            return content;
        }
    }
}
