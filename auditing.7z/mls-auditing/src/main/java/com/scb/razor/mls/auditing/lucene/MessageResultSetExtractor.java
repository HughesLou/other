package com.scb.razor.mls.auditing.lucene;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;

import javax.sql.DataSource;

import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.google.common.base.Function;
import com.scb.razor.mls.auditing.lucene.ParentAndChildQuery.MessageQuery;

public class MessageResultSetExtractor implements ResultSetExtractor<Void> {
    
    private final static Logger log = LoggerFactory.getLogger(MessageResultSetExtractor.class);
    
    private ExecutorService executorService;
    
    private DataSource dataSource;
    
    private IndexWriter indexWriter;
    
    private Date max = null;
    
    private long count = 0;
    
    private boolean commitOnFinish = true;
    
    private boolean recordLastSeenIncrement = false;
    
    private List<String> lastSeenIncrement;//this property only works when recordLastSeenIncrement=true
    
    private boolean recordAckAndNack = false;
    
    private Set<String> acks, nacks;
    
    private Function<Document, Void> beforeIndexing;
    
    @Override
    public Void extractData(ResultSet rs) throws SQLException, DataAccessException {
        
        Iterator<Long> idIter = IdIterators.fromResultSet(rs, new Function<ResultSet, Long>(){
            public Long apply(ResultSet input) {
                try {
                    return input.getLong("ID");
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }});
        MessageQuery mq = new MessageQuery();
        mq.setDataSource(dataSource);
        
        Date messageMax = null;
        List<String> messageMaxIds = new ArrayList<String>();
        Iterator<List<Map<String, Object>>> messageListIter = mq.query(idIter, executorService, 10);
        while(messageListIter.hasNext()) {
            List<Map<String, Object>> messageList = messageListIter.next();
            for(Map<String, Object> m : messageList) {
                Long id = (Long) m.get("id");
                Date createTimestamp = (Timestamp) m.get("create_timestamp");
                String messageType = (String) m.get("messageType");
                if(lastSeenIncrement != null) {
                    if(lastSeenIncrement.contains(id.toString())) {
                        continue;
                    }
                }
                if(messageMax == null) {
                    messageMax = createTimestamp;
                }
                if(createTimestamp.after(messageMax)) {
                    messageMax = createTimestamp;
                    messageMaxIds.clear();
                }
                if(createTimestamp.equals(messageMax)) {
                    messageMaxIds.add(id.toString());
                }
                if(recordAckAndNack) {
                    if(acks == null) {
                        acks = new HashSet<String>();
                    }
                    if(nacks == null) {
                        nacks = new HashSet<String>();
                    }
                    if("NACK".equals(messageType)) {
                        nacks.add(id.toString());
                    }
                    if("ACK".equals(messageType)) {
                        acks.add(id.toString());
                    }
                }
                count++;
                Document doc = ToDocument.fromMurexException(m);
                if(beforeIndexing != null) {
                    beforeIndexing.apply(doc);
                }
                try {
                    indexWriter.addDocument(doc);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                if(count % 10000 == 0) {
                    log.info("progress : {}", count);
                }
            }
        }
        if(recordLastSeenIncrement) {
            setLastSeenIncrement(messageMaxIds);
        }
        this.max = messageMax;
        if(commitOnFinish) {
            try {
                indexWriter.commit();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        if(count > 0) {//don't produce info-less log, a lot
            log.info("{} indexed, max timestamp is {} and corresponding ids {}", count, max, messageMaxIds);
        }
        
        return null;
    }

    public ExecutorService getExecutorService() {
        return executorService;
    }

    public void setExecutorService(ExecutorService executorService) {
        this.executorService = executorService;
    }

    public DataSource getDataSource() {
        return dataSource;
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public IndexWriter getIndexWriter() {
        return indexWriter;
    }

    public void setIndexWriter(IndexWriter indexWriter) {
        this.indexWriter = indexWriter;
    }

    public Date getMax() {
        return max;
    }

    public long getCount() {
        return count;
    }

    public boolean isCommitOnFinish() {
        return commitOnFinish;
    }

    public void setCommitOnFinish(boolean commitOnFinish) {
        this.commitOnFinish = commitOnFinish;
    }

    public Set<String> getAcks() {
        return acks;
    }

    public Set<String> getNacks() {
        return nacks;
    }

    public boolean isRecordAckAndNack() {
        return recordAckAndNack;
    }

    public void setRecordAckAndNack(boolean recordAckAndNack) {
        this.recordAckAndNack = recordAckAndNack;
    }

    public boolean isRecordLastSeenIncrement() {
        return recordLastSeenIncrement;
    }

    public void setRecordLastSeenIncrement(boolean recordLastSeenIncrement) {
        this.recordLastSeenIncrement = recordLastSeenIncrement;
    }

    public List<String> getLastSeenIncrement() {
        return lastSeenIncrement;
    }

    public void setLastSeenIncrement(List<String> lastSeenIncrement) {
        this.lastSeenIncrement = lastSeenIncrement;
    }

    public Function<Document, Void> getBeforeIndexing() {
        return beforeIndexing;
    }

    public void setBeforeIndexing(Function<Document, Void> beforeIndexing) {
        this.beforeIndexing = beforeIndexing;
    }
}
