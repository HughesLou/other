/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.mapping;

import com.scb.razor.mls.auditing.builder.MlsLoggingEventBuilder;
import com.scb.razor.mls.auditing.model.ArgumentLink;
import com.scb.razor.mls.auditing.model.MlsLoggingEvent;
import com.scb.razor.mls.persistent.model.LoggingEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.scb.razor.mls.persistent.utils.PersistentConstants.SEPARATOR;

/**
 * Description:
 * Author: 1466811
 */
@Component
public class LoggingEventMapper {

    private static final Logger logger = LoggerFactory.getLogger(LoggingEventMapper.class);

    /**
     * map LoggingEvent to MlsLoggingEventBuilder
     *
     * @param loggingEvent the data searched from database
     * @param uriPrefix    the client uri
     *
     * @return the MlsLoggingEventBuilder which is used to built MlsLoggingEvent
     */
    public MlsLoggingEventBuilder mapToMlsLoggingEvent(LoggingEvent loggingEvent, URI uriPrefix) {
        MlsLoggingEventBuilder mlsLoggingEventBuilder = new MlsLoggingEventBuilder();

        mlsLoggingEventBuilder.setId(loggingEvent.getId());

        String argument = loggingEvent.getArg0().trim();
        int index = argument.indexOf(SEPARATOR);
        if (index >= 0) {
            mlsLoggingEventBuilder.setSystemId(argument.substring(0, index).trim());
            mlsLoggingEventBuilder.setTradeRef(argument.substring(index + 1).trim());
        } else {
            mlsLoggingEventBuilder.setSystemId(argument);
            mlsLoggingEventBuilder.setTradeRef(null);
        }

        mlsLoggingEventBuilder.setDate(new Date(loggingEvent.getTimeStamp()));

        mlsLoggingEventBuilder.setArgumentLink(new ArgumentLink(uriPrefix, "Logging Event argument",
                "Logging Event argument", loggingEvent.getId().toString()));

        logger.debug("Mapping Logging Event {} successfully!", loggingEvent.getId());

        return mlsLoggingEventBuilder;
    }

    /**
     * get the list of MlsLoggingEvent from a list of LoggingEvent
     *
     * @param loggingEvents the list of LoggingEvent searched from database
     * @param uri           the client uri
     *
     * @return the list of MlsLoggingEvent
     */
    public List<MlsLoggingEvent> mapToMlsLoggingEventCollection(List<LoggingEvent> loggingEvents, URI uri) {
        List<MlsLoggingEvent> mlsLoggingEvents = new ArrayList<>();

        for (LoggingEvent loggingEvent : loggingEvents) {
            mlsLoggingEvents.add(mapToMlsLoggingEvent(loggingEvent, uri).build());
        }

        return mlsLoggingEvents;
    }
}
