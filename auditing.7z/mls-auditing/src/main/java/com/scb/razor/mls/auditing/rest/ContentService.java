/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.rest;

import com.scb.razor.mls.persistent.dao.MessageDao;
import com.scb.razor.mls.persistent.model.Message;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.zip.GZIPInputStream;

@Path("/Auditing/Content")
@Component
public class ContentService {

    @Autowired
    private MessageDao messageDaoImpl = null;

    @GET @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    @Transactional
    public Response getContent(@QueryParam("user") final String userId, @QueryParam("id") final Long id, @HeaderParam("Accept") String accept) {
        
        if(id == null) {
            throw new WebApplicationException(Status.BAD_REQUEST);
        }

        Message message = messageDaoImpl.findById(id);
        
        if(message == null) {
            throw new WebApplicationException(Status.NOT_FOUND);
        }
        
        byte[] contentByteArray = message.getContent();
        
        if(contentByteArray == null || contentByteArray.length == 0) {
            return Response.noContent().build();
        }
        
        String content = null;
        
        switch(message.getContentType()) {
            case TEXT : 
                content = new String(contentByteArray, StandardCharsets.UTF_8);
                break;
            case COMPRESSED_TEXT : 
            case COMPRESSED_BINARY : 
                try {
                    StringWriter sw = new StringWriter();
                    IOUtils.copy(new GZIPInputStream(new ByteArrayInputStream(contentByteArray)), sw);
                    content = sw.toString();
                } catch (IOException e) {
                    throw new WebApplicationException(e);
                }
                break;
            default: 
                content = new String(message.getContent());
                break;
        }
        
        //response content type can be json or xml, depending on 'accept' request header
        //NOTE the xml response doesn't have wrapper as json did
        if(accept.indexOf("application/xml") > -1) {
            //a trick to make it compatible with existing code
            //if the request is from existing code, its sent by ajax and accept value is like '*/*'
            //if the request is from a browser window (open link in new window), accept value is like 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'
            return Response.ok(content, MediaType.APPLICATION_XML).build();
        } else {
            return Response.ok(new ContentWrapper(content), MediaType.APPLICATION_JSON).build();
        }
    }

    public static class ContentWrapper {

        private String content;

        public ContentWrapper(String content) {
            this.content = content;
        }

        public String getContent() {
            return content;
        }
    }
}
