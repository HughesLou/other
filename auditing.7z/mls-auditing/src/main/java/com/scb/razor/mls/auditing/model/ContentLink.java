/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.model;

import java.net.URI;

public class ContentLink implements java.io.Serializable {

    private static final long serialVersionUID = 4331394244335766436L;
    private String name;
    private String description;
    private String mediaTypes;
    private String href;

    /**
     * the construct, generate the url link for every Message
     *
     * @param uriInfo     the client uri
     * @param mediaTypes  the content type of Message
     * @param name        the name of content
     * @param description the description of content
     * @param id          the user id
     */
    public ContentLink(final URI uriInfo, final String mediaTypes, final String name,
                       final String description, final String id) {
        this.name = name;
        this.description = description;
        this.mediaTypes = mediaTypes;
        this.href = uriInfo.toString() + "Auditing/Content?id=" + id;
    }

    public String getMediaTypes() {
        return mediaTypes;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }

    public String getHref() {
        return href;
    }

    public void setHref(final String href) {
        this.href = href;
    }
}
