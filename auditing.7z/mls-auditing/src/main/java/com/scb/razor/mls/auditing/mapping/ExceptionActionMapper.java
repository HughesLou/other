/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.mapping;

import com.scb.razor.mls.auditing.builder.MlsExceptionActionBuilder;
import com.scb.razor.mls.auditing.model.MlsExceptionAction;
import com.scb.razor.mls.persistent.model.ExceptionAction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: 1466811
 * Date:   12:14 PM 4/15/14
 */
@Component
public class ExceptionActionMapper {

    private static final Logger logger = LoggerFactory.getLogger(ExceptionActionMapper.class);

    /**
     * map AuditLog to MlsExceptionActionBuilder
     *
     * @param exceptionAction the data searched from database
     *
     * @return the MlsExceptionActionBuilder which is used to built MlsExceptionActionBuilder
     */
    public MlsExceptionActionBuilder mapToMlsExceptionAction(ExceptionAction exceptionAction) {
        MlsExceptionActionBuilder mlsExceptionActionBuilder = new MlsExceptionActionBuilder();

        mlsExceptionActionBuilder.setId(exceptionAction.getId());
        mlsExceptionActionBuilder.setActor(exceptionAction.getActor());
        mlsExceptionActionBuilder.setAction(exceptionAction.getAction());
        mlsExceptionActionBuilder.setTicketId("MLS-" + exceptionAction.getTicketId());
        mlsExceptionActionBuilder.setComments(exceptionAction.getComments());
        mlsExceptionActionBuilder.setCreatedDate(exceptionAction.getCreatedDate());

        logger.debug("Mapping ExceptionAction {} successfully!", exceptionAction.getId());

        return mlsExceptionActionBuilder;
    }

    /**
     * get the list of MlsExceptionAction from a list of ExceptionAction
     *
     * @param exceptionActions the list of ExceptionAction searched from database
     *
     * @return the list of MlsExceptionAction
     */
    public List<MlsExceptionAction> mapToMlsExceptionActionCollection(List<ExceptionAction> exceptionActions) {
        List<MlsExceptionAction> mlsExceptionActions = new ArrayList<>();

        for (ExceptionAction exceptionAction : exceptionActions) {
            mlsExceptionActions.add(mapToMlsExceptionAction(exceptionAction).build());
        }

        return mlsExceptionActions;
    }
}
