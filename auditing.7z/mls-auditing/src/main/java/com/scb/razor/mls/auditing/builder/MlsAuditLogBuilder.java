/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.builder;

import com.scb.razor.mls.auditing.model.MlsAuditLog;
import com.scb.razor.mls.persistent.utils.PersistentConstants.AuditLogAction;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * Description:
 * Author: 1466811
 * Date:   12:14 PM 4/9/14
 */
@Component
public class MlsAuditLogBuilder {

    private Long id;
    private String detail;
    private Date createdDate;
    private long entityId;
    private String userId;
    private AuditLogAction action;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public AuditLogAction getAction() {
        return action;
    }

    public void setAction(AuditLogAction action) {
        this.action = action;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public long getEntityId() {
        return entityId;
    }

    public void setEntityId(long entityId) {
        this.entityId = entityId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public MlsAuditLog build() {
        return new MlsAuditLog(this);
    }
}
