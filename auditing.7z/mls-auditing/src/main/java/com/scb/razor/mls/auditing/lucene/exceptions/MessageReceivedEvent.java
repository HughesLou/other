package com.scb.razor.mls.auditing.lucene.exceptions;

import java.util.List;

import com.scb.razor.mls.auditing.BusEvent;

/**
 * <pre>
 * flow : message nack, message replay, message ack
 * 
 * this event is specific to the ack for replayed message
 * 
 * status=RECEIVED and messageType=ack
 * </pre>
 * @author 1510954
 *
 */
public class MessageReceivedEvent implements BusEvent{

    private List<String> ids;

    public List<String> getIds() {
        return ids;
    }

    public void setIds(List<String> ids) {
        this.ids = ids;
    }
    
    public static class AckReceivedEvent extends MessageReceivedEvent {
        
    }
    
    public static class NackReceivedEvent extends MessageReceivedEvent {
        
    }
}
