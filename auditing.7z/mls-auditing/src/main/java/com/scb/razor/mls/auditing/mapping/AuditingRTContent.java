package com.scb.razor.mls.auditing.mapping;

import javax.xml.bind.annotation.*;

/**
 * Created with IntelliJ IDEA.
 * User: 1439970
 * Date: 11/12/14
 * Time: 5:06 PM
 * To change this template use File | Settings | File Templates.
 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType
@XmlRootElement(name = "systemResponse")
public class AuditingRTContent {

    @XmlElement(name = "responsePayload")
    private AuditingRTContent.ResponsePayload responsePayload;

    public AuditingRTContent.ResponsePayload getResponsePayload() {
        return responsePayload;
    }

    public void setResponsePayload(AuditingRTContent.ResponsePayload responsePayload) {
        this.responsePayload = responsePayload;
    }

    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType
    @XmlRootElement(name = "responsePayload")
    public static class ResponsePayload {

        @XmlElement(name = "nack")
        private AuditingRTContent.ResponsePayload.Nack nack;

        public AuditingRTContent.ResponsePayload.Nack getNack() {
            return nack;
        }

        public void setNack(AuditingRTContent.ResponsePayload.Nack nack) {
            this.nack = nack;
        }

        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType
        @XmlRootElement(name = "nack")
        public static class Nack {

            @XmlElement(name = "description")
            private String description;

            public String getDescription() {
                return description;
            }

            public void setDescription(String description) {
                this.description = description;
            }
        }
    }
}
