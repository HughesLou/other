package com.scb.razor.mls.auditing.rest;

import com.scb.razor.mls.auditing.model.MlsMessage;
import com.scb.razor.mls.auditing.model.MlsMessageProperty;
import com.scb.razor.mls.auditing.service.AuditingService;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.List;

import static com.scb.razor.mls.auditing.constant.AuditingConstants.*;

/**
 * Created with IntelliJ IDEA.
 * User: 1439970
 * Date: 11/13/14
 * Time: 2:28 PM
 * To change this template use File | Settings | File Templates.
 */
public class BuildDetailsExport {

    static class LabelValue {

        public LabelValue(String label, String value) {
            super();
            this.label = label;
            this.value = value;
        }

        private String label, value;

        public String getLabel() {
            return label;
        }

        public void setLabel(String label) {
            this.label = label;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }

    private static String getSingleNodeValue(Document doc, String tagName) {
        if (doc == null) {
            return null;
        }
        String value = doc.getElementsByTagName(tagName).item(0)
                .getFirstChild().getNodeValue();
        return value;
    }

    private static Node getNodesByTagName(Node node, String tagName, int index) {
        if (node == null) {
            return null;
        }
        List<Node> list = new ArrayList<Node>();
        buildeNodes(list, node, tagName);
        if (index > list.size() - 1) {
            return null;
        }
        return list.get(index);
    }

    private static List<Node> getNodesByTagName2(Node node, String tagName) {
        if (node == null) {
            return null;
        }
        List<Node> list = new ArrayList<Node>();
        buildeNodes(list, node, tagName);
        return list;
    }

    private static void buildeNodes(List<Node> list, Node node, String tagName) {
        NodeList nodeList = node.getChildNodes();
        Node _node = null;
        for (int i = 0; i < nodeList.getLength(); i++) {
            _node = nodeList.item(i);
            if (_node.getNodeName().equals(tagName)) {
                list.add(_node);
            }
            if (_node.hasChildNodes()) {
                buildeNodes(list, _node, tagName);
            }
        }
    }

    private static String getNodeValue(Node node) {
        if (node == null) {
            return "";
        }
        String value = node.getFirstChild().getNodeValue();
        return value;
    }

    private static String getNodeValues(List<Node> nodes) {
        if (nodes == null) {
            return "";
        }
        String result = "";
        String value = "";
        for (int i = 0; i < nodes.size(); i++) {
            value = nodes.get(i).getFirstChild().getNodeValue();
            result = result + value + "  ";
        }
        return result;
    }

    private static String getAttrValue(Node node, String attr) {
        if (node == null) {
            return "";
        }
        String value = node.getAttributes().getNamedItem(attr).getFirstChild()
                .getNodeValue();
        return value;
    }

    private static CellStyle getPublicCellStyle(SXSSFWorkbook wb) {
        CellStyle cellStyle = wb.createCellStyle();
        // titleCellStyle.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
        cellStyle.setAlignment(CellStyle.VERTICAL_CENTER);
        cellStyle.setAlignment(CellStyle.ALIGN_CENTER);
        cellStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
        cellStyle.setBorderBottom(CellStyle.BORDER_THIN);
        cellStyle.setBorderLeft(CellStyle.BORDER_THIN);
        cellStyle.setBorderTop(CellStyle.BORDER_THIN);
        cellStyle.setBorderRight(CellStyle.BORDER_THIN);
        // cellStyle.setWrapText(true);
        return cellStyle;
    }

    public static SXSSFWorkbook generateExcelFrame() throws Exception {
        SXSSFWorkbook wb = new SXSSFWorkbook(SXSSF_WORKBOOK_FLUSH_NUM);
        Sheet sheet = wb.createSheet("Auditing RT");

        // set column width
        sheet.setColumnWidth(0, 12000);
        sheet.setColumnWidth(1, 7000);
        sheet.setColumnWidth(2, 14000);
        sheet.setColumnWidth(3, 5000);
        sheet.setColumnWidth(4, 8000);
        sheet.setColumnWidth(5, 7000);
        sheet.setColumnWidth(6, 5000);
        sheet.setColumnWidth(7, 5000);

        return wb;
    }

    public static SXSSFWorkbook generateAllExcelData(List<MlsMessage> mlsMessages, SXSSFWorkbook wb, int num)
            throws Exception {
        List<MlsMessageProperty> mlsMessageProperties = null;
        Sheet sheet = wb.getSheet("Auditing RT");

        // title cell style
        CellStyle titleCellStyle = getPublicCellStyle(wb);
        Font titleFont = wb.createFont();
        titleFont.setFontHeightInPoints((short) 14);
        titleFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
        titleCellStyle.setFont(titleFont);
        titleCellStyle.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
        // data odd cell style
        Font cellFont = wb.createFont();
        cellFont.setFontHeightInPoints((short) 10);
        CellStyle oddCellStyle = getPublicCellStyle(wb);
        oddCellStyle.setFillForegroundColor(HSSFColor.WHITE.index);
        oddCellStyle.setFont(cellFont);
        // data even cell style
        CellStyle evenCellStyle = getPublicCellStyle(wb);
        evenCellStyle.setFillForegroundColor(HSSFColor.WHITE.index);
        evenCellStyle.setFont(cellFont);

        int mainTitleRowNum = 0;
        int subTitleRowNum = 1;
        int contentRowNum = 2 + num;
        for (int i = 0; i < mlsMessages.size(); i++) {
            String messageType = null;
            String leId = null;
            String imetaID = null;

            List<LabelValue> dataDetails = new ArrayList();

            dataDetails.add(new LabelValue("Tracking Id", mlsMessages.get(i).getTrackingId()));
            dataDetails.add(new LabelValue("Source System Id", mlsMessages.get(i).getSourceSysId()));
            dataDetails.add(new LabelValue("Description", mlsMessages.get(i).getDescription()));
            dataDetails.add(new LabelValue("Status", mlsMessages.get(i).getStatus().toString()));
            dataDetails.add(new LabelValue("Timestamp", mlsMessages.get(i).getCreateTimeStamp().toString()));
            mlsMessageProperties = mlsMessages.get(i).getProperties();

            for (MlsMessageProperty mlsMessageProperty : mlsMessageProperties) {
                switch (mlsMessageProperty.getKey()) {
                    case RT_MESSAGE_TYPR:
                        messageType = mlsMessageProperty.getValue();
                        break;
                    case RT_LE_ID:
                        leId = mlsMessageProperty.getValue();
                        break;
                    case RT_IMETA_ID:
                        imetaID = mlsMessageProperty.getValue();
                        break;
                }
            }

            dataDetails.add(new LabelValue("Message Type", messageType));
            dataDetails.add(new LabelValue("Le Id", leId));
            dataDetails.add(new LabelValue("Imeta Id", imetaID));

            if (sheet.getLastRowNum() == 0) {
                // ======= big title ========
                CellStyle bigTitleCellStyle = getPublicCellStyle(wb);
                Font bigTitleFont = wb.createFont();
                bigTitleFont.setFontHeightInPoints((short) 14);
                bigTitleFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
                bigTitleCellStyle.setFont(bigTitleFont);
                bigTitleCellStyle.setFillForegroundColor(HSSFColor.GREY_50_PERCENT.index);

                Row mergeRow = null;
                Cell mergeCell = null;
                mergeRow = sheet.createRow(mainTitleRowNum);
                // merge cell
                int firstCol = 0;
                int lastCol = firstCol + dataDetails.size() - 1;
                sheet.addMergedRegion(new CellRangeAddress(0, 0, firstCol,
                        lastCol));
                mergeCell = mergeRow.createCell(firstCol);
                mergeCell.setCellStyle(bigTitleCellStyle);
                mergeCell.setCellValue("Auditing RT Data");

                // =========== detail title row ==============
                Row titleRow = null;
                Cell titleCell = null;
                titleRow = sheet.createRow(subTitleRowNum);
                int titleColNum = 0;
                for (LabelValue lv : dataDetails) {
                    titleCell = titleRow.createCell(titleColNum++);
                    titleCell.setCellStyle(titleCellStyle);
                    titleCell.setCellValue(lv.getLabel());
                }
            }

            // =========== content row ==============
            Row contentRow = sheet.createRow(contentRowNum++);
            Cell contentCell = null;
            int contentColNum = 0;
            for (LabelValue lv : dataDetails) {
                contentCell = contentRow.createCell(contentColNum++);
                if (contentRowNum % 2 == 0) {
                    contentCell.setCellStyle(evenCellStyle);
                } else {
                    contentCell.setCellStyle(oddCellStyle);
                }
                contentCell.setCellValue(lv.getValue());
            }
        }

        return wb;
    }

    //SXSSFWorkbook
    public static SXSSFWorkbook generateExcelCurrentPage(String id, AuditingService auditingServiceImpl,
                                                         SXSSFWorkbook wb, int num) throws Exception {
        MlsMessage mlsMessage = null;
        List<MlsMessageProperty> mlsMessageProperties = null;

        Sheet sheet = wb.getSheet("Auditing RT");

        // title cell style
        CellStyle titleCellStyle = getPublicCellStyle(wb);
        Font titleFont = wb.createFont();
        titleFont.setFontHeightInPoints((short) 14);
        titleFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
        titleCellStyle.setFont(titleFont);
        titleCellStyle.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
        // data odd cell style
        Font cellFont = wb.createFont();
        cellFont.setFontHeightInPoints((short) 10);
        CellStyle oddCellStyle = getPublicCellStyle(wb);
        oddCellStyle.setFillForegroundColor(HSSFColor.WHITE.index);
        oddCellStyle.setFont(cellFont);
        // data even cell style
        CellStyle evenCellStyle = getPublicCellStyle(wb);
        evenCellStyle.setFillForegroundColor(HSSFColor.WHITE.index);
        evenCellStyle.setFont(cellFont);

        int mainTitleRowNum = 0;
        int subTitleRowNum = 1;
        int contentRowNum = 2 + num;

        mlsMessage = auditingServiceImpl.getMessageById(id);
        String messageType = null;
        String leId = null;
        String imetaID = null;

        List<LabelValue> dataDetails = new ArrayList();

        dataDetails.add(new LabelValue("Tracking Id", mlsMessage.getTrackingId()));
        dataDetails.add(new LabelValue("Source System Id", mlsMessage.getSourceSysId()));
        dataDetails.add(new LabelValue("Description", mlsMessage.getDescription()));
        dataDetails.add(new LabelValue("Status", mlsMessage.getStatus().toString()));
        dataDetails.add(new LabelValue("Timestamp", mlsMessage.getCreateTimeStamp().toString()));
        mlsMessageProperties = mlsMessage.getProperties();

        for (MlsMessageProperty mlsMessageProperty : mlsMessageProperties) {
            switch (mlsMessageProperty.getKey()) {
                case RT_MESSAGE_TYPR:
                    messageType = mlsMessageProperty.getValue();
                    break;
                case RT_LE_ID:
                    leId = mlsMessageProperty.getValue();
                    break;
                case RT_IMETA_ID:
                    imetaID = mlsMessageProperty.getValue();
                    break;
            }
        }

        dataDetails.add(new LabelValue("Message Type", messageType));
        dataDetails.add(new LabelValue("Le Id", leId));
        dataDetails.add(new LabelValue("Imeta Id", imetaID));

        if (sheet.getLastRowNum() == 0) {
            // ======= big title ========
            CellStyle bigTitleCellStyle = getPublicCellStyle(wb);
            Font bigTitleFont = wb.createFont();
            bigTitleFont.setFontHeightInPoints((short) 14);
            bigTitleFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
            bigTitleCellStyle.setFont(bigTitleFont);
            bigTitleCellStyle.setFillForegroundColor(HSSFColor.GREY_50_PERCENT.index);

            Row mergeRow = null;
            Cell mergeCell = null;
            mergeRow = sheet.createRow(mainTitleRowNum);
            // merge cell
            int firstCol = 0;
            int lastCol = firstCol + dataDetails.size() - 1;
            sheet.addMergedRegion(new CellRangeAddress(0, 0, firstCol,
                    lastCol));
            mergeCell = mergeRow.createCell(firstCol);
            mergeCell.setCellStyle(bigTitleCellStyle);
            mergeCell.setCellValue("Auditing RT Data");

            // =========== detail title row ==============
            Row titleRow = null;
            Cell titleCell = null;
            titleRow = sheet.createRow(subTitleRowNum);
            int titleColNum = 0;
            for (LabelValue lv : dataDetails) {
                titleCell = titleRow.createCell(titleColNum++);
                titleCell.setCellStyle(titleCellStyle);
                titleCell.setCellValue(lv.getLabel());
            }
        }

        // =========== content row ==============
        Row contentRow = sheet.createRow(contentRowNum++);
        Cell contentCell = null;
        int contentColNum = 0;
        for (LabelValue lv : dataDetails) {
            contentCell = contentRow.createCell(contentColNum++);
            if (contentRowNum % 2 == 0) {
                contentCell.setCellStyle(evenCellStyle);
            } else {
                contentCell.setCellStyle(oddCellStyle);
            }
            contentCell.setCellValue(lv.getValue());
        }

        return wb;
    }

    private static List<LabelValue> buildBreakClauseDetailsRow(Document scbmlDoc) {
        List<LabelValue> result = new ArrayList();
        Node earlyTerminationProvisionNode = getNodesByTagName(scbmlDoc,
                "earlyTerminationProvision", 0);
        String lv_PrimeBroker = "";
        List<Node> relatedParty = getNodesByTagName2(scbmlDoc, "relatedParty");
        for (int i = 0; i < relatedParty.size(); i++) {
            if (getNodeValue(getNodesByTagName(relatedParty.get(i), "role", 0))
                    .equals("PrimeBroker")) {
                lv_PrimeBroker = getAttrValue(
                        getNodesByTagName(relatedParty.get(i),
                                "partyReference", 0), "href");
            }
        }

        String breakClauseFirstDate = "";
        String breakClauseFrequency = "";
        String breakClauseOption = "";
        String breakClauseCalcAgent = "";

        Node optionalEarlyTerminationNode = getNodesByTagName(
                earlyTerminationProvisionNode, "optionalEarlyTermination", 0);
        Node mandatoryEarlyTerminationNode = getNodesByTagName(
                earlyTerminationProvisionNode, "mandatoryEarlyTermination", 0);
        if (optionalEarlyTerminationNode != null) {
            breakClauseFirstDate = getNodeValue(getNodesByTagName(
                    getNodesByTagName(
                            getNodesByTagName(optionalEarlyTerminationNode,
                                    "cashSettlementPaymentDate", 0),
                            "adjustableDates", 0), "unadjustedDate", 0));
        } else if (mandatoryEarlyTerminationNode != null) {
            breakClauseFirstDate = getNodeValue(getNodesByTagName(
                    getNodesByTagName(mandatoryEarlyTerminationNode,
                            "mandatoryEarlyTerminationDate", 0),
                    "unadjustedDate", 0));
        }

        String breakClauseFrequencyPeriodMultiplier = getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(earlyTerminationProvisionNode,
                                "optionalEarlyTerminationParameters", 0),
                        "exerciseFrequency", 0), "periodMultiplier", 0));
        String breakClauseFrequencyPeriod = getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(earlyTerminationProvisionNode,
                                "optionalEarlyTerminationParameters", 0),
                        "exerciseFrequency", 0), "period", 0));
        breakClauseFrequency = breakClauseFrequencyPeriodMultiplier
                + breakClauseFrequencyPeriod;

        if (mandatoryEarlyTerminationNode != null) {
            breakClauseOption = "Mandatory";
        } else if (optionalEarlyTerminationNode != null) {
            Node singlePartyOptionNode = getNodesByTagName(
                    optionalEarlyTerminationNode, "singlePartyOption", 0);
            if (singlePartyOptionNode == null) {
                breakClauseOption = "Optional - Mutual";
            } else {
                String buyerPartyReference = getAttrValue(
                        getNodesByTagName(singlePartyOptionNode,
                                "buyerPartyReference", 0), "href");
                if (buyerPartyReference.equals(lv_PrimeBroker)) {
                    breakClauseOption = "Optional - Unilateral My Opinion";
                } else {
                    breakClauseOption = "Optional - Unilateral Other Party Option";
                }
            }
        }
        breakClauseCalcAgent = getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(earlyTerminationProvisionNode,
                                "optionalEarlyTermination", 0),
                        "calculationAgent", 0), "calculationAgentParty", 0));

        result.add(new LabelValue("First Date", breakClauseFirstDate));
        result.add(new LabelValue("Frequency", breakClauseFrequency));
        result.add(new LabelValue("Option", breakClauseOption));
        result.add(new LabelValue("Calc Agent", breakClauseCalcAgent));
        return result;
    }

    private static List<LabelValue> buildSwaptionRow(Document scbmlDoc) {
        List<LabelValue> result = new ArrayList();

        String lv_capturesystem = getSingleNodeValue(scbmlDoc, "captureSystem");
        String lv_partyScheme = "http://www.sc.com/coding-schemes/eclipse1/"
                + lv_capturesystem + "-party-id";

        // SWAP DETAIL
        String lv_buyerReference_swapDetail = getAttrValue(
                getNodesByTagName(scbmlDoc, "buyerPartyReference", 0), "href");
        String lv_sellerReference_swapDetail = getAttrValue(
                getNodesByTagName(scbmlDoc, "sellerPartyReference", 0), "href");

        String BuyerPartyReference_swapDetail = "";
        String SellerPartyReference_swapDetail = "";
        List<Node> partys_swapDetail = getNodesByTagName2(scbmlDoc, "party");
        for (int i = 0; i < partys_swapDetail.size(); i++) {
            if (getAttrValue(partys_swapDetail.get(i), "id").equals(
                    lv_buyerReference_swapDetail)) {
                List<Node> nodes_inner = getNodesByTagName2(
                        partys_swapDetail.get(i), "partyId");
                for (int j = 0; j < nodes_inner.size(); j++) {
                    if (getAttrValue(nodes_inner.get(j), "partyIdScheme")
                            .equals(lv_partyScheme)) {
                        BuyerPartyReference_swapDetail = getNodeValue(nodes_inner
                                .get(j));
                    }
                }
            }
            if (getAttrValue(partys_swapDetail.get(i), "id").equals(
                    lv_sellerReference_swapDetail)) {
                List<Node> nodes_inner = getNodesByTagName2(
                        partys_swapDetail.get(i), "partyId");
                for (int j = 0; j < nodes_inner.size(); j++) {
                    if (getAttrValue(nodes_inner.get(j), "partyIdScheme")
                            .equals(lv_partyScheme)) {
                        SellerPartyReference_swapDetail = getNodeValue(nodes_inner
                                .get(j));
                    }
                }
            }
        }
        String OptionMaturityDate_swapDetail = getNodeValue(getNodesByTagName(
                getNodesByTagName(scbmlDoc, "adjustableDate", 0),
                "unadjustedDate", 0));
        String ExerciseType_swapDetail = "";
        if (!getNodeValue(getNodesByTagName(scbmlDoc, "cashSettlement", 0))
                .equals("")) {
            ExerciseType_swapDetail = "Cash";
        } else {
            ExerciseType_swapDetail = "Delivery";
        }
        String PremiumCurrency_swapDetail = getNodeValue(getNodesByTagName(
                getNodesByTagName(scbmlDoc, "premium", 0), "currency", 0));
        String PremiumAmount_swapDetail = getNodeValue(getNodesByTagName(
                getNodesByTagName(scbmlDoc, "premium", 0), "amount", 0));
        String PremiumPaymentDate_swapDetail = getNodeValue(getNodesByTagName(
                getNodesByTagName(scbmlDoc, "premium", 0), "unadjustedDate", 0));

        result.add(new LabelValue("BuyerParty Reference",
                BuyerPartyReference_swapDetail));
        result.add(new LabelValue("SellerParty Reference",
                SellerPartyReference_swapDetail));
        result.add(new LabelValue("Option Maturity Date",
                OptionMaturityDate_swapDetail));
        result.add(new LabelValue("Exercise Type", ExerciseType_swapDetail));
        result.add(new LabelValue("Premium Currency",
                PremiumCurrency_swapDetail));
        result.add(new LabelValue("Premium Amount", PremiumAmount_swapDetail));
        result.add(new LabelValue("Premium Payment Date",
                PremiumPaymentDate_swapDetail));

        // ----------Leg 1
        Node leg1Node = getNodesByTagName(scbmlDoc, "swapStream", 0);

        String PayerPartyReference_leg1 = "";
        String ReceiverPartyReference_leg1 = "";
        String lv_payerReference_leg1 = getAttrValue(
                getNodesByTagName(leg1Node, "payerPartyReference", 0), "href");
        String lv_receiverReference_leg1 = getAttrValue(
                getNodesByTagName(leg1Node, "receiverPartyReference", 0),
                "href");
        List<Node> partys_leg1 = getNodesByTagName2(scbmlDoc, "party");
        for (int i = 0; i < partys_leg1.size(); i++) {
            if (getAttrValue(partys_leg1.get(i), "id").equals(
                    lv_payerReference_leg1)) {
                List<Node> nodes_inner = getNodesByTagName2(partys_leg1.get(i),
                        "partyId");
                for (int j = 0; j < nodes_inner.size(); j++) {
                    if (getAttrValue(nodes_inner.get(j), "partyIdScheme")
                            .equals(lv_partyScheme)) {
                        PayerPartyReference_leg1 = getNodeValue(nodes_inner
                                .get(j));
                    }
                }
            }
            if (getAttrValue(partys_leg1.get(i), "id").equals(
                    lv_receiverReference_leg1)) {
                List<Node> nodes_inner = getNodesByTagName2(partys_leg1.get(i),
                        "partyId");
                for (int j = 0; j < nodes_inner.size(); j++) {
                    if (getAttrValue(nodes_inner.get(j), "partyIdScheme")
                            .equals(lv_partyScheme)) {
                        ReceiverPartyReference_leg1 = getNodeValue(nodes_inner
                                .get(j));
                    }
                }
            }
        }

        String LegType_leg1 = getAttrValue(leg1Node, "id");
        String EffectiveDate_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg1Node, "effectiveDate", 0),
                "unadjustedDate", 0));
        String Currency_leg1 = getNodeValue(getNodesByTagName(leg1Node,
                "currency", 0));
        String Nominal_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg1Node, "notionalSchedule", 0),
                "initialValue", 0));
        String TerminationDate_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg1Node, "terminationDate", 0),
                "unadjustedDate", 0));
        String Margin_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg1Node, "floatingRateCalculation", 0),
                "initialValue", 0));
        String DayCount_leg1 = getNodeValue(getNodesByTagName(leg1Node,
                "dayCountFraction", 0));
        String FixedRate_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg1Node, "fixedRateSchedule", 0),
                "initialValue", 0));
        String PaymentFrequency_1_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(leg1Node, "paymentDates", 0),
                        "paymentFrequency", 0), "periodMultiplier", 0));
        String PaymentFrequency_2_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(leg1Node, "paymentDates", 0),
                        "paymentFrequency", 0), "period", 0));
        String PaymentFrequency_leg1 = PaymentFrequency_1_leg1 + ""
                + PaymentFrequency_2_leg1;
        String PaymentDaysOffset_1_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(leg1Node, "paymentDates", 0),
                        "paymentDaysOffset", 0), "periodMultiplier", 0));
        String PaymentDaysOffset_2_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(leg1Node, "paymentDates", 0),
                        "paymentDaysOffset", 0), "period", 0));
        String PaymentDaysOffset_leg1 = PaymentDaysOffset_1_leg1
                + ", "
                + PaymentDaysOffset_2_leg1
                + ", "
                + getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(leg1Node, "paymentDates", 0),
                        "paymentDaysOffset", 0), "dayType", 0));
        ;
        String ResetFrequency_1_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(getNodesByTagName(leg1Node, "resetDates", 0),
                        "resetFrequency", 0), "periodMultiplier", 0));
        String ResetFrequency_2_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(getNodesByTagName(leg1Node, "resetDates", 0),
                        "resetFrequency", 0), "period", 0));
        String ResetFrequency_leg1 = ResetFrequency_1_leg1 + ""
                + ResetFrequency_2_leg1;
        String CompoundingFrequency_leg1 = "";
        String CompoundingStyle_leg1 = getNodeValue(getNodesByTagName(leg1Node,
                "compoundingMethod", 0));
        String FloatingRateIndex_leg1 = getNodeValue(getNodesByTagName(
                leg1Node, "floatingRateIndex", 0));
        String FloatingRateIndexMultiplier_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg1Node, "floatingRateCalculation", 0),
                "periodMultiplier", 0));
        String FloatingRateIndexPeriod_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg1Node, "floatingRateCalculation", 0),
                "period", 0));
        String NotionalStepDates_leg1 = getNodeValues(getNodesByTagName2(
                getNodesByTagName(leg1Node, "notionalStepSchedule", 0),
                "stepDate"));
        String NotionalSteps_leg1 = getNodeValues(getNodesByTagName2(
                getNodesByTagName(leg1Node, "notionalStepSchedule", 0),
                "stepValue"));

        String NotionalRateDate_leg1 = "", NotionalRateRate_leg1 = "";
        if (getNodesByTagName(leg1Node, "spreadSchedule", 0) != null) {
            NotionalRateDate_leg1 = getNodeValues(getNodesByTagName2(
                    getNodesByTagName(leg1Node, "spreadSchedule", 0),
                    "stepDate"));
            NotionalRateRate_leg1 = getNodeValues(getNodesByTagName2(
                    getNodesByTagName(leg1Node, "spreadSchedule", 0),
                    "stepValue"));
        } else if (getNodesByTagName(leg1Node, "fixedRateSchedule", 0) != null) {
            NotionalRateDate_leg1 = getNodeValues(getNodesByTagName2(
                    getNodesByTagName(leg1Node, "fixedRateSchedule", 0),
                    "stepDate"));
            NotionalRateRate_leg1 = getNodeValues(getNodesByTagName2(
                    getNodesByTagName(leg1Node, "fixedRateSchedule", 0),
                    "stepValue"));
        }
        String NotionalStepDates_view_leg1 = "";
        if (NotionalStepDates_leg1.equals("")) {
            NotionalStepDates_view_leg1 = NotionalRateDate_leg1;
        } else {
            NotionalStepDates_view_leg1 = NotionalStepDates_leg1;
        }

        // ---------- Leg2
        Node leg2Node = getNodesByTagName(scbmlDoc, "swapStream", 1);

        String PayerPartyReference_leg2 = "";
        String ReceiverPartyReference_leg2 = "";
        String lv_payerReference_leg2 = getAttrValue(
                getNodesByTagName(leg2Node, "payerPartyReference", 0), "href");
        String lv_receiverReference_leg2 = getAttrValue(
                getNodesByTagName(leg2Node, "receiverPartyReference", 0),
                "href");
        List<Node> partys_leg2 = getNodesByTagName2(scbmlDoc, "party");
        for (int i = 0; i < partys_leg2.size(); i++) {
            if (getAttrValue(partys_leg2.get(i), "id").equals(
                    lv_payerReference_leg2)) {
                List<Node> nodes_inner = getNodesByTagName2(partys_leg2.get(i),
                        "partyId");
                for (int j = 0; j < nodes_inner.size(); j++) {
                    if (getAttrValue(nodes_inner.get(j), "partyIdScheme")
                            .equals(lv_partyScheme)) {
                        PayerPartyReference_leg2 = getNodeValue(nodes_inner
                                .get(j));
                    }
                }
            }
            if (getAttrValue(partys_leg2.get(i), "id").equals(
                    lv_receiverReference_leg2)) {
                List<Node> nodes_inner = getNodesByTagName2(partys_leg2.get(i),
                        "partyId");
                for (int j = 0; j < nodes_inner.size(); j++) {
                    if (getAttrValue(nodes_inner.get(j), "partyIdScheme")
                            .equals(lv_partyScheme)) {
                        ReceiverPartyReference_leg2 = getNodeValue(nodes_inner
                                .get(j));
                    }
                }
            }
        }

        String LegType_leg2 = getAttrValue(leg2Node, "id");
        String EffectiveDate_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg2Node, "effectiveDate", 0),
                "unadjustedDate", 0));
        String Currency_leg2 = getNodeValue(getNodesByTagName(leg2Node,
                "currency", 0));
        String Nominal_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg2Node, "notionalSchedule", 0),
                "initialValue", 0));
        String TerminationDate_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg2Node, "terminationDate", 0),
                "unadjustedDate", 0));
        String Margin_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg2Node, "floatingRateCalculation", 0),
                "initialValue", 0));
        String DayCount_leg2 = getNodeValue(getNodesByTagName(leg2Node,
                "dayCountFraction", 0));
        String FixedRate_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg2Node, "fixedRateSchedule", 0),
                "initialValue", 0));
        String PaymentFrequency_1_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(leg2Node, "paymentDates", 0),
                        "paymentFrequency", 0), "periodMultiplier", 0));
        String PaymentFrequency_2_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(leg2Node, "paymentDates", 0),
                        "paymentFrequency", 0), "period", 0));
        String PaymentFrequency_leg2 = PaymentFrequency_1_leg2 + ""
                + PaymentFrequency_2_leg2;
        String PaymentDaysOffset_1_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(leg2Node, "paymentDates", 0),
                        "paymentDaysOffset", 0), "periodMultiplier", 0));
        String PaymentDaysOffset_2_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(leg2Node, "paymentDates", 0),
                        "paymentDaysOffset", 0), "period", 0));
        String PaymentDaysOffset_leg2 = PaymentDaysOffset_1_leg2
                + ", "
                + PaymentDaysOffset_2_leg2
                + ", "
                + getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(leg2Node, "paymentDates", 0),
                        "paymentDaysOffset", 0), "dayType", 0));
        ;
        String ResetFrequency_1_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(getNodesByTagName(leg2Node, "resetDates", 0),
                        "resetFrequency", 0), "periodMultiplier", 0));
        String ResetFrequency_2_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(getNodesByTagName(leg2Node, "resetDates", 0),
                        "resetFrequency", 0), "period", 0));
        String ResetFrequency_leg2 = ResetFrequency_1_leg2 + ""
                + ResetFrequency_2_leg2;
        String CompoundingFrequency_leg2 = "";
        String CompoundingStyle_leg2 = getNodeValue(getNodesByTagName(leg2Node,
                "compoundingMethod", 0));
        String FloatingRateIndex_leg2 = getNodeValue(getNodesByTagName(
                leg2Node, "floatingRateIndex", 0));
        String FloatingRateIndexMultiplier_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg2Node, "floatingRateCalculation", 0),
                "periodMultiplier", 0));
        String FloatingRateIndexPeriod_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg2Node, "floatingRateCalculation", 0),
                "period", 0));
        // String NotionalStepDates_leg2 =
        // getNodeValue(getNodesByTagName(leg2Node, "stepDate",0));
        // String NotionalSteps_leg2 = getNodeValue(getNodesByTagName(leg2Node,
        // "stepVate",0));

        String NotionalStepDates_leg2 = getNodeValues(getNodesByTagName2(
                getNodesByTagName(leg2Node, "notionalStepSchedule", 0),
                "stepDate"));
        String NotionalSteps_leg2 = getNodeValues(getNodesByTagName2(
                getNodesByTagName(leg2Node, "notionalStepSchedule", 0),
                "stepValue"));

        String NotionalRateDate_leg2 = "", NotionalRateRate_leg2 = "";
        if (getNodesByTagName(leg2Node, "spreadSchedule", 0) != null) {
            NotionalRateDate_leg2 = getNodeValues(getNodesByTagName2(
                    getNodesByTagName(leg2Node, "spreadSchedule", 0),
                    "stepDate"));
            NotionalRateRate_leg2 = getNodeValues(getNodesByTagName2(
                    getNodesByTagName(leg2Node, "spreadSchedule", 0),
                    "stepValue"));
        } else if (getNodesByTagName(leg2Node, "fixedRateSchedule", 0) != null) {
            NotionalRateDate_leg2 = getNodeValues(getNodesByTagName2(
                    getNodesByTagName(leg2Node, "fixedRateSchedule", 0),
                    "stepDate"));
            NotionalRateRate_leg2 = getNodeValues(getNodesByTagName2(
                    getNodesByTagName(leg2Node, "fixedRateSchedule", 0),
                    "stepValue"));
        }
        String NotionalStepDates_view_leg2 = "";
        if (NotionalStepDates_leg2.equals("")) {
            NotionalStepDates_view_leg2 = NotionalRateDate_leg2;
        } else {
            NotionalStepDates_view_leg2 = NotionalStepDates_leg2;
        }

        String rollConvention_leg1 = getNodeValue(getNodesByTagName(leg1Node,
                "rollConvention", 0));
        String rollConvention_leg2 = getNodeValue(getNodesByTagName(leg2Node,
                "rollConvention", 0));

        String calculationBDConvention_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg1Node,
                        "calculationPeriodDatesAdjustments", 0),
                "businessDayConvention", 0));
        String calculationBDConvention_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg2Node,
                        "calculationPeriodDatesAdjustments", 0),
                "businessDayConvention", 0));

        String calculationAdjCalendars_leg1 = getNodeValues(getNodesByTagName2(
                getNodesByTagName(leg1Node,
                        "calculationPeriodDatesAdjustments", 0),
                "businessCenter"));
        String calculationAdjCalendars_leg2 = getNodeValues(getNodesByTagName2(
                getNodesByTagName(leg2Node,
                        "calculationPeriodDatesAdjustments", 0),
                "businessCenter"));

        String paymentBDConvention_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg1Node, "paymentDatesAdjustments", 0),
                "businessDayConvention", 0));
        String paymentBDConvention_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg2Node, "paymentDatesAdjustments", 0),
                "businessDayConvention", 0));

        String paymentAdjCalendars_leg1 = getNodeValues(getNodesByTagName2(
                getNodesByTagName(leg1Node, "paymentDatesAdjustments", 0),
                "businessCenter"));
        String paymentAdjCalendars_leg2 = getNodeValues(getNodesByTagName2(
                getNodesByTagName(leg2Node, "paymentDatesAdjustments", 0),
                "businessCenter"));

        String resetBDConvention_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg1Node, "resetDatesAdjustments", 0),
                "businessDayConvention", 0));
        String resetBDConvention_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg2Node, "resetDatesAdjustments", 0),
                "businessDayConvention", 0));

        String resetAdjCalendars_leg1 = getNodeValues(getNodesByTagName2(
                getNodesByTagName(leg1Node, "resetDatesAdjustments", 0),
                "businessCenter"));
        String resetAdjCalendars_leg2 = getNodeValues(getNodesByTagName2(
                getNodesByTagName(leg2Node, "resetDatesAdjustments", 0),
                "businessCenter"));

        String TerminationBDConvention_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg1Node, "terminationDate", 0),
                "businessDayConvention", 0));
        String TerminationBDConvention_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg2Node, "terminationDate", 0),
                "businessDayConvention", 0));

        String TerminationAdjCalendars_leg1 = getNodeValues(getNodesByTagName2(
                getNodesByTagName(leg1Node, "terminationDate", 0),
                "businessCenter"));
        String TerminationAdjCalendars_leg2 = getNodeValues(getNodesByTagName2(
                getNodesByTagName(leg2Node, "terminationDate", 0),
                "businessCenter"));

        result.add(new LabelValue("Leg1_Payer Party Reference",
                PayerPartyReference_leg1));
        result.add(new LabelValue("Leg2_Payer Party Reference",
                PayerPartyReference_leg2));
        result.add(new LabelValue("Leg1_Receiver Party Reference",
                ReceiverPartyReference_leg1));
        result.add(new LabelValue("Leg2_Receiver Party Reference",
                ReceiverPartyReference_leg2));
        result.add(new LabelValue("Leg1_Leg Type (Fix/Float)", LegType_leg1));
        result.add(new LabelValue("Leg2_Leg Type (Fix/Float)", LegType_leg2));
        result.add(new LabelValue("Leg1_Effective Date", EffectiveDate_leg1));
        result.add(new LabelValue("Leg2_Effective Date", EffectiveDate_leg2));
        result.add(new LabelValue("Leg1_Notional Currency", Currency_leg1));
        result.add(new LabelValue("Leg2_Notional Currency", Currency_leg2));
        result.add(new LabelValue("Leg1_Notional Amount", Nominal_leg1));
        result.add(new LabelValue("Leg2_Notional Amount", Nominal_leg2));
        result.add(new LabelValue("Leg1_Termination Date", TerminationDate_leg1));
        result.add(new LabelValue("Leg2_Termination Date", TerminationDate_leg2));
        result.add(new LabelValue("Leg1_Margin", Margin_leg1));
        result.add(new LabelValue("Leg2_Margin", Margin_leg2));
        result.add(new LabelValue("Leg1_Day Count", DayCount_leg1));
        result.add(new LabelValue("Leg2_Day Count", DayCount_leg2));
        result.add(new LabelValue("Leg1_Fixed Rate", FixedRate_leg1));
        result.add(new LabelValue("Leg2_Fixed Rate", FixedRate_leg2));
        result.add(new LabelValue("Leg1_Payment Frequency",
                PaymentFrequency_leg1));
        result.add(new LabelValue("Leg2_Payment Frequency",
                PaymentFrequency_leg2));
        result.add(new LabelValue("Leg1_Reset Frequency", ResetFrequency_leg1));
        result.add(new LabelValue("Leg2_Reset Frequency", ResetFrequency_leg2));
        result.add(new LabelValue("Leg1_Compounding Frequency",
                CompoundingFrequency_leg1));
        result.add(new LabelValue("Leg2_Compounding Frequency",
                CompoundingFrequency_leg2));
        result.add(new LabelValue("Leg1_Compounding Style",
                CompoundingStyle_leg1));
        result.add(new LabelValue("Leg2_Compounding Style",
                CompoundingStyle_leg2));
        result.add(new LabelValue("Leg1_Floating Rate Index",
                FloatingRateIndex_leg1));
        result.add(new LabelValue("Leg2_Floating Rate Index",
                FloatingRateIndex_leg2));
        result.add(new LabelValue("Leg1_Floating Rate Index Multiplier",
                FloatingRateIndexMultiplier_leg1));
        result.add(new LabelValue("Leg2_Floating Rate Index Multiplier",
                FloatingRateIndexMultiplier_leg2));
        result.add(new LabelValue("Leg1_Floating Rate Index Period",
                FloatingRateIndexPeriod_leg1));
        result.add(new LabelValue("Leg2_Floating Rate Index Period",
                FloatingRateIndexPeriod_leg2));
        result.add(new LabelValue("Leg1_Notional Step Dates",
                NotionalStepDates_view_leg1));
        result.add(new LabelValue("Leg2_Notional Step Dates",
                NotionalStepDates_view_leg2));
        result.add(new LabelValue("Leg1_Notional Steps", NotionalSteps_leg1));
        result.add(new LabelValue("Leg2_Notional Steps", NotionalSteps_leg2));
        result.add(new LabelValue("Leg1_Notional Step Rates",
                NotionalRateRate_leg1));
        result.add(new LabelValue("Leg2_Notional Step Rates",
                NotionalRateRate_leg2));
        result.add(new LabelValue("Leg1_Roll Convention", rollConvention_leg1));
        result.add(new LabelValue("Leg2_Roll Convention", rollConvention_leg2));
        result.add(new LabelValue("Leg1_CalculationBDConvention",
                calculationBDConvention_leg1));
        result.add(new LabelValue("Leg2_CalculationBDConvention",
                calculationBDConvention_leg2));
        result.add(new LabelValue("Leg1_CalculationAdjCalendars",
                calculationAdjCalendars_leg1));
        result.add(new LabelValue("Leg2_CalculationAdjCalendars",
                calculationAdjCalendars_leg2));
        result.add(new LabelValue("Leg1_PaymentBDConvention",
                paymentBDConvention_leg1));
        result.add(new LabelValue("Leg2_PaymentBDConvention",
                paymentBDConvention_leg2));
        result.add(new LabelValue("Leg1_Payment Lag Days",
                PaymentDaysOffset_leg1));
        result.add(new LabelValue("Leg2_Payment Lag Days",
                PaymentDaysOffset_leg2));
        result.add(new LabelValue("Leg1_PaymentAdjCalendars",
                paymentAdjCalendars_leg1));
        result.add(new LabelValue("Leg2_PaymentAdjCalendars",
                paymentAdjCalendars_leg2));
        result.add(new LabelValue("Leg1_ResetBDConvention",
                resetBDConvention_leg1));
        result.add(new LabelValue("Leg2_ResetBDConvention",
                resetBDConvention_leg2));
        result.add(new LabelValue("Leg1_ResetAdjCalendars",
                resetAdjCalendars_leg1));
        result.add(new LabelValue("Leg2_ResetAdjCalendars",
                resetAdjCalendars_leg2));
        result.add(new LabelValue("Leg1_TerminationBDConvention",
                TerminationBDConvention_leg1));
        result.add(new LabelValue("Leg2_TerminationBDConvention",
                TerminationBDConvention_leg2));
        result.add(new LabelValue("Leg1_TerminationAdjCalendars",
                TerminationAdjCalendars_leg1));
        result.add(new LabelValue("Leg2_TerminationAdjCalendars",
                TerminationAdjCalendars_leg2));

        Node initialFixingDate_leg1 = getNodesByTagName(
                getNodesByTagName(scbmlDoc, "swapStream", 0),
                "initialFixingDate", 0);
        Node initialFixingDate_leg2 = getNodesByTagName(
                getNodesByTagName(scbmlDoc, "swapStream", 1),
                "initialFixingDate", 0);
        Node fixingDates_leg1 = getNodesByTagName(
                getNodesByTagName(scbmlDoc, "swapStream", 0), "fixingDates", 0);
        Node fixingDates_leg2 = getNodesByTagName(
                getNodesByTagName(scbmlDoc, "swapStream", 1), "fixingDates", 0);

        String i_offset_leg1 = getNodeValue(getNodesByTagName(
                initialFixingDate_leg1, "periodMultiplier", 0))
                + ", "
                + getNodeValue(getNodesByTagName(initialFixingDate_leg1,
                "period", 0))
                + ", "
                + getNodeValue(getNodesByTagName(initialFixingDate_leg1,
                "dayType", 0));
        String i_offset_leg2 = getNodeValue(getNodesByTagName(
                initialFixingDate_leg2, "periodMultiplier", 0))
                + ", "
                + getNodeValue(getNodesByTagName(initialFixingDate_leg2,
                "period", 0))
                + ", "
                + getNodeValue(getNodesByTagName(initialFixingDate_leg2,
                "dayType", 0));
        String i_businessDayConvention_leg1 = getNodeValue(getNodesByTagName(
                initialFixingDate_leg1, "businessDayConvention", 0));
        String i_businessDayConvention_leg2 = getNodeValue(getNodesByTagName(
                initialFixingDate_leg2, "businessDayConvention", 0));
        String i_calendars_leg1 = getNodeValues(getNodesByTagName2(
                initialFixingDate_leg1, "businessCenter"));
        String i_calendars_leg2 = getNodeValues(getNodesByTagName2(
                initialFixingDate_leg2, "businessCenter"));

        String f_offset_leg1 = getNodeValue(getNodesByTagName(fixingDates_leg1,
                "periodMultiplier", 0))
                + ", "
                + getNodeValue(getNodesByTagName(fixingDates_leg1, "period", 0))
                + ", "
                + getNodeValue(getNodesByTagName(fixingDates_leg1, "dayType", 0));
        String f_offset_leg2 = getNodeValue(getNodesByTagName(fixingDates_leg2,
                "periodMultiplier", 0))
                + ", "
                + getNodeValue(getNodesByTagName(fixingDates_leg2, "period", 0))
                + ", "
                + getNodeValue(getNodesByTagName(fixingDates_leg2, "dayType", 0));
        String f_businessDayConvention_leg1 = getNodeValue(getNodesByTagName(
                fixingDates_leg1, "businessDayConvention", 0));
        String f_businessDayConvention_leg2 = getNodeValue(getNodesByTagName(
                fixingDates_leg2, "businessDayConvention", 0));
        String f_calendars_leg1 = getNodeValues(getNodesByTagName2(
                fixingDates_leg1, "businessCenter"));
        String f_calendars_leg2 = getNodeValues(getNodesByTagName2(
                fixingDates_leg2, "businessCenter"));

        result.add(new LabelValue("Leg1_FixingDates Offset", f_offset_leg1));
        result.add(new LabelValue("Leg2_FixingDates Offset", f_offset_leg2));
        result.add(new LabelValue("Leg1_FixingDates BusinessDayConvention",
                f_businessDayConvention_leg1));
        result.add(new LabelValue("Leg2_FixingDates BusinessDayConvention",
                f_businessDayConvention_leg2));
        result.add(new LabelValue("Leg1_FixingDates Calendars",
                f_calendars_leg1));
        result.add(new LabelValue("Leg2_FixingDates Calendars",
                f_calendars_leg2));
        result.add(new LabelValue("Leg1_1st FixingDate Rule Offset",
                i_offset_leg1));
        result.add(new LabelValue("Leg2_1st FixingDate Rule Offset",
                i_offset_leg2));
        result.add(new LabelValue(
                "Leg1_1st FixingDate Rule BusinessDayConvention",
                i_businessDayConvention_leg1));
        result.add(new LabelValue(
                "Leg2_1st FixingDate Rule BusinessDayConvention",
                i_businessDayConvention_leg2));
        result.add(new LabelValue("Leg1_1st FixingDate Rule Calendars",
                i_calendars_leg1));
        result.add(new LabelValue("Leg2_1st FixingDate Rule Calendars",
                i_calendars_leg2));

        // confirm if it is needed to show
        String id = getSingleNodeValue(scbmlDoc, "id");
        boolean isShow = id.equals("InterestRate:Option:Swaption");
        if (!isShow) {
            for (LabelValue lv : result) {
                lv.setValue("");
            }
        }
        return result;
    }

    private static List<LabelValue> buildCapFloorRow(Document scbmlDoc) {
        List<LabelValue> result = new ArrayList();
        String lv_capturesystem = getSingleNodeValue(scbmlDoc, "captureSystem");
        String lv_partyScheme = "http://www.sc.com/coding-schemes/eclipse1/"
                + lv_capturesystem + "-party-id";

        // ------ details
        String PayerPartyRefernece = "";
        String ReceiverPartyReference = "";
        String lv_payerReference = getAttrValue(
                getNodesByTagName(scbmlDoc, "payerPartyReference", 0), "href");
        String lv_receiverReference = getAttrValue(
                getNodesByTagName(scbmlDoc, "receiverPartyReference", 0),
                "href");
        List<Node> partys = getNodesByTagName2(scbmlDoc, "party");
        for (int i = 0; i < partys.size(); i++) {
            if (getAttrValue(partys.get(i), "id").equals(lv_payerReference)) {
                List<Node> nodes_inner = getNodesByTagName2(partys.get(i),
                        "partyId");
                for (int j = 0; j < nodes_inner.size(); j++) {
                    if (getAttrValue(nodes_inner.get(j), "partyIdScheme")
                            .equals(lv_partyScheme)) {
                        PayerPartyRefernece = getNodeValue(nodes_inner.get(j));
                    }
                }
            }
            if (getAttrValue(partys.get(i), "id").equals(lv_receiverReference)) {
                List<Node> nodes_inner = getNodesByTagName2(partys.get(i),
                        "partyId");
                for (int j = 0; j < nodes_inner.size(); j++) {
                    if (getAttrValue(nodes_inner.get(j), "partyIdScheme")
                            .equals(lv_partyScheme)) {
                        ReceiverPartyReference = getNodeValue(nodes_inner
                                .get(j));
                    }
                }
            }
        }

        String BuyerPartyReference = "";
        if (getNodeValue(getNodesByTagName(scbmlDoc, "buyer", 0)).equals(
                "Payer")) {
            BuyerPartyReference = PayerPartyRefernece;
        } else {
            BuyerPartyReference = ReceiverPartyReference;
        }

        String SellerPartyReference = "";
        if (getNodeValue(getNodesByTagName(scbmlDoc, "seller", 0)).equals(
                "Payer")) {
            SellerPartyReference = PayerPartyRefernece;
        } else {
            SellerPartyReference = ReceiverPartyReference;
        }

        Node capFloorNode = getNodesByTagName(scbmlDoc, "capFloorStream", 0);
        String EffectiveDate = getNodeValue(getNodesByTagName(
                getNodesByTagName(capFloorNode, "effectiveDate", 0),
                "unadjustedDate", 0));
        String Currency = getNodeValue(getNodesByTagName(capFloorNode,
                "currency", 0));
        String Nominal = getNodeValue(getNodesByTagName(
                getNodesByTagName(capFloorNode, "notionalSchedule", 0),
                "initialValue", 0));
        String TerminationDate = getNodeValue(getNodesByTagName(
                getNodesByTagName(capFloorNode, "terminationDate", 0),
                "unadjustedDate", 0));
        String CapFloorType = "";
        if (!getNodeValue(
                getNodesByTagName(capFloorNode, "floorRateSchedule", 0))
                .equals("")) {
            CapFloorType = "Floor";
        } else {
            CapFloorType = "Cap";
        }
        String Strike = "";
        String Strike_tmp = getNodeValue(getNodesByTagName(
                getNodesByTagName(capFloorNode, "floorRateSchedule", 0),
                "initialValue", 0));
        if (!Strike_tmp.equals("")) {
            Strike = Strike_tmp;
        } else {
            Strike = getNodeValue(getNodesByTagName(
                    getNodesByTagName(capFloorNode, "capRateSchedule", 0),
                    "initialValue", 0));
        }

        String PaymentFrequency_1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(capFloorNode, "paymentDates", 0),
                        "paymentFrequency", 0), "periodMultiplier", 0));
        String PaymentFrequency_2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(capFloorNode, "paymentDates", 0),
                        "paymentFrequency", 0), "period", 0));
        String PaymentFrequency = PaymentFrequency_1 + "" + PaymentFrequency_2;
        String PaymentDaysOffset_1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(capFloorNode, "paymentDates", 0),
                        "paymentDaysOffset", 0), "periodMultiplier", 0));
        String PaymentDaysOffset_2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(capFloorNode, "paymentDates", 0),
                        "paymentDaysOffset", 0), "period", 0));
        String PaymentDaysOffset = PaymentDaysOffset_1
                + ", "
                + PaymentDaysOffset_2
                + ", "
                + getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(capFloorNode, "paymentDates",
                                0), "paymentDaysOffset", 0), "dayType",
                0));
        String ResetFrequency_1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(capFloorNode, "resetDates", 0),
                        "resetFrequency", 0), "periodMultiplier", 0));
        String ResetFrequency_2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(capFloorNode, "resetDates", 0),
                        "resetFrequency", 0), "period", 0));
        String ResetFrequency = ResetFrequency_1 + "" + ResetFrequency_2;
        String FloatingRateIndex = getNodeValue(getNodesByTagName(capFloorNode,
                "floatingRateIndex", 0));
        String FloatingRateIndexMultiplier = getNodeValue(getNodesByTagName(
                capFloorNode, "periodMultiplier", 0));
        String FloatingRateIndexPeriod = getNodeValue(getNodesByTagName(
                capFloorNode, "period", 0));
        String Spread = getNodeValue(getNodesByTagName(
                getNodesByTagName(capFloorNode, "spreadSchedule", 0),
                "initialValue", 0));
        String DayCount = getNodeValue(getNodesByTagName(capFloorNode,
                "dayCountFraction", 0));

        String PremiumCurrency = getNodeValue(getNodesByTagName(
                getNodesByTagName(scbmlDoc, "premium", 0), "currency", 0));
        String PremiumAmount = getNodeValue(getNodesByTagName(
                getNodesByTagName(scbmlDoc, "premium", 0), "amount", 0));
        String PremiumPaymentDate = getNodeValue(getNodesByTagName(
                getNodesByTagName(scbmlDoc, "premium", 0), "unadjustedDate", 0));

        result.add(new LabelValue("BuyerPartyReference", BuyerPartyReference));
        result.add(new LabelValue("SellerPartyReference", SellerPartyReference));
        result.add(new LabelValue("PayerPartyRefernece", PayerPartyRefernece));
        result.add(new LabelValue("ReceiverPartyReference",
                ReceiverPartyReference));
        result.add(new LabelValue("Effective Date", EffectiveDate));
        result.add(new LabelValue("Notional Currency", Currency));
        result.add(new LabelValue("Notional Amount", Nominal));
        result.add(new LabelValue("Termination Date", TerminationDate));
        result.add(new LabelValue("CapFloorType", CapFloorType));
        result.add(new LabelValue("Strike", Strike));
        result.add(new LabelValue("Payment Frequency", PaymentFrequency));
        result.add(new LabelValue("Payment Lag Days", PaymentDaysOffset));
        result.add(new LabelValue("Reset Frequency", ResetFrequency));
        result.add(new LabelValue("Floating Rate Index", FloatingRateIndex));
        result.add(new LabelValue("Floating Rate Period Multipler",
                FloatingRateIndexMultiplier));
        result.add(new LabelValue("Floating Rate Period",
                FloatingRateIndexPeriod));
        result.add(new LabelValue("Spread", Spread));
        result.add(new LabelValue("Day Count", DayCount));
        result.add(new LabelValue("Premium Currency", PremiumCurrency));
        result.add(new LabelValue("Premium Amount", PremiumAmount));
        result.add(new LabelValue("Premium Payment Date", PremiumPaymentDate));

        // confirm if it is needed to show
        String id = getSingleNodeValue(scbmlDoc, "id");
        boolean isShow = id.equals("InterestRate:CapFloor");
        if (!isShow) {
            for (LabelValue lv : result) {
                lv.setValue("");
            }
        }
        return result;
    }

    private static List<LabelValue> buildFRARow(Document scbmlDoc) {
        List<LabelValue> result = new ArrayList();

        String lv_capturesystem = getSingleNodeValue(scbmlDoc, "captureSystem");
        String lv_partyScheme = "http://www.sc.com/coding-schemes/eclipse1/"
                + lv_capturesystem + "-party-id";

        // ------ details
        String lv_buyerReference = getAttrValue(
                getNodesByTagName(scbmlDoc, "buyerPartyReference", 0), "href");
        String lv_sellerReference = getAttrValue(
                getNodesByTagName(scbmlDoc, "sellerPartyReference", 0), "href");
        String BuyerPartyReference = "";
        String SellerPartyReference = "";
        List<Node> partys = getNodesByTagName2(scbmlDoc, "party");
        for (int i = 0; i < partys.size(); i++) {
            if (getAttrValue(partys.get(i), "id").equals(lv_buyerReference)) {
                List<Node> nodes_inner = getNodesByTagName2(partys.get(i),
                        "partyId");
                for (int j = 0; j < nodes_inner.size(); j++) {
                    if (getAttrValue(nodes_inner.get(j), "partyIdScheme")
                            .equals(lv_partyScheme)) {
                        BuyerPartyReference = getNodeValue(nodes_inner.get(j));
                    }
                }
            }
            if (getAttrValue(partys.get(i), "id").equals(lv_sellerReference)) {
                List<Node> nodes_inner = getNodesByTagName2(partys.get(i),
                        "partyId");
                for (int j = 0; j < nodes_inner.size(); j++) {
                    if (getAttrValue(nodes_inner.get(j), "partyIdScheme")
                            .equals(lv_partyScheme)) {
                        SellerPartyReference = getNodeValue(nodes_inner.get(j));
                    }
                }
            }
        }

        Node fraNode = getNodesByTagName(scbmlDoc, "fra", 0);
        String EffectiveDate = getNodeValue(getNodesByTagName(fraNode,
                "adjustedEffectiveDate", 0));
        String Currency = getNodeValue(getNodesByTagName(fraNode, "currency", 0));
        String Nominal = getNodeValue(getNodesByTagName(fraNode, "amount", 0));
        String TerminationDate = getNodeValue(getNodesByTagName(fraNode,
                "adjustedTerminationDate", 0));
        String PaymentDate = getNodeValue(getNodesByTagName(
                getNodesByTagName(fraNode, "paymentDate", 0), "unadjustedDate",
                0));
        String DayCount = getNodeValue(getNodesByTagName(fraNode,
                "dayCountFraction", 0));
        String CalculationNumberOfDays = getNodeValue(getNodesByTagName(
                fraNode, "calculationPeriodNumberOfDays", 0));
        String FixedRate = getNodeValue(getNodesByTagName(fraNode, "fixedRate",
                0));
        String FloatingRateIndex = getNodeValue(getNodesByTagName(fraNode,
                "floatingRateIndex", 0));
        String FloatingRateIndexMultiplier = getNodeValue(getNodesByTagName(
                getNodesByTagName(fraNode, "indexTenor", 0),
                "periodMultiplier", 0));
        String FloatingRateIndexPeriod = getNodeValue(getNodesByTagName(
                getNodesByTagName(fraNode, "indexTenor", 0), "period", 0));
        String FRADiscountingType = getNodeValue(getNodesByTagName(fraNode,
                "fraDiscounting", 0));
        String paymentDateConvention = getNodeValue(getNodesByTagName(
                getNodesByTagName(fraNode, "paymentDate", 0),
                "businessDayConvention", 0));
        String paymentDateCentres = getNodeValues(getNodesByTagName2(
                getNodesByTagName(fraNode, "paymentDate", 0), "businessCenter"));
        Node fixingDate_node = getNodesByTagName(fraNode, "fixingDateOffset", 0);
        String fixingDate_offset = getNodeValue(getNodesByTagName(
                fixingDate_node, "periodMultiplier", 0))
                + ", "
                + getNodeValue(getNodesByTagName(fixingDate_node, "period", 0))
                + ", "
                + getNodeValue(getNodesByTagName(fixingDate_node, "dayType", 0));
        String fixingDate_convention = getNodeValue(getNodesByTagName(
                fixingDate_node, "businessDayConvention", 0));
        String fixingDate_centers = getNodeValues(getNodesByTagName2(
                fixingDate_node, "businessCenter"));

        result.add(new LabelValue("Buyer Party Reference", BuyerPartyReference));
        result.add(new LabelValue("Seller Party Reference",
                SellerPartyReference));
        result.add(new LabelValue("Effective Date", EffectiveDate));
        result.add(new LabelValue("Notional Currency", Currency));
        result.add(new LabelValue("Notional Amount", Nominal));
        result.add(new LabelValue("Termination Date", TerminationDate));
        result.add(new LabelValue("Payment Date", PaymentDate));
        result.add(new LabelValue("Day Count", DayCount));
        result.add(new LabelValue("CalculationNumberOfDays",
                CalculationNumberOfDays));
        result.add(new LabelValue("Fixed Rate", FixedRate));
        result.add(new LabelValue("Fixing Date Offset", fixingDate_offset));
        result.add(new LabelValue("Fixing Date Convention",
                fixingDate_convention));
        result.add(new LabelValue("Fixing Date Centres", fixingDate_centers));
        result.add(new LabelValue("Floating Rate Index", FloatingRateIndex));
        result.add(new LabelValue("Floating Rate Index Multiplier",
                FloatingRateIndexMultiplier));
        result.add(new LabelValue("Floating Rate Index Period",
                FloatingRateIndexPeriod));
        result.add(new LabelValue("FRA Discounting Type", FRADiscountingType));
        result.add(new LabelValue("Payment Date Holidays Convention",
                paymentDateConvention));
        result.add(new LabelValue("Payment Date Holidays Centres",
                paymentDateCentres));

        // confirm if it is needed to show
        String id = getSingleNodeValue(scbmlDoc, "id");
        boolean isShow = id.equals("InterestRate:FRA");
        if (!isShow) {
            for (LabelValue lv : result) {
                lv.setValue("");
            }
        }
        return result;
    }

    private static List<LabelValue> buildIRSwapRow(Document scbmlDoc) {
        List<LabelValue> result = new ArrayList();
        String lv_capturesystem = getSingleNodeValue(scbmlDoc, "captureSystem");
        String lv_partyScheme = "http://www.sc.com/coding-schemes/eclipse1/"
                + lv_capturesystem + "-party-id";

        // ----------Leg 1
        Node leg1Node = getNodesByTagName(scbmlDoc, "swapStream", 0);

        String PayerPartyReference_leg1 = "";
        String ReceiverPartyReference_leg1 = "";
        String lv_payerReference_leg1 = getAttrValue(
                getNodesByTagName(leg1Node, "payerPartyReference", 0), "href");
        String lv_receiverReference_leg1 = getAttrValue(
                getNodesByTagName(leg1Node, "receiverPartyReference", 0),
                "href");
        List<Node> partys_leg1 = getNodesByTagName2(scbmlDoc, "party");
        for (int i = 0; i < partys_leg1.size(); i++) {
            if (getAttrValue(partys_leg1.get(i), "id").equals(
                    lv_payerReference_leg1)) {
                List<Node> nodes_inner = getNodesByTagName2(partys_leg1.get(i),
                        "partyId");
                for (int j = 0; j < nodes_inner.size(); j++) {
                    if (getAttrValue(nodes_inner.get(j), "partyIdScheme")
                            .equals(lv_partyScheme)) {
                        PayerPartyReference_leg1 = getNodeValue(nodes_inner
                                .get(j));
                    }
                }
            }
            if (getAttrValue(partys_leg1.get(i), "id").equals(
                    lv_receiverReference_leg1)) {
                List<Node> nodes_inner = getNodesByTagName2(partys_leg1.get(i),
                        "partyId");
                for (int j = 0; j < nodes_inner.size(); j++) {
                    if (getAttrValue(nodes_inner.get(j), "partyIdScheme")
                            .equals(lv_partyScheme)) {
                        ReceiverPartyReference_leg1 = getNodeValue(nodes_inner
                                .get(j));
                    }
                }
            }
        }

        String LegType_leg1 = getAttrValue(leg1Node, "id");
        String EffectiveDate_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg1Node, "effectiveDate", 0),
                "unadjustedDate", 0));
        String Currency_leg1 = getNodeValue(getNodesByTagName(leg1Node,
                "currency", 0));
        String Nominal_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg1Node, "notionalSchedule", 0),
                "initialValue", 0));
        String TerminationDate_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg1Node, "terminationDate", 0),
                "unadjustedDate", 0));
        String Margin_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg1Node, "floatingRateCalculation", 0),
                "initialValue", 0));
        String DayCount_leg1 = getNodeValue(getNodesByTagName(leg1Node,
                "dayCountFraction", 0));
        String FixedRate_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg1Node, "fixedRateSchedule", 0),
                "initialValue", 0));
        String PaymentFrequency_1_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(leg1Node, "paymentDates", 0),
                        "paymentFrequency", 0), "periodMultiplier", 0));
        String PaymentFrequency_2_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(leg1Node, "paymentDates", 0),
                        "paymentFrequency", 0), "period", 0));
        String PaymentFrequency_leg1 = PaymentFrequency_1_leg1 + ""
                + PaymentFrequency_2_leg1;
        String PaymentDaysOffset_1_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(leg1Node, "paymentDates", 0),
                        "paymentDaysOffset", 0), "periodMultiplier", 0));
        String PaymentDaysOffset_2_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(leg1Node, "paymentDates", 0),
                        "paymentDaysOffset", 0), "period", 0));
        String PaymentDaysOffset_leg1 = PaymentDaysOffset_1_leg1
                + ", "
                + PaymentDaysOffset_2_leg1
                + ", "
                + getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(leg1Node, "paymentDates", 0),
                        "paymentDaysOffset", 0), "dayType", 0));
        ;
        String ResetFrequency_1_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(getNodesByTagName(leg1Node, "resetDates", 0),
                        "resetFrequency", 0), "periodMultiplier", 0));
        String ResetFrequency_2_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(getNodesByTagName(leg1Node, "resetDates", 0),
                        "resetFrequency", 0), "period", 0));
        String ResetFrequency_leg1 = ResetFrequency_1_leg1 + ""
                + ResetFrequency_2_leg1;
        String CompoundingFrequency_leg1 = "";
        String CompoundingStyle_leg1 = getNodeValue(getNodesByTagName(leg1Node,
                "compoundingMethod", 0));
        String FloatingRateIndex_leg1 = getNodeValue(getNodesByTagName(
                leg1Node, "floatingRateIndex", 0));
        String FloatingRateIndexMultiplier_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg1Node, "floatingRateCalculation", 0),
                "periodMultiplier", 0));
        String FloatingRateIndexPeriod_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg1Node, "floatingRateCalculation", 0),
                "period", 0));
        String NotionalStepDates_leg1 = getNodeValues(getNodesByTagName2(
                getNodesByTagName(leg1Node, "notionalStepSchedule", 0),
                "stepDate"));
        String NotionalSteps_leg1 = getNodeValues(getNodesByTagName2(
                getNodesByTagName(leg1Node, "notionalStepSchedule", 0),
                "stepValue"));

        String NotionalRateDate_leg1 = "", NotionalRateRate_leg1 = "";
        if (getNodesByTagName(leg1Node, "spreadSchedule", 0) != null) {
            NotionalRateDate_leg1 = getNodeValues(getNodesByTagName2(
                    getNodesByTagName(leg1Node, "spreadSchedule", 0),
                    "stepDate"));
            NotionalRateRate_leg1 = getNodeValues(getNodesByTagName2(
                    getNodesByTagName(leg1Node, "spreadSchedule", 0),
                    "stepValue"));
        } else if (getNodesByTagName(leg1Node, "fixedRateSchedule", 0) != null) {
            NotionalRateDate_leg1 = getNodeValues(getNodesByTagName2(
                    getNodesByTagName(leg1Node, "fixedRateSchedule", 0),
                    "stepDate"));
            NotionalRateRate_leg1 = getNodeValues(getNodesByTagName2(
                    getNodesByTagName(leg1Node, "fixedRateSchedule", 0),
                    "stepValue"));
        }
        String NotionalStepDates_view_leg1 = "";
        if (NotionalStepDates_leg1.equals("")) {
            NotionalStepDates_view_leg1 = NotionalRateDate_leg1;
        } else {
            NotionalStepDates_view_leg1 = NotionalStepDates_leg1;
        }

        String rollConvention_leg1 = getNodeValue(getNodesByTagName(leg1Node,
                "rollConvention", 0));
        String calculationBDConvention_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg1Node,
                        "calculationPeriodDatesAdjustments", 0),
                "businessDayConvention", 0));
        String calculationAdjCalendars_leg1 = getNodeValues(getNodesByTagName2(
                getNodesByTagName(leg1Node,
                        "calculationPeriodDatesAdjustments", 0),
                "businessCenter"));

        String paymentBDConvention_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg1Node, "paymentDatesAdjustments", 0),
                "businessDayConvention", 0));
        String paymentAdjCalendars_leg1 = getNodeValues(getNodesByTagName2(
                getNodesByTagName(leg1Node, "paymentDatesAdjustments", 0),
                "businessCenter"));

        String resetBDConvention_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg1Node, "resetDatesAdjustments", 0),
                "businessDayConvention", 0));
        String resetAdjCalendars_leg1 = getNodeValues(getNodesByTagName2(
                getNodesByTagName(leg1Node, "resetDatesAdjustments", 0),
                "businessCenter"));

        String TerminationBDConvention_leg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg1Node, "terminationDate", 0),
                "businessDayConvention", 0));
        String TerminationAdjCalendars_leg1 = getNodeValues(getNodesByTagName2(
                getNodesByTagName(leg1Node, "terminationDate", 0),
                "businessCenter"));

        // ---------- Leg2
        Node leg2Node = getNodesByTagName(scbmlDoc, "swapStream", 1);

        String PayerPartyReference_leg2 = "";
        String ReceiverPartyReference_leg2 = "";
        String lv_payerReference_leg2 = getAttrValue(
                getNodesByTagName(leg2Node, "payerPartyReference", 0), "href");
        String lv_receiverReference_leg2 = getAttrValue(
                getNodesByTagName(leg2Node, "receiverPartyReference", 0),
                "href");
        List<Node> partys_leg2 = getNodesByTagName2(scbmlDoc, "party");
        for (int i = 0; i < partys_leg2.size(); i++) {
            if (getAttrValue(partys_leg2.get(i), "id").equals(
                    lv_payerReference_leg2)) {
                List<Node> nodes_inner = getNodesByTagName2(partys_leg2.get(i),
                        "partyId");
                for (int j = 0; j < nodes_inner.size(); j++) {
                    if (getAttrValue(nodes_inner.get(j), "partyIdScheme")
                            .equals(lv_partyScheme)) {
                        PayerPartyReference_leg2 = getNodeValue(nodes_inner
                                .get(j));
                    }
                }
            }
            if (getAttrValue(partys_leg2.get(i), "id").equals(
                    lv_receiverReference_leg2)) {
                List<Node> nodes_inner = getNodesByTagName2(partys_leg2.get(i),
                        "partyId");
                for (int j = 0; j < nodes_inner.size(); j++) {
                    if (getAttrValue(nodes_inner.get(j), "partyIdScheme")
                            .equals(lv_partyScheme)) {
                        ReceiverPartyReference_leg2 = getNodeValue(nodes_inner
                                .get(j));
                    }
                }
            }
        }

        String LegType_leg2 = getAttrValue(leg2Node, "id");
        String EffectiveDate_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg2Node, "effectiveDate", 0),
                "unadjustedDate", 0));
        String Currency_leg2 = getNodeValue(getNodesByTagName(leg2Node,
                "currency", 0));
        String Nominal_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg2Node, "notionalSchedule", 0),
                "initialValue", 0));
        String TerminationDate_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg2Node, "terminationDate", 0),
                "unadjustedDate", 0));
        String Margin_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg2Node, "floatingRateCalculation", 0),
                "initialValue", 0));
        String DayCount_leg2 = getNodeValue(getNodesByTagName(leg2Node,
                "dayCountFraction", 0));
        String FixedRate_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg2Node, "fixedRateSchedule", 0),
                "initialValue", 0));
        String PaymentFrequency_1_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(leg2Node, "paymentDates", 0),
                        "paymentFrequency", 0), "periodMultiplier", 0));
        String PaymentFrequency_2_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(leg2Node, "paymentDates", 0),
                        "paymentFrequency", 0), "period", 0));
        String PaymentFrequency_leg2 = PaymentFrequency_1_leg2 + ""
                + PaymentFrequency_2_leg2;
        String PaymentDaysOffset_1_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(leg2Node, "paymentDates", 0),
                        "paymentDaysOffset", 0), "periodMultiplier", 0));
        String PaymentDaysOffset_2_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(leg2Node, "paymentDates", 0),
                        "paymentDaysOffset", 0), "period", 0));
        String PaymentDaysOffset_leg2 = PaymentDaysOffset_1_leg2
                + ", "
                + PaymentDaysOffset_2_leg2
                + ", "
                + getNodeValue(getNodesByTagName(
                getNodesByTagName(
                        getNodesByTagName(leg2Node, "paymentDates", 0),
                        "paymentDaysOffset", 0), "dayType", 0));
        ;
        String ResetFrequency_1_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(getNodesByTagName(leg2Node, "resetDates", 0),
                        "resetFrequency", 0), "periodMultiplier", 0));
        String ResetFrequency_2_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(getNodesByTagName(leg2Node, "resetDates", 0),
                        "resetFrequency", 0), "period", 0));
        String ResetFrequency_leg2 = ResetFrequency_1_leg2 + ""
                + ResetFrequency_2_leg2;
        String CompoundingFrequency_leg2 = "";
        String CompoundingStyle_leg2 = getNodeValue(getNodesByTagName(leg2Node,
                "compoundingMethod", 0));
        String FloatingRateIndex_leg2 = getNodeValue(getNodesByTagName(
                leg2Node, "floatingRateIndex", 0));
        String FloatingRateIndexMultiplier_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg2Node, "floatingRateCalculation", 0),
                "periodMultiplier", 0));
        String FloatingRateIndexPeriod_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg2Node, "floatingRateCalculation", 0),
                "period", 0));

        String NotionalStepDates_leg2 = getNodeValues(getNodesByTagName2(
                getNodesByTagName(leg2Node, "notionalStepSchedule", 0),
                "stepDate"));
        String NotionalSteps_leg2 = getNodeValues(getNodesByTagName2(
                getNodesByTagName(leg2Node, "notionalStepSchedule", 0),
                "stepValue"));

        String NotionalRateDate_leg2 = "", NotionalRateRate_leg2 = "";
        if (getNodesByTagName(leg2Node, "spreadSchedule", 0) != null) {
            NotionalRateDate_leg2 = getNodeValues(getNodesByTagName2(
                    getNodesByTagName(leg2Node, "spreadSchedule", 0),
                    "stepDate"));
            NotionalRateRate_leg2 = getNodeValues(getNodesByTagName2(
                    getNodesByTagName(leg2Node, "spreadSchedule", 0),
                    "stepValue"));
        } else if (getNodesByTagName(leg2Node, "fixedRateSchedule", 0) != null) {
            NotionalRateDate_leg2 = getNodeValues(getNodesByTagName2(
                    getNodesByTagName(leg2Node, "fixedRateSchedule", 0),
                    "stepDate"));
            NotionalRateRate_leg2 = getNodeValues(getNodesByTagName2(
                    getNodesByTagName(leg2Node, "fixedRateSchedule", 0),
                    "stepValue"));
        }
        String NotionalStepDates_view_leg2 = "";
        if (NotionalStepDates_leg2.equals("")) {
            NotionalStepDates_view_leg2 = NotionalRateDate_leg2;
        } else {
            NotionalStepDates_view_leg2 = NotionalStepDates_leg2;
        }

        String rollConvention_leg2 = getNodeValue(getNodesByTagName(leg2Node,
                "rollConvention", 0));
        String calculationBDConvention_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg2Node,
                        "calculationPeriodDatesAdjustments", 0),
                "businessDayConvention", 0));
        String calculationAdjCalendars_leg2 = getNodeValues(getNodesByTagName2(
                getNodesByTagName(leg2Node,
                        "calculationPeriodDatesAdjustments", 0),
                "businessCenter"));
        String paymentBDConvention_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg2Node, "paymentDatesAdjustments", 0),
                "businessDayConvention", 0));
        String paymentAdjCalendars_leg2 = getNodeValues(getNodesByTagName2(
                getNodesByTagName(leg2Node, "paymentDatesAdjustments", 0),
                "businessCenter"));
        String resetBDConvention_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg2Node, "resetDatesAdjustments", 0),
                "businessDayConvention", 0));
        String resetAdjCalendars_leg2 = getNodeValues(getNodesByTagName2(
                getNodesByTagName(leg2Node, "resetDatesAdjustments", 0),
                "businessCenter"));
        String TerminationBDConvention_leg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(leg2Node, "terminationDate", 0),
                "businessDayConvention", 0));
        String TerminationAdjCalendars_leg2 = getNodeValues(getNodesByTagName2(
                getNodesByTagName(leg2Node, "terminationDate", 0),
                "businessCenter"));

        result.add(new LabelValue("Leg1_Payer Party Reference",
                PayerPartyReference_leg1));
        result.add(new LabelValue("Leg2_Payer Party Reference",
                PayerPartyReference_leg2));
        result.add(new LabelValue("Leg1_Receiver Party Reference",
                ReceiverPartyReference_leg1));
        result.add(new LabelValue("Leg2_Receiver Party Reference",
                ReceiverPartyReference_leg2));
        result.add(new LabelValue("Leg1_Leg Type (Fix/Float)", LegType_leg1));
        result.add(new LabelValue("Leg2_Leg Type (Fix/Float)", LegType_leg2));
        result.add(new LabelValue("Leg1_Effective Date", EffectiveDate_leg1));
        result.add(new LabelValue("Leg2_Effective Date", EffectiveDate_leg2));
        result.add(new LabelValue("Leg1_Notional Currency", Currency_leg1));
        result.add(new LabelValue("Leg2_Notional Currency", Currency_leg2));
        result.add(new LabelValue("Leg1_Notional Amount", Nominal_leg1));
        result.add(new LabelValue("Leg2_Notional Amount", Nominal_leg2));
        result.add(new LabelValue("Leg1_Termination Date", TerminationDate_leg1));
        result.add(new LabelValue("Leg2_Termination Date", TerminationDate_leg2));
        result.add(new LabelValue("Leg1_Margin", Margin_leg1));
        result.add(new LabelValue("Leg2_Margin", Margin_leg2));
        result.add(new LabelValue("Leg1_Day Count", DayCount_leg1));
        result.add(new LabelValue("Leg2_Day Count", DayCount_leg2));
        result.add(new LabelValue("Leg1_Fixed Rate", FixedRate_leg1));
        result.add(new LabelValue("Leg2_Fixed Rate", FixedRate_leg2));
        result.add(new LabelValue("Leg1_Payment Frequency",
                PaymentFrequency_leg1));
        result.add(new LabelValue("Leg2_Payment Frequency",
                PaymentFrequency_leg2));
        result.add(new LabelValue("Leg1_Reset Frequency", ResetFrequency_leg1));
        result.add(new LabelValue("Leg2_Reset Frequency", ResetFrequency_leg2));
        result.add(new LabelValue("Leg1_Compounding Frequency",
                CompoundingFrequency_leg1));
        result.add(new LabelValue("Leg2_Compounding Frequency",
                CompoundingFrequency_leg2));
        result.add(new LabelValue("Leg1_Compounding Style",
                CompoundingStyle_leg1));
        result.add(new LabelValue("Leg2_Compounding Style",
                CompoundingStyle_leg2));
        result.add(new LabelValue("Leg1_Floating Rate Index",
                FloatingRateIndex_leg1));
        result.add(new LabelValue("Leg2_Floating Rate Index",
                FloatingRateIndex_leg2));
        result.add(new LabelValue("Leg1_Floating Rate Index Multiplier",
                FloatingRateIndexMultiplier_leg1));
        result.add(new LabelValue("Leg2_Floating Rate Index Multiplier",
                FloatingRateIndexMultiplier_leg2));
        result.add(new LabelValue("Leg1_Floating Rate Index Period",
                FloatingRateIndexPeriod_leg1));
        result.add(new LabelValue("Leg2_Floating Rate Index Period",
                FloatingRateIndexPeriod_leg2));
        result.add(new LabelValue("Leg1_Notional Step Dates",
                NotionalStepDates_view_leg1));
        result.add(new LabelValue("Leg2_Notional Step Dates",
                NotionalStepDates_view_leg2));
        result.add(new LabelValue("Leg1_Notional Steps", NotionalSteps_leg1));
        result.add(new LabelValue("Leg2_Notional Steps", NotionalSteps_leg2));
        result.add(new LabelValue("Leg1_Notional Step Rates/Margin",
                NotionalRateRate_leg1));
        result.add(new LabelValue("Leg2_Notional Step Rates/Margin",
                NotionalRateRate_leg2));
        result.add(new LabelValue("Leg1_Roll Convention", rollConvention_leg1));
        result.add(new LabelValue("Leg2_Roll Convention", rollConvention_leg2));
        result.add(new LabelValue("Leg1_CalculationBDConvention",
                calculationBDConvention_leg1));
        result.add(new LabelValue("Leg2_CalculationBDConvention",
                calculationBDConvention_leg2));
        result.add(new LabelValue("Leg1_CalculationAdjCalendars",
                calculationAdjCalendars_leg1));
        result.add(new LabelValue("Leg2_CalculationAdjCalendars",
                calculationAdjCalendars_leg2));
        result.add(new LabelValue("Leg1_PaymentBDConvention",
                paymentBDConvention_leg1));
        result.add(new LabelValue("Leg2_PaymentBDConvention",
                paymentBDConvention_leg2));
        result.add(new LabelValue("Leg1_Payment Lag Days",
                PaymentDaysOffset_leg1));
        result.add(new LabelValue("Leg2_Payment Lag Days",
                PaymentDaysOffset_leg2));
        result.add(new LabelValue("Leg1_PaymentAdjCalendars",
                paymentAdjCalendars_leg1));
        result.add(new LabelValue("Leg2_PaymentAdjCalendars",
                paymentAdjCalendars_leg2));
        result.add(new LabelValue("Leg1_ResetBDConvention",
                resetBDConvention_leg1));
        result.add(new LabelValue("Leg2_ResetBDConvention",
                resetBDConvention_leg2));
        result.add(new LabelValue("Leg1_ResetAdjCalendars",
                resetAdjCalendars_leg1));
        result.add(new LabelValue("Leg2_ResetAdjCalendars",
                resetAdjCalendars_leg2));
        result.add(new LabelValue("Leg1_TerminationBDConvention",
                TerminationBDConvention_leg1));
        result.add(new LabelValue("Leg2_TerminationBDConvention",
                TerminationBDConvention_leg2));
        result.add(new LabelValue("Leg1_TerminationAdjCalendars",
                TerminationAdjCalendars_leg1));
        result.add(new LabelValue("Leg2_TerminationAdjCalendars",
                TerminationAdjCalendars_leg2));

        Node initialFixingDate_leg1 = getNodesByTagName(
                getNodesByTagName(scbmlDoc, "swapStream", 0),
                "initialFixingDate", 0);
        Node initialFixingDate_leg2 = getNodesByTagName(
                getNodesByTagName(scbmlDoc, "swapStream", 1),
                "initialFixingDate", 0);
        Node fixingDates_leg1 = getNodesByTagName(
                getNodesByTagName(scbmlDoc, "swapStream", 0), "fixingDates", 0);
        Node fixingDates_leg2 = getNodesByTagName(
                getNodesByTagName(scbmlDoc, "swapStream", 1), "fixingDates", 0);

        String i_offset_leg1 = getNodeValue(getNodesByTagName(
                initialFixingDate_leg1, "periodMultiplier", 0))
                + ", "
                + getNodeValue(getNodesByTagName(initialFixingDate_leg1,
                "period", 0))
                + ", "
                + getNodeValue(getNodesByTagName(initialFixingDate_leg1,
                "dayType", 0));
        String i_offset_leg2 = getNodeValue(getNodesByTagName(
                initialFixingDate_leg2, "periodMultiplier", 0))
                + ", "
                + getNodeValue(getNodesByTagName(initialFixingDate_leg2,
                "period", 0))
                + ", "
                + getNodeValue(getNodesByTagName(initialFixingDate_leg2,
                "dayType", 0));
        String i_businessDayConvention_leg1 = getNodeValue(getNodesByTagName(
                initialFixingDate_leg1, "businessDayConvention", 0));
        String i_businessDayConvention_leg2 = getNodeValue(getNodesByTagName(
                initialFixingDate_leg2, "businessDayConvention", 0));
        String i_calendars_leg1 = getNodeValues(getNodesByTagName2(
                initialFixingDate_leg1, "businessCenter"));
        String i_calendars_leg2 = getNodeValues(getNodesByTagName2(
                initialFixingDate_leg2, "businessCenter"));

        String f_offset_leg1 = getNodeValue(getNodesByTagName(fixingDates_leg1,
                "periodMultiplier", 0))
                + ", "
                + getNodeValue(getNodesByTagName(fixingDates_leg1, "period", 0))
                + ", "
                + getNodeValue(getNodesByTagName(fixingDates_leg1, "dayType", 0));
        String f_offset_leg2 = getNodeValue(getNodesByTagName(fixingDates_leg2,
                "periodMultiplier", 0))
                + ", "
                + getNodeValue(getNodesByTagName(fixingDates_leg2, "period", 0))
                + ", "
                + getNodeValue(getNodesByTagName(fixingDates_leg2, "dayType", 0));
        String f_businessDayConvention_leg1 = getNodeValue(getNodesByTagName(
                fixingDates_leg1, "businessDayConvention", 0));
        String f_businessDayConvention_leg2 = getNodeValue(getNodesByTagName(
                fixingDates_leg2, "businessDayConvention", 0));
        String f_calendars_leg1 = getNodeValues(getNodesByTagName2(
                fixingDates_leg1, "businessCenter"));
        String f_calendars_leg2 = getNodeValues(getNodesByTagName2(
                fixingDates_leg2, "businessCenter"));

        result.add(new LabelValue("Leg1_FixingDates Offset", f_offset_leg1));
        result.add(new LabelValue("Leg2_FixingDates Offset", f_offset_leg2));
        result.add(new LabelValue("Leg1_FixingDates BusinessDayConvention",
                f_businessDayConvention_leg1));
        result.add(new LabelValue("Leg2_FixingDates BusinessDayConvention",
                f_businessDayConvention_leg2));
        result.add(new LabelValue("Leg1_FixingDates Calendars",
                f_calendars_leg1));
        result.add(new LabelValue("Leg2_FixingDates Calendars",
                f_calendars_leg2));
        result.add(new LabelValue("Leg1_1st FixingDate Rule Offset",
                i_offset_leg1));
        result.add(new LabelValue("Leg2_1st FixingDate Rule Offset",
                i_offset_leg2));
        result.add(new LabelValue(
                "Leg1_1st FixingDate Rule BusinessDayConvention",
                i_businessDayConvention_leg1));
        result.add(new LabelValue(
                "Leg2_1st FixingDate Rule BusinessDayConvention",
                i_businessDayConvention_leg2));
        result.add(new LabelValue("Leg1_1st FixingDate Rule Calendars",
                i_calendars_leg1));
        result.add(new LabelValue("Leg2_1st FixingDate Rule Calendars",
                i_calendars_leg2));

        // confirm if it is needed to show
        String id = getSingleNodeValue(scbmlDoc, "id");
        boolean isShow = id.equals("InterestRate:IRSwap:FixedFloat")
                || id.equals("InterestRate:IRSwap:FloatFloat")
                || id.equals("InterestRate:IRSwap:OIS")
                || id.equals("InterestRate:IRSwap:Basis");
        if (!isShow) {
            for (LabelValue lv : result) {
                lv.setValue("");
            }
        }
        return result;
    }

    private static List<LabelValue> buildStubHeaderDetailsRow(Document scbmlDoc) {
        List<LabelValue> result = new ArrayList();

        Node stubLeg1Node = getNodesByTagName(scbmlDoc, "swapStream", 0);
        Node stubLeg2Node = getNodesByTagName(scbmlDoc, "swapStream", 1);
        Node stubCalculationPeriodAmountLeg1Node = getNodesByTagName(
                stubLeg1Node, "stubCalculationPeriodAmount", 0);
        Node stubCalculationPeriodAmountLeg2Node = getNodesByTagName(
                stubLeg2Node, "stubCalculationPeriodAmount", 0);

        String stubFirstDateLeg1 = "", stubFirstDateLeg2 = "";
        String stubEndDateLeg1 = "", stubEndDateLeg2 = "";
        String stubFrontTypeLeg1 = "", stubFrontTypeLeg2 = "";
        String stubFrontIndexLeg1 = "", stubFrontIndexLeg2 = "";
        String stubEndTypeLeg1 = "", stubEndTypeLeg2 = "";
        String stubEndIndexLeg1 = "", stubEndIndexLeg2 = "";

        // leg1 values
        stubFirstDateLeg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(stubLeg1Node, "calculationPeriodDates", 0),
                "firstRegularPeriodStartDate", 0));
        stubEndDateLeg1 = getNodeValue(getNodesByTagName(
                getNodesByTagName(stubLeg1Node, "calculationPeriodDates", 0),
                "lastRegularPeriodEndDate", 0));
        List<Node> initialStubFloatingRateNodesLeg1 = getNodesByTagName2(
                getNodesByTagName(stubCalculationPeriodAmountLeg1Node,
                        "initialStub", 0), "floatingRate");
        if (initialStubFloatingRateNodesLeg1 != null
                && initialStubFloatingRateNodesLeg1.size() > 1) {
            stubFrontTypeLeg1 = "Interpolation";
        }
        if (initialStubFloatingRateNodesLeg1 != null) {
            for (int i = 0; i < initialStubFloatingRateNodesLeg1.size(); i++) {
                String periodMultiplier = getNodeValue(getNodesByTagName(
                        getNodesByTagName(
                                initialStubFloatingRateNodesLeg1.get(i),
                                "indexTenor", 0), "periodMultiplier", 0));
                String period = getNodeValue(getNodesByTagName(
                        getNodesByTagName(
                                initialStubFloatingRateNodesLeg1.get(i),
                                "indexTenor", 0), "period", 0));
                if (initialStubFloatingRateNodesLeg1.size() - 1 == i) {
                    stubFrontIndexLeg1 = stubFrontIndexLeg1 + periodMultiplier
                            + period;
                } else {
                    stubFrontIndexLeg1 = stubFrontIndexLeg1 + periodMultiplier
                            + period + ",";
                }
            }
        }

        List<Node> finalStubFloatingRateNodesLeg1 = getNodesByTagName2(
                getNodesByTagName(stubCalculationPeriodAmountLeg1Node,
                        "finalStub", 0), "floatingRate");
        if (finalStubFloatingRateNodesLeg1 != null
                && finalStubFloatingRateNodesLeg1.size() > 1) {
            stubEndTypeLeg1 = "Interpolation";
        }
        if (finalStubFloatingRateNodesLeg1 != null) {
            for (int i = 0; i < finalStubFloatingRateNodesLeg1.size(); i++) {
                String periodMultiplier = getNodeValue(getNodesByTagName(
                        getNodesByTagName(
                                finalStubFloatingRateNodesLeg1.get(i),
                                "indexTenor", 0), "periodMultiplier", 0));
                String period = getNodeValue(getNodesByTagName(
                        getNodesByTagName(
                                finalStubFloatingRateNodesLeg1.get(i),
                                "indexTenor", 0), "period", 0));
                if (finalStubFloatingRateNodesLeg1.size() - 1 == i) {
                    stubEndIndexLeg1 = stubEndIndexLeg1 + periodMultiplier
                            + period;
                } else {
                    stubEndIndexLeg1 = stubEndIndexLeg1 + periodMultiplier
                            + period + ",";
                }
            }
        }

        // leg2 values
        stubFirstDateLeg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(stubLeg2Node, "calculationPeriodDates", 0),
                "firstRegularPeriodStartDate", 0));
        stubEndDateLeg2 = getNodeValue(getNodesByTagName(
                getNodesByTagName(stubLeg2Node, "calculationPeriodDates", 0),
                "lastRegularPeriodEndDate", 0));
        List<Node> initialStubFloatingRateNodesLeg2 = getNodesByTagName2(
                getNodesByTagName(stubCalculationPeriodAmountLeg2Node,
                        "initialStub", 0), "floatingRate");
        if (initialStubFloatingRateNodesLeg2 != null
                && initialStubFloatingRateNodesLeg2.size() > 1) {
            stubFrontTypeLeg2 = "Interpolation";
        }
        if (initialStubFloatingRateNodesLeg2 != null) {
            for (int i = 0; i < initialStubFloatingRateNodesLeg2.size(); i++) {
                String periodMultiplier = getNodeValue(getNodesByTagName(
                        getNodesByTagName(
                                initialStubFloatingRateNodesLeg2.get(i),
                                "indexTenor", 0), "periodMultiplier", 0));
                String period = getNodeValue(getNodesByTagName(
                        getNodesByTagName(
                                initialStubFloatingRateNodesLeg2.get(i),
                                "indexTenor", 0), "period", 0));
                if (initialStubFloatingRateNodesLeg2.size() - 1 == i) {
                    stubFrontIndexLeg2 = stubFrontIndexLeg2 + periodMultiplier
                            + period;
                } else {
                    stubFrontIndexLeg2 = stubFrontIndexLeg2 + periodMultiplier
                            + period + ",";
                }
            }
        }

        List<Node> finalStubFloatingRateNodesLeg2 = getNodesByTagName2(
                getNodesByTagName(stubCalculationPeriodAmountLeg2Node,
                        "finalStub", 0), "floatingRate");
        if (finalStubFloatingRateNodesLeg2 != null
                && finalStubFloatingRateNodesLeg2.size() > 1) {
            stubEndTypeLeg2 = "Interpolation";
        }
        if (finalStubFloatingRateNodesLeg2 != null) {
            for (int i = 0; i < finalStubFloatingRateNodesLeg2.size(); i++) {
                String periodMultiplier = getNodeValue(getNodesByTagName(
                        getNodesByTagName(
                                finalStubFloatingRateNodesLeg2.get(i),
                                "indexTenor", 0), "periodMultiplier", 0));
                String period = getNodeValue(getNodesByTagName(
                        getNodesByTagName(
                                finalStubFloatingRateNodesLeg2.get(i),
                                "indexTenor", 0), "period", 0));
                if (finalStubFloatingRateNodesLeg2.size() - 1 == i) {
                    stubEndIndexLeg2 = stubEndIndexLeg2 + periodMultiplier
                            + period;
                } else {
                    stubEndIndexLeg2 = stubEndIndexLeg2 + periodMultiplier
                            + period + ",";
                }
            }
        }

        result.add(new LabelValue("Leg1_Upfront Stub Period End Date",
                stubFirstDateLeg1));
        result.add(new LabelValue("Leg2_Upfront Stub Period End Date",
                stubFirstDateLeg2));
        result.add(new LabelValue("Leg1_In Arrear Stub Period Start Date",
                stubEndDateLeg1));
        result.add(new LabelValue("Leg2_In Arrear Stub Period Start Date",
                stubEndDateLeg2));
        result.add(new LabelValue("Leg1_Front Stub Fixing Type",
                stubFrontTypeLeg1));
        result.add(new LabelValue("Leg2_Front Stub Fixing Type",
                stubFrontTypeLeg2));
        result.add(new LabelValue("Leg1_Front Stub Fixing Index",
                stubFrontIndexLeg1));
        result.add(new LabelValue("Leg2_Front Stub Fixing Index",
                stubFrontIndexLeg2));
        result.add(new LabelValue("Leg1_End Stub Fixing Type", stubEndTypeLeg1));
        result.add(new LabelValue("Leg2_End Stub Fixing Type", stubEndTypeLeg2));
        result.add(new LabelValue("Leg1_End Stub Fixing Index",
                stubEndIndexLeg1));
        result.add(new LabelValue("Leg2_End Stub Fixing Index",
                stubEndIndexLeg2));
        return result;
    }

    private static List<LabelValue> buildAllocationDetailsRow(Document scbmlDoc) {
        List<LabelValue> result = new ArrayList();
        String lv_capturesystem = getSingleNodeValue(scbmlDoc, "captureSystem");
        String lv_partyScheme = "http://www.sc.com/coding-schemes/eclipse1/"
                + lv_capturesystem + "-party-id";
        String allocationAmount = "";
        String allocationCurrency = "";
        String allocationPartyName = "";
        List<Node> partys_head = getNodesByTagName2(scbmlDoc, "party");
        List<Node> allocationNodes = getNodesByTagName2(scbmlDoc, "allocation");
        for (int index = 0; index < allocationNodes.size(); index++) {
            String allocationPartyReference = getAttrValue(
                    getNodesByTagName2(allocationNodes.get(index),
                            "partyReference").get(1), "href");
            for (int j = 0; j < partys_head.size(); j++) {
                if (getAttrValue(partys_head.get(j), "id").equals(
                        allocationPartyReference)) {
                    List<Node> nodes_inner = getNodesByTagName2(
                            partys_head.get(j), "partyId");
                    for (int k = 0; k < nodes_inner.size(); k++) {
                        if (getAttrValue(nodes_inner.get(k), "partyIdScheme")
                                .equals(lv_partyScheme)) {
                            allocationPartyName = allocationPartyName
                                    + getNodeValue(nodes_inner.get(k)) + "  ";
                        }
                    }
                }
            }
            allocationAmount = allocationAmount
                    + getNodeValue(getNodesByTagName(
                    allocationNodes.get(index), "amount", 0)) + "  ";
            allocationCurrency = allocationCurrency
                    + getNodeValue(getNodesByTagName(
                    allocationNodes.get(index), "currency", 0)) + "  ";
        }
        result.add(new LabelValue("Party", allocationPartyName));
        result.add(new LabelValue("Amount", allocationAmount));
        result.add(new LabelValue("Currency", allocationCurrency));
        return result;
    }

    private static List<LabelValue> buildOperationFeeRow(Document scbmlDoc) {
        List<LabelValue> result = new ArrayList();
        String lv_capturesystem = getSingleNodeValue(scbmlDoc, "captureSystem");
        String lv_partyScheme = "http://www.sc.com/coding-schemes/eclipse1/"
                + lv_capturesystem + "-party-id";
        String operationFeeAmount = "";
        String operationFeeCurrency = "";
        String operationFeeDate = "";
        String operationFeeType = "";
        String operationFeePayerPartyName = "";
        String operationFeeReceiverPartyName = "";
        List<Node> partys_head = getNodesByTagName2(scbmlDoc, "party");
        List<Node> operationFeeNodes = getNodesByTagName2(scbmlDoc, "payment");
        for (int operationFee_count = 0; operationFee_count < operationFeeNodes
                .size(); operationFee_count++) {
            String operationFeePayerPartyReference = getAttrValue(
                    getNodesByTagName(
                            operationFeeNodes.get(operationFee_count),
                            "payerPartyReference", 0), "href");
            String operationFeeReceiverPartyReference = getAttrValue(
                    getNodesByTagName(
                            operationFeeNodes.get(operationFee_count),
                            "receiverPartyReference", 0), "href");
            for (int j = 0; j < partys_head.size(); j++) {
                if (getAttrValue(partys_head.get(j), "id").equals(
                        operationFeePayerPartyReference)) {
                    List<Node> nodes_inner = getNodesByTagName2(
                            partys_head.get(j), "partyId");
                    for (int k = 0; k < nodes_inner.size(); k++) {
                        if (getAttrValue(nodes_inner.get(k), "partyIdScheme")
                                .equals(lv_partyScheme)) {
                            operationFeePayerPartyName = operationFeePayerPartyName
                                    + getNodeValue(nodes_inner.get(k)) + "  ";
                        }
                    }
                }
                if (getAttrValue(partys_head.get(j), "id").equals(
                        operationFeeReceiverPartyReference)) {
                    List<Node> nodes_inner = getNodesByTagName2(
                            partys_head.get(j), "partyId");
                    for (int k = 0; k < nodes_inner.size(); k++) {
                        if (getAttrValue(nodes_inner.get(k), "partyIdScheme")
                                .equals(lv_partyScheme)) {
                            operationFeeReceiverPartyName = operationFeeReceiverPartyName
                                    + getNodeValue(nodes_inner.get(k)) + "  ";
                        }
                    }
                }
            }

            operationFeeAmount = operationFeeAmount
                    + getNodeValue(getNodesByTagName(
                    operationFeeNodes.get(operationFee_count),
                    "amount", 0)) + "  ";
            operationFeeCurrency = operationFeeCurrency
                    + getNodeValue(getNodesByTagName(
                    operationFeeNodes.get(operationFee_count),
                    "currency", 0)) + "  ";
            operationFeeDate = operationFeeDate
                    + getNodeValue(getNodesByTagName(
                    operationFeeNodes.get(operationFee_count),
                    "unadjustedDate", 0)) + "  ";
            operationFeeType = operationFeeType
                    + getNodeValue(getNodesByTagName(
                    operationFeeNodes.get(operationFee_count),
                    "paymentType", 0)) + "  ";
        }
        result.add(new LabelValue("Payer Party", operationFeePayerPartyName));
        result.add(new LabelValue("Receiver Party",
                operationFeeReceiverPartyName));
        result.add(new LabelValue("Date", operationFeeDate));
        result.add(new LabelValue("Amount", operationFeeAmount));
        result.add(new LabelValue("Currency", operationFeeCurrency));
        result.add(new LabelValue("Type", operationFeeType));
        return result;
    }

    private static List<LabelValue> buildAdditionFeeRow(Document scbmlDoc) {
        List<LabelValue> result = new ArrayList();
        String lv_capturesystem = getSingleNodeValue(scbmlDoc, "captureSystem");
        String lv_partyScheme = "http://www.sc.com/coding-schemes/eclipse1/"
                + lv_capturesystem + "-party-id";
        String AdditionalPaymentDate = "";
        String AdditionalPaymentAmount = "";
        String AdditionalPaymentCurrency = "";
        String additionalPayerPartyName = "";
        String additionalReceiverPartyName = "";
        List<Node> partys_head = getNodesByTagName2(scbmlDoc, "party");
        List<Node> additionalPaymentNodes = getNodesByTagName2(scbmlDoc,
                "additionalPayment");
        for (int additionalPayment_count = 0; additionalPayment_count < additionalPaymentNodes
                .size(); additionalPayment_count++) {
            String additionalPayerPartyReference = getAttrValue(
                    getNodesByTagName(
                            additionalPaymentNodes.get(additionalPayment_count),
                            "payerPartyReference", 0), "href");
            String additionalReceiverPartyReference = getAttrValue(
                    getNodesByTagName(
                            additionalPaymentNodes.get(additionalPayment_count),
                            "receiverPartyReference", 0), "href");
            for (int j = 0; j < partys_head.size(); j++) {
                if (getAttrValue(partys_head.get(j), "id").equals(
                        additionalPayerPartyReference)) {
                    List<Node> nodes_inner = getNodesByTagName2(
                            partys_head.get(j), "partyId");
                    for (int k = 0; k < nodes_inner.size(); k++) {
                        if (getAttrValue(nodes_inner.get(k), "partyIdScheme")
                                .equals(lv_partyScheme)) {
                            additionalPayerPartyName = additionalPayerPartyName
                                    + getNodeValue(nodes_inner.get(k)) + "  ";
                        }
                    }
                }
                if (getAttrValue(partys_head.get(j), "id").equals(
                        additionalReceiverPartyReference)) {
                    List<Node> nodes_inner = getNodesByTagName2(
                            partys_head.get(j), "partyId");
                    for (int k = 0; k < nodes_inner.size(); k++) {
                        if (getAttrValue(nodes_inner.get(k), "partyIdScheme")
                                .equals(lv_partyScheme)) {
                            additionalReceiverPartyName = additionalReceiverPartyName
                                    + getNodeValue(nodes_inner.get(k)) + "  ";
                        }
                    }
                }
            }
            AdditionalPaymentDate = AdditionalPaymentDate
                    + getNodeValue(getNodesByTagName(
                    additionalPaymentNodes.get(additionalPayment_count),
                    "unadjustedDate", 0)) + "  ";
            AdditionalPaymentAmount = AdditionalPaymentAmount
                    + getNodeValue(getNodesByTagName(
                    additionalPaymentNodes.get(additionalPayment_count),
                    "amount", 0)) + "  ";
            AdditionalPaymentCurrency = AdditionalPaymentCurrency
                    + getNodeValue(getNodesByTagName(
                    additionalPaymentNodes.get(additionalPayment_count),
                    "currency", 0)) + "  ";
        }
        result.add(new LabelValue("Payer Party", additionalPayerPartyName));
        result.add(new LabelValue("Receiver Party", additionalReceiverPartyName));
        result.add(new LabelValue("Date", AdditionalPaymentDate));
        result.add(new LabelValue("Amount", AdditionalPaymentAmount));
        result.add(new LabelValue("Currency", AdditionalPaymentCurrency));
        return result;
    }

    private static List<LabelValue> buildNovationHeaderRow(Document scbmlDoc) {
        List<LabelValue> result = new ArrayList();
        Node novationNode = getNodesByTagName(scbmlDoc, "novation", 0);
        String outgoingParty = getAttrValue(
                getNodesByTagName(novationNode, "transferor", 0), "href");
        String remainingParty = getAttrValue(
                getNodesByTagName(novationNode, "remainingParty", 0), "href");
        String incomingParty = getAttrValue(
                getNodesByTagName(novationNode, "transferee", 0), "href");
        String cancelDealNumber = getNodeValue(getNodesByTagName(
                getNodesByTagName(novationNode, "oldTradeIdentifier", 0),
                "tradeId", 0));
        String outgoingPartyName = "";
        String remainingPartyName = "";
        String incomingPartyName = "";
        List<Node> partys_head = getNodesByTagName2(scbmlDoc, "party");
        for (int i = 0; i < partys_head.size(); i++) {
            if (getAttrValue(partys_head.get(i), "id").equals(outgoingParty)) {
                outgoingPartyName = getNodeValue(getNodesByTagName(
                        partys_head.get(i), "partyName", 0));
            }
            if (getAttrValue(partys_head.get(i), "id").equals(remainingParty)) {
                remainingPartyName = getNodeValue(getNodesByTagName(
                        partys_head.get(i), "partyName", 0));
            }
            if (getAttrValue(partys_head.get(i), "id").equals(incomingParty)) {
                incomingPartyName = getNodeValue(getNodesByTagName(
                        partys_head.get(i), "partyName", 0));
            }
        }
        result.add(new LabelValue("Outgoing Party", outgoingPartyName));
        result.add(new LabelValue("Remaining Party FMID", remainingPartyName));
        result.add(new LabelValue("Incoming Party", incomingPartyName));
        result.add(new LabelValue("Cancellation Deal Number", cancelDealNumber));
        return result;
    }

    private static List<LabelValue> buildTradeHeaderRow(Document scbmlDoc) {
        List<LabelValue> result = new ArrayList();

        String lv_capturesystem = getSingleNodeValue(scbmlDoc, "captureSystem");
        String lv_partyScheme = "http://www.sc.com/coding-schemes/eclipse1/"
                + lv_capturesystem + "-party-id";
        // ----------Head
        String Counterparty = "", ExecutingParty = "";
        String lv_receiverReference_Counterparty = "";
        String TradeSourcePartyID = "";
        String lv_receiverReference_TradeSourcePartyID = "";
        String GlobalExternalTradeId = "";
        String CounterpartyFMID = "", ExecutingPartyFMID = "";
        String lv_ExecutingParty = "";

        List<Node> relatedParty = getNodesByTagName2(scbmlDoc, "relatedParty");
        for (int i = 0; i < relatedParty.size(); i++) {
            if (getNodeValue(getNodesByTagName(relatedParty.get(i), "role", 0))
                    .equals("Counterparty")) {
                lv_receiverReference_Counterparty = getAttrValue(
                        getNodesByTagName(relatedParty.get(i),
                                "partyReference", 0), "href");
            }
            if (getNodeValue(getNodesByTagName(relatedParty.get(i), "role", 0))
                    .equals("ExecutingBroker")) {
                lv_ExecutingParty = getAttrValue(
                        getNodesByTagName(relatedParty.get(i),
                                "partyReference", 0), "href");
            }
            if (getNodeValue(getNodesByTagName(relatedParty.get(i), "role", 0))
                    .equals("TradeSource")) {
                lv_receiverReference_TradeSourcePartyID = getAttrValue(
                        getNodesByTagName(relatedParty.get(i),
                                "partyReference", 0), "href");
            }
        }

        List<Node> partys_head = getNodesByTagName2(scbmlDoc, "party");
        for (int i = 0; i < partys_head.size(); i++) {
            if (getAttrValue(partys_head.get(i), "id").equals(
                    lv_receiverReference_Counterparty)) {
                List<Node> nodes_inner = getNodesByTagName2(partys_head.get(i),
                        "partyId");
                for (int j = 0; j < nodes_inner.size(); j++) {
                    if (getAttrValue(nodes_inner.get(j), "partyIdScheme")
                            .equals(lv_partyScheme)) {
                        Counterparty = getNodeValue(nodes_inner.get(j));
                    }
                }
            }
            if (getAttrValue(partys_head.get(i), "id").equals(
                    lv_receiverReference_TradeSourcePartyID)) {
                List<Node> nodes_inner = getNodesByTagName2(partys_head.get(i),
                        "partyId");
                for (int j = 0; j < nodes_inner.size(); j++) {
                    if (getAttrValue(nodes_inner.get(j), "partyIdScheme")
                            .equals(lv_partyScheme)) {
                        TradeSourcePartyID = getNodeValue(nodes_inner.get(j));
                    }
                }
            }
            if (getAttrValue(partys_head.get(i), "id").equals(
                    lv_receiverReference_Counterparty)) {
                List<Node> nodes_inner = getNodesByTagName2(partys_head.get(i),
                        "partyId");
                for (int j = 0; j < nodes_inner.size(); j++) {
                    if (getAttrValue(nodes_inner.get(j), "partyIdScheme")
                            .equals("http://www.sc.com/coding-scheme/party-id/fm-id")) {
                        CounterpartyFMID = getNodeValue(nodes_inner.get(j));
                    }
                }
            }
            if (getAttrValue(partys_head.get(i), "id")
                    .equals(lv_ExecutingParty)) {
                List<Node> nodes_inner = getNodesByTagName2(partys_head.get(i),
                        "partyId");
                for (int j = 0; j < nodes_inner.size(); j++) {
                    if (getAttrValue(nodes_inner.get(j), "partyIdScheme")
                            .equals(lv_partyScheme)) {
                        ExecutingParty = getNodeValue(nodes_inner.get(j));
                    }
                }
            }
            if (getAttrValue(partys_head.get(i), "id")
                    .equals(lv_ExecutingParty)) {
                List<Node> nodes_inner = getNodesByTagName2(partys_head.get(i),
                        "partyId");
                for (int j = 0; j < nodes_inner.size(); j++) {
                    if (getAttrValue(nodes_inner.get(j), "partyIdScheme")
                            .equals("http://www.sc.com/coding-scheme/party-id/fm-id")) {
                        ExecutingPartyFMID = getNodeValue(nodes_inner.get(j));
                    }
                }
            }
        }

        List<Node> partyTradeIdentifier = getNodesByTagName2(scbmlDoc,
                "partyTradeIdentifier");
        for (int i = 0; i < partyTradeIdentifier.size(); i++) {
            if (getAttrValue(
                    getNodesByTagName(partyTradeIdentifier.get(i),
                            "partyReference", 0), "href").equals(
                    lv_receiverReference_TradeSourcePartyID)) {
                GlobalExternalTradeId = getNodeValue(getNodesByTagName(
                        partyTradeIdentifier.get(i), "tradeId", 0));
            }
        }

        String TradeDate = getSingleNodeValue(scbmlDoc, "tradeDate");
        String ExecutionDate = getSingleNodeValue(scbmlDoc,
                "initiatedTimestamp");
        String id = getSingleNodeValue(scbmlDoc, "id");
        String idView = id;
        Node nonDeliverableSettlementNode = getNodesByTagName(scbmlDoc,
                "nonDeliverableSettlement", 0);
        if (nonDeliverableSettlementNode != null) {
            idView = idView + " (NonDeliverable)";
        }
        result.add(new LabelValue("Counterparty", Counterparty));
        result.add(new LabelValue("Counterparty FMID", CounterpartyFMID));
        result.add(new LabelValue("Executing Party", ExecutingParty));
        result.add(new LabelValue("Executing Party FMID", ExecutingPartyFMID));
        result.add(new LabelValue("Product Type", idView));
        result.add(new LabelValue("Trade Source", TradeSourcePartyID));
        result.add(new LabelValue("Trade Source Trade ID",
                GlobalExternalTradeId));
        result.add(new LabelValue("Trade Date", TradeDate));
        result.add(new LabelValue("Execution Date/Time", ExecutionDate));
        return result;
    }
}
