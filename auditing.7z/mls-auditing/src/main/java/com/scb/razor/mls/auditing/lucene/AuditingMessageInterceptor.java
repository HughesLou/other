package com.scb.razor.mls.auditing.lucene;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Iterator;

import javax.annotation.Resource;

import org.hibernate.type.Type;

import com.google.common.collect.Iterables;
import com.google.common.collect.Sets;
import com.google.common.eventbus.EventBus;
import com.scb.razor.mls.persistent.interceptor.AuditLogInterceptor;
import com.scb.razor.mls.persistent.model.Message;

public class AuditingMessageInterceptor extends AuditLogInterceptor {

    private static final long serialVersionUID = 1L;
    
    @Resource
    private EventBus bus;
    
    //http://www.mkyong.com/hibernate/hibernate-interceptor-example-audit-log/
    HashSet<Long> creates = new HashSet<>();
    HashSet<Long> deletes = new HashSet<>();
    HashSet<Long> updates = new HashSet<>();
    
    @Override
    public boolean onFlushDirty(Object entity, Serializable id, Object[] currentState, Object[] previousState, String[] propertyNames, Type[] types) {
        if(entity instanceof Message && id != null) {
            updates.add((Long)id);
        }
        return super.onFlushDirty(entity, id, currentState, previousState, propertyNames, types);
    }
    
    @Override
    public boolean onSave(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) {
        if(entity instanceof Message && id != null) {
            creates.add((Long)id);
        }
        return super.onSave(entity, id, state, propertyNames, types);
    }
    
    @Override
    public void onDelete(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) {
        if(entity instanceof Message && id != null) {
            deletes.add((Long)id);
        }
        super.onDelete(entity, id, state, propertyNames, types);
    }

    @Override
    public void postFlush(@SuppressWarnings("rawtypes") Iterator entities) {
        
        try {
            HashSet<Long> ids = Sets.newHashSet(Iterables.concat(creates, updates, deletes));
            if(ids.isEmpty() == false) {
                bus.post(MessageEntityChangedEvent.create(ids));
            }
        } finally {
            creates.clear();
            updates.clear();
            deletes.clear();
        }
        super.postFlush(entities);
    }
}
