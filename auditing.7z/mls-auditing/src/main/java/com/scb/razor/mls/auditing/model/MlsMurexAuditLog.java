/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.model;

import com.scb.razor.mls.auditing.builder.MlsMurexAuditLogBuilder;

import java.util.Date;

/**
 * Description:
 * Author: 1466811
 * Date:   12:12 PM 4/9/14
 */
public class MlsMurexAuditLog implements java.io.Serializable {

    private static final long serialVersionUID = 2794405033678361126L;
    private Long id;
    private String userId;
    private String uploadFileName;
    private String uploadServerType;
    private String uploadFileType;
    private Date createdDate;
    private String comments;

    public MlsMurexAuditLog() {
    }

    public MlsMurexAuditLog(MlsMurexAuditLogBuilder builder) {
        this.id = builder.getId();
        this.userId = builder.getUserId();
        this.uploadFileName = builder.getUploadFileName();
        this.uploadServerType = builder.getUploadServerType();
        this.uploadFileType = builder.getUploadFileType();
        this.comments = builder.getComments();
        this.createdDate = builder.getCreatedDate();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUploadFileName() {
        return uploadFileName;
    }

    public void setUploadFileName(String uploadFileName) {
        this.uploadFileName = uploadFileName;
    }

    public String getUploadServerType() {
        return uploadServerType;
    }

    public void setUploadServerType(String uploadServerType) {
        this.uploadServerType = uploadServerType;
    }

    public String getUploadFileType() {
        return uploadFileType;
    }

    public void setUploadFileType(String uploadFileType) {
        this.uploadFileType = uploadFileType;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }
}
