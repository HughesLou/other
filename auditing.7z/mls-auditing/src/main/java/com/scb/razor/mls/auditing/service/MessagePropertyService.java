/*
 * Copyright (c) 2015. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.service;

import java.util.Set;

/**
 * Description:
 * Author: 1466811
 * Date:   2:56 PM 8/6/15
 */
public interface MessagePropertyService {

    Set<String> getPropertyKeys();
}
