package com.scb.razor.mls.auditing.lucene.exceptions;

import java.io.Serializable;
import java.util.List;

import com.google.common.collect.Lists;
import com.scb.razor.mls.auditing.BusEvent;

public class NewExceptionEvent implements BusEvent {

    private List<? extends Serializable> ids;

    public List<? extends Serializable> getIds() {
        return ids;
    }

    public void setIds(List<? extends Serializable> ids) {
        this.ids = ids;
    }
    
    //murex exception : nack
    public static class NewMurexExceptionEvent extends NewExceptionEvent {
        
        public NewMurexExceptionEvent() {}
        
        public NewMurexExceptionEvent(List<Integer> ids) {
            this();
            setIds(ids);
        }
        
        public NewMurexExceptionEvent(Integer... ids) {
            this(Lists.newArrayList(ids));
        }
    }
    
    //mls exception : mls
    public static class NewMlsExceptionEvent extends NewExceptionEvent {
        
        public NewMlsExceptionEvent(){}
        
        public NewMlsExceptionEvent(List<Long> ids) {
            this();
            setIds(ids);
        }
        
        public NewMlsExceptionEvent(Long... ids) {
            this(Lists.newArrayList(ids));
        }
    }
}
