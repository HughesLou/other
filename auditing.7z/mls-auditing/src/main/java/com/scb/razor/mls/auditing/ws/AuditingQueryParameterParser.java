/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.ws;

import com.scb.razor.mls.persistent.search.AuditingSearchCriteria;
import com.scb.sabre.ticketing.security.IEntitlementService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.scb.razor.mls.persistent.utils.PersistentConstants.*;

@Component
public class AuditingQueryParameterParser {

    @Autowired
    private IEntitlementService auditingEntitlementsService = null;
    @Value("${message.authorizedField:}")
    private String authorizedField = null;

    public AuditingQueryParameterParser() {
    }

    /**
     * generate the AuditingSearchCriteria based the map of parameters
     *
     * @param params the map of parameter passed by client
     *
     * @return the AuditingSearchCriteria
     */
    public AuditingSearchCriteria buildSearchCriteria(Map<String, String[]> params) {
        AuditingSearchCriteria auditingSearchCriteria = new AuditingSearchCriteria();

        if (params.containsKey(DATE_FROM)) {
            auditingSearchCriteria.setDateFrom(StringUtils.join(params.get(DATE_FROM), ""));
        }

        if (params.containsKey(DATE_TO)) {
            auditingSearchCriteria.setDateTo(StringUtils.join(params.get(DATE_TO), ""));
        }

        if (params.containsKey(FIRST_RESULT)) {
            auditingSearchCriteria.setFirstResult(Integer.parseInt(
                    StringUtils.join(params.get(FIRST_RESULT), "")));
        }

        if (params.containsKey(MAX_RESULTS)) {
            auditingSearchCriteria.setMaxResults(Integer.parseInt(
                    StringUtils.join(params.get(MAX_RESULTS), "")));
        }

        if (params.containsKey(SORT_COL_NAME)) {
            auditingSearchCriteria.setSortColName(StringUtils.join(params.get(SORT_COL_NAME), ""));
        }

        if (params.containsKey(IS_SORT_BY_ASC)) {
            auditingSearchCriteria.setSortByAsc(Boolean.parseBoolean(
                    StringUtils.join(params.get(IS_SORT_BY_ASC), "")));
        }

        String type = StringUtils.join(params.get(TYPE), "");

        if (type.equalsIgnoreCase(RT)) {
            List<String> authorizedInfo = new ArrayList<>(auditingEntitlementsService.getEntitlements(
                    StringUtils.join(params.get(USER), "")));

            auditingSearchCriteria.setAuthorizedItem(authorizedField);

            if (params.containsKey(TRACKING_ID)) {
                auditingSearchCriteria.setTrackingId(StringUtils.join(params.get(TRACKING_ID), ""));
            } else if (authorizedField.equalsIgnoreCase(AUTHORIZED_ITEM_T)) {
                auditingSearchCriteria.setAuthorizedInfo(authorizedInfo);
            }

            if (params.containsKey(SOURCE_SYS_ID)) {
                auditingSearchCriteria.setSourceSysId(StringUtils.join(params.get(SOURCE_SYS_ID), ""));
            } else if (authorizedField.equalsIgnoreCase(AUTHORIZED_ITEM_S)) {
                auditingSearchCriteria.setAuthorizedInfo(authorizedInfo);
            }

            if (params.containsKey(WILDCARD)) {
                auditingSearchCriteria.setWildcard(StringUtils.join(params.get(WILDCARD), ""));
            }

            if (params.containsKey(STATUS)) {
                auditingSearchCriteria.setStatus(StringUtils.join(params.get(STATUS), ""));
            }

            if (params.containsKey(CHANNEL)) {
                auditingSearchCriteria.setChannel(StringUtils.join(params.get(CHANNEL), ""));
            }

            if (params.containsKey(FILTER_FIELD)) {
                auditingSearchCriteria.setFilterField(StringUtils.join(params.get(FILTER_FIELD), ""));
            }
        } else if (type.equalsIgnoreCase(EOD)) {
            if (params.containsKey(TRADE_REF)) {
                auditingSearchCriteria.setTradeRef(StringUtils.join(params.get(TRADE_REF), ""));
            }

            if (params.containsKey(SYSTEM_ID)) {
                auditingSearchCriteria.setSystemId(StringUtils.join(params.get(SYSTEM_ID), ""));
            }
        } else if (type.equalsIgnoreCase(SDM)) {
            if (params.containsKey(USER_ID)) {
                auditingSearchCriteria.setUserId(StringUtils.join(params.get(USER_ID), ""));
            }

            if (params.containsKey(ENTITY_ID)) {
                auditingSearchCriteria.setEntityId(Long.parseLong(StringUtils.join(params.get(ENTITY_ID), "")));
            }

            if (params.containsKey(ACTION)) {
                auditingSearchCriteria.setAction(Enum.valueOf(AuditLogAction.class,
                        StringUtils.join(params.get(ACTION), "")));
            }

            if (params.containsKey(DETAIL)) {
                auditingSearchCriteria.setDetail(StringUtils.join(params.get(DETAIL), ""));
            }
        } else if (type.equalsIgnoreCase(EXCEPTION)) {
            if (params.containsKey(ACTOR)) {
                auditingSearchCriteria.setUserId(StringUtils.join(params.get(ACTOR), ""));
            }

            if (params.containsKey(TICKET_ID)) {
                auditingSearchCriteria.setTicketId(Long.parseLong(StringUtils.join(params.get(TICKET_ID), "")));
            }

            if (params.containsKey(ACTION)) {
                auditingSearchCriteria.setAction(Enum.valueOf(AuditLogAction.class,
                        StringUtils.join(params.get(ACTION), "")));
            }

            if (params.containsKey(COMMENTS)) {
                auditingSearchCriteria.setComments(StringUtils.join(params.get(COMMENTS), ""));
            }
        } else if (type.equalsIgnoreCase(MUREX)) {
            if (params.containsKey(USER_ID)) {
                auditingSearchCriteria.setUserId(StringUtils.join(params.get(USER_ID), ""));
            }

            if (params.containsKey(UPLOAD_SERVER_TYPE)) {
                auditingSearchCriteria.setUploadServerType(StringUtils.join(params.get(UPLOAD_SERVER_TYPE), ""));
            }

            if (params.containsKey(UPLOAD_FILE_TYPE)) {
                auditingSearchCriteria.setUploadFileType(StringUtils.join(params.get(UPLOAD_FILE_TYPE), ""));
            }
            if (params.containsKey(UPLOAD_FILE_NAME)) {
                auditingSearchCriteria.setUploadFileName(StringUtils.join(params.get(UPLOAD_FILE_NAME), ""));
            }
        }

        return auditingSearchCriteria;
    }
}
