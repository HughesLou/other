/*
 * Copyright (c) 2015. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.service.impl;

import com.scb.razor.mls.auditing.service.MessagePropertyService;
import com.scb.razor.mls.persistent.dao.MessagePropertyDao;
import com.scb.razor.mls.persistent.utils.PersistentConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Set;

/**
 * Description:
 * Author: 1466811
 * Date:   2:57 PM 8/6/15
 */
@Service
public class MessagePropertyServiceImpl implements MessagePropertyService {

    private static final Logger LOGGER = LoggerFactory.getLogger(MessagePropertyServiceImpl.class);

    @Resource
    private MessagePropertyDao messagePropertyDaoImpl = null;

    @Override
    @Transactional(readOnly = true)
    public Set<String> getPropertyKeys() {
        LOGGER.info("Start to get properties");
        Set<String> messageProperties = messagePropertyDaoImpl.getPropertyKeys();
        messageProperties.addAll(PersistentConstants.AuditRTMsgSearchItems.getAllTheAvailableItems());
        return messageProperties;
    }
}
