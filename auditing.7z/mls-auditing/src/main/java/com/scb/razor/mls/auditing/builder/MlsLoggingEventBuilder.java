/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.builder;

import com.scb.razor.mls.auditing.model.ArgumentLink;
import com.scb.razor.mls.auditing.model.MlsLoggingEvent;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class MlsLoggingEventBuilder {

    private long id;
    private String systemId;
    private String tradeRef;
    private Date date;
    private ArgumentLink argumentLink;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getSystemId() {
        return systemId;
    }

    public void setSystemId(String systemId) {
        this.systemId = systemId;
    }

    public String getTradeRef() {
        return tradeRef;
    }

    public void setTradeRef(String tradeRef) {
        this.tradeRef = tradeRef;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public ArgumentLink getArgumentLink() {
        return argumentLink;
    }

    public void setArgumentLink(ArgumentLink argumentLink) {
        this.argumentLink = argumentLink;
    }

    public MlsLoggingEvent build() {
        return new MlsLoggingEvent(this);
    }
}
