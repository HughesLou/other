package com.scb.razor.mls.auditing;

import java.io.File;
import java.lang.Thread.UncaughtExceptionHandler;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.jms.ConnectionFactory;
import javax.naming.Context;
import javax.naming.InitialContext;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jms.connection.UserCredentialsConnectionFactoryAdapter;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.concurrent.ConcurrentTaskScheduler;

import com.google.common.base.Objects;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.webmethods.jms.WmConnectionFactory;
import com.webmethods.jms.WmJMSFactory;

@Configuration
public class BeansConfiguration {

    private final static Logger log = LoggerFactory.getLogger(BeansConfiguration.class);
    
    @Autowired @Qualifier("configurationProperties")
    private Properties conf;
    
    @Bean
    public WorkingDirectory workingDirectory() throws Exception {
        String str = conf.getProperty("mls.workdir");
        if(StringUtils.isBlank(str)) {
            throw new RuntimeException("working directory not defined : ${mls.workdir}");
        }
        File dir = new File(str);
        if(!dir.exists()) {
            log.info("working directory not existing, try to create one");
            dir.mkdir();
        }
        if(!dir.isDirectory()) {
            throw new RuntimeException("not a directory : " + str);
        }
        WorkingDirectory wd = new WorkingDirectory(dir);
        File cacheFolder = wd.getCacheFolder();
        if(!cacheFolder.exists()) {
            log.info("cache folder doesn't exist, creating");
            cacheFolder.mkdir();
        }
        return wd;
    }
    
    @Bean(destroyMethod="shutdown")
    public ExecutorService alotThreadsExecutorService() throws Exception {
        ThreadFactoryBuilder b = new ThreadFactoryBuilder();
        b.setNameFormat("mls-thread-%d");
        b.setDaemon(false);
        b.setUncaughtExceptionHandler(new UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread t, Throwable e) {
                log.error("uncaught exception , you should handle every exception for the task submitted to executor service", e);
            }
        });
        int ncpu = Runtime.getRuntime().availableProcessors();
        int nthread = ncpu < 10 ? 10 : ncpu;
        return Executors.newFixedThreadPool(nthread * 2, b.build());
    }

    @Bean
    public TaskScheduler scheduler() throws Exception {
        ConcurrentTaskScheduler s = new ConcurrentTaskScheduler();
        s.setConcurrentExecutor(alotThreadsExecutorService());
        return s;
    }
    
    //@Bean 
    public ConnectionFactory jmsConnectionFactory() throws Exception {
        
        String initialContextFactory    = conf.getProperty(Context.INITIAL_CONTEXT_FACTORY),
                providerUrl             = conf.getProperty(Context.PROVIDER_URL),
                jndiName                = conf.getProperty("edmi.connectionFactory");
        
        if(StringUtils.isNotBlank(jndiName)) {
            Properties p = new Properties();
            p.put(Context.INITIAL_CONTEXT_FACTORY,  initialContextFactory);
            p.put(Context.PROVIDER_URL,             providerUrl);
            
            log.info(String.format("jms cf : {} {} {}", initialContextFactory, providerUrl, jndiName));
            
            Context context = new InitialContext(p);
            ConnectionFactory connFactory = (ConnectionFactory) context.lookup(jndiName);
            return connFactory;
        } 
        
        WmConnectionFactory wmcf = WmJMSFactory.getTopicConnectionFactory();

        String  brokerHost  = conf.getProperty("middlewareBrokerHostPort"),
                brokerName  = conf.getProperty("middlewareBrokerName"),
                clientId    = conf.getProperty("clientId"),
                application = conf.getProperty("application"),
                clientGroup = conf.getProperty("clientGroup");
        
        wmcf.setClientGroup(clientGroup);
        wmcf.setBrokerHost(brokerHost);
        wmcf.setBrokerName(brokerName);
        wmcf.setApplication(application);
        if(StringUtils.isNotBlank(clientId)) {
            wmcf.setClientID(clientId);
        }
        
        String  sslEnabled        = conf.getProperty("mls.wm.ssl.enable"),
                sslKeyStore       = conf.getProperty("mls.broker.ssl.keyStore"),
                sslKeyStoreType   = conf.getProperty("mls.broker.ssl.keyStore.type"),
                sslTrustStore     = conf.getProperty("mls.broker.ssl.trustStore"),
                sslTrustStoreType = conf.getProperty("mls.broker.ssl.trustStore.type"),
                sslEncrypted      = conf.getProperty("mls.broker.ssl.encrypted"),
                sslUsername       = conf.getProperty("mls.broker.ssl.username"),
                sslPassword       = conf.getProperty("mls.broker.ssl.password");
        
        if(Objects.equal("true", sslEnabled)){
            ClassPathResource store1 = new ClassPathResource(sslKeyStore);
            ClassPathResource store2 = new ClassPathResource(sslTrustStore);
            wmcf.setSSLKeystoreType(sslKeyStoreType);
            wmcf.setSSLKeystore(store1.getFile().getPath());
            wmcf.setSSLTruststoreType(sslTrustStoreType);
            wmcf.setSSLTruststore(store2.getFile().getPath());
            wmcf.setSSLEncrypted(Objects.equal("true", sslEncrypted));
        }
        if(StringUtils.isNotBlank(sslUsername)) {
            UserCredentialsConnectionFactoryAdapter adapter = new UserCredentialsConnectionFactoryAdapter();
            adapter.setTargetConnectionFactory(wmcf);
            adapter.setUsername(sslUsername);
            adapter.setPassword(sslPassword);
            return adapter;
        }
        return wmcf;
    }
    //@bean ssl context
}
