package com.scb.razor.mls.auditing.lucene.exceptions;

import com.scb.razor.mls.auditing.BusEvent;

public class ActionPerformEvent implements BusEvent{

    private String action;
    
    private String targetId;
    
    public static ActionPerformEvent newMls(String action, String id) {
        MlsExceptionActionPerformEvent evt = new MlsExceptionActionPerformEvent();
        evt.setAction(action);
        evt.setTargetId(id);
        return evt;
    }
    
    public static ActionPerformEvent newMurex(String action, String id) {
        MurexExceptionActionPerformEvent evt = new MurexExceptionActionPerformEvent();
        evt.setAction(action);
        evt.setTargetId(id);
        return evt;
    }
    
    public static class MlsExceptionActionPerformEvent extends ActionPerformEvent {
        public Long getId() {
            return Long.valueOf(getTargetId());
        }
    }
    
    public static class MurexExceptionActionPerformEvent extends ActionPerformEvent {
        public Long getId() {
            return Long.valueOf(getTargetId());
        }
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getTargetId() {
        return targetId;
    }

    public void setTargetId(String targetId) {
        this.targetId = targetId;
    }
}
