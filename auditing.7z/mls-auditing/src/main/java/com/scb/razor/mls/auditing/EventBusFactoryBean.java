package com.scb.razor.mls.auditing;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import com.google.common.eventbus.AsyncEventBus;
import com.google.common.eventbus.EventBus;
import com.google.common.util.concurrent.ThreadFactoryBuilder;

/**
 * <p>Event will be sent to <b><em>ALL</em></b> corresponding handlers registered to EventBus.
 *   it will scan all spring managed beans for handlers.
 *   event handling will be <b><em>ASYNC</em></b> and by default 1 thread executor
 * </p>
 * 
 * how to use it <br/>
 * <pre>
 * class A {
 *  &nbsp;@Autowired EventBus bus;
 * 
 *   public void someAction() {
 *     //do something
 *     bus.post(new SomeEvent());
 *   }
 * }
 * class B {
 *  &nbsp;@Subscribe
 *   public void onSomeEvent(SomeEvent e) {
 *    //print e;
 *  }
 * }
 * </pre>
 * <p> B should be spring managed beans so that EventBus can detect annotation <em>Subscribe</em>
 */
@Component
public class EventBusFactoryBean implements FactoryBean<EventBus>, ApplicationListener<ContextRefreshedEvent> {

    private final static Logger log = LoggerFactory.getLogger(EventBusFactoryBean.class);

    @Override
    public EventBus getObject() throws Exception {
        ThreadFactory fac = new ThreadFactoryBuilder()
            .setDaemon(false)
            .setNameFormat("eventbus-%d")
            .build();
        Executor e = Executors.newFixedThreadPool(3, fac);
        EventBus bus = new AsyncEventBus("eventbus", e);

        log.info(String.format("EventBus created with 1 thread as executors : %s", bus));
        return bus;
    }

    @Override
    public Class<?> getObjectType() {
        return EventBus.class;
    }

    @Override
    public boolean isSingleton() {
        return true;
    }

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        log.info("spring context started, now register beans to eventbus");
        ApplicationContext ctx = event.getApplicationContext();
        EventBus bus = ctx.getBean(EventBus.class);
        for (String id : ctx.getBeanDefinitionNames()) {
            if (ctx.getType(id) == EventBus.class)
                continue;// bypass itself
            bus.register(ctx.getBean(id));// all spring beans are scanned for
                                          // annotation @Subscribe
        }
    }
}
