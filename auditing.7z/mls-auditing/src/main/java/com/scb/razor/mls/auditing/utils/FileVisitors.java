package com.scb.razor.mls.auditing.utils;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;

import com.google.common.base.Function;
import com.google.common.base.Objects;

public class FileVisitors {

    public static FileVisitor<Path> byFunction(final Function<Path, Void> func) {
        
        return new SimpleFileVisitor<Path>(){
            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                func.apply(file);
                return super.visitFile(file, attrs);
            }
        };
    }
    
    public static FileVisitor<Path> deleteAllFilesExcept(final String... excludeNames) {
        
        return byFunction(new Function<Path, Void>() {
            public Void apply(Path input) {
                String name = input.toFile().getName();
                for(String i : excludeNames) {
                    if(Objects.equal(i, name)) {
                        return null;
                    }
                }
                try {
                    Files.delete(input);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                return null;
            }
        });
    }
}
