package com.scb.razor.mls.auditing.lucene;

import java.util.Set;

import com.scb.razor.mls.auditing.BusEvent;

/**
 * Message entity created or updated
 * @author 1510954
 */
public class MessageEntityChangedEvent implements BusEvent {

    private Set<Long> messageIds;

    public Set<Long> getMessageIds() {
        return messageIds;
    }

    public void setMessageIds(Set<Long> messageIds) {
        this.messageIds = messageIds;
    }
    
    public static MessageEntityChangedEvent create(Set<Long> ids) {
        MessageEntityChangedEvent me = new MessageEntityChangedEvent();
        me.setMessageIds(ids);
        return me;
    }
}
