/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.mapping;

import com.scb.razor.mls.auditing.builder.MlsAuditLogBuilder;
import com.scb.razor.mls.auditing.model.MlsAuditLog;
import com.scb.razor.mls.persistent.model.StaticMappingAudit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: 1466811
 * Date:   12:23 PM 4/9/14
 */
@Component
public class AuditLogMapper {

    private static final Logger logger = LoggerFactory.getLogger(AuditLogMapper.class);

    /**
     * map AuditLog to MlsAuditLogBuilder
     *
     * @param auditLog the data searched from database
     *
     * @return the MlsAuditLogBuilder which is used to built MlsAuditLog
     */
    public MlsAuditLogBuilder mapToMlsAuditLog(StaticMappingAudit auditLog) {
        MlsAuditLogBuilder mlsAuditLogBuilder = new MlsAuditLogBuilder();

        mlsAuditLogBuilder.setId(auditLog.getId());
        mlsAuditLogBuilder.setUserId(auditLog.getUserId());
        mlsAuditLogBuilder.setEntityId(auditLog.getEntityId());
        mlsAuditLogBuilder.setAction(auditLog.getAction());
        mlsAuditLogBuilder.setDetail(auditLog.getDetail());
        mlsAuditLogBuilder.setCreatedDate(auditLog.getCreatedDate());

        logger.debug("Mapping AuditLog {} successfully!", auditLog.getId());

        return mlsAuditLogBuilder;
    }

    /**
     * get the list of MlsAuditLog from a list of AuditLog
     *
     * @param auditLogs the list of AuditLog searched from database
     *
     * @return the list of MlsAuditLog
     */
    public List<MlsAuditLog> mapToMlsAuditLogCollection(List<StaticMappingAudit> auditLogs) {
        List<MlsAuditLog> mlsAuditLogs = new ArrayList<>();

        for (StaticMappingAudit auditLog : auditLogs) {
            mlsAuditLogs.add(mapToMlsAuditLog(auditLog).build());
        }

        return mlsAuditLogs;
    }
}
