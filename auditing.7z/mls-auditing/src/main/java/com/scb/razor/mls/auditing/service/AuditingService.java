/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.service;

import com.scb.razor.mls.auditing.model.*;
import com.scb.razor.mls.persistent.model.Message;
import com.scb.razor.mls.persistent.search.AuditingSearchCriteria;

import java.net.URI;
import java.util.List;
import java.util.Set;

public interface AuditingService {

    Set<String> getAvailableSourceSysIds(String userId);

    Set<String> getAvailableStatuses();

    Set<String> getAvailableChannels();

    Set<String> getAvailableKeys();

    List<String> getAvailableActions();

    List<String> getExceptionActions();

    List<MlsMessage> listMessages(List<Long> ids, String userId, URI uri);

    List<MlsMessage> listMessagesByTrackingId(List<String> trackingIds, String userId, URI uri);

    List<MlsMessage> listMessages(AuditingSearchCriteria searchCriteria, String userId, URI uri);

    MlsMessage getMessageById(String id);

    Long getMessagesAmount(AuditingSearchCriteria searchCriteria, String userId);

    List<MlsLoggingEvent> listLoggingEvents(AuditingSearchCriteria searchCriteria, URI uri);

    Long getLoggingEventsAmount(AuditingSearchCriteria searchCriteria);

    List<MlsAuditLog> listAuditLogs(AuditingSearchCriteria searchCriteria);

    Long getAuditLogsAmount(AuditingSearchCriteria searchCriteria);

    List<MlsExceptionAction> listExceptionActions(AuditingSearchCriteria searchCriteria);

    Long getExceptionActionsAmount(AuditingSearchCriteria searchCriteria);

    Long getMurexAuditAmount(AuditingSearchCriteria searchCriteria);

    List<MlsMurexAuditLog> listMurexAudit(AuditingSearchCriteria searchCriteria);
	
    Message getMessageByIdentity(long id);

    Message getNackOriginalMessage(String trackingId,String sourceSysId);
}