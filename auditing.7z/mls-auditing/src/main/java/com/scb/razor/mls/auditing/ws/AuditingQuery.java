/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.ws;

import com.scb.razor.mls.auditing.model.*;
import com.scb.razor.mls.auditing.service.AuditingService;
import com.scb.razor.mls.persistent.search.AuditingSearchCriteria;
import com.scb.sabre.ticketing.model.Error;
import com.scb.sabre.ticketing.ws.MessageWrapper;
import com.scb.sabre.ws.messaging.Interest;
import com.scb.sabre.ws.messaging.MessagePublisher;
import com.scb.sabre.ws.messaging.MessageSubscription;
import com.scb.sabre.ws.messaging.SubscriptionManager;
import com.scb.sabre.ws.socket.annotation.OnClose;
import com.scb.sabre.ws.socket.annotation.OnConnection;
import com.scb.sabre.ws.socket.annotation.WebSocket;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.net.URI;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import static com.scb.razor.mls.persistent.utils.PersistentConstants.*;

@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@WebSocket(uri = "/Auditing")
public class AuditingQuery implements MessageSubscription<String> {

    private static final Logger logger = LoggerFactory.getLogger(AuditingQuery.class);
    private SubscriptionManager subManager;
    @Autowired
    private AuditingService auditingServiceImpl = null;
    @Autowired
    private AuditingQueryParameterParser auditingQueryParameterParser = null;

    @OnClose
    public void onClose() {
        subManager.unsubscribe();
    }

    /**
     * get the list of available data and publish them to the client
     *
     * @param publisher  the publisher
     * @param parameters the parameters for searching
     * @param uri        the client uri
     *
     * @throws IOException
     * @throws ParseException
     */
    @OnConnection
    public void onConnection(final MessagePublisher<MessageWrapper<Object[]>> publisher,
                             final Map<String, String[]> parameters, final URI uri) throws IOException {

        String userId = StringUtils.join(parameters.get("user"), "");

        logger.info("Loading data based on query params by user {}", userId);

        String type = StringUtils.join(parameters.get(TYPE), "");

        AuditingSearchCriteria searchCriteria = auditingQueryParameterParser.buildSearchCriteria(parameters);

        try {
            if (type.equals(RT)) {
                List<MlsMessage> mlsMessages = auditingServiceImpl.listMessages(searchCriteria, userId, uri);
                publisher.publish(new MessageWrapper<Object[]>("UpdateMessage",
                        mlsMessages.toArray(new MlsMessage[mlsMessages.size()])));
            } else if (type.equals(EOD)) {
                List<MlsLoggingEvent> mlsLoggingEvents = auditingServiceImpl.listLoggingEvents(searchCriteria, uri);
                publisher.publish(new MessageWrapper<Object[]>("UpdateLoggingEvent",
                        mlsLoggingEvents.toArray(new MlsLoggingEvent[mlsLoggingEvents.size()])));
            } else if (type.equals(SDM)) {
                List<MlsAuditLog> mlsAuditLogs = auditingServiceImpl.listAuditLogs(searchCriteria);
                publisher.publish(new MessageWrapper<Object[]>("UpdateAuditLog",
                        mlsAuditLogs.toArray(new MlsAuditLog[mlsAuditLogs.size()])));
            } else if (type.equals(EXCEPTION)) {
                List<MlsExceptionAction> actions = auditingServiceImpl.listExceptionActions(searchCriteria);
                publisher.publish(new MessageWrapper<Object[]>("UpdateExceptionAction",
                        actions.toArray(new MlsExceptionAction[actions.size()])));
            } else if (type.equals(MUREX)) {
                List<MlsMurexAuditLog> actions = auditingServiceImpl.listMurexAudit(searchCriteria);
                publisher.publish(new MessageWrapper<Object[]>("UpdateMurexAuditLog",
                        actions.toArray(new MlsMurexAuditLog[actions.size()])));
            } else {
                logger.error("Type is not available");
            }
            logger.info("Data has been published to web socket");
        } catch (Exception ex) {
            logger.error(String.format("Error while getting data: %s", ex.getMessage()), ex);
            publisher.publishError(MessageWrapper.createError(new Error(ex)));
        }
    }

    @Override
    public void onMessage(Interest<String> tInterest, String message) {}
}
