/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.ws

import com.scb.sabre.ticketing.security.EntitlementsService
import spock.lang.Specification

import static com.scb.razor.mls.persistent.utils.PersistentConstants.*
import static org.mockito.Matchers.anyString
import static org.mockito.Mockito.mock
import static org.mockito.Mockito.when

/**
 * Description:
 * Author: 1466811
 * Date:   5:58 PM 5/16/14
 */
class AuditingQueryParameterParserTest extends Specification {

    def "build the SearchCriteria based on a map"() {
        given:
        def auditingEntitlementsService = mock(EntitlementsService.class);
        def parser = new AuditingQueryParameterParser();
        def field = AuditingQueryParameterParser.class.getDeclaredField("auditingEntitlementsService");
        field.setAccessible(true);
        field.set(parser, auditingEntitlementsService);
        def authorizedField = "SOURCE_SYS_ID"
        def pro = AuditingQueryParameterParser.class.getDeclaredField("authorizedField");
        pro.setAccessible(true);
        pro.set(parser, authorizedField);

        def type0 = RT;
        def type1 = EOD;
        def type2 = SDM;
        def type3 = EXCEPTION;

        def dateFrom = "14-07-2014"
        def dateTo = "30-07-2014"
        def firstResult = "0";
        def maxResults = "20";
        def sortColName = "TEST_SORT_COL_NAME";
        def isSortByAsc = "TEST_IS_SORT_BY_ASC";

        def trackingId = "TEST_TRACKING_ID";
        def sourceSysId = "TEST_SOURCE_SYS_ID";
        def status = "TEST_STATUS";
        def filter_field = "TEST_FILTER_FIELD";

        def tradeRef = "TEST_TRADE_REF"
        def systemId = "TEST_SYSTEM_ID"

        def userId = "1466811";
        def entityId = "100"
        def action = "create"
        def detail = "TEST_DETAIL"

        def actor = "TEST_ACTOR"
        def ticketId = "200"
        def comments = "TEST_COMMENTS"

        def entitlements = new HashSet<String>();
        entitlements.add("TEST");

        def queryString = new HashMap<String, String[]>();
        queryString.put(USER, (String[]) [userId]);
        queryString.put(USER_ID, (String[]) [userId]);
        queryString.put(STATUS, (String[]) [status]);
        queryString.put(FILTER_FIELD, (String[]) [filter_field]);
        queryString.put(FIRST_RESULT, [firstResult].toArray())
        queryString.put(MAX_RESULTS, [maxResults].toArray())
        queryString.put(TRADE_REF, [tradeRef].toArray())
        queryString.put(SYSTEM_ID, [systemId].toArray())
        queryString.put(ENTITY_ID, [entityId].toArray())
        queryString.put(ACTION, [action].toArray())
        queryString.put(DATE_FROM, [dateFrom].toArray())
        queryString.put(DATE_TO, [dateTo].toArray())
        queryString.put(STATUS, [status].toArray())
        queryString.put(SORT_COL_NAME, [sortColName].toArray())
        queryString.put(IS_SORT_BY_ASC, [isSortByAsc].toArray())
        queryString.put(DETAIL, [detail].toArray())
        queryString.put(ACTOR, [actor].toArray())
        queryString.put(TICKET_ID, [ticketId].toArray())
        queryString.put(COMMENTS, [comments].toArray())


        when(auditingEntitlementsService.getEntitlements(anyString())).thenReturn(entitlements);

        when:
        queryString.put(TYPE, (String[]) [type0]);
        def criteria0 = parser.buildSearchCriteria(queryString);
        queryString.put(TRACKING_ID, (String[]) [trackingId]);
        queryString.put(SOURCE_SYS_ID, (String[]) [sourceSysId]);
        queryString.put(TYPE, (String[]) [type0]);
        def criteria01 = parser.buildSearchCriteria(queryString);
        queryString.put(TYPE, (String[]) [type1]);
        def criteria1 = parser.buildSearchCriteria(queryString);
        queryString.put(TYPE, (String[]) [type2]);
        def criteria2 = parser.buildSearchCriteria(queryString);
        queryString.put(TYPE, (String[]) [type3]);
        def criteria3 = parser.buildSearchCriteria(queryString);

        authorizedField = "TRACKING_ID"
        pro = AuditingQueryParameterParser.class.getDeclaredField("authorizedField");
        pro.setAccessible(true);
        pro.set(parser, authorizedField);
        queryString.remove(TRACKING_ID)
        queryString.put(TYPE, (String[]) [type0]);
        def criteria02 = parser.buildSearchCriteria(queryString);

        then:
        criteria0.getFirstResult().equals(Integer.parseInt(firstResult));
        criteria0.getMaxResults().equals(Integer.parseInt(maxResults));
        criteria01.getTrackingId().equals(trackingId);
        criteria01.getSourceSysId().equals(sourceSysId);
        criteria1.getTradeRef().equals(tradeRef)
        criteria2.getDetail().equals(detail)
        criteria3.getUserId().equals(actor)
        criteria02.getFilterField().equals(filter_field)
    }
}
