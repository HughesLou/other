/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.mapping

import com.scb.razor.mls.common.constants.MLS
import com.scb.razor.mls.persistent.model.Message
import com.scb.razor.mls.persistent.model.MessageProperty
import spock.lang.Shared
import spock.lang.Specification

/**
 * Description:
 * Author: 1466811
 * Date:   9:57 AM 5/14/14
 */
public class MessageMapperTest extends Specification {

    @Shared messageMapper;
    @Shared message;
    @Shared uri;
    @Shared id;
    @Shared userId;

    def setupSpec() {
        messageMapper = new MessageMapper();
        uri = new URI("http://localhost:8094/mls-auditing-service/");

        id = 1000L;
        message = new Message(id);
        message.setStatus(Message.Status.RECEIVED);
        message.setContent("test".getBytes());
        message.setContentType(Message.ContentType.TEXT);
        message.setCreateTimeStamp(Calendar.getInstance().getTime());
        message.setSourceSysId(MLS.Interface.findByAlias("ctpy"));
        message.setTrackingId("1392799091118");

        MessageProperty messageProperty = new MessageProperty(1001L);
        messageProperty.setKey("ORIG_JMSXDeliveryCount");
        messageProperty.setValue("AAA");
        messageProperty.setMessage(message);

        Set<MessageProperty> messageProperties = new HashSet<MessageProperty>();
        messageProperties.add(messageProperty);
        message.setMessageProperties(messageProperties);
    }

    /**
     * Test method for mapToMlsMessage()
     */
    def "Map a message to MlsMessageBuilder"() {
        given: "accept the message and the uri"
        def mlsMessageBuilder = messageMapper.mapToMlsMessage(message, uri,userId);

        expect: "the MlsMessageBuilder is not null"
        mlsMessageBuilder != null;
    }

    /**
     * Test method for mapToMlsMessageCollection()
     */
    def "Map a message list to MlsMessage list"() {
        given: "accept the message list and the uri"
        def messages = new ArrayList<Message>();
        messages.add((Message) message);

        when:
        def mlsMessages = messageMapper.mapToMlsMessageCollection(messages, uri,userId);

        then: "the size is 1"
        mlsMessages.size() == 1;
    }
}
