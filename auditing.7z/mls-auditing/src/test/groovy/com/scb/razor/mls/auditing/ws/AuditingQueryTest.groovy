/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.ws

import com.scb.razor.mls.auditing.model.MlsAuditLog
import com.scb.razor.mls.auditing.model.MlsExceptionAction
import com.scb.razor.mls.auditing.model.MlsLoggingEvent
import com.scb.razor.mls.auditing.model.MlsMessage
import com.scb.razor.mls.auditing.service.impl.AuditingServiceImpl
import com.scb.razor.mls.persistent.search.AuditingSearchCriteria
import com.scb.sabre.ws.messaging.MessagePublisher
import com.scb.sabre.ws.messaging.SubscriptionManager
import org.mockito.ArgumentCaptor
import spock.lang.Specification

import static com.scb.razor.mls.persistent.utils.PersistentConstants.*
import static org.mockito.Matchers.*
import static org.mockito.Mockito.*

/**
 * Description:
 * Author: 1466811
 * Date:   5:58 PM 5/16/14
 */
class AuditingQueryTest extends Specification {

    def "search results"() {
        given:
        def parameters0 = new HashMap<String, String[]>();
        parameters0.put(TYPE, (String[]) [RT]);
        def result0 = new ArrayList<MlsMessage>();
        def parameters1 = new HashMap<String, String[]>();
        parameters1.put(TYPE, (String[]) [EOD]);
        def result1 = new ArrayList<MlsLoggingEvent>();
        def parameters2 = new HashMap<String, String[]>();
        parameters2.put(TYPE, (String[]) [SDM]);
        def result2 = new ArrayList<MlsAuditLog>();
        def parameters3 = new HashMap<String, String[]>();
        parameters3.put(TYPE, (String[]) [EXCEPTION]);
        def result3 = new ArrayList<MlsExceptionAction>();
        def parameters4 = new HashMap<String, String[]>();
        parameters4.put(TYPE, (String[]) ["TEST"]);
        def uri = new URI("http://localhost:8094/mls-auditing-service/");

        def auditingQuery = new AuditingQuery();
        def searchCriteria = new AuditingSearchCriteria();
        def auditingServiceImpl = spy(new AuditingServiceImpl());
        def auditingQueryParameterParser = spy(new AuditingQueryParameterParser());
        def publisher = mock(MessagePublisher.class);

        def field0 = AuditingQuery.class.getDeclaredField("auditingServiceImpl");
        field0.setAccessible(true);
        field0.set(auditingQuery, auditingServiceImpl);

        def field1 = AuditingQuery.class.getDeclaredField("auditingQueryParameterParser");
        field1.setAccessible(true);
        field1.set(auditingQuery, auditingQueryParameterParser);

        when:
        doReturn(searchCriteria).when(auditingQueryParameterParser).buildSearchCriteria(anyMap())
        doReturn(result0).when(auditingServiceImpl).listMessages(searchCriteria, null, uri)
        doReturn(result1).when(auditingServiceImpl).listLoggingEvents(any(AuditingSearchCriteria.class),
                any(URI.class))
        doReturn(result2).when(auditingServiceImpl).listAuditLogs(any(AuditingSearchCriteria.class))
        doReturn(result3).when(auditingServiceImpl).listExceptionActions(any(AuditingSearchCriteria.class))
        doNothing().when(publisher).publish(anyObject());

        auditingQuery.onConnection(publisher, parameters0, uri);
        auditingQuery.onConnection(publisher, parameters1, uri);
        auditingQuery.onConnection(publisher, parameters2, uri);
        auditingQuery.onConnection(publisher, parameters3, uri);
        auditingQuery.onConnection(publisher, parameters4, uri);

        then:
        def captor = ArgumentCaptor.forClass(Object.class)
        verify(publisher, times(4)).publish(captor.capture())
    }

    def "test onClose"() {
        given:
        def auditingQuery = new AuditingQuery();
        def subManager = mock(SubscriptionManager.class)
        def field = AuditingQuery.class.getDeclaredField("subManager");
        field.setAccessible(true);
        field.set(auditingQuery, subManager);

        when:
        doNothing().when(subManager).unsubscribe()
        auditingQuery.onClose()

        then:
        verify(subManager).unsubscribe()
    }
}
