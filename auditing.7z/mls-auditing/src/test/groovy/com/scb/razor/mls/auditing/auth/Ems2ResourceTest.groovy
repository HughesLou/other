package com.scb.razor.mls.auditing.auth

import spock.lang.Specification;

class Ems2ResourceTest extends Specification {
    
    def srv
    def baseUrl
    
    def setup() {
        srv = com.sun.net.httpserver.HttpServer.create(new InetSocketAddress(0), 0)
        srv.start()
        baseUrl = "http://localhost:${srv.address.port}/"
    }
    
    def cleanup() {
        srv.stop(1) //delay 1 seconds
    }
    
    def "test resource"() {
        given : 
            srv.createContext("/", {ex ->
                    def uri = ex.getRequestURI().toString();
                    def resp = ""
                    switch(uri) {
                        case "/ems2/rest/entity/RAZOR_MLS_EXCEPTION" : 
                            resp = '{"name":"RAZOR_MLS_EXCEPTION","locked":true,"id":451064}';
                            break;
                        case "/ems2/rest/entity/451064/roles" : 
                            resp = '{"count":6,"roles":[{"name":"DEV","entity":{"name":"RAZOR_MLS_EXCEPTION","locked":true,"id":451064},"id":519159},{"name":"EMS2_ADMIN","entity":{"name":"RAZOR_MLS_EXCEPTION","locked":true,"id":451064},"id":451147},{"name":"FMO","entity":{"name":"RAZOR_MLS_EXCEPTION","locked":true,"id":451064},"id":451149},{"name":"FMO_ADMIN","entity":{"name":"RAZOR_MLS_EXCEPTION","locked":true,"id":451064},"id":531450},{"name":"PSRD","entity":{"name":"RAZOR_MLS_EXCEPTION","locked":true,"id":451064},"id":527503},{"name":"PSS","entity":{"name":"RAZOR_MLS_EXCEPTION","locked":true,"id":451064},"id":519151}]}';
                            break;
                        case "/ems2/rest/user/role/519159" : 
                            resp = '{"count":15,"users":[{"loginId":"1439970","fullName":"Sarah Zhao","lineManagerId":null,"lineManagerName":null,"id":437458},{"loginId":"1466811","fullName":"Zhiwei Lu","lineManagerId":null,"lineManagerName":null,"id":437492},{"loginId":"1470797","fullName":"Xi Zhang","lineManagerId":null,"lineManagerName":null,"id":437495},{"loginId":"1478480","fullName":"Min Li","lineManagerId":null,"lineManagerName":null,"id":437497},{"loginId":"1394207","fullName":"Ji Wang","lineManagerId":null,"lineManagerName":null,"id":437498},{"loginId":"1439115","fullName":"YiFan Zhang","lineManagerId":null,"lineManagerName":null,"id":437499},{"loginId":"1439153","fullName":"Bi Hai Tian","lineManagerId":null,"lineManagerName":null,"id":520000},{"loginId":"1453731","fullName":"Wenfeng Jiang","lineManagerId":null,"lineManagerName":null,"id":520014},{"loginId":"1408677","fullName":"Rakesh Chimanpure","lineManagerId":null,"lineManagerName":null,"id":2099},{"loginId":"1403768","fullName":"Christine Haiou Zhu","lineManagerId":null,"lineManagerName":null,"id":528610},{"loginId":"1425145","fullName":"Krishna Raju K V","lineManagerId":null,"lineManagerName":null,"id":546553},{"loginId":"1168721","fullName":"Vikranth S","lineManagerId":null,"lineManagerName":null,"id":546554},{"loginId":"1535027","fullName":"Ferry Van Het Groenewoud","lineManagerId":null,"lineManagerName":null,"id":546557},{"loginId":"1506618","fullName":"Hon Haw Chong","lineManagerId":null,"lineManagerName":null,"id":546555},{"loginId":"1462612","fullName":"Abhishek Gupta","lineManagerId":null,"lineManagerName":null,"id":546556}]}';
                            break;
                        case "/ems2/rest/entitlements/entity/name/RAZOR_MLS_EXCEPTION/user/1439970" : 
                            resp = '{"count":1,"entitlements":[{"subject":{"name":"RT|ALM_MX3|TechnicalException","entity":{"name":"RAZOR_MLS_EXCEPTION","locked":true,"id":451064},"longName":"/RT|ALM_MX3|TechnicalException","id":527564},"action":{"name":"EXECUTE","entity":{"name":"RAZOR_MLS_EXCEPTION","locked":true,"id":451064},"id":451176},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_EXCEPTION","locked":true,"id":451064},"id":519159},"id":527610}]}';
                            break;
                        
                    }
                    ex.getResponseHeaders().add("Content-Type", "application/json");
                    ex.sendResponseHeaders(200, resp.getBytes().length)
                    ex.getResponseBody().write(resp.getBytes())
                    ex.getResponseBody().close()
                })
            def ems2 = new Ems2Resource(baseUrl: baseUrl)
            ems2.afterPropertiesSet()
        
        when :
            def entity = ems2.getEntityByName("RAZOR_MLS_EXCEPTION")
            def roles = ems2.getRolesByEntityId(entity.id + "")
            def entitlements = ems2.getEntitlementsByEntityNameAndLoginId("RAZOR_MLS_EXCEPTION", "1439970")
            
        then :
            entity.name == "RAZOR_MLS_EXCEPTION"
            roles.size() == 6
            entitlements.size() == 1
    }
    
    def "test cache hit within timeout"() {
        given :
            def callCount = 0
            srv.createContext("/", {ex->
                    def uri = ex.getRequestURI().toString();
                    def resp = ""
                    switch(uri) {
                        case "/ems2/rest/entity/RAZOR_MLS_EXCEPTION" :
                            resp = '{"name":"RAZOR_MLS_EXCEPTION","locked":true,"id":451064}';
                            callCount++;
                            break;
                        
                    }
                    ex.getResponseHeaders().add("Content-Type", "application/json");
                    ex.sendResponseHeaders(200, resp.getBytes().length)
                    ex.getResponseBody().write(resp.getBytes())
                    ex.getResponseBody().close()
                })
            def ems2 = new Ems2Resource(baseUrl: baseUrl)
            ems2.afterPropertiesSet()
        
        when :
            ems2.getEntityByName("RAZOR_MLS_EXCEPTION")
            ems2.getEntityByName("RAZOR_MLS_EXCEPTION")
            ems2.getEntityByName("RAZOR_MLS_EXCEPTION")
            
        then :
            callCount == 1
    }
    
    def "test request again if cache expire"() {
        given :
            def callCount = 0
            srv.createContext("/", {ex->
                    def uri = ex.getRequestURI().toString();
                    def resp = ""
                    switch(uri) {
                        case "/ems2/rest/entity/RAZOR_MLS_EXCEPTION" :
                            resp = '{"name":"RAZOR_MLS_EXCEPTION","locked":true,"id":451064}';
                            callCount++;
                            break;
                        
                    }
                    ex.getResponseHeaders().add("Content-Type", "application/json");
                    ex.sendResponseHeaders(200, resp.getBytes().length)
                    ex.getResponseBody().write(resp.getBytes())
                    ex.getResponseBody().close()
                })
            def ems2 = new Ems2Resource(baseUrl: baseUrl)
            ems2.setCacheTimeoutSeconds(1)
            ems2.afterPropertiesSet()
        
        when :
            ems2.getEntityByName("RAZOR_MLS_EXCEPTION")
            def c2 = callCount
            ems2.getEntityByName("RAZOR_MLS_EXCEPTION")
            def c3 = callCount
            sleep(1300)
            ems2.getEntityByName("RAZOR_MLS_EXCEPTION")
            def c4 = callCount
            
        then :
            c2 == 1
            c3 == 1
            c4 == 2
    }
    
    def "test #invalidateCache"() {
        given :
            def callCount = 0
            srv.createContext("/", {ex->
                    def uri = ex.getRequestURI().toString();
                    def resp = ""
                    switch(uri) {
                        case "/ems2/rest/entity/RAZOR_MLS_EXCEPTION" :
                            resp = '{"name":"RAZOR_MLS_EXCEPTION","locked":true,"id":451064}';
                            callCount++;
                            break;
                        
                    }
                    ex.getResponseHeaders().add("Content-Type", "application/json");
                    ex.sendResponseHeaders(200, resp.getBytes().length)
                    ex.getResponseBody().write(resp.getBytes())
                    ex.getResponseBody().close()
                })
            def ems2 = new Ems2Resource(baseUrl: baseUrl)
            ems2.setCacheTimeoutSeconds(100)
            ems2.afterPropertiesSet()
        
        when :
            ems2.getEntityByName("RAZOR_MLS_EXCEPTION")
            def c2 = callCount
            ems2.getEntityByName("RAZOR_MLS_EXCEPTION")
            def c3 = callCount
            ems2.invalidateCache()
            ems2.getEntityByName("RAZOR_MLS_EXCEPTION")
            def c4 = callCount
            
        then :
            c2 == 1
            c3 == 1
            c4 == 2
    }
    
    def "test request only once if many concurrent requesters"() {
        //TODO implement the case
        //concurrency control, if 2 request same url, only one should pass and the other wait for the result for reuse
        when :
        def a = 1
        then :
        a == 1
    }
}
