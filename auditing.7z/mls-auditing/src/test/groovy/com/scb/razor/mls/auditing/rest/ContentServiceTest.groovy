/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.rest

import com.scb.razor.mls.common.constants.MLS
import com.scb.razor.mls.persistent.dao.impl.MessageDaoImpl
import com.scb.razor.mls.persistent.model.Message
import com.scb.razor.mls.persistent.model.MessageProperty
import spock.lang.Specification

import static org.mockito.Matchers.anyLong
import static org.mockito.Mockito.doReturn
import static org.mockito.Mockito.spy

/**
 * Description:
 * Author: 1466811
 * Date:   1:52 PM 5/16/14
 */
class ContentServiceTest extends Specification {
    /**
     * Test method for getContent()
     */
    def "get the Message content by id"() {
        given:
        def contentService = new ContentService();
        def id = 1000L;
        def userId = "1466811";
        def message = new Message(id);
        message.setStatus(Message.Status.RECEIVED);
        message.setContent("test".getBytes());
        message.setContentType(Message.ContentType.TEXT)

        message.setCreateTimeStamp(Calendar.getInstance().getTime());
        message.setSourceSysId(MLS.Interface.findByAlias("ctpy"));
        message.setTrackingId("1392799091118");

        MessageProperty messageProperty = new MessageProperty(1001L);
        messageProperty.setKey("ORIG_JMSXDeliveryCount");
        messageProperty.setValue("AAA");
        messageProperty.setMessage(message);

        Set<MessageProperty> messageProperties = new HashSet<MessageProperty>();
        messageProperties.add(messageProperty);
        message.setMessageProperties(messageProperties);

        def messageDaoImpl = spy(new MessageDaoImpl());
        def field = ContentService.class.getDeclaredField("messageDaoImpl");
        field.setAccessible(true);
        field.set(contentService, messageDaoImpl);

        when:
        doReturn(message).when(messageDaoImpl).findById(anyLong())
        def response0 = contentService.getContent(userId, id, "*/*");
        message.setContentType(Message.ContentType.TEXT);
        doReturn(message).when(messageDaoImpl).findById(anyLong())
        def response1 = contentService.getContent(userId, id, "*/*");

        then:
        response0.getStatus() == 200;
        response0.getEntity() != null;
        response1.getStatus() == 200;
        response1.getEntity() != null;
    }
}
