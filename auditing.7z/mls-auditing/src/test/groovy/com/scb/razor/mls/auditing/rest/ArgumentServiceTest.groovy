/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.rest

import com.scb.razor.mls.persistent.dao.impl.LoggingEventDaoImpl
import com.scb.razor.mls.persistent.model.LoggingEvent
import spock.lang.Specification

import static org.mockito.Mockito.mock
import static org.mockito.Mockito.when

/**
 * Description:
 * Author: 1466811
 * Date:   5:23 PM 5/14/14
 */
class ArgumentServiceTest extends Specification {
    /**
     * Test method for getContent()
     */

    def "get the content by id"() {
        given:
        def argumentService = new ArgumentService();
        def id = 1000L;
        def loggingEvent = new LoggingEvent(id);
        loggingEvent.setArg0("EBBS|EB266980300303");
        loggingEvent.setArg1("Test!");
        loggingEvent.setArg2(null);
        loggingEvent.setArg3(null);
        loggingEvent.setCallerClass("com.scb.razor.mls.eod.job.writer.MxmlItemWriter");
        loggingEvent.setCallerFilename("MxmlItemWriter.java");
        loggingEvent.setCallerLine("73");
        loggingEvent.setCallerMethod("logAuditEvent");
        loggingEvent.setFormattedMessage("PCT|Unique Id");
        loggingEvent.setLevelString("INFO");
        loggingEvent.setLoggerName("com.scb.razor.mls.eod.job.writer.MxmlItemWriter");
        loggingEvent.setReferenceFlag(1L);
        loggingEvent.setThreadName("WmSessionDispatcher");
        loggingEvent.setTimeStamp(1395299030896L);

        def loggingEventDaoImpl = mock(LoggingEventDaoImpl.class);
        when(loggingEventDaoImpl.findById(id)).thenReturn(loggingEvent);

        def field = ArgumentService.class.getDeclaredField("loggingEventDaoImpl");
        field.setAccessible(true);
        field.set(argumentService, loggingEventDaoImpl);


        when:
        def response = argumentService.getContent(String.valueOf(id));

        then:
        response.getEntity() != null;
        response.getStatus() == 200;
        ((ArgumentService.ContentWrapper) response.getEntity()).getContent() != null;
    }
}
