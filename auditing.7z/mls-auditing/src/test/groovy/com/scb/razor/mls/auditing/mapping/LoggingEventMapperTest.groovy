/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.mapping

import com.scb.razor.mls.auditing.model.MlsLoggingEvent
import com.scb.razor.mls.persistent.model.LoggingEvent
import spock.lang.Shared
import spock.lang.Specification

/**
 * Description:
 * Author: 1466811
 * Date:   4:21 PM 5/14/14
 */
class LoggingEventMapperTest extends Specification {
    @Shared loggingEventMapper;
    @Shared loggingEvent;
    @Shared uri;
    @Shared id;

    def setupSpec() {
        loggingEventMapper = new LoggingEventMapper();
        uri = new URI("http://localhost:8094/mls-auditing-service/");

        id = 1000L;
        loggingEvent = new LoggingEvent(id);
        loggingEvent.setArg1("Test!");
        loggingEvent.setArg2(null);
        loggingEvent.setArg3(null);
        loggingEvent.setCallerClass("com.scb.razor.mls.eod.job.writer.MxmlItemWriter");
        loggingEvent.setCallerFilename("MxmlItemWriter.java");
        loggingEvent.setCallerLine("73");
        loggingEvent.setCallerMethod("logAuditEvent");
        loggingEvent.setFormattedMessage("PCT|Unique Id");
        loggingEvent.setLevelString("INFO");
        loggingEvent.setLoggerName("com.scb.razor.mls.eod.job.writer.MxmlItemWriter");
        loggingEvent.setReferenceFlag(1L);
        loggingEvent.setThreadName("WmSessionDispatcher");
        loggingEvent.setTimeStamp(1395299030896L);
    }

    /**
     * Test method for mapToMlsLoggingEvent()
     */
    def "Map a loggingEvent to MlsLoggingEventBuilder"() {
        given: "the loggingEvent and the uri"
        loggingEvent.setArg0("EBBS|EB266980300303");
        def builder = loggingEventMapper.mapToMlsLoggingEvent(loggingEvent, uri);

        expect: "the MlsLoggingEventBuilder is not null"
        builder != null
    }

    /**
     * Test method for mapToMlsLoggingEventCollection()
     */
    def "Map a loggingEvent list to MlsMessage list"() {
        given: "the loggingEvent list and the uri"
        loggingEvent.setArg0("EBBS");
        List<LoggingEvent> loggingEvents = new ArrayList<LoggingEvent>();
        loggingEvents.add((LoggingEvent) loggingEvent);

        when:
        List<MlsLoggingEvent> mlsLoggingEvents = loggingEventMapper.
                mapToMlsLoggingEventCollection(loggingEvents, uri);

        then: "the size of list is 1"
        mlsLoggingEvents.size() == 1
    }
}
