package com.scb.razor.mls.auditing.lucene

import java.nio.file.Files;

import org.apache.lucene.analysis.core.WhitespaceAnalyzer;
import org.apache.lucene.document.Document
import org.apache.lucene.document.LongField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.document.Field.Store;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.MatchAllDocsQuery;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.store.SimpleFSDirectory

import spock.lang.Specification;


class LuceneFeatureTest extends Specification {
    
    /**
     * experimental feature of lucene #openIfChanged
     * testcase to make sure it doesn't make different behavior in future version
     * (or detect it if do)
     */
    def "test DirectoryReader.openIfChanged"() {
        
        given :
            def dir = new RAMDirectory()
            def iw = new IndexWriter(dir, new IndexWriterConfig(new WhitespaceAnalyzer()))
            Document dd = new Document();
            dd.add(new TextField("foo", "bar", Store.NO));
            dd.add(new LongField("time", System.currentTimeMillis(), Store.NO));
            dd.add(new TextField("id", "id" + 1, Store.YES));
            iw.addDocument(dd);
            iw.commit();
            IndexSearcher is = new IndexSearcher(DirectoryReader.open(dir));
            Document d = new Document();
            d.add(new TextField("foo", "bar", Store.NO));
            d.add(new LongField("time", System.currentTimeMillis(), Store.NO));
            d.add(new TextField("id", "id" + 1, Store.YES));
            iw.addDocument(d);
            iw.commit();
        
        when :
            def r1 = is.getIndexReader()
            def r2 = DirectoryReader.openIfChanged(r1, iw)
            def r3 = DirectoryReader.openIfChanged(r2, iw)
                
        then : 
            r1 != null
            r2 != null
            r3 == null
    }
    
    def "test index fragment files increase if old reader doesn't get closed"() {
        
        given :
            def indexdir = Files.createTempDirectory("test-index");
            println(indexdir)
            def dir = new SimpleFSDirectory(indexdir);
            def iw = new IndexWriter(dir, new IndexWriterConfig(new WhitespaceAnalyzer()))
            
        when :
            iw.addDocument(createRandomDoc())
            iw.commit()
            int fc1 = indexdir.toFile().list().length
            def is1 = new IndexSearcher(DirectoryReader.openIfChanged(DirectoryReader.open(dir), iw))
            def dc1 = is1.count(new MatchAllDocsQuery());
            
            iw.addDocument(createRandomDoc())
//            iw.commit();
            int fc2 = indexdir.toFile().list().length
            def is2 = new IndexSearcher(DirectoryReader.openIfChanged(is1.getIndexReader(), iw))
            def dc2 = is2.count(new MatchAllDocsQuery());
            def dc11 = is1.count(new MatchAllDocsQuery());
            
            iw.deleteAll()
            int fc3 = indexdir.toFile().list().length
            def is3 = new IndexSearcher(DirectoryReader.openIfChanged(is2.getIndexReader(), iw))
            def dc3 = is3.count(new MatchAllDocsQuery());
            def dc22 = is2.count(new MatchAllDocsQuery());
            def dc111 = is1.count(new MatchAllDocsQuery());
            
            //close old reader will lead to deleting relevant (only to this reader) index files
            is3.getIndexReader().close()
            is2.getIndexReader().close()
            is1.getIndexReader().close()
            int fc4 = indexdir.toFile().list().length
        then :
            dc1 == 1
            dc11 == 1
            dc111 == 1
            dc2 == 2
            dc22 == 2
            dc3 == 0
            fc2 > fc1
            fc3 > fc2
            fc4 < fc3
    }
    
    def createRandomDoc() {
        Document d = new Document();
        d.add(new TextField("foo", "bar " + Math.random(), Store.NO));
        return d;
    }
}