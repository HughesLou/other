package com.scb.razor.mls.auditing.rest

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.sql.DataSource

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.concurrent.ConcurrentTaskScheduler

import com.google.common.eventbus.EventBus;
import com.scb.razor.mls.auditing.WorkingDirectory
import com.scb.razor.mls.auditing.lucene.MessageIndex
import com.scb.razor.mls.auditing.lucene.exceptions.LiveExceptionStore;

@Configuration
class FakeSpringConfiguration {

    @Bean
    public EventBus bus() {
        return new EventBus()
    }
    
    @Bean
    public LiveExceptionStore store() {
        return [onActionPerformed: {}] as LiveExceptionStore;
    }
    
    @Bean
    public WorkingDirectory wd() {
        return new WorkingDirectory();
    }
    
    @Bean
    public DataSource ds() {
        return [:] as DataSource;
    }
    
    @Bean
    public TaskScheduler ts() {
        return new ConcurrentTaskScheduler();
    }
    
    @Bean
    public ExecutorService es() {
        return Executors.newFixedThreadPool(1);
    }
    
    @Bean
    public MessageIndex mi() {
        return new MessageIndex();
    }
}
