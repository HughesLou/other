
(function(){

angular.module('exceptions', ['ws', 'md.data.table', 'auth', 'cfp.hotkeys', 'shared'])
.config(configuration)
.factory('Exceptions', ExceptionService)
.controller('ExceptionsCtrl', ExceptionsCtrl)

/** @ngInject */
function configuration($routeProvider, configProvider) {
	$routeProvider
	.when('/exceptions', {
		templateUrl: 'exceptions/exceptions.html', 
		controller: 'ExceptionsCtrl',
		resolve: {login: ['AuthenticationService', function(auth){ return auth.login()}]}
	})

	configProvider
}

/** @ngInject */
function ExceptionService($q, $http, $httpParamSerializer, $timeout, WSResource, currentUser, config) {

	var sourceSystemMapping = {
		ALM_IN		: 'S2BX',
		ALM_MX3		: 'Murex3 FX',
		ALM_OUT		: 'Murex3',
		ALM_PDC		: 'Murex3 MLC ALM',
		ALM_REALM	: 'Murex3 ALM'	,
		ALM_SSI		: 'Assasin',
		CALENDAR	: 'PeopleSoft'	,
		CTPY		: 'SCI',
		FRTP		: 'Murex2',
		FX_IN		: 'S2BX',
		FX_MX3		: 'Murex3 ALM',
		FX_OUT		: 'Murex3',
		FX_PDC		: 'Murex3 MLC FX',
		FX_REALM	: 'Murex3 FX'	,
		FX_SSI		: 'Assasin',
		SWIFT		: 'Qstar'
	}
	var statusMapping = {'Submitted': 'New', 'Completed': 'Replayed', 'Ignored': 'Discarded'}

	var mapper = function(item) {
		var rtn = {availableActions: []}
		item.tags.forEach(function(tag){
			switch(tag.tagName) {
				case "Interface ID" 		: rtn.interfaceId = tag.tagValue;break;
				case "Application ID" 		: rtn.applicationId = tag.tagValue;break;
				case "JPP_counterpartCode" 	: rtn.counterpartCode = tag.tagValue;break;
				case "JPP_portfolioLabel" 	: rtn.portfolioLabel = tag.tagValue;break;
			}
		});
		rtn.sourceSystem = sourceSystemMapping[rtn.interfaceId] || 'Unknown'
		rtn.sourceId = rtn.interfaceId
		for(var key in item.availableActions) {
			var x = item.availableActions[key]
			rtn.availableActions.push({label: x.description, url : x.href, commentRequired: x.commentRequired})
		}
		if(item.resources && item.resources.length) {
			rtn.viewMessageUrl = item.resources[0].href + '&' + $httpParamSerializer(currentUser.authTokenParams)
		}
		for(var i in item) {
			if('string' == typeof item[i]) {
				rtn[i] = item[i]
			}
		}
		rtn.statusAlias = statusMapping[rtn.currentStatus] || rtn.currentStatus
		rtn.interfaceIdAlias = interfaceIdAlias[rtn.interfaceId]
		rtn._origin = item
		return rtn
	}

	var resource = new WSResource({
		listurl		: config.exceptions.wsrest.listurl,
		counturl	: config.exceptions.wsrest.counturl,
		entryMapper	: mapper,
		countDecoder: function(resp) {return resp[0]},
		defaultParams: {status: 'Submitted'}
	})

	resource.statusMapping = statusMapping

	resource.categories = [
		{value: 'TechnicalException',       label: 'Technical Exception'},
		{value: 'StaticMappingDataMissing', label: 'Static Exception'},
		{value: 'MalformattedException',    label: 'Malformatted Exception'}]
		
	resource.statuses = [
		{value: 'Submitted', label: 'New (Submitted)'},
		{value: 'Completed', label: 'Completed (Replayed)'},
		{value: 'Ignored',   label: 'Ignored (Discarded)'}]

	var interfaceIdAlias = {
		FRTP      : 'Murex2.11 inbound',
		ALM_IN    : 'ALM trade inbound',
		FX_IN     : 'FX trade inbound',
		FX_MX3    : 'ALM to FX trade inbound',
		ALM_MX3   : 'ALM Trade Inbound',
		FX_OUT    : 'FX Trade Outbound',
		ALM_OUT   : 'Trade Outbound',
		FX_REALM  : 'FX CashFlow',
		ALM_REALM : 'ALM CashFlow',
		FX_PDC    : 'PDC',
		ALM_PDC   : 'PDC',
		CALENDAR  : 'Calendar',
		CTPY      : 'Counterparty',
		FX_SSI    : 'FX SSI inbound',
		ALM_SSI   : 'ALM SSI inbound'
	}

	return resource
}

/** @ngInject */
function ExceptionsCtrl($scope, Exceptions, currentUser, AuthenticationService) {

	angular.extend($scope, {
		selection   : null,  //selected when single selection
		selections  : [],  //all selected when multiple selection
		query 		: {},
		pager 		: {page: 1, limit: 10},
		service 	: Exceptions,
		currentUser : currentUser,
		authService : AuthenticationService
	})
}

})()