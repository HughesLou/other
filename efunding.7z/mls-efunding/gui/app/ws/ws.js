
(function(){
/*
purpose : to handle weird server interaction :
resource list can only be fetched from server via the first frame of ws connection
*/

angular.module('ws', [])
.provider('ws', wsProvider)

/** @ngInject */
function wsProvider() {

	this.interceptors = []

	var interceptorsFn = []

	this.$get = ['$injector', '$q', function($injector, $q) {

		this.interceptors.forEach(function(i) {
			if(angular.isString(i)) {
				interceptorsFn.push($injector.get(i))
			}
		})

		//Instead of Web Socket, Server-Sent Event is
		//what we really need here. 'bi-directional, full-duplex' is useless for this particular app
		//well, now it is legacy, and need to be taken care of
		function WebSocketRequest() {

			//to request list of entity (Exceptions etc)
			function getFirstFrameAndClose(url) {
				var defer = $q.defer()

				var config = {url: url}
				interceptorsFn.forEach(function(fn){
					fn(config)
				})

				try {
					var ws = new WebSocket(config.url);
				} catch(err) {
					console.log('ws connection error', err)
					defer.reject('ws connection error : ' + err)
				}

				angular.extend(ws, {
					onmessage : function(frame) {
						defer.notify(2)
						defer.resolve(frame.data)
					},
					onopen : function() {
						defer.notify(1)
					},
					onerror : function(e) {
						defer.reject('ws error : ' + e) //TODO reject with detail error info from 'e'
					}
				})

				defer.promise.finally(function(){
					ws.close()  //TODO enclose with try catch ?
				})

				return defer.promise
			}

			//ws , ignored first frame which is always list of entity
			function createWebSocketAndIgnoreFirstFrame(url) {
				var defer = $q.defer()

				createWebSocket(url).then(function(ws){
					ws.onmessage = function(frame) {
						defer.resolve(ws)
					}
					ws.onerror = function(err){
						defer.reject(err)
					}
				}, function(ex){
					defer.reject(ex)
				})
				return defer.promise
			}

			function createWebSocket(url) {
				var config = {url: url}
				interceptorsFn.forEach(function(fn){
					fn(config)
				})

				var d = $q.defer()
				try {
					var ws = new WebSocket(config.url);
					$q.resolve(ws)
				}catch(ex){
					console.log('ws connect to %o failed with ex %o. after interceptors: %o', url, ex, config)
					d.reject(ex)
				}
				return d.promise
			}

			var wslist = []

			function connectWebSocket(url, onmessage, onerror) {
				createWebSocketAndIgnoreFirstFrame(url, function(ws) {
					wslist.push(ws)
					ws.onmessage = onmessage
					ws.onerror = onerror || function(e){
						var idx = wslist.indexOf(ws)
						idx >= 0 && wslist.splice(idx, 1)
						throw "ws error " + e
					}
				})
			}

			return {
				get : getFirstFrameAndClose,
				connect : connectWebSocket
			}
		}
		return WebSocketRequest()
	}]
}


})()