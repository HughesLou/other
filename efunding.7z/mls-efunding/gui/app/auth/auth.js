
(function(){

angular.module('auth', ['ngMaterial', 'ws', 'config'])
.config(configuration)
.factory('authTokenInterceptorForHttp', authTokenInterceptorForHttp)
.factory('authTokenInterceptorForWs', authTokenInterceptorForWs)
.service('AuthenticationService', authenticationService)
.service('currentUser', currentUser)
.controller('LoginCtrl', LoginCtrl)
.controller('LogoutCtrl', LogoutCtrl) // test controller with a name
.run(loadLocalInfo)

/** @ngInject */
function configuration($routeProvider, $httpProvider, wsProvider) {
	$routeProvider
	.when('/login', {templateUrl: 'auth/login.html', controller: 'LoginCtrl'})
	.when('/logout', {templateUrl: 'auth/login.html', controller: 'LoginCtrl'})

	$httpProvider.interceptors.push('authTokenInterceptorForHttp')

	wsProvider.interceptors.push('authTokenInterceptorForWs')
}

/** @ngInject */
function authenticationService ($http, $q, $cookies, $mdDialog, currentUser, config) {
	var self = this
	var authenticating = false
	self.authenticate = function (username, password) {

		authenticating = true

		var xhrOptions = {
			params: {
				ACTION: 'LDAPLOGIN', 
				LOGON_ID: username, 
				PASSWORD: password, 
				appName: 'MLS', 
				userType: 'LDAP', 
				isSsnExtnReqd: 'True'},
			responseType: 'json'
		}

		return $http.get(config.auth.uva.loginurl, xhrOptions).then(function(resp){
			if(!resp.data.authCred) {
				return $q.reject(resp.data.error)
			}
			var profile = resp.data.authCred
			return generateChallenge($q, profile.sessionKey).then(function(challenge) {
				var map = {
					username: username,
					password: password,
					authenticated: true,
					profile: profile,
					authTokenParams : {
						user: username,
						sessionKey: profile.sessionKey,
						challenge: challenge.challenge,
						hash: challenge.hash
					}

				}
				$cookies.put('SappUserId', username)
				$cookies.put('SappChallenge', challenge.challenge)
				$cookies.put('SappHash', challenge.hash)
				currentUser.setUser(map)
				angular.extend(self, map)
				if(window.sessionStorage) {
					window.sessionStorage.setItem('authentication', JSON.stringify(map))
				}
				return profile
			})
		}, function(resp){
			return $q.reject(resp.statusText + ', code=' + resp.status)
		}).finally(function() {
			authenticating = false
		})
	}

	self.login = function() {
		if(currentUser.authenticated) {
			return currentUser.profile
		}
		return $mdDialog.show({
			controller: 'LoginCtrl',
			templateUrl: 'auth/login.html',
			ariaLabel: 'Login Dialog',
			escapeToClose: false
		})
	}

	self.logout = function() {
		currentUser.clear()
		if(window.sessionStorage) {
			window.sessionStorage.removeItem('authentication')
		}
		self.login()
	}
}

/** @ngInject */
function AuthorizationService ($http, $q, AuthenticationService) {
	var self = this
	self.entitlements = []

	self.hasPermission = function(r) {
		return true
	}

	self.hasRole = function(r) {
		return true
	}

	self.canActAs = function(u) {
		return true
	}
}

/** @ngInject */
function authTokenInterceptorForHttp($q, currentUser) {
	return {
		'request' : function(config) {

			if(!config || /\w+\.\w+(\?.*)?$/.test(config.url)) {
				return config// bypass xx.js, xx.html
			}

			if(!currentUser.authenticated) {
				return config //no auth available for injection
			}
			if(/challenge=/.test(config.url) || (config && config.headers && config.headers.challenge)) {
				return config //already set
			}
			config.params = config.params || {}
			if(config.params.challenge) {  //TODO better check all 4 params : user, sessionkey, challenge, hash
				return config //already set
			}
			angular.extend(config.params, currentUser.authTokenParams)
			return config
		}
	}
}

/** @ngInject */
function authTokenInterceptorForWs($q, $httpParamSerializer, currentUser) {

	return function(config) {
		if(!currentUser.authenticated) {
			return //no auth available for injection
		}
		if(/challenge=/.test(config.url)) {
			return //already set
		}
		var qs = $httpParamSerializer(currentUser.authTokenParams)

		var url = /\?/.test(config.url) ? config.url : (config.url + '?')

		url = /&$/.test(url) ? url : (url + '&')

		config.url = url + qs
	}
}

/** @ngInject */
function currentUser () {

	var self = this
	self.clear = function() {
		angular.extend(self, {
			username: null,
			profile: null,
			password: null,
			authenticated: false
		})
	}
	self.setUser = function(u) {
		angular.extend(self, u)
	}
	self.clear()
}

/** @ngInject */
function LoginCtrl($location, $q, $scope, $mdDialog, currentUser, AuthenticationService) {
	angular.extend($scope, {
		authinfo: AuthenticationService,
		currentUser: currentUser
	})
	$scope.authenticate = function() {
		angular.extend($scope, {authenticating: true, error: null})
		$scope.authenticating = true
		$scope.authpromise = AuthenticationService.authenticate($scope.username, $scope.password)
		$scope.authpromise.then(function(){
			$mdDialog && $mdDialog.hide(AuthenticationService.profile)  //check if the form opened within a dialog
			//TODO redirect to dashboard page
		}, function(reason) {
			$scope.error = reason
		}).finally(function(){
			$scope.authenticating = false
		})
	}
}

/** @ngInject */
function LogoutCtrl(){
	console.log('logout')
}

/** @ngInject */
function loadLocalInfo(currentUser) {
	var store = window.sessionStorage
	if(store) {
		var item = store.getItem('authentication')
		if(item) {
			var obj = JSON.parse(item)
			currentUser.setUser(obj)
			return
		}
	}
	//TODO load info stored in cookie or local storage
	//FAKE A USER
	// angular.extend(currentUser, {
	// 	authenticated: true, 
	// 	username: '1439970', 
	// 	profile: {userFullName: 'Liu Jay'}, 
	// 	authTokenParams: {
	// 			user: '1439970',
	// 			sessionKey: 'undefined',
	// 			challenge: 'MDMyMTg1OTUtMjRFMi1DOURDLUVFQUQtMTNERTdGMEU3MTdC',
	// 			hash: 'MzNlNDNlNGNkNGExNTE1ODIyNjZmNDA1ZDU0MzA4ODdlMDQ5YjQzMQ=='
	// 	}
	// })
}

//http://stackoverflow.com/questions/105034/create-guid-uuid-in-javascript
//https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/digest
//private function, convert ArrayBuffer to hex string
function /*private*/ toHexString(buffer) {
  var hexCodes = [];
  var view = new DataView(buffer);
  for (var i = 0; i < view.byteLength; i += 4) {
    // Using getUint32 reduces the number of iterations needed (we process 4 bytes each time)
    var value = view.getUint32(i)
    // toString(16) will give the hex representation of the number without padding
    var stringValue = value.toString(16)
    // We use concatenation and slice for padding
    var padding = '00000000'
    var paddedValue = (padding + stringValue).slice(-padding.length)
    hexCodes.push(paddedValue);
  }

  // Join all the hex strings into one
  return hexCodes.join("");
}

//http://stackoverflow.com/questions/105034/create-guid-uuid-in-javascript
function /*private*/ generateUUID() {
	return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
	    var r = Math.random()*16|0, v = c == 'x' ? r : (r&0x3|0x8);
	    return v.toString(16);
	})
}

function /*private*/ generateChallenge($q, sessionKey) {

//TODO Only secure origins are allowed (see: https://goo.gl/Y0ZkNV)
//cryptography api is 'Powerful new feature', and 'http' scheme have no access to it
//so rollback to crypto-js'
	// if(!window.crypto || !window.TextEncoder) {
	// 	return $q.reject('crypto is not supported in your browser')
	// }
	// var uuid = generateUUID(), encoder = new TextEncoder('utf-8')
	// return window.crypto.subtle.digest('SHA-1', encoder.encode(sessionKey + uuid)).then(function(buf){
	// 	return {
	// 		hash : btoa(toHexString(buf)),
	// 		challenge : btoa(uuid)
	// 	}
	// })

	var uuid = generateUUID(), skey = sessionKey
	// var uuid = '3EA24139-ADB9-4D6F-CF7D-6B03065FD443', skey = '392216377818539833963269888166077768250710359185492465578149'
	var hash = CryptoJS.SHA1(skey + uuid)
	return $q.resolve({hash: btoa(hash.toString()), challenge: btoa(uuid)})
}

})()