
list of all the icons https://design.google.com/icons/

read more about material icons http://google.github.io/material-design-icons/#icon-font-for-the-web