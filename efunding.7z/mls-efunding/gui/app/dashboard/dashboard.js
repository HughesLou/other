
(function(){

angular.module('dashboard', ['config', 'auth', 'exceptions', 'auditingRT'])
.config(configuration)
.controller('DashboardCtrl', DashboardCtrl)
.controller('DashboardNumbersCtrl', DashboardNumbersCtrl)

/** @ngInject */
function configuration($routeProvider) {
	$routeProvider.when('/dashboard', {
		templateUrl: 'dashboard/dashboard.html', 
		controller: 'DashboardCtrl',
		resolve: {
			login : ['AuthenticationService', function(auth){ return auth.login()}]
		}
	}).when('/testcode', {
		templateUrl: 'dashboard/include.html',
		controller: 'TestcodeCtrl',
		resolve: {
			login : ['AuthenticationService', function(auth){ return auth.login()}]
		}
	})
}

/** @ngInject */
function DashboardCtrl($location, $q, $scope, $document, currentUser, Exceptions, AuditingRTNack, AuditingRT, AuthenticationService) {

	document.title = 'Exceptions Dashboard'

	angular.extend($scope, {
		currentUser	: currentUser,
		authService : AuthenticationService,
		currentView : "exception",
		isCurrentView : function(name) {
			return name == $scope.currentView
		},
		setCurrentView : function(name) {
			$scope.currentView = name
		}
	})

	$scope.resetQuery = function(type, query) {
		$scope.setCurrentView(type)
		$scope[type].query = query
		$scope.$broadcast('resource-list.refresh')
	}

	$scope.exception = {
		service : Exceptions
	}

	$scope.nack = {
		service : AuditingRTNack
	}

	$scope.filter = {
		service : AuditingRT
	}
}

/** @ngInject */
function DashboardNumbersService($q, $http, ws, config) {
	var self = this
	self.numbers = { //TODO
		exp : {
			all : 0,
			FX_IN : 0
		},
		nack: {
			all: 0,
			FX_IN: 0
		},
		filtered: {
			all: 0,
			FX_IN : 0
		}
	}
	ws.createWebSocket(config.dashboard.counterWS).then(function(ws){
		ws.onmessage = function(frame) {
			var json = JSON.parse(frame.data)
			if(json.type == 'exception') {
				//TODO
				self.numbers.exp.all++
				self.numbers.FX_OUT++
			}
		}
	})
}

/** @ngInject */
function DashboardNumbersCtrl($scope, $q, $interval, $mdDialog, Exceptions, AuditingRTNack, AuditingRT, config, ws) {

	var wslisteners = []
	ws.connect(config.dashboard.counterWS).then(function(conn) {
		conn.onmessage = function(frame) {
			var messages = JSON.parse(frame.data)
			wslisteners.forEach(function(fn){
				fn(messages)
			})
		}

		$scope.$on('$destroy', function() {
			conn.close()
		})
	})
	var countExpFn = function(systems) {
		var count = null
		wslisteners.push(function(messages) {
			if(count == null) {
				return 
			}
			messages.forEach(function(msg){
				if(systems.indexOf(msg.source_system) < 0) {
					return
				}
				if(msg.destination == 'T_EXCPT_X_MLS_OUT') { //TODO should not expose server internal info
					msg.channel != 'REPLAY' ? count++ : count--
				}
			})
		})
		return function() {
			return count == null ? Exceptions.count({customFilter: "Interface ID;EQUALS;" + systems.join(';OR;Interface ID;EQUALS;')}).then(function(c){count = c; return c;}) : $q.resolve(count)
		}
	}
	var countNackFn = function(systems) {
		return function() {
			return $q.all(systems.map(function(i){return AuditingRTNack.count({sourceSysId: i})})).then(function(narr){
				return narr.reduce(function(pv, cv){return pv + cv}, 0)
			})
		}
	}
	var expParamsFn = function(systems) {
		return {customFilter: "Interface ID;EQUALS;" + systems.join(';OR;Interface ID;EQUALS;')}
	}

	var filterParamsFn = function(systems) {
		return function() {
			return $q.all(systems.map(function(i){return AuditingRTNack.count({sourceSysId: i, status: 'FILTERED'})})).then(function(narr){
				return narr.reduce(function(pv, cv){return pv + cv}, 0)
			})
		}
	}
	var countFilterFn = function(systems) {
		return function() {
			return $q.all(systems.map(function(i){return AuditingRT.count({sourceSysId: i, status: 'FILTERED'})})).then(function(narr){
				return narr.reduce(function(pv, cv){return pv + cv}, 0)
			})
		}
	}

	$scope.paramsTree = [{
		label: 'MLS Exception',
		counter: function(){return Exceptions.count()},
		queryParams: {},
		children: [{
			label: 'FX',
			counter: countExpFn(['FX_IN', 'FX_MX3', 'FRTP', 'FX_OUT', 'FX_REALM', 'FX_PDC']),
			queryParams : expParamsFn(['FX_IN', 'FX_MX3', 'FRTP', 'FX_OUT', 'FX_REALM', 'FX_PDC']),
			children: [{
				label: 'Trade Inbound',
				counter: countExpFn(['FX_IN', 'FX_MX3', 'FRTP']),
				queryParams : expParamsFn(['FX_IN', 'FX_MX3', 'FRTP']),
				children: []
			}, {
				label: 'Trade Outbound',
				counter: countExpFn(['FX_OUT']),
				queryParams : expParamsFn(['FX_OUT']),
				children: []
			}, {
				label: 'CashFlow',
				counter: countExpFn(['FX_REALM']),
				queryParams : expParamsFn(['FX_REALM']),
				children: []
			}, {
				label: 'PDC',
				counter: countExpFn(['FX_PDC']),
				queryParams : expParamsFn(['FX_PDC']),
				children: []
			}]
		}, {
			label: 'ALM',
			counter: countExpFn(['ALM_IN', 'ALM_MX3', 'FRTP', 'ALM_OUT', 'ALM_REALM', 'ALM_PDC']),
			queryParams : expParamsFn(['ALM_IN', 'ALM_MX3', 'FRTP', 'ALM_OUT', 'ALM_REALM', 'ALM_PDC']),
			children: [{
				label: 'Trade Inbound',
				counter: countExpFn(['ALM_IN', 'ALM_MX3', 'FRTP']),
				queryParams : expParamsFn(['ALM_IN', 'ALM_MX3', 'FRTP']),
				children: []
			}, {
				label: 'Trade Outbound',
				counter: countExpFn(['ALM_OUT']),
				queryParams : expParamsFn(['ALM_OUT']),
				children: []
			}, {
				label: 'CashFlow',
				counter: countExpFn(['ALM_REALM']),
				queryParams : expParamsFn(['ALM_REALM']),
				children: []
			}, {
				label: 'PDC',
				counter: countExpFn(['ALM_PDC']),
				queryParams : expParamsFn(['ALM_PDC']),
				children: []
			}]
		}, {
			label: 'Static Data',
			counter: countExpFn(['CALENDAR', 'CTPY', 'FX_SSI', 'ALM_SSI']),
			queryParams : expParamsFn(['CALENDAR', 'CTPY', 'FX_SSI', 'ALM_SSI']),
			children: [{
				label: 'Calendar',
				counter: countExpFn(['CALENDAR']),
				queryParams : expParamsFn(['CALENDAR']),
				children: []
			}, {
				label: 'Customer',
				counter: countExpFn(['CTPY']),
				queryParams : expParamsFn(['CTPY']),
				children: []
			}, {
				label: 'Settlement Instruction',
				counter: countExpFn(['FX_SSI', 'ALM_SSI']),
				queryParams : expParamsFn(['FX_SSI', 'ALM_SSI']),
				children: []
			}]
		}]
	}, {
		label: 'Murex Exception',
		counter: function(){return AuditingRTNack.count()},
		queryParams: {},
		children: [{
			label: 'ALM trade inbound',
			counter: countNackFn(['ALM_IN']),
			queryParams: {sourceSysId: 'ALM_IN'}
		}, {
			label: 'ALM SSI inbound',
			counter: countNackFn(['ALM_SSI']),
			queryParams: {sourceSysId: 'ALM_SSI'}
		}, {
			label: 'Calendar',
			counter: countNackFn(['CALENDAR']),
			queryParams: {sourceSysId: 'CALENDAR'}
		}, {
			label: 'Counterparty',
			counter: countNackFn(['CTPY']),
			queryParams: {sourceSysId: 'CTPY'}
		}, {
			label: 'Murex2.11 inbound',
			counter: countNackFn(['FRTP']),
			queryParams: {sourceSysId: 'FRTP'}
		}, {
			label: 'FX trade inbound',
			counter: countNackFn(['FX_IN']),
			queryParams: {sourceSysId: 'FX_IN'}
		}, {
			label: 'ALM to FX trade inbound',
			counter: countNackFn(['FX_MX3']),
			queryParams: {sourceSysId: 'FX_MX3'}
		}, {
			label: 'FX to ALM trade inbound',
			counter: countNackFn(['ALM_MX3']),
			queryParams: {sourceSysId: 'ALM_MX3'}
		}, {
			label: 'FX SSI inbound',
			counter: countNackFn(['FX_SSI']),
			queryParams: {sourceSysId: 'FX_SSI'}
		}]
	}, {
		label: 'MLS Filtered', 
		counter : function(){return AuditingRT.count({status:'FILTERED'})},
		queryParams: {status: 'FILTERED'},
		children: [{
			label: 'ALM trade inbound',
			counter: countFilterFn(['ALM_IN']),
			queryParams: {status: 'FILTERED', sourceSysId: 'ALM_IN'}
		}, {
			label: 'ALM SSI inbound',
			counter: countFilterFn(['ALM_SSI']),
			queryParams: {status: 'FILTERED', sourceSysId: 'ALM_SSI'}
		}, {
			label: 'Calendar',
			counter: countFilterFn(['CALENDAR']),
			queryParams: {status: 'FILTERED', sourceSysId: 'CALENDAR'}
		}, {
			label: 'Counterparty',
			counter: countFilterFn(['CTPY']),
			queryParams: {status: 'FILTERED', sourceSysId: 'CTPY'}
		}, {
			label: 'Murex2.11 inbound',
			counter: countFilterFn(['FRTP']),
			queryParams: {status: 'FILTERED', sourceSysId: 'FRTP'}
		}, {
			label: 'FX trade inbound',
			counter: countFilterFn(['FX_IN']),
			queryParams: {status: 'FILTERED', sourceSysId: 'FX_IN'}
		}, {
			label: 'ALM to FX trade inbound',
			counter: countFilterFn(['FX_MX3']),
			queryParams: {status: 'FILTERED', sourceSysId: 'FX_MX3'}
		}, {
			label: 'FX to ALM trade inbound',
			counter: countFilterFn(['ALM_MX3']),
			queryParams: {status: 'FILTERED', sourceSysId: 'ALM_MX3'}
		}, {
			label: 'FX SSI inbound',
			counter: countFilterFn(['FX_SSI']),
			queryParams: {status: 'FILTERED', sourceSysId: 'FX_SSI'}
		}]
	}]

	// var allSystems = ['ALM_IN', 'ALM_MX3', 'ALM_OUT', 'ALM_PDC', 'ALM_REALM', 'ALM_SSI', 'CALENDAR', 'CTPY', 'FRTP', 'FX_IN', 'FX_MX3', 'FX_OUT', 'FX_PDC', 'FX_REALM', 'FX_SSI', 'SWIFT']

	var typeMarker = function(type) {
		var f = function(node) {
			node.type = type
			node.children && node.children.forEach(f)
		}
		return f
	}
	typeMarker('exception')($scope.paramsTree[0]) // add {type:'exception'} to first root node and its subtree
	typeMarker('nack')($scope.paramsTree[1])  //add {type: 'nack'} to second root node and its subtree
	typeMarker('filter')($scope.paramsTree[2])  //add {type: 'nack'} to second root node and its subtree

	//currently supports only 3 layers of drill down
	//to support 4 layers : 1) add var 'selectedNode3' 2) update function countNode and selectNode 3) add section in html
	//to support n layers : redesign required

	var countNode = function(node) {//count selected node and its children, and children's children
		if(node.countold == null || node.countold == undefined) {
			node.countold = node.count
		}
		node.count = null
		node.counter().then(function(n){
			node.count = n
		})
		if(node.children && node.children.length) {
			if(node == $scope.selectedNode || node == $scope.selectedNode2) {
				//only selected node's children should be counted, waste no resource
				node.children.forEach(countNode)
			}
		}
	}

	$scope.isNumberChanged = function(node) {
		return node.countold != null && node.count != null && node.countold != node.count
	}

	//on select : 1. expand children 2. remove highlight number change
	$scope.selectNode = function(node) {
		var haveThisNode = function(i) {return i == node}
		if($scope.paramsTree.some(haveThisNode)) {
			$scope.selectedNode = node
			$scope.selectedNode2 = null
		} else {
			$scope.paramsTree.forEach(function(i){
				if( i.children && i.children.some(haveThisNode) ) {
					$scope.selectedNode2 = node
				}
			})
		}
		node.countold = null
		countNode(node)
	}

	$scope.refreshNumbers = function() {
		$scope.paramsTree.forEach(countNode)
	}

	$scope.refreshNumbers()
}

})()