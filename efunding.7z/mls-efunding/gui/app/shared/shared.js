(function(){

angular.module('shared', ['ws', 'ngMaterial'])
.factory('WSResource', WSResourceFactory)
.filter('aging', AgingFilter)
.directive('resourceList', ResourceListDirective)
.directive('inpageColumnFilter', InpageColumnFilterDirective)
.controller('ResourceListCtrl', ResourceListCtrl)
.controller('DialogCtrl', DialogCtrl)

/**
 * simulate restful resource, the underlying is actually websocket
 */
/** @ngInject */
function WSResourceFactory($q, $http, $httpParamSerializer, ws) {

	var toQueryString = function(obj, ignoreEmptyParams) {
		var params = {}
		angular.extend(params, obj)
		if(ignoreEmptyParams) {
			for(var i in params) {
				if(/^ *$/.test(params[i])) {
					delete params[i]
				}
			}
		}
		return $httpParamSerializer(params)
	}

	var appendQueryStringToUrl = function(url, qs) {
		return url + (/\?/.test(url) ? '' : '?') + (/\&$/.test(url) ? '' : '&') + qs
	}

	var WSResource = function(opt) {
		if(!opt.listurl || !opt.counturl) {
			throw new Error('option listurl and counturl are all required')
		}
		var defaults = {
			ignoreEmptyParams: true  //ignore empty parameter {name: '', age:11} => "age=11"
		}
		this.opt = angular.extend(defaults, opt)
	}

	WSResource.prototype.list = function(params) {
		var opt = this.opt, 
			params = angular.extend({}, opt.defaultParams, params),
			params = opt.transformParams ? opt.transformParams(params) : params,
			url = appendQueryStringToUrl(opt.listurl, toQueryString(params, opt.ignoreEmptyParams))
		return ws.get(url).then(function(str) {
			var json = JSON.parse(str)
			if(/error/i.test(json.type)) {
				return $q.reject(json.type + " : " + json.payload)
			}
			if(angular.isFunction(opt.entryMapper)) {
				return json.payload.map(opt.entryMapper)
			}
			return json.payload
		})
	}

	WSResource.prototype.count = function(params) {
		var opt = this.opt, 
			params = angular.extend({}, opt.defaultParams, params),
			params = opt.transformParams ? opt.transformParams(params) : params,
			form = toQueryString(params, opt.ignoreEmptyParams)
		return $http.post(opt.counturl, form, {headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}}).then(function(resp) {
			return angular.isFunction(opt.countDecoder) ? opt.countDecoder(resp.data) : resp.data
		}, function(resp) {
			return $q.reject("status=" + resp.status + ", text='" + resp.statusText + "'")
		})
	}

	/**
	 * @return {data: [], count: 123}
	 */
	WSResource.prototype.listWithCount = function(params) {
		return $q.all([this.list(params), this.count(params)]).then(function(vals) {
			return {data: vals[0], count: vals[1]}
		})
	}

	/**
	 * action have a url property
	 * action do a POST request
	 * additional post content is optional, parameter form
	 */
	WSResource.prototype.performAction = function(action, form) {
		var opt = this.opt, errorback = function(resp) {
			return $q.reject('status=' + resp.status + ", statusText=" + resp.statusText, resp)
		}
		if(!form) {
			return $http.post(action.url).catch(errorback)
		} else {
			return $http.post(action.url, typeof form == 'string' ? form : toQueryString(form, opt.ignoreEmptyParams), {headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}}).catch(errorback)
		}
	}

	return WSResource
}

/** @ngInject */
function AgingFilter() {

	return function(time, relativeTo) {
		if(!time) {
			return '-'
		}
		var offset = new Date().getTimezoneOffset() * 60 * 1000 //adjust timezone offset if any
		try {
			var date = Date.parse(time)
		} catch (err) {
			return '-'
		}
		var now = relativeTo
		var diff = now - date
		var years = diff / (1000 * 3600 * 24 * 365) | 0,
			months= diff / (1000 * 3600 * 24 * 30) | 0,
			days  = diff / (1000 * 3600 * 24) | 0,
			hours = diff / (1000 * 3600) | 0,
			mins  = diff / (1000 * 60) | 0,
			secs  = diff / 1000 | 0
		return years > 0 ? years + ' years' :
			months > 0 ? months + ' months' :
			days > 0 ? days + ' days' :
			hours > 0 ? hours + ' hrs' :
			mins > 0 ? mins + ' mins' : secs + 's'
	}
}

/** @ngInject */
function ResourceListDirective($parse) {

	return {
		restrict: 'E',
		scope : {
			service: '=',
			queryRefresh: '=query', //used to reset query and do a data refresh
			title: '@',
			filterTemplate: '@',
			detailTemplate: '@',
			tableTemplate: '@'
		},
		templateUrl: 'shared/resource-list.html',
		controller: 'ResourceListCtrl',
		compile: function(element, attrs, transclude) {
			// console.log(element.find('resource-table-header'))
		}
	}
}

/** @ngInject */
function ResourceListCtrl($scope, $element, $attrs, $transclude, $q, $interval, $mdBottomSheet, $mdDialog, $mdToast, hotkeys) {

	//$on and $watch are used together to trigger refresh of the resourcelist when query changes
	//you may wonder why not call #queryDatalist() directly in $on's callback
	//Answer : digest cycle happens AFTER callback
	//you may wonder why use 'on/emit' listener style of code, why not expose #queryDatalist to outside world
	//Answer : tried, without luck. there are 2 ways : 1) locate dom element and acquire the scope, then $apply -- ugly
	//         2) expose binding using {api : '='} -- cannot manage to get it work, see 
	//        links http://stackoverflow.com/questions/16709373/angularjs-how-to-call-controller-function-from-outside-of-controller-component
	//        links http://stackoverflow.com/questions/18533370/how-to-expose-a-public-api-from-a-directive-that-is-a-reusable-component
	$scope.$on('resource-list.refresh', function(){
		$scope.refreshFlag = !$scope.refreshFlag
	})

	$scope.$watch('queryRefresh', function(nv, pv){
		$scope.resetQuery(nv)
	})

	angular.extend($scope, {
		hidefilters : true,  //for GUI
		hidedetails : true,  //for GUI
		toggleFilters : function(show) {
			$scope.hidefilters = show == undefined ? !$scope.hidefilters : show
		},
		toggleDetails : function(show) {
			$scope.hidedetails = show == undefined ? !$scope.hidedetails : show
		},
		selectItem : function(item) {
			$scope.selection = item
		},
		selectAndShow : function(item) {
			$scope.selectItem(item)
			$scope.hidedetails = false
		},
		pager: {page: 1, limit: 10},
		selections: []
	})

	var errToast = $mdToast.simple().action('OK').highlightAction(true).position('top right')

	var queryDatalist = function() {
		var first = $scope.pager.limit * ($scope.pager.page - 1)
		var params = angular.extend({}, $scope.query, {firstResult: first, maxResults: $scope.pager.limit})
		$scope.hidefilters = true //make sure validated before hiding
		$scope.promise = $scope.service.listWithCount(params).then(function(data) {
			$scope.datalist = data
			$scope.originlist = data.data.slice()  //copy array
			$scope.hidedetails = true
			$scope.selections.splice(0)
			return data
		}, function(err) {
			$mdToast.show(errToast.textContent(err))
			return $q.reject(err)
		})
		return $scope.promise
	}
	$scope.queryDatalist = queryDatalist

	var gotoNext = function(step) {
		if(!$scope.datalist || !$scope.datalist.data || !$scope.datalist.data.length) {
			return
		}

		var arr = $scope.datalist.data, idx = arr.indexOf($scope.selection)
		if(!$scope.selection) {
			$scope.selection = arr[0]
			return
		}
		idx += step
		idx = idx < 0 ? 0 : (idx >= arr.length ? (arr.length - 1) : idx)
		$scope.selection = $scope.datalist.data[idx]
	}

	hotkeys.bindTo($scope).add({
		combo: 'v',
		description: 'Show/Hide selected detail',
		callback: function() {
			$scope.hidedetails = !$scope.hidedetails
		}
	}).add({
		combo: 'j',
		description: 'Next',
		callback: function() {
			gotoNext(1)
		}
	}).add({
		combo: 'k',
		description: 'Previous',
		callback: function() {
			gotoNext(-1)
		}
	}).add({
		combo: 'esc',
		description: 'Close popup',
		callback: function() {
			$scope.hidedetails = true
			$scope.hidefilters = true
		}
	}).add({
		combo: 'f',
		description: 'Show/Hide filter form',
		callback: function() {
			$scope.hidefilters = !$scope.hidefilters
		}
	})

	$scope.onPaginate = function(page, limit) {
		$scope.pager.page = page
		$scope.pager.limit = limit
		queryDatalist()
	}

	$scope.onReorder = function(order) {
		//todo set order
		queryDatalist()
	}

	$scope.performAction = function(action) {

		var finalback = function() {
				$scope.actionInProgress = null
			},
			errorback = function(err) {
				err && $mdToast.show(errToast.textContent(err)) // err=undefined means user cancelled the action
			},
			callback = function() {
				$scope.selection.availableActions.splice($scope.selection.availableActions.indexOf(action), 1)
				//TODO refresh exception from server instead of updating properties in local
				$scope.queryDatalist()
			}
		if(action.commentRequired) {
			return $mdDialog.show({templateUrl: 'shared/input-comment-dialog.html', controller: 'DialogCtrl'}).then(function(comment) {
				$scope.actionInProgress = action
				return $scope.service.performAction(action, {comment: comment})
			}).then(callback, errorback).finally(finalback)
		} else {
			$scope.actionInProgress = action
			return $scope.service.performAction(action).then(callback, errorback).finally(finalback)
		}
	}

	$scope.resetQuery = function(newQuery, onlyReset) {
		if(!$scope.query) {
			$scope.query = {}
		}
		for(var x in $scope.query) {
			delete $scope.query[x]
		}
		for(var x in newQuery) {
			$scope.query[x] = newQuery[x]
		}
		if(onlyReset) { //reset only, do not query server
			return $q.resolve()
		}
		return $scope.queryDatalist()
	}

	$scope.now = Date.now()

	var timer = $interval(function() {
		$scope.now = Date.now()
	}, 20000)

	$scope.$on('$destroy', function() {
		$interval.cancel(timer)
		timer = undefined
	})
}

/** @ngInject */
function InpageColumnFilterDirective($parse) {

	return {
		restrict: 'E',
		scope : {
			filterableList: '=',
			originalList: '=',
			propertyName: '@'
		},
		templateUrl: 'shared/inpage-column-filter.html',
		compile: function(element, attrs, transclude) {
		}, 
		controller: ["$scope", "$element", "$attrs", function($scope, $element, $attrs){

			$scope.inpageFilter = function(value) {
				$scope.filterableList = $scope.originalList.filter(function(i){
					return i[$scope.propertyName] == value
				})
				$scope.filterBy = value
			}
			$scope.clearInpageFilter = function() {
				$scope.filterableList = $scope.originalList.slice()
				$scope.filterBy = null
			}
			$scope.inpageFilterMenu = function($mdOpenMenu, ev) {
				$scope.inpageFilterItems = $scope.originalList.reduce(function(pv, cv){
					if(pv.indexOf(cv[$scope.propertyName]) < 0) {
						pv.push(cv[$scope.propertyName])
					}
					return pv
				}, [])
				$mdOpenMenu(ev)
			}
		}]
	}
}

/** @ngInject */
function DialogCtrl($scope, $mdDialog) {

	$scope.hideDialog = function(obj) {
		$mdDialog.hide(obj)
	}

	$scope.cancelDialog = function() {
		$mdDialog.cancel()
	}
}

})()