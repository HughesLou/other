
(function(){

angular.module('config', [])
.config(configuration)
.provider('config', configProvider)
.controller('ConfigurationCtrl', ConfigurationCtrl)

/** @ngInject */
function configuration($routeProvider) {
	$routeProvider.when('/config', {templateUrl: 'config/config.html', controller: ConfigurationCtrl});
}

/** @ngInject */
function configProvider() {

	var Config = function(conf) {
		angular.extend(this, conf)
	}

	var locateByPath = function(path, obj) {
		return path && path.split('.').reduce(function(prev, key){
			return prev && prev[key]
		})
	}

	var locateParentByPath = function(path, obj) {
		var p = /.*(?=\.\w+)/.exec(path)
		return locateByPath(path && path[0], obj)
	}

	Config.prototype.set = function(path, value) {
		var obj, objkey
		path && path.split('.').reduce(function(prev, key){
			obj = prev, objkey = key
			return angular.isObject(prev) && prev[key]
		}, this)
		return obj && (obj[objkey] = value)
	}

	Config.prototype.get = function(path) {
		var obj, objkey
		path && path.split('.').reduce(function(prev, key){
			obj = prev, objkey = key
			return angular.isObject(prev) && prev[key]
		}, this)
		return obj && obj[objkey]
	}

	Config.prototype.getUserPreference = function(key){
		var userPreference = localStorage.userPreference && JSON.parse(localStorage.userPreference)
		return userPreference && userPreference[key]
	}

	Config.prototype.setUserPreference = function(key, value){
		var userPreference = (localStorage.userPreference && JSON.parse(localStorage.userPreference)) || {}
		userPreference[key] = value
		localStorage.userPreference = JSON.stringify(userPreference)
	}

	this.listeners = []  //TODO make use of observers 

	var conf = new Config({
		exceptions: {
			wsrest : {
				listurl : 'ws://uklvadrzr10a.uk.standardchartered.com:8092/exception-ticketing-api/live/Ticket',
				counturl: 'http://uklvadrzr10a.uk.standardchartered.com:8092/exception-ticketing-api/Ticket/SearchedTicketsAmount'
			}
		},
		auditingRT : {
			wsrest: {
				listurl : 'ws://uklvadrzr10a.uk.standardchartered.com:8094/mls-auditing-service/live/Auditing',
				counturl: 'http://uklvadrzr10a.uk.standardchartered.com:8094/mls-auditing-service/Auditing/MessagesAmount'
			}
		},
		dashboard: {
			counterWS: 'ws://uklvadrzr10a.uk.standardchartered.com:8094/mls-auditing-service/ws'
		},
		auth : {
			uva : {
				loginurl : "http://uklpadtoy11a.uk.standardchartered.com:8080/ums/servlet/JSONLoginServlet"
			}
		}
	})

	this.$get = function() {
		return conf
	}
}

/** @ngInject */
function ConfigurationCtrl($location, $q, $scope, config) {
	$scope.tree = config
	$scope.hasChildren = function(tree) {
		return typeof tree != 'string'
	}
	console.log("show / edit settings", config);
}

/** @ngInject */
function initializationFn(config) {
}

})()