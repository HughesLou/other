(function(){

angular.module('auditingRT', ['ws', 'md.data.table', 'auth', 'cfp.hotkeys', 'shared'])
.config(configuration)
.factory('AuditingRTNack', AuditingRTNackService)
.factory('AuditingRT', AuditingRTService)
.controller('AuditingRTCtrl', AuditingRTCtrl)

/** @ngInject */
function configuration($routeProvider) {
	$routeProvider
	.when('/auditingRT', {
		templateUrl: 'auditingRT/auditingRT.html', 
		controller: 'AuditingRTCtrl',
		resolve: {login: ['AuthenticationService', function(auth){ return auth.login()}]}
	})
}

var statusMapping = {
	RECEIVED: 'New',
	DELIVERED_RESOLVED: 'Ignored',
	DELIVERED: 'Replayed',
	FILTERED: 'Filtered'
}
var interfaceIdAlias = {
	FRTP: 'Murex2.11 inbound',
	ALM_IN: 'ALM trade inbound',
	FX_IN: 'FX trade inbound',
	FX_MX3: 'ALM to FX trade inbound',
	ALM_MX3: 'ALM Trade Inbound',
	FX_OUT: 'FX Trade Outbound',
	ALM_OUT: 'Trade Outbound',
	FX_REALM: 'FX CashFlow',
	ALM_REALM: 'ALM CashFlow',
	FX_PDC: 'PDC',
	ALM_PDC: 'PDC',
	CALENDAR: 'Calendar',
	CTPY: 'Counterparty',
	FX_SSI: 'FX SSI inbound',
	ALM_SSI: 'ALM SSI inbound'
}
var mapper = function(item) {
	var rtn = {properties: item.properties, availableActions: []}
	for(var i in item) {
		if (!angular.isObject(item[i])) {
			rtn[i] = item[i]
		}
	}
	if(item.contentLink) {
		rtn.viewMessageUrl = item.contentLink.href
	}
	for(var key in item.actions) {
		var x = item.actions[key]
		rtn.availableActions.push({label: x.name, url : x.href, commentRequired: true})
	}
	item.properties && item.properties.forEach(function(prop){
		if(/captureSystem/i.test(prop.key)){
			rtn.sourceSystem = prop.value
		}
	})
	rtn.statusAlias = statusMapping[item.status] || item.status
	rtn.interfaceIdAlias = interfaceIdAlias[rtn.sourceSysId]
	rtn._origin = item
	return rtn
}

var beforeRequesting = function(params) {
	var p = angular.extend({}, params)
	if(p.gid) {
		//if gid presented in query, translate to filterField param
		if(p.filterField) {
			p.filterField = 'S2BX_ID;EQUALS;' + p.gid + ';AND;' + p.filterField
		} else {
			p.filterField = 'S2BX_ID;EQUALS;' + p.gid
		}
		delete p.gid
	}
	return p
}

/** @ngInject */
function AuditingRTService($httpParamSerializer, WSResource, currentUser, config) {

	var resource = new WSResource({
		listurl: config.auditingRT.wsrest.listurl,
		counturl : config.auditingRT.wsrest.counturl,
		defaultParams : {type: 'RT'},
		transformParams : beforeRequesting,
		entryMapper : function(item) {
			var rtn = mapper(item)
			if(rtn.viewMessageUrl) {
				rtn.viewMessageUrl += '&stripToMxml=true&' + $httpParamSerializer(currentUser.authTokenParams)
			}
			return rtn
		}
	})
	resource.statuses = statusMapping
	resource.interfaceIdAlias = interfaceIdAlias
	return resource
}

/** @ngInject */
function AuditingRTNackService($httpParamSerializer, WSResource, currentUser, config) {
	
	var resource = new WSResource({
		listurl: config.auditingRT.wsrest.listurl,
		counturl : config.auditingRT.wsrest.counturl,
		defaultParams : {filterField: 'messageType;EQUALS;NACK', type: 'RT', channel: 'ACKNOWLEDGE', status: 'RECEIVED'},
		transformParams : beforeRequesting,
		entryMapper : function(item) {
			var rtn = mapper(item)
			if(rtn.viewMessageUrl) {
				rtn.viewMessageUrl += '&stripToMxml=true&' + $httpParamSerializer(currentUser.authTokenParams)
			}
			return rtn
		}
	})
	resource.statuses = statusMapping
	resource.interfaceIdAlias = interfaceIdAlias
	return resource
}

/** @ngInject */
function AuditingRTCtrl($location, $q, $scope, $interval, $mdBottomSheet, $mdDialog, $mdToast, hotkeys, AuditingRTNack, currentUser, AuthenticationService) {

	angular.extend($scope, {
		selection   : null,  //selected when single selection
		selections  : [],  //all selected when multiple selection
		query 		: {},
		pager 		: {page: 1, limit: 10},
		service 	: AuditingRTNack,
		currentUser : currentUser,
		authService : AuthenticationService
	})
}

})()