

angular.module("app", ['ngMessages', 'ngRoute', 'ngCookies', 'config', 'auth', 'ws', 'dashboard', 'exceptions', 'cfp.hotkeys', 'shared', 'auditingRT'])
	.config(configuration)
	.directive('ngContextmenu', contextmenuDirective)
	.controller('AppController', AppController)

/** @ngInject */
function configuration($routeProvider, $httpProvider, $rootScopeProvider, $controllerProvider, $mdThemingProvider) {

	//fix CORS x-request-with header not supported issue, only under angular-1.1.1 or below
	// delete $httpProvider.defaults.headers.common['X-Requested-With']  

	//running in production, https://code.angularjs.org/1.4.9/docs/guide/production
	//$compileProvider.debugInfoEnabled(false) 

	//theme
	$mdThemingProvider.theme('default')
		.primaryPalette('blue')
		.accentPalette('deep-orange')
}


/** @ngInject */
function contextmenuDirective($parse) {
	return function($scope, $element, attrs) {
		var fn = $parse(attrs.ngContextmenu)
		$element.bind('contextmenu', function(evt) {
			$scope.$apply(function() {
				evt.preventDefault()
				fn($scope, {$event: evt})
			})
		})
	}
}

/** @ngInject */
function AppController($scope) {
	//controllerAs
	this.version = '0.0.2'
}