
## How to run

### run without server

* close all chrome processes
* add paramter `--allow-file-access-from-files` to chrome shortcut
* open chrome by *clicking this shortcut*
* drag index.html to chrome
* navigateto file://c:/existing/path/app/index.html#/dashboard

### run with python (assume python installed)

* open windows cmd, and cd to root folder of this project
* if python2, `python -m SimpleHTTPServer 8000`
* if python3, `python -m http.server 8000`
* chrome navigate to http://localhost:8000/app/index.html#/dashboard

### run with jetty (it is overkilled)

* under project base folder
* `mvn jetty:run`
* chrome navigate to http://localhost:8000/app/index.html#/dashboard

### run with gulp (support auto reload)

* under project base folder
* `gulp serve`
* chrome navigate to http://localhost:3000/app/index.html#/dashboard

## Build

### Unoptimized package 

  just pack app/* : `tar -czf app.tgz app/`

### Optimized package (gulp required)

	gulp
	tar -czf app.tgz dist/

## Dependencies

* [angular.js](https://github.com/angular/angular) 1.4.9
* [angular material](https://github.com/angular/material) 1.0.5


## Project layout

* index.html is the access point
* Every 2nd level folder is an angular module, module folder have a js file name same as folder name, that js defines the module
* Every module can have its own css/html/js files, index.html is responsible for loading those required assets, in appropriate order

## Developer guide

see [link](DeveloperGuide.md)
