
# Guideline

## one module, one folder

## use Promise, it leads to robust code

## write a directive/factory/filter if you find code duplication is required

## don't forget :

* `/* @ngInject */`
* IIFE  `(function(){})()`
* `$scope.$on('$destroy', cb)` to release resource , for example , timer
* handle exception where it might occur -- even you think that is normally unlikely
* existing code : if you think it is ugly, **refactor or completely rewrite**
