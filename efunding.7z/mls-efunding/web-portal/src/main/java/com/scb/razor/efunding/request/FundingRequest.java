package com.scb.razor.efunding.request;

public class FundingRequest {

}
