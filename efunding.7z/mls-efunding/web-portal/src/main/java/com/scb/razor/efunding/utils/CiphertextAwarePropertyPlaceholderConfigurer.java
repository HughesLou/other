package com.scb.razor.efunding.utils;

import java.util.List;

import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;

import com.scb.sabre.tcc.util.CipherBean;

/**
 * if the value is cyphertext, return decrypted value instead of original value .
 * 
 * cyphertext detection : text value starts with "encrypted:"
 * @author 1510954
 */
public class CiphertextAwarePropertyPlaceholderConfigurer extends PropertyPlaceholderConfigurer {
	
	private final static String PREFIX = "encrypted:";
	
	private List<String> encryptedPropertyNames; //implicitly encrypted (without encrypted: prefix but still is)

	@Override
    protected String convertProperty(String propertyName, String propertyValue) {
	    if(encryptedPropertyNames != null && encryptedPropertyNames.contains(propertyName)) {
	        propertyValue = decryptValue(propertyValue);
	    }
	    if(propertyValue.startsWith(PREFIX)) {
	        propertyValue = decryptValue(propertyValue);
	    }
        return super.convertProperty(propertyName, propertyValue);
    }
	
	private String decryptValue(String input) {
	    String trim = input.replace(PREFIX, "").trim();
        return cipher.decrypt(trim);
	}
	
	@Override
	protected String convertPropertyValue(String originalValue) {
		if(originalValue == null || !originalValue.startsWith(PREFIX)) {
			return originalValue;
		}
		
		String trim = originalValue.replace(PREFIX, "").trim();
		return cipher.decrypt(trim);
	}
	
	private CipherBean cipher;

	public CipherBean getCipher() {
		return cipher;
	}

	public void setCipher(CipherBean cipher) {
		this.cipher = cipher;
	}

    public List<String> getEncryptedPropertyNames() {
        return encryptedPropertyNames;
    }

    public void setEncryptedPropertyNames(List<String> encryptedPropertyNames) {
        this.encryptedPropertyNames = encryptedPropertyNames;
    }
}
