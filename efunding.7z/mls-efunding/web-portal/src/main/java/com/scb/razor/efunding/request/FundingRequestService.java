package com.scb.razor.efunding.request;

import java.util.HashSet;
import java.util.Set;

import org.springframework.stereotype.Component;

@Component
public class FundingRequestService {
    
    private Set<ActionHandler> handlers = new HashSet<>();

    public void performAction(ActionContext ctx) {
        //find handler
        ActionHandler handler = null;
        handler.handle();
    }
    
    public void lockIn(FundingRequest ctx, Object actionParams) {
        //before reaching this line :
        //#action parameters should be validated
        //#guarantee this is the only action performed against this FundingRequest
    }
    
    public void book(FundingRequest ctx, Object actionParams) {
        
    }
    
    public void amend(FundingRequest ctx, Object actionParams) {
        
    }
    
    public void breakFunding(FundingRequest ctx, Object actionParams) {
        
    }
    
    public void rollOver(FundingRequest ctx, Object actionParams) {
        
    }
    
    public void newRequest(FundingRequest ctx, Object actionParams) {
        
    }
    
    public void tenorExtension(FundingRequest ctx, Object actionParams) {
        
    }
    
    public void topUp(FundingRequest ctx, Object actionParams) {
        
    }
    
    public void additionalCurrency(FundingRequest ctx, Object actionParams) {
        
    }
    
    public void additionalDrawdownTenor(FundingRequest ctx, Object actionParams) {
        
    }
    
    public void repricingFrequency(FundingRequest ctx, Object actionParams) {
        
    }
    
    public void paymentSchedule(FundingRequest ctx, Object actionParams) {
        
    }
    
    public void rateReset(FundingRequest ctx, Object actionParams) {
        
    }
    
    public void cancel(FundingRequest ctx, Object actionParams) {
        
    }
}

class ActionContext{
    
}

class ActionHandler {
    
    private Boolean accept;
    
    private Object input;
    
    public boolean accept() {
        if(this.accept != null) {
            return this.accept;
        }
        this.accept = false;
        return this.accept;
    }
    
    public void handle() {
        
    }
}