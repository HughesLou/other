package com.scb.razor.efunding.idea;

import java.util.concurrent.Semaphore;

public class FundingContext {

    private FundingRequest req;
    
    private Semaphore actionInProgress = new Semaphore(1);
    
    public void perform(Action action) throws Exception {
        actionInProgress.acquire();
        //TODO action
        actionInProgress.release();
    }
}

class FundingRequest {
    
}

class RFQ {
    
}

class Action {
    //lock-in, break-fund, amendment
}
