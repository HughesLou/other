package com.scb.razor.efunding.kv;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

/**
 * a value belong to a set (data structure)
 * 
 * 'set' implies no duplicate entries, it is perfectly feasible to have this hypothesis in database data
 * @author 1510954
 */
@Entity
@DiscriminatorValue("SET")
public class SetValue extends Value{

    @Column(name="SET_KEY")
    private String setkey;

    public String getSetkey() {
        return setkey;
    }

    public void setSetkey(String setkey) {
        this.setkey = setkey;
    }
}
