package com.scb.razor.efunding.kv;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Component;

@Component
public class KeyValueService {

    private final static Logger log = LoggerFactory.getLogger(KeyValueService.class);
    
    @Resource
    private SessionFactory sessionFactory;
    
    public Map<String, String> getSettings() {
        HibernateTemplate ht = new HibernateTemplate(sessionFactory);
        MapValue mv = new MapValue();
        mv.setSetkey("RUNTIME_SETTING");
        List<MapValue> list = ht.findByExample(mv);
        
        Map<String, String> map = new HashMap<>();
        for(MapValue i : list) {
            map.put(i.getKey(), i.getValue());
        }
        return map;
    }
}
