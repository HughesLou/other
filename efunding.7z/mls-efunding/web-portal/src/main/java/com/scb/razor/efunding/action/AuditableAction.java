package com.scb.razor.efunding.action;

/**
 * business action, performed by user or system, persisted and available for audit trail
 * @author 1510954
 *
 */
public interface AuditableAction {

    public String describe();
}
