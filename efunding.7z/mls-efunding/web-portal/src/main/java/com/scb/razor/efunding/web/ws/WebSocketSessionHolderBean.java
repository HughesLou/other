package com.scb.razor.efunding.web.ws;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.websocket.Session;

import org.springframework.stereotype.Component;

import com.google.common.eventbus.Subscribe;
import com.scb.razor.efunding.BusEvent;

@Component
public class WebSocketSessionHolderBean {

    private List<Session> sessions = new LinkedList<>();
    
    public void onOpen(Session session) {
        sessions.add(session);
    }
    
    public void onCloseOrError(Session session) {
        Iterator<Session> iter = sessions.iterator();
        while(iter.hasNext()) {
            if(iter.next() == session) {
                iter.remove();
            }
        }
    }
    
    @Subscribe
    public void onEvent(BusEvent evt) throws Exception {
        Iterator<Session> iter = sessions.iterator();
        String message = "event : " + evt;
        while(iter.hasNext()) {
            Session session = iter.next();
            if(session.isOpen() == false) {
                iter.remove();
            } else {
                session.getAsyncRemote().sendText(message);
            }
        }
    }
}
