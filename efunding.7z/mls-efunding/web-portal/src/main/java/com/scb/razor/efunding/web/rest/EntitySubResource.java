package com.scb.razor.efunding.web.rest;

import java.beans.PropertyDescriptor;
import java.beans.PropertyEditor;
import java.beans.PropertyEditorSupport;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jettison.json.JSONObject;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.beans.SimpleTypeConverter;
import org.springframework.beans.TypeConverter;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.web.bind.ServletRequestDataBinder;

import com.sun.jersey.api.NotFoundException;

public class EntitySubResource implements InitializingBean{
	
	private final static Logger log = LoggerFactory.getLogger(EntitySubResource.class);

	private Class<?> entityClass;
	
	private String idPropertyName;
	
	private Class<?> idPropertyType;
	
	private TypeConverter typeConverter;
	
	private String[] defaultExcludeFields;
	
	private String[] defaultIncludeFields;
	
	private String defaultSort;
	
	private String[] allReadableFields;//has method like getAbc(), may not map to db column
	
	private Map<Class<?>, PropertyEditor> propertyEditors;
	
	/*@Autowired doesn't work with SubResource, manual injection is required*/
	private HibernateTemplate ht;
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Object list(
			@Context HttpServletRequest req,
			@QueryParam("firstResult") @DefaultValue("0")  int firstResult,
			@QueryParam("maxResults")  @DefaultValue("20") int maxResults,
			@QueryParam("sort") String sort,
			@QueryParam("fields") String fields,
			@QueryParam("view") @DefaultValue("list") String view) {
	    
	    boolean count = "count".equalsIgnoreCase(view);
		
		Object inst;
		try {
			inst = entityClass.newInstance();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		ServletRequestDataBinder binder = new ServletRequestDataBinder(inst);
		for(Entry<Class<?>, PropertyEditor> entry : propertyEditors.entrySet()) {
			binder.registerCustomEditor(entry.getKey(), entry.getValue());
		}
		binder.bind(req);
		if (binder.getBindingResult().hasErrors()) {
			throw new RuntimeException(binder.getBindingResult().toString());
		}
		
		Object example = binder.getTarget();
		DetachedCriteria dc = DetachedCriteria.forClass(entityClass);
		dc.add(Example.create(example));
		
		if (StringUtils.isNotBlank(req.getParameter(idPropertyName))) {
			//fix : hibernate Example criterion will by pass id property
			try {
				dc.add(Restrictions.eq(idPropertyName, new BeanWrapperImpl(example).getPropertyValue(idPropertyName)));
			}catch(Exception e) {
				throw new WebApplicationException(e);
			}
		}
		
		BeanWrapperImpl bw = new BeanWrapperImpl(entityClass);
		bw.setAutoGrowNestedPaths(true);//IMPORTANT when #getPropertyType called : will create value if nested property is null value
		
		Set<String> alias = new HashSet<String>();
		for(String pname : allReadableFields) {
			if (pname.contains(".")) {
				alias.add(split(pname).getKey());
			}
		}
		for(String a : alias) {
			dc.createAlias(a, a.replace(".", "_") + "_");
		}
		
		for(String pname : allReadableFields) {
			
			String pin 	 = req.getParameter(pname + "In");
			String pfrom = req.getParameter(pname + "From");
			String pto   = req.getParameter(pname + "To");
			String plike = req.getParameter(pname + "Like");
			String pnull = req.getParameter(pname + "IsNull");
			String pnot = req.getParameter(pname + "IsNot");
			String pp    = req.getParameter(pname);
			
			Class<?> cls = bw.getPropertyType(pname);
			if(cls == null) {
				log.warn("{} parameter will be ignored as no bean property found for it", pin);
				continue;
			}
			
			String propertyPath = pname;
			if(propertyPath.contains(".")) {
				SimpleEntry<String, String> se = split(propertyPath);
				propertyPath = se.getKey().replace(".", "_") + "_." + se.getValue();
			}
			
			if (StringUtils.isNotBlank(pp) && pname.contains(".")) {
				Object v = typeConverter.convertIfNecessary(pp, cls);
				dc.add(Restrictions.eq(propertyPath, v));
			}
			
			if (StringUtils.isNotBlank(pin)) {
				String[] ins = pin.split(",");
				ArrayList<Object> invalues = new ArrayList<Object>();
				
				for(String in : ins) {
					Object v = typeConverter.convertIfNecessary(in, cls);
					invalues.add(v);
				}
				dc.add(Restrictions.in(propertyPath, invalues));
			}
			
			if (StringUtils.isNotBlank(pfrom)) {
				Object v = typeConverter.convertIfNecessary(pfrom, cls);
				dc.add(Restrictions.ge(propertyPath, v));
			}
			
			if (StringUtils.isNotBlank(pto)) {
				Object v = typeConverter.convertIfNecessary(pto, cls);
				dc.add(Restrictions.lt(propertyPath, v));
			}
						
			if (StringUtils.isNotBlank(plike)) {
				dc.add(Restrictions.ilike(propertyPath, plike));
			}
			
			if (StringUtils.isNotBlank(pnot)) {
				dc.add(Restrictions.ne(propertyPath, pnot));
			}

			if (StringUtils.isNotBlank(pnull) && StringUtils.containsIgnoreCase(pnull, "yes")) {
				dc.add(Restrictions.isNull(propertyPath));
			}
			
			if (StringUtils.isNotBlank(pnull) && StringUtils.containsIgnoreCase(pnull, "no")) {
				dc.add(Restrictions.isNotNull(propertyPath));
			}
		}
		
		sort = StringUtils.isBlank(sort) ? defaultSort : sort;
		if (!StringUtils.isBlank(sort) && !count) {
			
			log.debug("sort param found, will apply '{}'", sort);
			
			Pattern ptn = Pattern.compile("([+-]?) *([^+-,]+) *");
			Matcher m = ptn.matcher(sort);
			
			while(m.find()) {
				String a = m.group(1), p = m.group(2);
				if(!ArrayUtils.contains(allReadableFields, p)) {
					log.warn("will ignore sort param {} as no corresponding bean property found");
				};
				String propertyPath = p;
				if(propertyPath.contains(".")) {
					SimpleEntry<String, String> se = split(propertyPath);
					propertyPath = se.getKey().replace(".", "_") + "_." + se.getValue();
				}
				if("-".equals(a)) {
					dc.addOrder(Order.desc(propertyPath));
				} else {
					dc.addOrder(Order.asc(propertyPath));
				}
			}
		}
		
		if (count) {
			dc.setProjection(Projections.rowCount());
			@SuppressWarnings("unchecked")
			List<BigDecimal> list = (List<BigDecimal>) ht.findByCriteria(dc);
			HashMap<String, Object> map = new HashMap<String, Object>();
			map.put("count", list.get(0));
			return map;
		} else {
			@SuppressWarnings("rawtypes")
			List result = ht.findByCriteria(dc, firstResult, maxResults);
			
			if (fields != null) {
				log.debug("fields param found, will apply this filter on resultset '{}'", fields);
			} else if(defaultIncludeFields != null) {
				log.debug("will apply default include field filter '{}'", (Object)defaultIncludeFields);
			} else if (defaultExcludeFields != null) {
				log.debug("will apply default exclude field filter '{}'", (Object)defaultExcludeFields);
			}
			
			List<Object> transformed = new ArrayList<Object>();
			for(Object o : result) {
				Map<String, Object> map = applyFieldsFilter(o, fields);
				transformed.add(map);
			}
			return transformed;
		}
	}
	
	@GET @Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Object one(@PathParam("id") String id, @QueryParam("fields") String fields) {
		
		Serializable sid = (Serializable) typeConverter.convertIfNecessary(id, idPropertyType);
		
		Object result = ht.get(entityClass, sid);
		
		if (result == null) {
			throw new NotFoundException(String.format("%s not found ", id));
		}
		
		Map<String, Object> map = applyFieldsFilter(result, fields);
		return map;
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Object createEntities(JSONObject json) {
		
		Object bean = toBean(json);
		ht.save(bean);
		ht.flush();
		return bean;
	}
	
	@PUT @Path("/{id}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Object updateEntity(@PathParam("id") String idstr, JSONObject json) {
		
		Serializable id = (Serializable) typeConverter.convertIfNecessary(idstr, idPropertyType);
			
		Object bean = toBean(json);
		
		BeanWrapperImpl bw = new BeanWrapperImpl(bean);
		bw.setPropertyValue(idPropertyName, id);
		
		ht.update(bean);
		ht.flush();
		return bean;
	}

	@Override
	public void afterPropertiesSet() {
		
		if (propertyEditors == null) {
			propertyEditors = new HashMap<Class<?>, PropertyEditor>();
			
			propertyEditors.put(java.sql.Date.class, new PropertyEditorSupport(){
				
				@Override
				public void setAsText(String text) throws IllegalArgumentException {
						setValue(java.sql.Date.valueOf(text));
				}
			});
			
			propertyEditors.put(java.util.Date.class, new PropertyEditorSupport(){
				
				@Override
				public void setAsText(String text) throws IllegalArgumentException {
					try {
						Date date = DateUtils.parseDate(text, "yyyy-MM-dd'T'HH:mm:ss", "yyyy-MM-dd", "yyyy-MM-dd HH:mm:ss");
						setValue(date);
					}catch(Exception e) {
						throw new IllegalArgumentException(e);
					}
				}
			});
		}
		
		if (typeConverter == null) {
			SimpleTypeConverter tc = new SimpleTypeConverter();
			
			for(Entry<Class<?>, PropertyEditor> entry : propertyEditors.entrySet()) {
				tc.registerCustomEditor(entry.getKey(), entry.getValue());
			}
			typeConverter = tc;
		}
		log.debug("typeConverter for {} is {}", entityClass, typeConverter);
		
		if (idPropertyName == null || idPropertyType == null) {
			Field idField = null;
			for(Field f : FieldUtils.getAllFields(entityClass)) {
				Id i = f.getAnnotation(Id.class);
				if (i != null) {
					idField = f;
					break;
				}
			}
			if (idField == null) {
				throw new RuntimeException(String.format("NO id field found for %s", entityClass));
			}
			setIdPropertyName(idField.getName());
			setIdPropertyType(idField.getType());
		}
		log.debug("id is {}:{}", idPropertyName, idPropertyType);
		
		if (allReadableFields == null) {
			ArrayList<String> temp = new ArrayList<String>();
			walkReadableFields("", entityClass, temp);
			setAllReadableFields(temp.toArray(new String[temp.size()]));
		}
		log.debug("allReadableFields for {} is {}", entityClass, ArrayUtils.toString(allReadableFields));
	}
	
	private Object toBean(JSONObject json) {
		ObjectMapper om = new ObjectMapper();
		try {
			return om.readValue(json.toString(), entityClass);
		}catch(Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	private Map<String, Object> applyFieldsFilter(Object bean, String fieldsFromParam) {
		
		HashMap<String, Object> map = new HashMap<String, Object>();
		
		String[] excludes = null, includes = null;
		BeanWrapperImpl bw = new BeanWrapperImpl(bean);
		
		if (StringUtils.isNotBlank(fieldsFromParam)) {
			Pattern ptn = Pattern.compile("([+-]?) *([^+-,]+) *");
			Matcher m = ptn.matcher(fieldsFromParam);
			ArrayList<String> exlist = new ArrayList<String>(), inlist = new ArrayList<String>();
			while(m.find()) {
				String t = m.group(1), fname = m.group(2);
				if (ArrayUtils.contains(allReadableFields, fname)) {
					if ("-".equals(t)) {
						exlist.add(fname);
					} else {
						inlist.add(fname);
					}
				}
			}
			excludes = exlist.toArray(new String[exlist.size()]);
			includes = inlist.toArray(new String[inlist.size()]);
		}
		
		excludes = (excludes == null || excludes.length == 0) ? defaultExcludeFields : excludes;
		includes = (includes == null || includes.length == 0) ? defaultIncludeFields : includes;
		
		for(String f : allReadableFields) {
			if (f.contains(".")) {
				continue;
			}
			if (excludes != null && excludes.length > 0) {
				if (ArrayUtils.contains(excludes, f) == false) {
					map.put(f, bw.getPropertyValue(f));
				}
			} else if (includes != null && includes.length > 0) {
				if (ArrayUtils.contains(includes, f) == true) {
					map.put(f, bw.getPropertyValue(f));
				}
			} else {
				map.put(f, bw.getPropertyValue(f));
			}
		}
		return map;
	}
	
	private SimpleEntry<String, String> split(String propertyPath) {
		if(propertyPath.contains(".") == false)
			return new SimpleEntry<String, String>(null, propertyPath);
		return new SimpleEntry<String, String>(propertyPath.substring(0, propertyPath.lastIndexOf(".")), propertyPath.substring(propertyPath.lastIndexOf(".") + 1, propertyPath.length()));
	}
	
	private void walkReadableFields(String root, Class<?> klass, List<String> list) {
		//TODO cyclic detection
		BeanWrapperImpl bw = new BeanWrapperImpl(klass);
		PropertyDescriptor[] pds = bw.getPropertyDescriptors();
		for(PropertyDescriptor pd : pds) {
			String pname = pd.getName();
			String fullName = (root == "" ? "" : (root + ".")) + pname;
			if (bw.isReadableProperty(pname) && !pname.equals("class")) {
				list.add(fullName);
			}
			Entity ent = pd.getPropertyType().getAnnotation(Entity.class);
			if (ent != null) {
				walkReadableFields(fullName, pd.getPropertyType(), list);
			}
		}
	}
	
	//==================================================
	//setter and getter
	public Class<?> getEntityClass() {
		return entityClass;
	}

	public void setEntityClass(Class<?> entityClass) {
		this.entityClass = entityClass;
	}

	public void setHibernateTemplate(HibernateTemplate ht) {
		this.ht = ht;
	}

	public HibernateTemplate getHibernateTemplate() {
		return ht;
	}

	public TypeConverter getTypeConverter() {
		return typeConverter;
	}

	public void setTypeConverter(TypeConverter typeConverter) {
		this.typeConverter = typeConverter;
	}

	public String[] getDefaultExcludeFields() {
		return defaultExcludeFields;
	}

	public void setDefaultExcludeFields(String... defaultExcludeFields) {
		this.defaultExcludeFields = defaultExcludeFields;
	}

	public String[] getDefaultIncludeFields() {
		return defaultIncludeFields;
	}

	public void setDefaultIncludeFields(String... defaultIncludeFields) {
		this.defaultIncludeFields = defaultIncludeFields;
	}

	public String[] getAllReadableFields() {
		return allReadableFields;
	}

	public void setAllReadableFields(String... allReadableFields) {
		this.allReadableFields = allReadableFields;
	}

	public String getIdPropertyName() {
		return idPropertyName;
	}

	public void setIdPropertyName(String idPropertyName) {
		this.idPropertyName = idPropertyName;
	}

	public Class<?> getIdPropertyType() {
		return idPropertyType;
	}

	public void setIdPropertyType(Class<?> idPropertyType) {
		this.idPropertyType = idPropertyType;
	}

	public String getDefaultSort() {
		return defaultSort;
	}

	public void setDefaultSort(String defaultSort) {
		this.defaultSort = defaultSort;
	}

	public Map<Class<?>, PropertyEditor> getPropertyEditors() {
		return propertyEditors;
	}

	public void setPropertyEditors(Map<Class<?>, PropertyEditor> propertyEditors) {
		this.propertyEditors = propertyEditors;
	}
}
