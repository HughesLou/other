package com.scb.razor.efunding.idea;

import java.util.concurrent.Semaphore;

/**
 * for async actions, it is action itself's responsible to call 'done()' after action performed completely
 * @author 1510954
 *
 */
public abstract class AsyncAction {
    
    public AsyncAction(Semaphore permit) {
        this.permit = permit;
    }
    
    public AsyncAction() {
    }

    protected transient Semaphore permit;
    
    protected void done() {
        permit.release();
    }
}
