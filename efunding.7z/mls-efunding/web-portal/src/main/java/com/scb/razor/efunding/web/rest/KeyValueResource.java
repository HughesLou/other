package com.scb.razor.efunding.web.rest;

import javax.annotation.Resource;
import javax.ws.rs.Path;

import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Component;

import com.scb.razor.efunding.kv.MapValue;
import com.scb.razor.efunding.kv.SetValue;

@Component
@Path("/kv")
public class KeyValueResource {

    @Resource
    private SessionFactory sessionFactory;
    
    @Path("/map")
    public EntitySubResource mapSubResource() {
        HibernateTemplate ht = new HibernateTemplate(sessionFactory);
        EntitySubResource sr = new EntitySubResource();
        sr.setEntityClass(MapValue.class);
        sr.setHibernateTemplate(ht);
        sr.afterPropertiesSet();
        return sr;
    }
    
    @Path("/set")
    public EntitySubResource setSubResource() {
        HibernateTemplate ht = new HibernateTemplate(sessionFactory);
        EntitySubResource sr = new EntitySubResource();
        sr.setEntityClass(SetValue.class);
        sr.setHibernateTemplate(ht);
        sr.afterPropertiesSet();
        return sr;
    }
}
