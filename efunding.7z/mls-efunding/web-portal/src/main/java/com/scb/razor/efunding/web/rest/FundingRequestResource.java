package com.scb.razor.efunding.web.rest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

@Path("/requests")
public class FundingRequestResource {

    @GET
    public Object list() {
        return "list...";
    }

}
