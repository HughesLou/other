package com.scb.razor.efunding.request;

public class RFQ {

    private Object request;
    
    private Object response;
}
