package com.scb.razor.efunding.web.ws;


import javax.websocket.server.ServerEndpointConfig.Configurator;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

/**
 * this is tricky.
 * 
 * the purpose of implementing ApplicationContextAware and annotating with @Component is to acquire a spring context so that 
 * spring beans can be injected into websocket endpoints. the instance hold by spring context is useless.
 * 
 * {@link #setApplicationContext(ApplicationContext)} will be invoked when spring scan packages for context initialization.
 * the acquired context will be a static field -- because instantiation of {@link Configurator} is out of control
 * 
 * 
 *  This class need to be in spring scan path.
 * @author 1510954
 *
 */
@Component
public class SpringServerEndpointConfigurator extends Configurator implements ApplicationContextAware {
    
    @Override
    public <T> T getEndpointInstance(Class<T> endpointClass) throws InstantiationException {
        return CONTEXT.getAutowireCapableBeanFactory().createBean(endpointClass);
    }
    
    private static ApplicationContext CONTEXT;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        CONTEXT = applicationContext;
    }
}
