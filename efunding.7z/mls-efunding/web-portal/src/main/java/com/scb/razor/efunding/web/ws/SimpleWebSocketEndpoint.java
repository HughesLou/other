package com.scb.razor.efunding.web.ws;

import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@ServerEndpoint(value="/socket", configurator=com.scb.razor.efunding.web.ws.SpringServerEndpointConfigurator.class)
public class SimpleWebSocketEndpoint {
    
    private final static Logger log = LoggerFactory.getLogger(SimpleWebSocketEndpoint.class);
    
    @Resource
    private SessionFactory sessionFactory;

    @OnMessage
    public void onMessage(String message, Session session) throws Exception{
        log.debug("received incoming message {}", message);
    }
    
    @Resource
    private WebSocketSessionHolderBean sessionHolder;
    
    @OnOpen
    public void onOpen(Session session) {
        session.setMaxIdleTimeout(TimeUnit.HOURS.toMillis(5));//5 hrs idle
        sessionHolder.onOpen(session);
    }
    
    @OnClose
    public void onClose(Session session) {
        sessionHolder.onCloseOrError(session);
    }
    
    @OnError
    public void onError(Session session) {
        sessionHolder.onCloseOrError(session);
    }
    
//    @Subscribe
//    public void onBusEvent(BusEvent evt) {
//        log.debug("received bus event {}", evt);
//    }
}
