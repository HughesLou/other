package com.scb.razor.efunding.web.rest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

import org.springframework.core.io.ClassPathResource;

@Path("/runtime")
public class RuntimeResource {

    @GET
    @Path("/file/{file}")
    public Object getFileInClassPath(@PathParam("file") String file) throws Exception{
        
        ClassPathResource r = new ClassPathResource(file);
        return r.getFile();
    }
    
    @GET
    @Path("/dump")
    public Object threadDump() throws Exception {
        
        return "//TODO";
    }
}
