package com.scb.razor.efunding.kv;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

/**
 * a value has a key mapped to it, all (key, value)s contained in a set 
 * @author 1510954
 */
@Entity
@DiscriminatorValue("MAP")
public class MapValue extends SetValue{

    @Column(name="MAP_KEY")
    private String key;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
