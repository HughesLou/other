package com.scb.razor.efunding.test;

import java.util.Properties;

import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.dialect.H2Dialect;
import org.hibernate.dialect.Oracle10gDialect;
import org.hibernate.tool.hbm2ddl.SchemaExport;
import org.junit.Test;

import com.scb.razor.efunding.kv.MapValue;
import com.scb.razor.efunding.kv.SetValue;
import com.scb.razor.efunding.kv.Value;

public class SchemaGenerationUtility {

    @Test
    public void testExportH2() throws Exception {
        
        Configuration conf = new Configuration();
        conf.addAnnotatedClass(Value.class);
        conf.addAnnotatedClass(MapValue.class);
        conf.addAnnotatedClass(SetValue.class);
        
        Properties p = new Properties();
        p.put(Environment.DIALECT, Oracle10gDialect.class.getCanonicalName());
        conf.addProperties(p);
        
        SchemaExport se = new SchemaExport(conf);
        
        System.out.println("\n\n\n\nORACLE ORACLE\n\n\n\n\n");
        se.create(true, false);
        
        System.out.println("\n\n\n\nH2H2H2H2\n\n\n\n\n");
        conf.getProperties().put(Environment.DIALECT, H2Dialect.class.getCanonicalName());
        se.create(true, false);
    }
}
