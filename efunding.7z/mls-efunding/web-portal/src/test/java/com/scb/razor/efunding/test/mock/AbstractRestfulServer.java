package com.scb.razor.efunding.test.mock;

import org.junit.rules.TestRule;
import org.junit.runner.Description;
import org.junit.runners.model.Statement;

import com.sun.jersey.api.container.httpserver.HttpServerFactory;
import com.sun.jersey.api.core.DefaultResourceConfig;
import com.sun.net.httpserver.HttpServer;

public abstract class AbstractRestfulServer implements TestRule{

    @Override
    public Statement apply(final Statement base, Description description) {
        return new Statement() {
            @Override
            public void evaluate() throws Throwable {
                beforeEvaluate();
                base.evaluate();
            }
        };
    }
    
    protected void beforeEvaluate() {
        try {
            this.createServer();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    @SuppressWarnings("restriction")
    private HttpServer srv;
    
    @SuppressWarnings("restriction")
    private void createServer() throws Exception {
        if(srv != null) {
            return;
        }
        DefaultResourceConfig rc = new DefaultResourceConfig(getResourceClasses());
        srv = HttpServerFactory.create(getURI(), rc);
        srv.start();
    }
    
    protected abstract String getURI();
    
    protected abstract Class[] getResourceClasses();
}
