package com.scb.razor.efunding.test;

import javax.ws.rs.core.MediaType;

import org.junit.ClassRule;
import org.junit.Test;

import com.scb.razor.efunding.test.mock.WebappServerInfo;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;

public class WebappPlayground {
    
    @ClassRule
    public static WebappServerInfo SRV = new WebappServerInfo();
//    /**
//     * webapp is the last to bring up before testcase run
//     */
//    @ClassRule
//    public static WebappServerInfo createWebapp() {
//        SRV = new WebappServerInfo();
//        return SRV;
//    }
    
    @Test
    public void testAccess() throws Exception {
        
        Thread.sleep(10000000);
        Client client = new Client();
        WebResource r = client.resource(SRV.getAddress() + "/efunding/rest/kv/map");
        
        System.out.println(r.get(String.class));
        
        r.entity("{\"key\":\"ksdfs\", \"value\":\"123\"}", MediaType.APPLICATION_JSON).post();
        
        System.out.println(r.get(String.class));
        
    }
}
