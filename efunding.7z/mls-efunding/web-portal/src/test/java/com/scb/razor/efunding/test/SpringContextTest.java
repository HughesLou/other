package com.scb.razor.efunding.test;

import java.util.Properties;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.scb.razor.efunding.kv.MapValue;
import com.scb.razor.efunding.test.mock.H2ServerInfo;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="classpath:applicationContext.xml")
//@Transactional
public class SpringContextTest {

    @Resource @Qualifier("configurationProperties")
    private Properties conf;
    
    @Resource
    private SessionFactory sessionFactory;
    
    @ClassRule
    public static H2ServerInfo h2 = new H2ServerInfo();
    
    @Transactional
    @Test
    public void testBootSpringContext() throws Exception {
        
        HibernateTemplate ht = new HibernateTemplate();
        ht.setSessionFactory(sessionFactory);

        System.out.println(ht.find("select count(*) from MapValue"));
        
        MapValue kv = new MapValue();
        kv.setKey("k");
        kv.setValue("v");
        ht.save(kv);
        
        System.out.println(ht.find("select count(*) from MapValue"));
    }
}
