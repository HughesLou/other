package com.scb.razor.efunding.test.mock;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.eclipse.jetty.annotations.AnnotationConfiguration;
import org.eclipse.jetty.plus.webapp.EnvConfiguration;
import org.eclipse.jetty.plus.webapp.PlusConfiguration;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.ServerConnector;
import org.eclipse.jetty.server.handler.ContextHandlerCollection;
import org.eclipse.jetty.server.handler.HandlerCollection;
import org.eclipse.jetty.webapp.Configuration;
import org.eclipse.jetty.webapp.FragmentConfiguration;
import org.eclipse.jetty.webapp.MetaInfConfiguration;
import org.eclipse.jetty.webapp.WebAppContext;
import org.eclipse.jetty.webapp.WebInfConfiguration;
import org.eclipse.jetty.webapp.WebXmlConfiguration;
import org.junit.rules.TestRule;
import org.junit.runner.Description;
import org.junit.runners.model.Statement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WebappServerInfo implements TestRule{
    
    private final static Logger log = LoggerFactory.getLogger(WebappServerInfo.class);

    private Server srv = null;
    
    private WebAppContext webapp;
    
    @Override
    public Statement apply(final Statement base, Description description) {
        return new Statement() {
            @Override
            public void evaluate() throws Throwable {
                beforeEvaluate();
                base.evaluate();
            }
        };
    }
    
    private String addr;
    public String getAddress() {
        return addr;
    }
    
    protected void beforeEvaluate() {
        try {
            this.createServer();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    private synchronized Server createServer() throws Exception {
        
        if (srv != null && srv.isRunning()) {
            return srv;
        }
        
        H2ServerInfo h2 = new H2ServerInfo();
        h2.createServer();
        
        srv = new Server();
        ServerConnector ctor = new ServerConnector(srv);
        ctor.setPort(0);//ctor.setPort(0);
        srv.addConnector(ctor);
        
        HandlerCollection handlers = new HandlerCollection();
        ContextHandlerCollection contexts = new ContextHandlerCollection();
        handlers.addHandler(contexts);
        srv.setHandler(handlers);
        
        srv.start();
        
        addr = "http://localhost:" + ctor.getLocalPort();
        
        log.info(String.format("started at %s:%s\n", "localhost", ctor.getLocalPort()));
        
        File webappdir = new File("target/test-webapp");
        if(webappdir.exists())
            FileUtils.deleteDirectory(webappdir);
        webappdir.mkdir();
        FileUtils.copyDirectory(new File("src/main/webapp/WEB-INF"), new File(webappdir, "WEB-INF"));
        FileUtils.copyDirectory(new File("target/classes"), new File(webappdir, "WEB-INF/classes"));
        webapp = new WebAppContext();
        webapp.setContextPath("/efunding");
        webapp.setResourceBase(webappdir.getPath());
        webapp.setAttribute("org.eclipse.jetty.websocket.jsr356",Boolean.TRUE);
        webapp.setConfigurations(new Configuration[]{
                new AnnotationConfiguration(),
                new WebXmlConfiguration(),
                new WebInfConfiguration(),
                new PlusConfiguration(),
                new MetaInfConfiguration(),
                new FragmentConfiguration(),
                new EnvConfiguration()
        });
        contexts.addHandler(webapp);
        contexts.manage(webapp);
        webapp.start();
        
        webapp.dump(System.err);
        
        return srv;
    }
}
