package com.scb.razor.efunding.test.mock;

import java.io.File;
import java.util.Arrays;

import org.apache.commons.io.FileUtils;
import org.h2.Driver;
import org.h2.tools.Server;
import org.junit.rules.TestRule;
import org.junit.runner.Description;
import org.junit.runners.model.Statement;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;
import org.springframework.jdbc.datasource.init.DataSourceInitializer;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;

/**
 * NOT IN USE , DUE TO THAT CANNOT GUARRANTEE IT IS INITED BEFORE APP (ClassRule)
 */
public class H2ServerInfo implements TestRule {

	@Override
	public Statement apply(final Statement base, Description description) {
		return new Statement() {
			@Override
			public void evaluate() throws Throwable {
				createServer();
				if(base != null)
					base.evaluate();
			}
		};
	}
	
	private SimpleDriverDataSource dataSource;
	
	private Server srv;
	
	public void createServer() throws Exception {
		
		if(srv != null && srv.isRunning(true)) {
			return;
		}
		
		File basedir = new File("target/h2db");
		if(basedir.exists()) {
			FileUtils.deleteDirectory(basedir);
		}
		basedir.mkdir();
		srv = Server.createTcpServer("-tcpPort", "29898", "-tcpPassword", "sa", "-baseDir", basedir.getPath());
		srv.start();
		
		dataSource = new SimpleDriverDataSource();
		dataSource.setDriverClass(Driver.class);
		dataSource.setUrl("jdbc:h2:tcp://localhost:29898/./test;MODE=Oracle;DB_CLOSE_ON_EXIT=FALSE");
		dataSource.setUsername("sa");
		dataSource.setPassword("sa");
		
//		DataSourceInitializer dsi = new DataSourceInitializer();
//		dsi.setDataSource(dataSource);
//		
//		ClassPathResource schema = new ClassPathResource("/schema.sql");
//		ClassPathResource data = new ClassPathResource("/data.sql");
//		if(schema.exists() && data.exists()){
//			ResourceDatabasePopulator p = new ResourceDatabasePopulator();
//			p.addScript(schema);
//			p.addScript(data);
//			dsi.setDatabasePopulator(p);
//			dsi.afterPropertiesSet();
//		}
	}
	
	public void cleanUp() throws Exception {
		
		DataSourceInitializer dsi = new DataSourceInitializer();
		dsi.setDataSource(dataSource);
		
		String s = "";
		for(String t : Arrays.asList("COLL_INTEREST", "COLL_MESSAGE_TRACKING", "COLL_EXCEPTION")) {
			s += "truncate table " + t + ";\n";
		}
		ByteArrayResource truncate = new ByteArrayResource(s.getBytes());
		ClassPathResource data = new ClassPathResource("/data.sql");
		if(truncate.exists() && data.exists()){
			ResourceDatabasePopulator p = new ResourceDatabasePopulator();
			p.addScript(truncate);
			p.addScript(data);
			dsi.setDatabasePopulator(p);
			dsi.afterPropertiesSet();
		}
	}
}
