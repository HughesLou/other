package com.scb.razor.efunding.test.mock;

import java.io.File;
import java.io.StringReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;

import net.timewalker.ffmq3.listeners.ClientListener;
import net.timewalker.ffmq3.listeners.tcp.io.TcpListener;
import net.timewalker.ffmq3.local.FFMQEngine;
import net.timewalker.ffmq3.management.destination.definition.TopicDefinition;
import net.timewalker.ffmq3.utils.Settings;

import org.apache.commons.io.FileUtils;
import org.junit.Test;
import org.junit.rules.TestRule;
import org.junit.runner.Description;
import org.junit.runners.model.Statement;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.jms.listener.DefaultMessageListenerContainer;
import org.springframework.jndi.JndiObjectFactoryBean;
import org.xml.sax.InputSource;

public class MQServerInfo implements TestRule {
	
	private ClientListener srv = null;

	@Override
	public Statement apply(final Statement base, Description description) {
		return new Statement() {
			@Override
			public void evaluate() throws Throwable {
				
				if(srv == null ||  !srv.isStarted()) {
					FileUtils.deleteDirectory(new File("target/mq-data"));
					new File("target/mq-data").mkdir();
					Properties p = new Properties();
					p.put("management.templates.directory", "target/mq-data");
					p.put("management.defaultData.directory", "target/mq-data");
					p.put("management.destinationDefinitions.directory", "target/mq-data");
					Settings settings = new Settings(p);
					FFMQEngine engine = new FFMQEngine("systestmq", settings);
					engine.deploy();
					
					srv = new TcpListener(engine, "0.0.0.0", 10002, settings);
					srv.start();
					
					List<String> topics = Arrays.asList("T_TRADEBOOKING_PUB", "T_TRADEBOOKINGACK_SUB", "scbExDoc_Pub_ReqExDocHandling", "scbExDoc_Sub_RespExDoc_ECLiPSE");
					for(String name : topics) {
						TopicDefinition t1 = new TopicDefinition();
						t1.setName(name);
						t1.setJournalFolder(new File("target/mq-data"));
						t1.setUseJournal(true);
						t1.setInitialBlockCount(100);
						t1.setAutoExtendAmount(100);
						t1.setBlockSize(1024);
						t1.setMaxBlockCount(10000);
						t1.setRawDataFolder("target/mq-data");
						t1.setDataFolder(new File("target/mq-data"));
						t1.setMaxNonPersistentMessages(100000);
						t1.check();
						engine.createTopic(t1);
					}
					
					JndiObjectFactoryBean fb = new JndiObjectFactoryBean();
					fb.setJndiName("factory/ConnectionFactory");
					Properties pp = new Properties();
					pp.put("java.naming.factory.initial", "net.timewalker.ffmq3.jndi.FFMQInitialContextFactory");
					pp.put("java.naming.provider.url", "tcp://localhost:10002");
					fb.setJndiEnvironment(pp);
					fb.afterPropertiesSet();
					ConnectionFactory cf = (ConnectionFactory) fb.getObject();
					
					for(final String name : topics) {
						receivers.put(name, new ArrayBlockingQueue<String>(50));
						DefaultMessageListenerContainer c = new DefaultMessageListenerContainer();
						c.setConnectionFactory(cf);
						c.setDestinationName(name);
						c.setPubSubDomain(true);
						c.setMessageListener(new MessageListener() {
							public void onMessage(Message msg) {
								BlockingQueue<String> que = receivers.get(name);
								try {
									que.put(((TextMessage)msg).getText());
								} catch (Exception e) {
									throw new RuntimeException(e);
								}
							}
						});
						c.afterPropertiesSet();
						c.start();
					}
				}
				
				if(base != null) {
					base.evaluate();
				}
			}
		};
	}
	
	private Map<String, BlockingQueue<String>> receivers = new HashMap<String, BlockingQueue<String>>();
	
	public void publish(String topic, final String text) throws Exception {
		JndiObjectFactoryBean fb = new JndiObjectFactoryBean();
		fb.setJndiName("factory/ConnectionFactory");
		Properties p = new Properties();
		p.put("java.naming.factory.initial", "net.timewalker.ffmq3.jndi.FFMQInitialContextFactory");
		p.put("java.naming.provider.url", "tcp://localhost:10002");
		fb.setJndiEnvironment(p);
		fb.afterPropertiesSet();
		ConnectionFactory cf = (ConnectionFactory) fb.getObject();
		
		JmsTemplate jt = new JmsTemplate(cf);
		jt.setPubSubDomain(true);
		jt.send(topic, new MessageCreator() {
			public Message createMessage(Session session) throws JMSException {
				TextMessage tm = session.createTextMessage();
				tm.setText(text);
				return tm;
			}
		});
	}
	
	public String receive(String topic) throws Exception{
		return receivers.get(topic).poll(3, TimeUnit.SECONDS);
	}
	
	public void cleanUp() throws Exception {
		for(BlockingQueue<String> bq : receivers.values()) {
			bq.clear();
		}
	}
	
	public void on(String topic, BookingMessageListener listener) throws Exception {
		
		JndiObjectFactoryBean fb = new JndiObjectFactoryBean();
		fb.setJndiName("factory/ConnectionFactory");
		Properties pp = new Properties();
		pp.put("java.naming.factory.initial", "net.timewalker.ffmq3.jndi.FFMQInitialContextFactory");
		pp.put("java.naming.provider.url", "tcp://localhost:10002");
		fb.setJndiEnvironment(pp);
		fb.afterPropertiesSet();
		ConnectionFactory cf = (ConnectionFactory) fb.getObject();
		
		DefaultMessageListenerContainer c = new DefaultMessageListenerContainer();
		c.setConnectionFactory(cf);
		c.setDestinationName(topic);
		c.setPubSubDomain(true);
		c.setMessageListener(listener);
		c.afterPropertiesSet();
		c.start();
	}
	
	public static abstract class BookingMessageListener implements MessageListener {
		
		@Override
		public void onMessage(Message msg) {
			
			try {
				onMessageInternal(msg);
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
		
		public void onMessageInternal(Message msg) throws Exception {
			
			TextMessage t = (TextMessage) msg;
			
			String text = t.getText();
			
			String tid = readTrackingId(text);
			
			onReceived(tid, text);
		}
		
		public abstract void onReceived(String trackingId, String msg) throws Exception;
		
		private String readTrackingId(String msg) throws Exception {
			XPath xpath = XPathFactory.newInstance().newXPath();
			String trackingId = xpath.evaluate("//*[local-name()='trackingId']/text()", new InputSource(new StringReader(msg)));
			return trackingId;
		}
	}
	
	
	
	
	
	
	
	
	//testcase
	//=============================================================
	@Test
	public void testConnectivity() throws Throwable {
		
		MQServerInfo mq = new MQServerInfo();
		mq.apply(null, null).evaluate();
		
		JndiObjectFactoryBean fb = new JndiObjectFactoryBean();
		fb.setJndiName("factory/ConnectionFactory");
		Properties p = new Properties();
		p.put("java.naming.factory.initial", "net.timewalker.ffmq3.jndi.FFMQInitialContextFactory");
		p.put("java.naming.provider.url", "tcp://localhost:10002");
		fb.setJndiEnvironment(p);
		fb.afterPropertiesSet();
		ConnectionFactory cf = (ConnectionFactory) fb.getObject();
		
		final JmsTemplate jt = new JmsTemplate(cf);
		jt.setPubSubDomain(true);
		new Thread() {
			public void run() {
				try {
					for(int i = 0; i < 100; i++) {
						jt.send("T_TRADEBOOKING_PUB", new MessageCreator() {
							public Message createMessage(Session session) throws JMSException {
								TextMessage tm = session.createTextMessage();
								tm.setText("xsdfwfwfsdfwefwef");
								return tm;
							}
						});
					}
				} catch (Exception e) {
					// TODO: handle exception
				}
			};
		}.start();
		
		DefaultMessageListenerContainer c = new DefaultMessageListenerContainer();
		c.setDestinationName("T_TRADEBOOKING_PUB");
		c.setConnectionFactory(cf);
		c.setPubSubDomain(true);
		c.setMessageListener(new MessageListener() {
			public void onMessage(Message paramMessage) {
				System.out.println("xxxx" + paramMessage);
			}
		});
		c.afterPropertiesSet();
		c.start();
		Thread.sleep(1000000);
	}
	
	@Test
	public void testPublish() throws Throwable {
		
		MQServerInfo mq = new MQServerInfo();
		mq.apply(null, null).evaluate();
		
		mq.publish("T_TRADEBOOKING_PUB", "xxx");
	}
}
