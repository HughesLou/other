package com.scb.razor.efunding.test;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.eclipse.jetty.annotations.AnnotationConfiguration;
import org.eclipse.jetty.plus.webapp.EnvConfiguration;
import org.eclipse.jetty.plus.webapp.PlusConfiguration;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.ServerConnector;
import org.eclipse.jetty.server.handler.ContextHandlerCollection;
import org.eclipse.jetty.server.handler.HandlerCollection;
import org.eclipse.jetty.webapp.Configuration;
import org.eclipse.jetty.webapp.FragmentConfiguration;
import org.eclipse.jetty.webapp.MetaInfConfiguration;
import org.eclipse.jetty.webapp.WebAppContext;
import org.eclipse.jetty.webapp.WebInfConfiguration;
import org.eclipse.jetty.webapp.WebXmlConfiguration;
import org.junit.Assert;
import org.junit.ClassRule;
import org.junit.Test;
import org.springframework.core.io.ClassPathResource;

import com.scb.razor.efunding.test.mock.H2ServerInfo;
import com.scb.sabre.tcc.util.CipherBean;

public class Playground {
    
    @ClassRule
    public static H2ServerInfo h2 = new H2ServerInfo();
    
    @Test
    public void testCipherBean() throws Exception {
        CipherBean cb = new CipherBean();
        cb.setKeyFileLocation(new ClassPathResource("cipher-key.txt").getURL());
        cb.init();
        String encrypt = cb.encrypt("sa");
        Assert.assertEquals("mRIP88i4Ph8=", encrypt);
        
    }
    
    @Test
    public void testWebSocket() throws Exception {
        
        Server srv = new Server();
        ServerConnector ctor = new ServerConnector(srv);
        ctor.setPort(0);
        srv.addConnector(ctor);
        
        HandlerCollection handlers = new HandlerCollection();
        ContextHandlerCollection contexts = new ContextHandlerCollection();
        handlers.addHandler(contexts);
        srv.setHandler(handlers);
        
        srv.start();
        
        System.out.printf("started at %s:%s\n", "localhost", ctor.getLocalPort());
        
        File webappdir = new File("target/test-webapp");
        if(webappdir.exists())
            FileUtils.deleteDirectory(webappdir);
        webappdir.mkdir();
        FileUtils.copyDirectory(new File("src/main/webapp/WEB-INF"), new File(webappdir, "WEB-INF"));
        FileUtils.copyDirectory(new File("target/classes"), new File(webappdir, "WEB-INF/classes"));
        WebAppContext ctx = new WebAppContext();
        ctx.setContextPath("/efunding");
        ctx.setResourceBase(webappdir.getPath());
        ctx.setAttribute("org.eclipse.jetty.websocket.jsr356",Boolean.TRUE);
        ctx.setConfigurations(new Configuration[]{
                new AnnotationConfiguration(),
                new WebXmlConfiguration(),
                new WebInfConfiguration(),
                new PlusConfiguration(),
                new MetaInfConfiguration(),
                new FragmentConfiguration(),
                new EnvConfiguration()
        });
        contexts.addHandler(ctx);
        contexts.manage(ctx);
        ctx.start();
        
        ctx.dump(System.err);
        
        Thread.sleep(Integer.MAX_VALUE);
    }
}
