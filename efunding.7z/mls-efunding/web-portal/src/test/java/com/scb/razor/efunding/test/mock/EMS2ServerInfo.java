package com.scb.razor.efunding.test.mock;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

public class EMS2ServerInfo extends AbstractRestfulServer {

    
    @Path("/ems2/rest")
    public static class Ems2Resource {
        
        @GET
        @Path("/entitlements/entity/name/:entity/user/:uid")
        public Object entitlements(@PathParam("entity") String entity, @PathParam("uid") String uid) {
            return null;
        }
        
        @GET
        @Path("/entity/{entity}")
        public Object entity(@PathParam("entity") String entity) {
            return null;
        }
        
        @GET
        @Path("/entity/{entity}/roles")
        public Object entityRoles(@PathParam("entity") String entity) {
            return null;
        }
        
        @GET
        @Path("/user/role/:role")
        public Object userRoles(@PathParam("role") String role) {
            return null;
        }
    }

    @Override
    protected String getURI() {
        return "http://localhost:16080";
    }

    @Override
    protected Class[] getResourceClasses() {
        return new Class[]{Ems2Resource.class};
    }
}
