package com.scb.razor.mls.auditing.lucene.exceptions;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.apache.lucene.analysis.core.WhitespaceAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanClause.Occur;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.NumericRangeQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Sort;
import org.apache.lucene.search.SortField;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.SimpleFSDirectory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Component;

import com.google.common.base.Function;
import com.google.common.base.Joiner;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Sets;
import com.google.common.eventbus.EventBus;
import com.google.common.eventbus.Subscribe;
import com.scb.razor.mls.auditing.WorkingDirectory;
import com.scb.razor.mls.auditing.lucene.IdIterators;
import com.scb.razor.mls.auditing.lucene.IndexSearcherManager;
import com.scb.razor.mls.auditing.lucene.MessageIndex;
import com.scb.razor.mls.auditing.lucene.ParentAndChildQuery;
import com.scb.razor.mls.auditing.lucene.ParentAndChildQuery.MessageQuery;
import com.scb.razor.mls.auditing.lucene.ParentAndChildQuery.TicketQuery;
import com.scb.razor.mls.auditing.lucene.ToDocument;
import com.scb.razor.mls.auditing.lucene.exceptions.ActionPerformEvent.MlsExceptionActionPerformEvent;
import com.scb.razor.mls.auditing.lucene.exceptions.ActionPerformEvent.MurexExceptionActionPerformEvent;
import com.scb.razor.mls.auditing.utils.FileVisitors;

/**
 * a store holds only new exceptions, that to be handled by user
 * @author 1510954
 */
@Component
public class LiveExceptionStore implements InitializingBean, DisposableBean {
    
    private final static Logger log = LoggerFactory.getLogger(LiveExceptionStore.class);
    
    @Resource 
    private WorkingDirectory workingDirectory;
    
    @Resource
    private DataSource dataSource;
    
    @Resource
    private TaskScheduler taskScheduler;
    
    @Resource
    private ExecutorService executorService;
    
    @Resource
    private MessageIndex messageIndex;
    
    @Resource
    private EventBus bus;
    
    private IndexWriter indexWriter;
    
    private IndexSearcherManager indexSearcherManager;
    
    private CountDownLatch indexed;
    
    @Subscribe
    public void onActionPerformed(ActionPerformEvent evt) throws Exception {
        
        log.info("ActionPerformEvent : action={}, id={}", evt.getAction(), evt.getTargetId());
        
        String action = evt.getAction();
        ParentAndChildQuery<Long> pcq = evt instanceof MlsExceptionActionPerformEvent ? new TicketQuery() : new MessageQuery();
        pcq.setDataSource(dataSource);
        List<Map<String, Object>> list = pcq.query(Arrays.asList(Long.valueOf(evt.getTargetId())));
        if(list.size() == 0) {
            log.error("no entity found with id={}", evt.getTargetId());
            throw new RuntimeException("message not found : " + evt.getTargetId());
        }
        Map<String, Object> entity = list.get(0);
        
        if("replay".equalsIgnoreCase(action)) {
            entity.put("status", "replayed");
        } else if("discard".equalsIgnoreCase(action)) {
            entity.put("status", "discard");
        } else if("MarkResolved".equalsIgnoreCase(action)) {
            entity.put("status", "discard");
        } else {
            log.warn("unrecognized action {} for {}", action, entity.get("id"));
            entity.put("status", action);
        }
        
        log.info("To update index with id={}, status={}", entity.get("id"), entity.get("status"));
        
        if(evt instanceof MlsExceptionActionPerformEvent) {
            indexWriter.deleteDocuments(new BooleanQuery.Builder().add(new TermQuery(new Term("id", evt.getTargetId())), Occur.FILTER).add(new TermQuery(new Term("xtype", "mls")), Occur.FILTER).build());
            indexWriter.addDocument(ToDocument.fromMlsException(entity));
        }
        if(evt instanceof MurexExceptionActionPerformEvent) {
            indexWriter.deleteDocuments(new BooleanQuery.Builder().add(new TermQuery(new Term("id", evt.getTargetId())), Occur.FILTER).add(new TermQuery(new Term("xtype", "murex")), Occur.FILTER).build());
            indexWriter.addDocument(ToDocument.fromMurexException(entity));
        }
        onIndexChanged();
    }
    
    //wait if store is not ready
    public void awaitIndex(){
        try {
            indexed.await();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
    
    public int count(Query q) {
        IndexSearcher is = indexSearcherManager.acquire();
        try {
            return is.count(q);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            indexSearcherManager.release(is);
        }
    }
    
    public List<Long> searchMessageIds(Query q, int start, int limit, Sort sort) throws IOException {
        
        List<Long> ids = new ArrayList<>();
        
        IndexSearcher indexSearcher = indexSearcherManager.acquire();
        try {
            TopDocs topdocs = null;
            if(sort == null) {
                topdocs = indexSearcher.search(q, start + limit);
            } else {
                topdocs = indexSearcher.search(q, start + limit, sort);
            }
            for(int i = start; i < topdocs.totalHits & i < (start + limit); i++) {
                Document doc = indexSearcher.doc(topdocs.scoreDocs[i].doc);
                ids.add(Long.valueOf(doc.get("id")));
            }
            
            return ids;
        } finally {
            indexSearcherManager.release(indexSearcher);
        }
    }
    
    public List<Long> searchMessageIds(Query q, int start, int limit) throws IOException {
        return searchMessageIds(q, start, limit, null);
    }
    
    /**
     * 'status' only stores in index
     */
    public List<IdAndStatus> searchStatus(Query q, int start, int limit, Sort sort) throws IOException {
        List<IdAndStatus> list = new ArrayList<>();
        IndexSearcher indexSearcher = indexSearcherManager.acquire();
        try {
            TopDocs topdocs = null;
            if(sort == null) {
                topdocs = indexSearcher.search(q, start + limit);
            } else {
                topdocs = indexSearcher.search(q, start + limit, sort);
            }
            Set<String> fields = Sets.newHashSet("id", "status");
            for(int i = start; i < topdocs.totalHits & i < (start + limit); i++) {
                Document doc = indexSearcher.doc(topdocs.scoreDocs[i].doc, fields);
                IdAndStatus xi = new IdAndStatus();
                xi.setId(Long.valueOf(doc.get("id")));
                xi.setStatus(doc.get("status"));
                list.add(xi);
            }
            return list;
        } finally {
            indexSearcherManager.release(indexSearcher);
        }
    }
    
    private File indexFolder;

    @Override
    public void afterPropertiesSet() throws Exception {
        // TODO Auto-generated method stub
        
        indexFolder = new File(workingDirectory.getAsFile(), "index-live");
        if(indexFolder.exists() == false) {
            log.info("index dir {} doesn't exist, try to create it", indexFolder.getAbsolutePath());
            indexFolder.mkdirs();
        }
        if(indexFolder.isFile()) {
            throw new RuntimeException("index dir actually is a file");
        }
        log.info("index dir = {}", indexFolder);
        
        if(indexWriter == null) {
            FSDirectory fsd = SimpleFSDirectory.open(indexFolder.toPath());
            WhitespaceAnalyzer analyzer = new WhitespaceAnalyzer();
            indexWriter = new IndexWriter(fsd, new IndexWriterConfig(analyzer));
            log.info("indexwriter created with dir={}, analyzer={}", fsd, analyzer);
        }
        log.info("indexWriter is {}", indexWriter);
        
        if(indexSearcherManager == null) {
            indexSearcherManager = new IndexSearcherManager();
        }
        log.info("indexSearcherManager is {}", indexSearcherManager);
        
        final File readyfile = new File(indexFolder, ".ready");
        boolean ready = readyfile.exists();
        
        indexed = new CountDownLatch(ready ? 0 : 1);
        
        if(ready == false) {
            Files.walkFileTree(indexFolder.toPath(), FileVisitors.deleteAllFilesExcept("write.lock"));
            
            executorService.submit(new Runnable(){
                public void run() {
                    try {
                        initialIndexing();
                    } catch (Exception e) {
                        log.error("fail to initialize index", e);
                    }
                }
            });
        } else {
            indexSearcherManager.setIndexSearcher(new IndexSearcher(DirectoryReader.open(new SimpleFSDirectory(indexFolder.toPath()))));
        }

        String crawlCron = "*/30 * * * * *";
        taskScheduler.schedule(new Runnable() {
            public void run() {
                if(indexed.getCount() > 0) {
                    log.info("index not ready, will bypass this incremental indexing schedule");
                    return;//TODO find a better way, to bypass current schedule when index is not ready yet
                }
                long before = System.currentTimeMillis();
                try {
                    crawlIncrementalFromDatabase();
                } catch (Exception e) {
                    log.error("fail to craw database", e);
                }
                log.debug("{}ms takes for this incremental update", System.currentTimeMillis() - before);
            }
        }, new CronTrigger(crawlCron));
        log.info("crawl database (incremental) scheduled as {}", crawlCron);
        
        String houseKeepingCron = "0 0 23 * * *"; // everyday at 23:00, do housekeeping
        taskScheduler.schedule(new Runnable() {
            @Override
            public void run() {
                if(indexed.getCount() > 0) {
                    log.info("index not ready, will bypass this housekeeping schedule");
                    return;//TODO find a better way, to bypass current schedule when index is not ready yet
                }
                try {
                    houseKeeping();
                } catch (Exception e) {
                    log.error("housekeeping exception : " + e.getMessage(), e);
                }
            }
        }, new CronTrigger(houseKeepingCron));
        log.info("housekeeping scheduled as {}", houseKeepingCron);
    }

    @Override
    public void destroy() throws Exception {
        if(indexWriter != null && indexed != null && indexed.getCount() == 0) {
            log.info("closing indexWriter {}", indexWriter);
            indexWriter.close();//assert commitOnClose=true
        }
    }
    
    public static class IdAndStatus {
        
        Long id;
        
        String status;

        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }
    }
    
    private void crawlIncrementalFromDatabase() throws Exception {
        
        Entry<Date, List<Long>> ticketLast = readLastFile(".last.mls"), messageLast = readLastFile(".last.murex");
        log.debug("last mls {}, {}. last murex {}, {}", ticketLast.getKey(), ticketLast.getValue(), messageLast.getKey(), messageLast.getValue());
        
        //order asc is important
        Iterator<Long> messageIdIter = IdIterators.fromNamedParamQuery("SELECT ID FROM MESSAGE WHERE STATUS='RECEIVED' AND CREATE_TIMESTAMP>=:last ORDER BY CREATE_TIMESTAMP ASC", ImmutableMap.of("last", (Object)messageLast.getKey()), dataSource, new Function<ResultSet, Long>() {
            public Long apply(ResultSet input) {
                try {
                    return input.getLong("ID");
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        
        Date messageMax = null; List<Long> messageMaxIds = new ArrayList<Long>();
        int messageCount = 0;
        MessageQuery mq = new MessageQuery();
        mq.setDataSource(dataSource);
        Iterator<List<Map<String, Object>>> messageListIter = mq.query(messageIdIter, executorService, 10);
        while(messageListIter.hasNext()) {
            List<Map<String, Object>> messageList = messageListIter.next();
            for(Map<String, Object> message : messageList) {
                String messageType = (String) message.get("messageType");
                String trackingId = (String) message.get("tracking_id");
                Date createTimestamp = (Timestamp) message.get("create_timestamp");
                Long id = (Long) message.get("id");
                if(messageMax == null) {
                    messageMax = createTimestamp;
                }
                if(createTimestamp.after(messageMax)) {
                    messageMaxIds.clear();
                    messageMax = createTimestamp;
                }
                if(createTimestamp.equals(messageMax)) {
                    messageMaxIds.add(id);
                }
                if(messageLast.getValue().contains(id)) {
                    continue;//bypass already indexed
                }
                if("NACK".equals(messageType)) {
                    String oid = ToDocument.readOriginalTrackingId(trackingId);
                    BooleanQuery q1 = new BooleanQuery.Builder().add(new TermQuery(new Term("original_tracking_id", oid)), Occur.FILTER)/*add(new TermQuery(new Term("xtype", "murex")), Occur.FILTER)*/.build();
                    if(count(q1) > 0) {
                        message.put("status", "replay_failed");
                        //TODO update those older 'replayed' to 'replay_failed' ?
                    } else {
                        message.put("status", "new");
                    }
                    indexWriter.addDocument(ToDocument.fromMurexException(message));
                    messageCount++;
                }
                /**  uncomment this to support 'replay_success' (only for murex exception, for mls exception, coding required)
                if("ACK".equals(messageType)) {
                    String oid = ToDocument.readOriginalTrackingId(trackingId);
                    BooleanQuery q1 = new BooleanQuery.Builder().add(new TermQuery(new Term("original_tracking_id", oid)), Occur.FILTER).build();
                    if(count(q1) > 0) {
                        message.put("status", "replay_success");
                        indexWriter.addDocument(ToDocument.fromMurexException(message));
                    } else {
                        message.put("status", "new");
                    }
                }*/
            }
        }
        if(messageCount > 0) {
            log.info("{} messages indexed, max date is {}  {}", messageCount, messageMax, messageMaxIds);
        }
        
        Iterator<Long> ticketIdIter = IdIterators.fromNamedParamQuery("SELECT ID FROM SCB_TICKET WHERE CREATEDTIMESTAMP>=:last ORDER BY CREATEDTIMESTAMP ASC", ImmutableMap.of("last", (Object)ticketLast.getKey()), dataSource, new Function<ResultSet, Long>() {
            public Long apply(ResultSet input) {
                try {
                    return input.getLong("ID");
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        Date ticketMax = null; List<Long> ticketMaxIds = new ArrayList<Long>();
        int ticketCount = 0;
        TicketQuery tq = new TicketQuery();
        tq.setDataSource(dataSource);
        Iterator<List<Map<String, Object>>> ticketListIter = tq.query(ticketIdIter, executorService, 10);
        while(ticketListIter.hasNext()) {
            List<Map<String, Object>> ticketList = ticketListIter.next();
            for(Map<String, Object> ticket: ticketList) {
                String status = (String) ticket.get("status");
                Date createTimestamp = (Timestamp) ticket.get("createdtimestamp");
                Long id = (Long) ticket.get("id");
                if(ticketMax == null) {
                    ticketMax = createTimestamp;
                }
                if(createTimestamp.after(ticketMax)) {
                    ticketMaxIds.clear();
                    ticketMax = createTimestamp;
                }
                if(createTimestamp.equals(ticketMax)) {
                    ticketMaxIds.add(id);
                }
                if(ticketLast.getValue().contains(id)) {
                    continue;//bypass already indexed
                }
                if("Ignored".equals(status)) {
                    continue;//should never happen to newly inserted exception
                }
                ticket.put("status", "new");
                indexWriter.addDocument(ToDocument.fromMlsException(ticket));
                ticketCount++;
            }
        }
        if(ticketCount > 0) {
            log.info("{} tickets indexed, max date is {} {}", ticketCount, ticketMax, ticketMaxIds);
        }
        if(ticketMax != null && ticketCount > 0)
            writeStringToFile(ticketMax.getTime() + "," + Joiner.on(",").join(ticketMaxIds.iterator()), new File(indexFolder, ".last.mls"));
        if(messageMax != null && messageCount > 0)
            writeStringToFile(messageMax.getTime() + "," + Joiner.on(",").join(messageMaxIds.iterator()), new File(indexFolder, ".last.murex"));
        
        onIndexChanged();
    }
    
    private void houseKeeping() throws IOException {
        
        JdbcTemplate jt = new JdbcTemplate(dataSource);
        Date messageMin = jt.queryForObject("SELECT MIN(CREATE_TIMESTAMP) FROM MESSAGE", Timestamp.class);
        Date ticketMin  = jt.queryForObject("SELECT MIN(CREATEDTIMESTAMP) FROM SCB_TICKET", Timestamp.class);
        log.info("housekeeping starts with messageMin={}, ticketMin={}", messageMin, ticketMin);
        
        indexWriter.deleteDocuments(NumericRangeQuery.newLongRange("create_timestamp", 0L, messageMin.getTime()/1000L, true, false));
        indexWriter.deleteDocuments(NumericRangeQuery.newLongRange("createdtimestamp", 0L, messageMin.getTime()/1000L, true, false));
        
        log.info("housekeeping done messageMin={}, ticketMin={}", messageMin, ticketMin);
        onIndexChanged();
    }
    
    private void initialIndexing() throws Exception {
        
        BooleanClause receivedClause = new BooleanClause(new TermQuery(new Term("status", "RECEIVED")), Occur.FILTER),
                nackClause = new BooleanClause(new TermQuery(new Term("messageType", "NACK")), Occur.FILTER),
                ackClause = new BooleanClause(new TermQuery(new Term("messageType", "ACK")), Occur.FILTER);
        
        JdbcTemplate jt = new JdbcTemplate(dataSource);
        Date messageMax = jt.queryForObject("SELECT MAX(CREATE_TIMESTAMP) FROM MESSAGE", Timestamp.class);
        Date ticketMax  = jt.queryForObject("SELECT MAX(CREATEDTIMESTAMP) FROM SCB_TICKET", Timestamp.class);
        
        long nextPrint = System.currentTimeMillis() + 1000 * 10L;//10s later
        
        Iterator<Long> iditer = IdIterators.fromQuery("SELECT ID FROM SCB_TICKET WHERE STATUS='Submitted'", dataSource, new Function<ResultSet, Long>(){
            public Long apply(ResultSet input) {
                try {
                    return input.getLong("ID");
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        TicketQuery tq = new TicketQuery();
        tq.setDataSource(dataSource);
        Iterator<List<Map<String, Object>>> iter = tq.query(iditer, executorService, 10);
        List<Long> ticketMaxIds = new ArrayList<Long>();
        int ticketCount = 0;
        IndexSearcher is = messageIndex.getIndexSearcherManager().acquire();
        try {
            while(iter.hasNext()) {
                List<Map<String, Object>> list = iter.next();
                for(Map<String, Object> row : list) {
                    ticketCount++;
                    Date createTimestamp = (Date)row.get("createdtimestamp");
                    Long id = (Long)row.get("id");
                    String trackingId = (String) row.get("JPP_trackingId");
                    if(createTimestamp.equals(ticketMax)) {
                        ticketMaxIds.add(id);
                    }
                    if(trackingId != null) {
                        String otid = ToDocument.readOriginalTrackingId(trackingId);
                        BooleanClause up = new BooleanClause(NumericRangeQuery.newLongRange("create_timestamp", createTimestamp.getTime()/1000L, Long.MAX_VALUE, false, false), Occur.FILTER);
                        BooleanQuery testup = new BooleanQuery.Builder().add(receivedClause).add(ackClause).add(up).add(new TermQuery(new Term("original_tracking_id", otid)), Occur.FILTER).build();
                        BooleanQuery testup2 = new BooleanQuery.Builder().add(receivedClause).add(nackClause).add(up).add(new TermQuery(new Term("original_tracking_id", otid)), Occur.FILTER).build();
                        if(is.count(testup) > 0) {
                            row.put("status", "replay_success");//attention, it assumes, if replay with success, user will not try to replay it again (where might lead to replay fail) 
                        } else if(is.count(testup2) > 0) {
                            row.put("status", "replay_failed");
                        } else {
                            row.put("status", "new");
                        }
                    } else {
                        row.put("status", "new");
                    }
                    indexWriter.addDocument(ToDocument.fromMlsException(row));
                    if(System.currentTimeMillis() > nextPrint) {
                        nextPrint = System.currentTimeMillis() + 1000 * 10L;
                        log.info("initial indexing progress ticket {}", ticketCount);
                    }
                }
            }
        } finally {
            messageIndex.getIndexSearcherManager().release(is);
        }
        log.info("{} mls exceptions indexed, with maxdate {}, {}", ticketCount, ticketMax, ticketMaxIds);
        
        //done indexing mls exceptions, next indexing murex exceptions
        
        //1. get all nack
        //2. reason status of each nack (new, replay success, replay failed)
        //3. put 'new' and 'replay_failed' to index
        
        BooleanQuery q = new BooleanQuery.Builder().add(receivedClause).add(nackClause).build();
        int nackCount = messageIndex.count(q);// potential issue : count and search not at same time point, data discrepancy may arise (use messageIndex.getIndexSearcherManager().acquire())
        List<Long> nackIds = messageIndex.searchMessageIds(q, 0, nackCount, new Sort(new SortField("create_timestamp", SortField.Type.LONG, true)));//NB: potential issue, it store all nack ids in memory, could lead to OOM
        log.info("{} nacks to be processed", nackIds.size());
        MessageQuery mq = new MessageQuery();
        mq.setDataSource(dataSource);
        Iterator<List<Map<String, Object>>> nacksIter = mq.query(nackIds.iterator(), executorService, 10);
        int indexedNackCount = 0, replayFailedCount = 0;
        List<Long> messageMaxIds = new ArrayList<Long>();
        IndexSearcher is2 = messageIndex.getIndexSearcherManager().acquire();
        try {
            while(nacksIter.hasNext()) {
                List<Map<String, Object>> nacks = nacksIter.next();
                for(Map<String, Object> nack : nacks) {
                    Long id = (Long) nack.get("id");
                    Timestamp createTimestamp = (Timestamp) nack.get("create_timestamp");
                    if(createTimestamp.equals(messageMax)) {
                        messageMaxIds.add(id);
                    }
                    String otid = ToDocument.readOriginalTrackingId((String)nack.get("tracking_id"));
                    BooleanClause otidClause = new BooleanClause(new TermQuery(new Term("original_tracking_id", otid)), Occur.FILTER);
                    BooleanClause up = new BooleanClause(NumericRangeQuery.newLongRange("create_timestamp", createTimestamp.getTime()/1000L, Long.MAX_VALUE, false, false), Occur.FILTER);
                    BooleanClause down = new BooleanClause(NumericRangeQuery.newLongRange("create_timestamp", 0L, createTimestamp.getTime()/1000L, false, false), Occur.FILTER);
                    BooleanQuery testup   = new BooleanQuery.Builder().add(otidClause).add(receivedClause).add(ackClause).add(up).build();
                    BooleanQuery testdown = new BooleanQuery.Builder().add(otidClause).add(receivedClause).add(nackClause).add(down).build();
                    if(is2.count(testup) > 0) {
                        nack.put("status", "replay_success");
                    } else {
                        if(is2.count(testdown) > 0) {
                            nack.put("status", "replay_failed");
                            replayFailedCount++;
                        } else {
                            nack.put("status", "new");
                        }
                        indexWriter.addDocument(ToDocument.fromMurexException(nack));// index only 'new' or 'replay_failed'. excluding 'replay_success'
                        indexedNackCount++;
                    }
                    if(System.currentTimeMillis() > nextPrint) {
                        nextPrint = System.currentTimeMillis() + 1000 * 10L;
                        log.info("initial indexing progress message {}", indexedNackCount);
                    }
                }
            }
        } finally {
            messageIndex.getIndexSearcherManager().release(is2);
        }
        log.info("{} nack found, {} indexed, with {} indexed as 'replay_failed'", nackCount, indexedNackCount, replayFailedCount);
        
        if(ticketMax == null && messageMax == null) {
            throw new RuntimeException("at least 1 message required to make the index available");
        }
        writeStringToFile("Hello from Jay", new File(indexFolder, ".ready"));
        long now = System.currentTimeMillis();
        writeStringToFile((ticketMax == null ? now : ticketMax.getTime()) + "," + Joiner.on(",").join(ticketMaxIds.iterator()), new File(indexFolder, ".last.mls"));
        writeStringToFile((messageMax == null ? now : messageMax.getTime()) + "," + Joiner.on(",").join(messageMaxIds.iterator()), new File(indexFolder, ".last.murex"));
        log.info(".ready, .last.mls, .last.murex files are written");
        
        indexWriter.commit();
        indexSearcherManager.setIndexSearcher(new IndexSearcher(DirectoryReader.open(new SimpleFSDirectory(indexFolder.toPath()))));
        
        indexed.countDown();
    }
    
    private void writeStringToFile(String txt, File path) throws IOException {
        Files.copy(new ByteArrayInputStream(txt.getBytes()), path.toPath(), StandardCopyOption.REPLACE_EXISTING);
    }
    
    private Entry<Date, List<Long>> readLastFile(String fileName) throws IOException {
        byte[] bytes = Files.readAllBytes(new File(indexFolder, fileName).toPath());
        String line = new String(bytes);
        String[] cols = line.split(",");
        List<Long> ids = new ArrayList<Long>();
        Date d = new Timestamp(Long.valueOf(cols[0]));
        for(int i = 1; i < cols.length; i++) {
            if(cols[i] != null && !cols[i].isEmpty()) {
                ids.add(Long.valueOf(cols[i]));
            }
        }
        return new AbstractMap.SimpleEntry<Date, List<Long>>(d, ids);
    }
    
    //update indexSearcher on index changed
    //@Subscribe
    private void onIndexChanged(/*IndexChangedEvent evt*/) {
        IndexSearcher indexSearcher = indexSearcherManager.acquire();
        try {
            //indexSearcher can search 'back in time', so here is the logic to keep it latest 
            DirectoryReader oldReader = (DirectoryReader)indexSearcher.getIndexReader();
            try {
                DirectoryReader r = DirectoryReader.openIfChanged(oldReader, indexWriter);
                if(r == null) {
                    //head up : although the doc say "though, the current implementation never returns null"
                    //it is not true, it do return null if no change
                    //this boost perf under frequent read
                    return ;
                }
                try {
                    // close out dated readers, remove segment files belongs only to this reader
                    // if not, the number of segment files in index folder will grow and grow... ( i used to see 7k files, shocked me)
                    oldReader.close();
                } catch (Exception ee) {
                    log.error("fail to close outdated index reader", ee);
                }
                indexSearcherManager.setIndexSearcher(new IndexSearcher(r));
            }catch(Exception e) {
                throw new RuntimeException(e);
            }
        } finally {
            indexSearcherManager.release(indexSearcher);
        }
    }
    
    ////////////////////////////////////////////////////////

    public DataSource getDataSource() {
        return dataSource;
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public TaskScheduler getTaskScheduler() {
        return taskScheduler;
    }

    public void setTaskScheduler(TaskScheduler taskScheduler) {
        this.taskScheduler = taskScheduler;
    }

    public ExecutorService getExecutorService() {
        return executorService;
    }

    public void setExecutorService(ExecutorService executorService) {
        this.executorService = executorService;
    }

    public MessageIndex getMessageIndex() {
        return messageIndex;
    }

    public void setMessageIndex(MessageIndex messageIndex) {
        this.messageIndex = messageIndex;
    }

    public IndexWriter getIndexWriter() {
        return indexWriter;
    }

    public void setIndexWriter(IndexWriter indexWriter) {
        this.indexWriter = indexWriter;
    }

    public IndexSearcherManager getIndexSearcherManager() {
        return indexSearcherManager;
    }

    public void setIndexSearcherManager(IndexSearcherManager indexSearcherManager) {
        this.indexSearcherManager = indexSearcherManager;
    }

    public WorkingDirectory getWorkingDirectory() {
        return workingDirectory;
    }

    public void setWorkingDirectory(WorkingDirectory workingDirectory) {
        this.workingDirectory = workingDirectory;
    }
}
