package com.scb.razor.mls.auditing.rest;

import static org.apache.commons.lang3.StringUtils.isBlank;

import java.net.URI;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.base.Objects;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.eventbus.EventBus;
import com.scb.razor.mls.auditing.lucene.exceptions.ActionPerformEvent;
import com.scb.razor.mls.auditing.lucene.exceptions.LiveExceptionStore;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.representation.Form;

/**
 * This seems stupid. Forgive me. But this idea may grow up, as 'API server', like apigee.
 * 
 *  potential issue :
 *  <ol>
 *    <li> agent maybe blocked by firewall while the client don't
 *    <li> agent's DNS server is different with client's, and nslookup returns different results
 *    <li> for https connection, agent has to decide for client whether to trust remote or not
 *    <li> target server may restrict ip access
 *    <li> if client's credential cannot be fetched & sent to agent, then it cannot 'act as' client
 *  </ol>
 *  those can be solved by making contract with remote server
 */
@Component
@Path("/agent")
public class ActionPerformingAgentWebService {
    
    private final static Logger log = LoggerFactory.getLogger(ActionPerformingAgentWebService.class);

    @Autowired
    private EventBus bus;
    
    @Autowired
    private LiveExceptionStore liveExceptionStore;
    
    private static Client client = new Client();
    
    //use cache as lock, to forbid user take up same ticket at same time
    private static Cache<String, Object> lock = CacheBuilder.newBuilder().expireAfterWrite(1, TimeUnit.MINUTES).build();
    
    /**
     * 1. dispatch to target url
     * 2. detect second request and refuse it
     */
    @POST
    @Path("/actions")
    public Object performAction(@Context HttpHeaders reqHeaders, @Context UriInfo ui, Form form) throws Exception {
        
        String action = ui.getQueryParameters().getFirst("__action"), 
               id     = ui.getQueryParameters().getFirst("__id"),
               url    = ui.getQueryParameters().getFirst("__target"),
               xtype  = ui.getQueryParameters().getFirst("__xtype");
        
        if(isBlank(action) || isBlank(id) || isBlank(url) || isBlank(xtype)) {
            return Response.status(Status.BAD_REQUEST).entity("missing mandatory query parameter").build();
        }
        URI target = new URI(url),
            self   = ui.getAbsolutePath();
        
        boolean same = Objects.equal(target.getScheme(), self.getScheme())
                    && Objects.equal(target.getHost(), self.getHost())
                    && Objects.equal(target.getPort(), self.getPort())
                    && Objects.equal(target.getPath(), self.getPath());
        if(same) {
            return Response.status(Status.BAD_REQUEST).entity("call self").build();//stop call itself
        }    
        
        UriBuilder b = UriBuilder.fromUri(target);
        MultivaluedMap<String, String> mmap = ui.getQueryParameters();
        for(String key : mmap.keySet()) {
            if(key.startsWith("__")) {
                continue;
            }
            b.queryParam(key, mmap.get(key).toArray());
        }
        URI uri = b.build();
        
        WebResource r = client.resource(uri);
        for(String key : reqHeaders.getRequestHeaders().keySet()) {
            List<String> vals = reqHeaders.getRequestHeader(key);
            for(String v : vals) {
                r.header(key, v);
            }
        }
        ClientResponse cresp = null;
        if(lock.getIfPresent(url) != null) {
            return Response.status(Status.PRECONDITION_FAILED).entity("already taken by other user").build();
        }
        lock.put(url, "");
        try {
            cresp = r.entity(form).post(ClientResponse.class);
        } catch(Exception ex) {
            log.error(ex.getMessage(), ex);
            lock.invalidate(url);
        }
        if(cresp.getStatus() < 300) {//success
            ActionPerformEvent evt = "mls".equals(xtype) ? ActionPerformEvent.newMls(action, id) : ActionPerformEvent.newMurex(action, id);
            try {
                liveExceptionStore.onActionPerformed(evt);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        String body = IOUtils.toString(cresp.getEntityInputStream());
        return Response.status(cresp.getStatus()).entity(body).type(cresp.getHeaders().getFirst("Content-Type")).build();
        
    }
}
