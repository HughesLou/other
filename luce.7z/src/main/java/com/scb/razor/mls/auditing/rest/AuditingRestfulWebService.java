/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.rest;

import com.google.common.collect.ImmutableMap;
import com.scb.razor.mls.auditing.auth.Ems2Resource;
import com.scb.razor.mls.auditing.jms.AuditingDynamicPublisher;
import com.scb.razor.mls.auditing.jms.AuditingPublisher;
import com.scb.razor.mls.auditing.lucene.MessageIndex;
import com.scb.razor.mls.auditing.lucene.exceptions.LiveExceptionStore;
import com.scb.razor.mls.auditing.model.MlsMessage;
import com.scb.razor.mls.auditing.service.AuditingService;
import com.scb.razor.mls.auditing.ws.AuditingQueryParameterParser;
import com.scb.razor.mls.persistent.model.Message;
import com.scb.razor.mls.persistent.model.MessageProperty;
import com.scb.razor.mls.persistent.search.AuditingSearchCriteria;
import com.scb.sabre.ticketing.security.Entitlement;
import com.scb.sabre.ticketing.security.IEntitlementService;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.lucene.analysis.core.WhitespaceAnalyzer;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryparser.flexible.standard.StandardQueryParser;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.BooleanClause.Occur;
import org.apache.lucene.search.BooleanQuery.Builder;
import org.apache.lucene.search.MatchAllDocsQuery;
import org.apache.lucene.search.NumericRangeQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Sort;
import org.apache.lucene.search.SortField;
import org.apache.lucene.search.TermQuery;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Component;

import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriInfo;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;

import static com.scb.razor.mls.auditing.constant.AuditingConstants.RT_EXPORT_FILE_NAME;
import static com.scb.razor.mls.auditing.constant.AuditingConstants.RT_EXPORT_NUM;
import static com.scb.razor.mls.persistent.utils.PersistentConstants.*;
import static org.apache.commons.lang3.StringUtils.isNotBlank;

@Component
@Path("/Auditing")
public class AuditingRestfulWebService {

    private static final Logger logger = LoggerFactory.getLogger(AuditingRestfulWebService.class);
    @Autowired
    private AuditingService auditingServiceImpl = null;
    @Autowired
    private AuditingQueryParameterParser auditingQueryParameterParser = null;
    @Autowired
    private IEntitlementService auditingEntitlementsService = null;
    @Value("#{'${message.authorizedField.excluded}'.split(',')}")
    private List<String> excludedAuthorizedField = new ArrayList<>();
    @Autowired
    protected SessionFactory sessionFactory = null;

    @Autowired
    private AuditingPublisher auditingPublisher = null;

    @Autowired
    private AuditingDynamicPublisher auditingDynamicPublisher = null;
    
    @Autowired
    private MessageIndex messageIndex;
    
    @Autowired
    private LiveExceptionStore liveExceptionStore;
    
    @Autowired
    private Ems2Resource ems2;

    /**
     * get all of the available SourceSysId for specified user
     *
     * @param userId the user id
     *
     * @return response set of SourceSysId to the web client if successful
     */
    @GET
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Path("AvailableSourceSysIds")
    public Response getAvailableSourceSysIds(@QueryParam("user") final String userId) {
        logger.info("Attempting to get Source System ID for user {}", userId);
        Set<String> sourceSysIds = auditingServiceImpl.getAvailableSourceSysIds(userId);
        sourceSysIds.removeAll(excludedAuthorizedField);
        logger.info("End of getting Source System IDs with the amount {}.", sourceSysIds.size());
        return Response.ok(sourceSysIds).build();
    }

    /**
     * get all of the available Status for specified user
     *
     * @param userId the user id
     *
     * @return response set of Status to the web client if successful
     */
    @GET
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Path("AvailableStatuses")
    public Response getAvailableStatuses(@QueryParam("user") final String userId) {
        logger.info("Attempting to get Statuses for user {}", userId);
        Set<String> statuses = auditingServiceImpl.getAvailableStatuses();
        logger.info("End of getting Statuses with the amount {}.", statuses.size());
        return Response.ok(statuses).build();
    }

    /**
     * get all of the available Status for specified user
     *
     * @param userId the user id
     *
     * @return response set of Status to the web client if successful
     */
    @GET
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Path("AvailableChannels")
    public Response getAvailableChannels(@QueryParam("user") final String userId) {
        logger.info("Attempting to get Channels for user {}", userId);
        Set<String> channels = auditingServiceImpl.getAvailableChannels();
        logger.info("End of getting Statuses with the amount {}.", channels.size());
        return Response.ok(channels).build();
    }

    /**
     * get all of the available Key for specified user
     *
     * @param userId the user id
     *
     * @return response set of Key to the web client if successful
     */
    @GET
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Path("AvailableKeys")
    public Response getAvailableKeys(@QueryParam("user") final String userId) {
        logger.info("Attempting to get Keys for user {}", userId);
        Set<String> keys = auditingServiceImpl.getAvailableKeys();
        logger.info("End of getting Keys with the amount {}.", keys.size());
        return Response.ok(keys).build();
    }
    
    @GET @Path("/messages")
    @Produces({MediaType.APPLICATION_JSON})
    public Object search(
            @QueryParam("q") String qs, 
            @QueryParam("view") @DefaultValue("list") String view,
            @Context UriInfo uri
            ) throws Exception {
        
        logger.debug("uri={}", uri.getRequestUri());
        
        List<String> nonDynamicKeys = Arrays.asList("q", "sort", "view", "firstResult", "maxResults", "user", "hash", "challenge", "sessionKey", "customFilter", "createdDateFrom", "createdDateTo", "dateFrom", "dateTo", "filterField");
        
        MultivaluedMap<String, String> params = uri.getQueryParameters();
        
        String xtype = params.getFirst("xtype");
        
        Builder b = new BooleanQuery.Builder();
        
        if(isNotBlank(qs)) {
            StandardQueryParser parser = new StandardQueryParser(new WhitespaceAnalyzer());
            Query query = parser.parse(qs, "text");
            b.add(query, Occur.FILTER);
        }
        
        if(isNotBlank(xtype)) {
            b.add(new TermQuery(new Term("xtype", xtype)), Occur.FILTER);
        }
        
        if(Objects.equals(xtype, "mls")) {
            String  createdDateFrom = params.getFirst("createdDateFrom"),
                    createdDateTo   = params.getFirst("createdDateTo"),
                    customFilter    = params.getFirst("customFilter"),
                    userId          = params.getFirst("user");
            for(String key : uri.getQueryParameters().keySet()) {
                String value = uri.getQueryParameters().getFirst(key);
                if(StringUtils.isBlank(value)) {
                    continue;
                }
                if(nonDynamicKeys.contains(key)) {
                    continue;
                }
                if(key.endsWith("In")) {
                    String okey = key.substring(0, key.length() - 2);
                    Builder bb = new BooleanQuery.Builder().setMinimumNumberShouldMatch(1);
                    for(String ii : value.split(",")) {
                        if(!ii.isEmpty()) {
                            bb.add(new TermQuery(new Term(okey, ii)), Occur.SHOULD);
                        }
                    }
                    BooleanQuery bbq = bb.build();
                    if(bbq.clauses().size() > 0) {
                        b.add(bbq, Occur.FILTER);
                    }
                } else {
                    b.add(new TermQuery(new Term(key, value)), Occur.FILTER);
                }
            }
            if(isNotBlank(createdDateTo) || isNotBlank(createdDateFrom)) {
                long dateFrom = 0L, dateTo = Long.MAX_VALUE;
                if(isNotBlank(createdDateTo)) {
                    dateTo = DateUtils.parseDate(createdDateTo, "dd-MM-yyyy", "yyyy-MM-dd").getTime()/1000L + 3600 * 24;
                }
                if(isNotBlank(createdDateFrom)) {
                    dateTo = DateUtils.parseDate(createdDateFrom, "dd-MM-yyyy", "yyyy-MM-dd").getTime()/1000L + 3600 * 24;
                }
                b.add(NumericRangeQuery.newLongRange("createdtimestamp", dateFrom, dateTo, true, false), Occur.FILTER);
            }
            if(isNotBlank(customFilter)) {
                String filterField = customFilter;
                Pattern ptn = Pattern.compile("(\\w[\\w ]+\\w);(EQUALS|CONTAINS);([^;]+)(;(AND|OR)?)?", Pattern.CASE_INSENSITIVE);
                Matcher m = ptn.matcher(filterField);
                Builder b2 = new BooleanQuery.Builder();
                String lastandor = null;
                while(m.find()) {
                    String field = m.group(1), value = m.group(3), andor = m.group(5);
                    field = field.replaceAll(" +", "_");//"Application ID" => "Application ID"
                    boolean isEquals = "equals".equalsIgnoreCase(m.group(2));
                    if(!isEquals) {
                        logger.warn("lucene doesn't support 'contains' filter");
                    } else {
                        if(lastandor != null) {
                            b2.add(new TermQuery(new Term(field, value)), "and".equalsIgnoreCase(lastandor) ? Occur.FILTER : Occur.SHOULD);
                        } else {
                            b2.add(new TermQuery(new Term(field, value)), "and".equalsIgnoreCase(andor) ? Occur.FILTER : Occur.SHOULD);
                        }
                    }
                    lastandor = andor;
                }
                BooleanQuery bq2 = b2.build();
                if(bq2.clauses().size() > 0) {
                    b.add(bq2, Occur.FILTER);
                }
            }
            List<Entitlement> entitlements = ems2.getEntitlementsByEntityNameAndLoginId("RAZOR_MLS_EXCEPTION", userId);
            Pattern ptn = Pattern.compile("(\\w+)\\|(\\w+)\\|(\\w+)");
            Builder typeb = new BooleanQuery.Builder(), interfaceb = new BooleanQuery.Builder(), appb = new BooleanQuery.Builder();
            typeb.setMinimumNumberShouldMatch(1);
            interfaceb.setMinimumNumberShouldMatch(1);
            appb.setMinimumNumberShouldMatch(1);
            Set<String> s1 = new HashSet<String>(), s2 = new HashSet<String>(), s3 = new HashSet<String>();
            for(Entitlement en : entitlements) {
                if(en.getAction() == null || !"view".equals(en.getAction().getName())) {
                    continue;//retrieve only 'view' permission
                }
                String subject = en.getSubject().getName();
                Matcher m = ptn.matcher(subject);
                if(m.find()) {
                    s1.add(m.group(1));
                    s2.add(m.group(2));
                    s3.add(m.group(3));
                }
            }
            for(String a : s1) {
                appb.add(new TermQuery(new Term("Application_ID", a)), Occur.SHOULD);
            }
            for(String a : s2) {
                interfaceb.add(new TermQuery(new Term("Interface_ID", a)), Occur.SHOULD);
            }
            for(String a : s3) {
                typeb.add(new TermQuery(new Term("type", a)), Occur.SHOULD);
            }
            List<BooleanQuery> bqs = Arrays.asList(appb.build(), interfaceb.build(), typeb.build());
            for(BooleanQuery xq : bqs) {
                if(xq.clauses().size() > 0) {
                    b.add(xq, Occur.FILTER);
                }
            }
        }
        
        if(Objects.equals(xtype, "murex") || xtype == null) {
            String dateFrom      = params.getFirst("dateFrom");
            String dateTo        = params.getFirst("dateTo");
            String filterField   = params.getFirst("filterField");
            String userId        = params.getFirst("user");
            for(String key : uri.getQueryParameters().keySet()) {
                String value = uri.getQueryParameters().getFirst(key);
                if(StringUtils.isBlank(value)) {
                    continue;
                }
                if("trackingId".equals(key)) {
                    key = "tracking_id";
                }
                if("sourceSysId".equals(key)) {
                    key = "source_sys_id";
                }
                if("trackingIdIn".equals(key)) {
                    key = "tracking_idIn";
                }
                if("sourceSysIdIn".equals(key)) {
                    key = "source_sys_idIn";
                }
                if(nonDynamicKeys.contains(key)) {
                    continue;
                }
                if(key.endsWith("In")) {
                    String okey = key.substring(0, key.length() - 2);
                    Builder bb = new BooleanQuery.Builder().setMinimumNumberShouldMatch(1);
                    for(String ii : value.split(",")) {
                        if(!ii.isEmpty()) {
                            bb.add(new TermQuery(new Term(okey, ii)), Occur.SHOULD);
                        }
                    }
                    BooleanQuery bbq = bb.build();
                    if(bbq.clauses().size() > 0) {
                        b.add(bbq, Occur.FILTER);
                    }
                } else {
                    b.add(new TermQuery(new Term(key, value)), Occur.FILTER);
                }
            }
            if(isNotBlank(dateFrom) || isNotBlank(dateTo)) {
                long from = 0L, to = Long.MAX_VALUE;
                if(dateFrom != null) {
                    from = DateUtils.parseDate(dateFrom, "dd-MM-yyyy", "yyyy-MM-dd").getTime()/1000;
                }
                if(dateTo != null) {
                    to = DateUtils.parseDate(dateTo, "dd-MM-yyyy", "yyyy-MM-dd").getTime()/1000 + 3600 * 24;
                }
                b.add(NumericRangeQuery.newLongRange("create_timestamp", from, to, true, false), Occur.FILTER);
            }
            
            if(isNotBlank(filterField)) {//TODO : remove this query feature, it is ugly. here is for backward compatibility
                Pattern ptn = Pattern.compile("(\\w+);(EQUALS|CONTAINS);([^;]+)(;(AND|OR)?)?", Pattern.CASE_INSENSITIVE);
                Matcher m = ptn.matcher(filterField);
                Builder b2 = new BooleanQuery.Builder();
                String lastandor = null;
                while(m.find()) {
                    String field = m.group(1), value = m.group(3), andor = m.group(5);
                    boolean isEquals = "equals".equalsIgnoreCase(m.group(2));
                    if(!isEquals) {
                        logger.warn("lucene doesn't support 'contains' filter");
                    } else {
                        if(lastandor != null) {
                            b2.add(new TermQuery(new Term(field, value)), "and".equalsIgnoreCase(lastandor) ? Occur.FILTER : Occur.SHOULD);
                        } else {
                            b2.add(new TermQuery(new Term(field, value)), "and".equalsIgnoreCase(andor) ? Occur.FILTER : Occur.SHOULD);
                        }
                    }
                    lastandor = andor;
                }
                BooleanQuery bq2 = b2.build();
                if(bq2.clauses().size() > 0) {
                    b.add(bq2, Occur.FILTER);
                }
            }
            List<Entitlement> entitlements = ems2.getEntitlementsByEntityNameAndLoginId("RAZOR_MLS_AUDITING", userId);
            List<String> sourceIds = new ArrayList<String>();
            for(Entitlement ent : entitlements) {
                if(ent.getAction() != null && "View".equals(ent.getAction().getName())) {
                    if(ent.getSubject() != null) {
                        sourceIds.add(ent.getSubject().getName());
                    }
                }
            }
            if(!sourceIds.isEmpty()) {
                Builder bb = new BooleanQuery.Builder().setMinimumNumberShouldMatch(1);
                for(String sid : sourceIds) {
                    bb.add(new TermQuery(new Term("source_sys_id", sid)), Occur.SHOULD);
                }
                b.add(bb.build(), Occur.FILTER);//which interface id can be viewed by this user ?
            }
        }
        
        BooleanQuery boolq = b.build();
        Query query = boolq.clauses().size() > 0 ? boolq : new MatchAllDocsQuery();
        
        logger.debug("query {}", query);
        
        if("count".equals(view)) {
            if(xtype == null) {
                return messageIndex.count(query);
            }
            return liveExceptionStore.count(query);
        }
        
        List<SortField> sflist = new ArrayList<>();
        if(isNotBlank(params.getFirst("sort"))) {
            String sort = params.getFirst("sort");
            Pattern ptn = Pattern.compile("(\\-)?(\\w+)");
            Matcher m = ptn.matcher(sort);
            while(m.find()) {
                String asc = m.group(1), field = m.group(2);
                if(!"create_timestamp".equals(field) && !"createdtimestamp".equals(field)) {
                    throw new RuntimeException("supports only by create timestamp");
                }
                sflist.add(new SortField(field, SortField.Type.LONG, asc == null ? false : true));
            }
        }
        Sort sort = sflist.isEmpty() ? null : new Sort(sflist.toArray(new SortField[sflist.size()]));
        
        int start = isNotBlank(params.getFirst("firstResult")) ? Integer.valueOf(params.getFirst("firstResult")) : 0;
        int limit = isNotBlank(params.getFirst("maxResults")) ? Integer.valueOf(params.getFirst("maxResults")) : 20;
        
        if("idAndStatus".equals(view)) {
            return liveExceptionStore.searchStatus(query, start, limit, sort);
        }
        List<Long> ids = null;
        if(xtype == null) {
            ids = messageIndex.searchMessageIds(query, start, limit, sort);
        } else {
            ids = liveExceptionStore.searchMessageIds(query, start, limit, sort);
        }
        
        if("ids".equals(view)) {
            return ids;
        }
        
        if("mls".equals(xtype)) {
            throw new RuntimeException("for mls exceptions, currently supports only searching for ids, not entire message");
        }
        
        //default view="list"
        String user = uri.getQueryParameters().getFirst("user");
        if(StringUtils.isBlank(user)) {
            throw new RuntimeException("missing parameter : user");
        }
        List<MlsMessage> messages = auditingServiceImpl.listMessages(ids, user, uri.getBaseUri());
        return messages;
    }

    /**
     * the the amount of searched Message data
     *
     * @param userId      the user id
     * @param trackingId  the key of data to search
     * @param sourceSysId the value of data to search
     * @param status      the status of data to search
     * @param filterField the type of data to search
     * @param dateFrom    the start date to search
     * @param dateTo      the end date to search
     *
     * @return response the amount to the web client if successful
     */
    @POST
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Path("MessagesAmount")
    public Response getMessagesAmount(
            @QueryParam("user") final String userId,
            @QueryParam("useIndex") @DefaultValue("false") boolean useIndex,
            @FormParam("trackingId") final String trackingId,
            @FormParam("wildcard") final String wildcard,
            @FormParam("sourceSysId") final String sourceSysId,
            @FormParam("status") final String status,
            @FormParam("channel") final String channel,
            @FormParam("filterField") final String filterField,
            @FormParam("dateFrom") final String dateFrom,
            @FormParam("dateTo") final String dateTo) throws Exception {
        logger.info("Attempting to get the message amount for user {} by filter.", userId);

        if (null == userId) {
            return Response.serverError().entity("UserId is empty!").build();
        }
        
        if(useIndex) { 
            Builder b = new BooleanQuery.Builder();
            if(trackingId != null) {
                b.add(new TermQuery(new Term("tracking_id", trackingId)), Occur.FILTER);
            }
            if(sourceSysId != null) {
                b.add(new TermQuery(new Term("source_sys_id", sourceSysId)), Occur.FILTER);
            }
            if(status != null) {
                b.add(new TermQuery(new Term("status", status)), Occur.FILTER);
            }
            if(channel != null) {
                b.add(new TermQuery(new Term("channel", channel)), Occur.FILTER);
            }
            if(dateFrom != null || dateTo != null) {
                long from = System.currentTimeMillis()/1000L - 3600 * 24 * 365;
                long to = System.currentTimeMillis()/1000L   + 3600 * 24 * 365;
                if(dateFrom != null) {
                    from = DateUtils.parseDate(dateFrom, "dd-MM-yyyy").getTime()/1000;
                }
                if(dateTo != null) {
                    to = DateUtils.parseDate(dateTo, "dd-MM-yyyy").getTime()/1000;
                }
                b.add(NumericRangeQuery.newLongRange("create_timestamp", from, to, true, false), Occur.FILTER);
            }
            if(filterField != null) {
                Pattern ptn = Pattern.compile("(\\w+);(EQUALS|CONTAINS);([^;]+)(;(AND|OR)?)?", Pattern.CASE_INSENSITIVE);
                Matcher m = ptn.matcher(filterField);
                Builder b2 = new BooleanQuery.Builder();
                String lastandor = null;
                boolean atleast1 = false;
                while(m.find()) {
                    String field = m.group(1), value = m.group(3), andor = m.group(5);
                    boolean isEquals = "equals".equalsIgnoreCase(m.group(2));
                    if(!isEquals) {
                        logger.warn("lucene doesn't support 'contains' filter");
                    } else {
                        if(lastandor != null) {
                            b2.add(new TermQuery(new Term(field, value)), "and".equalsIgnoreCase(lastandor) ? Occur.FILTER : Occur.SHOULD);
                            atleast1 = true;
                        } else {
                            b2.add(new TermQuery(new Term(field, value)), "and".equalsIgnoreCase(andor) ? Occur.FILTER : Occur.SHOULD);
                            atleast1 = true;
                        }
                    }
                    lastandor = andor;
                }
                if(atleast1) {
                    b.add(b2.build(), Occur.FILTER);
                }
            }
            
            int count = messageIndex.count(b.build());
            return Response.ok(count).build();
        }
        
        Map<String, String[]> searchMap = new HashMap<>();
        searchMap.put(TYPE, new String[]{RT});
        searchMap.put(USER, new String[]{userId});
        if (trackingId != null)
            searchMap.put(TRACKING_ID, new String[]{trackingId});
        if (wildcard != null)
            searchMap.put(WILDCARD, new String[]{wildcard});
        if (sourceSysId != null)
            searchMap.put(SOURCE_SYS_ID, new String[]{sourceSysId});
        if (status != null)
            searchMap.put(STATUS, new String[]{status});
        if (channel != null)
            searchMap.put(CHANNEL, new String[]{channel});
        if (filterField != null)
            searchMap.put(FILTER_FIELD, new String[]{filterField});
        if (dateFrom != null)
            searchMap.put(DATE_FROM, new String[]{dateFrom});
        if (dateTo != null)
            searchMap.put(DATE_TO, new String[]{dateTo});

        AuditingSearchCriteria searchCriteria = auditingQueryParameterParser.buildSearchCriteria(searchMap);
        if (searchCriteria == null) {
            return Response.ok(0).build();
        }
        Long amount = auditingServiceImpl.getMessagesAmount(searchCriteria, userId);
        logger.info("End of getting the message amount {} for user {}.", amount, userId);
        return Response.ok(amount).build();
    }

    /**
     * get the actions info for specified user and subject
     *
     * @param userId  the user id
     * @param subject the subject to search
     *
     * @return a list of available actions
     */
    @GET
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Path("ActionsInfo")
    public Response getActionsInfo(@QueryParam("user") final String userId,
                                   @QueryParam("subject") final String subject) {
        List<Entitlement> entitlements = auditingEntitlementsService.getEntitlementsFor(userId);
        Set<String> actions = new TreeSet<>();
        for (Entitlement entitlement : entitlements) {
            if (subject.equalsIgnoreCase(entitlement.getSubject().getName())) {
                actions.add(entitlement.getAction().getName());
            }
        }
        return Response.ok(actions).build();
    }

    /**
     * get the entitlements info for specified user
     *
     * @param userId the user id
     *
     * @return a list of entitlements
     */
    @GET
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Path("EntitlementsInfo")
    public Response getEntitlementsInfo(@QueryParam("user") final String userId) {
        List<String> entitlements = new ArrayList<>(auditingEntitlementsService.getEntitlements(userId));
        return Response.ok(entitlements).build();
    }

    /**
     * the the amount of searched LoggingEvent data
     *
     * @param userId   the user id
     * @param systemId the key of data to search
     * @param tradeRef the type of data to search
     * @param dateFrom the start data to search
     * @param dateTo   the end data to search
     *
     * @return response the amount to the web client if successful
     */
    @POST
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Path("LoggingEventsAmount")
    public Response getLoggingEventsAmount(
            @QueryParam("user") final String userId,
            @FormParam("systemId") final String systemId,
            @FormParam("tradeRef") final String tradeRef,
            @FormParam("dateFrom") final String dateFrom,
            @FormParam("dateTo") final String dateTo) {
        logger.info("Attempting to get the message amount for user {} by filter.", userId);

        Map<String, String[]> searchMap = new HashMap<>();
        searchMap.put(TYPE, new String[]{EOD});
        if (tradeRef != null)
            searchMap.put(TRADE_REF, new String[]{tradeRef});
        if (systemId != null)
            searchMap.put(SYSTEM_ID, new String[]{systemId});
        if (dateFrom != null)
            searchMap.put(DATE_FROM, new String[]{dateFrom});
        if (dateTo != null)
            searchMap.put(DATE_TO, new String[]{dateTo});

        AuditingSearchCriteria searchCriteria = auditingQueryParameterParser.buildSearchCriteria(searchMap);
        if (searchCriteria == null) {
            return Response.ok(0).build();
        }
        Long amount = auditingServiceImpl.getLoggingEventsAmount(searchCriteria);
        logger.info("End of getting the logging event amount {} for user {}.", amount, userId);
        return Response.ok(amount).build();
    }

    /**
     * get the actions for specified user and subject
     *
     * @param userId the user id
     *
     * @return a list of available actions
     */
    @GET
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Path("Action")
    public Response getActions(@QueryParam("user") final String userId) {
        logger.info("Attempting to get the actions in AuditLog for user {}.", userId);
        List<String> actions = auditingServiceImpl.getAvailableActions();
        logger.info("End of getting the {} actions in AuditLog user {}.", actions.size(), userId);
        return Response.ok(actions).build();
    }

    /**
     * the the amount of searched AuditLog data
     *
     * @param user     the user id
     * @param userId   the userId to search
     * @param action   the action to search
     * @param entityId the entityId to search
     * @param detail   the detail to search
     * @param dateFrom the start data to search
     * @param dateTo   the end data to search
     *
     * @return response the amount to the web client if successful
     */
    @POST
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Path("AuditLogsAmount")
    public Response getAuditLogsAmount(
            @QueryParam("user") final String user,
            @FormParam("userId") final String userId,
            @FormParam("action") final String action,
            @FormParam("entityId") final String entityId,
            @FormParam("detail") final String detail,
            @FormParam("dateFrom") final String dateFrom,
            @FormParam("dateTo") final String dateTo) {
        logger.info("Attempting to get the message amount for user {} by filter.", user);

        Map<String, String[]> searchMap = new HashMap<>();
        searchMap.put(TYPE, new String[]{SDM});
        if (userId != null)
            searchMap.put(USER_ID, new String[]{userId});
        if (action != null)
            searchMap.put(ACTION, new String[]{action});
        if (entityId != null)
            searchMap.put(ENTITY_ID, new String[]{entityId});
        if (detail != null)
            searchMap.put(DETAIL, new String[]{detail});
        if (dateFrom != null)
            searchMap.put(DATE_FROM, new String[]{dateFrom});
        if (dateTo != null)
            searchMap.put(DATE_TO, new String[]{dateTo});

        AuditingSearchCriteria searchCriteria = auditingQueryParameterParser.buildSearchCriteria(searchMap);
        if (searchCriteria == null) {
            return Response.ok(0).build();
        }
        Long amount = auditingServiceImpl.getAuditLogsAmount(searchCriteria);
        logger.info("End of getting the message amount {} for user {}.", amount, user);
        return Response.ok(amount).build();
    }

    /**
     * get the actions for specified user and subject
     *
     * @param userId the user id
     *
     * @return a list of available actions
     */
    @GET
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Path("ExceptionAction")
    public Response getExceptionActions(@QueryParam("user") final String userId) {
        logger.info("Attempting to get the actions in Exception Action for user {}.", userId);
        List<String> actions = auditingServiceImpl.getExceptionActions();
        logger.info("End of getting the {} actions in Exception Action for user {}.", actions.size(), userId);
        return Response.ok(actions).build();
    }

    /**
     * the the amount of searched AuditLog data
     *
     * @param user     the user id
     * @param actor    the actor to search
     * @param ticketId the ticketId to search
     * @param comments the comments to search
     * @param dateFrom the start data to search
     * @param dateTo   the end data to search
     *
     * @return response the amount to the web client if successful
     */
    @POST
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Path("ExceptionActionsAmount")
    public Response getExceptionActionsAmount(
            @QueryParam("user") final String user,
            @FormParam("actor") final String actor,
            @FormParam("action") final String action,
            @FormParam("ticketId") final String ticketId,
            @FormParam("comments") final String comments,
            @FormParam("dateFrom") final String dateFrom,
            @FormParam("dateTo") final String dateTo) {
        logger.info("Attempting to get the Exception Action amount for user {} by filter.", user);

        Map<String, String[]> searchMap = new HashMap<>();
        searchMap.put(TYPE, new String[]{EXCEPTION});
        if (actor != null)
            searchMap.put(ACTOR, new String[]{actor});
        if (action != null)
            searchMap.put(ACTION, new String[]{action});
        if (ticketId != null)
            searchMap.put(TICKET_ID, new String[]{ticketId});
        if (comments != null)
            searchMap.put(COMMENTS, new String[]{comments});
        if (dateFrom != null)
            searchMap.put(DATE_FROM, new String[]{dateFrom});
        if (dateTo != null)
            searchMap.put(DATE_TO, new String[]{dateTo});

        AuditingSearchCriteria searchCriteria = auditingQueryParameterParser.buildSearchCriteria(searchMap);
        if (searchCriteria == null) {
            return Response.ok(0).build();
        }
        Long amount = auditingServiceImpl.getExceptionActionsAmount(searchCriteria);
        logger.info("End of getting the Exception Action amount {} for user {}.", amount, user);
        return Response.ok(amount).build();
    }

    @POST
    @Path("/ExportContent")
    public Response exportContent(
            @QueryParam("user") final String userId,
            @QueryParam("ids") final String ids) {
        logger.info("Attempting to export AuditingRT data for:" + userId);
        try {
            String[] idArray = ids.split(",");

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            SXSSFWorkbook wb = BuildDetailsExport.generateExcelFrame();

            for (int i = 0; i < idArray.length; i++) {
                wb = BuildDetailsExport.generateExcelCurrentPage(idArray[i], auditingServiceImpl, wb, i);
            }
            wb.write(baos);
            DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
            String fileName = RT_EXPORT_FILE_NAME +
                    String.valueOf(dateFormat.format(Calendar.getInstance().getTime())) + ".csv";
            logger.info("Export AuditingRT data successfully for:" + userId);
            return Response
                    .ok(baos.toByteArray(), MediaType.APPLICATION_OCTET_STREAM)
                    .header("Content-Disposition",
                            "attachment; filename=" + fileName).build();
        } catch (Exception e) {
            logger.error("Export AuditingRT data error", e);
            throw new RuntimeException(e);
        }
    }

    @POST
    @Path("/ExportContentAll")
    public Response exportContentAll(
            @QueryParam("user") final String userId,
            @FormParam("trackingId") final String trackingId,
            @FormParam("sourceSysId") final String sourceSysId,
            @FormParam("status") final String status,
            @FormParam("filterField") final String filterField,
            @FormParam("dateFrom") final String dateFrom,
            @FormParam("dateTo") final String dateTo,
            @FormParam("amount") final Integer amount) {
        logger.info("Attempting to export all AuditingRT data for:" + userId);
        if (null == userId) {
            return Response.serverError().entity("UserId is empty!").build();
        }
        Map<String, String[]> searchMap = new HashMap<>();
        searchMap.put(TYPE, new String[]{RT});
        searchMap.put(USER, new String[]{userId});
        if (trackingId != null)
            searchMap.put(TRACKING_ID, new String[]{trackingId});
        if (sourceSysId != null)
            searchMap.put(SOURCE_SYS_ID, new String[]{sourceSysId});
        if (status != null)
            searchMap.put(STATUS, new String[]{status});
        if (filterField != null)
            searchMap.put(FILTER_FIELD, new String[]{filterField});
        if (dateFrom != null)
            searchMap.put(DATE_FROM, new String[]{dateFrom});
        if (dateTo != null)
            searchMap.put(DATE_TO, new String[]{dateTo});

        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            SXSSFWorkbook wb = BuildDetailsExport.generateExcelFrame();
            double pageNum = Math.floor(amount / RT_EXPORT_NUM);
            for (int i = 0; i < (int) pageNum + 1; i++) {
                searchMap.put(FIRST_RESULT, new String[]{Integer.toString(i)});
                searchMap.put(MAX_RESULTS, new String[]{Integer.toString(RT_EXPORT_NUM)});
                AuditingSearchCriteria searchCriteria = auditingQueryParameterParser.buildSearchCriteria(searchMap);
                List<MlsMessage> mlsMessages = auditingServiceImpl.listMessages(searchCriteria, userId, null);
                wb = BuildDetailsExport.generateAllExcelData(mlsMessages, wb, i * RT_EXPORT_NUM);
            }
            wb.write(baos);
            DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
            String fileName = RT_EXPORT_FILE_NAME +
                    String.valueOf(dateFormat.format(Calendar.getInstance().getTime())) + ".csv";
            logger.info("Export all AuditingRT data successfully for:" + userId);
            return Response
                    .ok(baos.toByteArray(), MediaType.APPLICATION_OCTET_STREAM)
                    .header("Content-Disposition",
                            "attachment; filename=" + fileName).build();
        } catch (Exception e) {
            logger.error("Export all AuditingRT data error", e);
            throw new RuntimeException(e);
        }
    }

    /**
     * the the amount of searched AuditLog data
     *
     * @param user             the user id
     * @param uploadServerType upload server type : FX or ALM
     * @param uploadFileType   upload file type : Journal,data mart and limits
     * @param dateFrom         the start data to search
     * @param dateTo           the end data to search
     *
     * @return response the amount to the web client if successful
     */
    @POST
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Path("MurexAuditAmount")
    public Response getMurexAuditAmount(
            @FormParam("userId") final String user,
            @FormParam("serverType") final String uploadServerType,
            @FormParam("fileType") final String uploadFileType,
            @FormParam("fileName") final String uploadFileName,
            @FormParam("dateFrom") final String dateFrom,
            @FormParam("dateTo") final String dateTo) {
        logger.info("Attempting to get the Murex Audit amount for user {} by filter.", user);

        Map<String, String[]> searchMap = new HashMap<>();
        searchMap.put(TYPE, new String[]{MUREX});
        if (StringUtils.isNotEmpty(uploadServerType))
            searchMap.put(UPLOAD_SERVER_TYPE, new String[]{uploadServerType});
        if (StringUtils.isNotEmpty(uploadFileType))
            searchMap.put(UPLOAD_FILE_TYPE, new String[]{uploadFileType});
        if (StringUtils.isNotEmpty(uploadFileName))
            searchMap.put(UPLOAD_FILE_NAME, new String[]{uploadFileName});
        if (StringUtils.isNotEmpty(user))
            searchMap.put(USER_ID, new String[]{user});
        if (dateFrom != null)
            searchMap.put(DATE_FROM, new String[]{dateFrom});
        if (dateTo != null)
            searchMap.put(DATE_TO, new String[]{dateTo});

        AuditingSearchCriteria searchCriteria = auditingQueryParameterParser.buildSearchCriteria(searchMap);
        if (searchCriteria == null) {
            return Response.ok(0).build();
        }
        Long amount = auditingServiceImpl.getMurexAuditAmount(searchCriteria);
        logger.info("End of getting the Murex Audit amount {} for user {}.", amount, user);
        return Response.ok(amount).build();
    }

    @POST
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Path("RTAction")
    public Response replayAuditingRTMessage(
            @QueryParam("user") final String userId,
            @QueryParam("action") final String action,
            @QueryParam("id") final String id) {
        logger.info("Attempting to get the message amount for user {} by filter.", userId);

        if (null == userId || userId.isEmpty()) {
            return Response.serverError().entity("User Id is empty!").build();
        }
        Message message = auditingServiceImpl.getMessageByIdentity(Long.parseLong(id));
        if(message == null) {
            return Response.status(Status.NOT_FOUND).entity(ImmutableMap.of("error", "message not found")).build();
        }
        if("MarkResolved".equals(action)) {// do nothing here, see ActionPerformingAgentWebService for action result
            return Response.ok().build();
        }
        logger.info("End of getting the message for user {} by Id {}.", userId, id);
        try {
            replayAuditedRTMsg(message);
        }catch(Exception e) {
            return Response.status(500).entity(e.getMessage()).build();
        }
        return Response.ok("ok").build();
    }

    private void replayAuditedRTMsg(Message message) {
        logger.info("Starting with replay original message.");
        Set<MessageProperty> messageProperties = message.getMessageProperties();
        Map<String, String> jmsProperties = new HashMap<>();
        boolean replayNackMessage = false;
        boolean isAckMessage = false;
        String trackingIdOfNackMessage = null;
        for (MessageProperty messageProperty : messageProperties) {
            if ("messageType".equals(messageProperty.getKey()) && ("NACK".equals(messageProperty.getValue()))) {
                replayNackMessage = true;
                trackingIdOfNackMessage = message.getTrackingId();
                break;
            }
            if("messageType".equals(messageProperty.getKey()) && ("ACK".equals(messageProperty.getValue()))){
                isAckMessage = true;
            }
            jmsProperties.put(messageProperty.getKey(), messageProperty.getValue());
        }
        if (replayNackMessage) {
            trackingIdOfNackMessage = extractTrackingIdForOriginalMessage(trackingIdOfNackMessage);
            HibernateTemplate ht = new HibernateTemplate(sessionFactory);
            @SuppressWarnings("rawtypes")
            List origins = ht.find("FROM Message WHERE trackingId=? and channel=? and status=? and sourceSysId=?", trackingIdOfNackMessage, Message.Channel.DISPATCH, Message.Status.RECEIVED, message.getSourceSysId());
            if(origins.size() == 0) {
                throw new RuntimeException("Cannot find original message to replay");
            }
            message = auditingServiceImpl.getNackOriginalMessage(trackingIdOfNackMessage,message.getSourceSysId().toString());
            messageProperties = message.getMessageProperties();
            jmsProperties.clear();
            for (MessageProperty messageProperty : messageProperties) {
                jmsProperties.put(messageProperty.getKey(), messageProperty.getValue());
            }
        }
        byte[] messageContent = message.getContent();
        String messageStringContent = null;
        Message.ContentType contentType = message.getContentType();
        ByteArrayOutputStream out = null;
        GZIPInputStream gunzip = null;
        try {
            if (contentType != null && (com.scb.razor.mls.persistent.model.Message.ContentType.COMPRESSED_BINARY == contentType || com.scb.razor.mls.persistent.model.Message.ContentType.COMPRESSED_TEXT == message.getContentType())) {
                gunzip = new GZIPInputStream(new ByteArrayInputStream(messageContent));
                out = new ByteArrayOutputStream();
                byte[] buffer = new byte[256];
                int n;
                while ((n = gunzip.read(buffer)) >= 0) {
                    out.write(buffer, 0, n);
                }
                messageStringContent = out.toString();
            } else {
                messageStringContent = new String(messageContent);
            }
        } catch (IOException e) {
            logger.error("Error happened during retrieving the original message before publishing", e);
        } finally {
            try {
                if (gunzip != null) {
                    gunzip.close();
                }
                if (out != null) {
                    out.close();
                }
            } catch (IOException e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            }
        }
        if(isAckMessage){
            String destination = message.getDestination();
            String extractedDestination = extractDestination(destination);
            auditingDynamicPublisher.publishMessage("",messageStringContent,jmsProperties,message,extractedDestination);
        }
        if(messageStringContent!=null)
        auditingPublisher.publishMessage("", messageStringContent, jmsProperties, message);
        logger.info("Ending with replay original message.");
    }

    private String extractTrackingIdForOriginalMessage(String str) {
        String[] strArray = str.split("_");
        int size = strArray.length;
        StringBuilder sb = new StringBuilder();
        if (size > 5) {
            for (int i = 2; i < size - 2; i++) {
                sb.append(strArray[i]);
                if (i != size - 3) {
                    sb.append("_");
                }
            }
        } else {
            sb.append(strArray[2]);
        }
        return sb.toString().trim();//trim for trackingId "MX_FXCASH_28572584|2|NOTNEW               _67628361_1469524608061". should figure out why there are whitespaces in middle
    }

    private String extractDestination(String str) {
        int beginIndex = str.indexOf("[name=");
        int endIndex = str.indexOf(" eventType");
        String destination = null;
        if(endIndex>beginIndex){
           destination  = str.substring((beginIndex+6),endIndex);
        }
        return destination;
    }

    @POST
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Path("BatchProcess")
    public Response batchProcess(@QueryParam("user") final String userId,
                                 @FormParam("guids") final String guids) {
        if (guids == null) {
            return Response.serverError().entity("Missing id and/or action parameters").build();
        }
        String[] guidList = guids.split("#");
        logger.info("Attempt to batch replay {} auditing rt messages by {}", guidList.length, userId);
        for (String guid : guidList) {
            Message message = auditingServiceImpl.getMessageByIdentity(Long.parseLong(guid));
            logger.info("End of getting the message for user {} by Id {}.", userId, guid);
            replayAuditedRTMsg(message);
        }
        return Response.ok("ok").build();
    }

    @POST
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Path("BatchProcessForTrackingIds")
    public Response batchProcessForTrackingIds(@QueryParam("user") final String userId,
                                 @FormParam("trackingIds") final String trackingIds) {
        if (trackingIds == null) {
            return Response.serverError().entity("Missing id and/or action parameters").build();
        }
        StringBuilder errorMsg = new StringBuilder();
        String[] trackingIdAndSourceIdList = trackingIds.split("#");
        logger.info("Attempt to batch replay {} auditing rt messages by {}", trackingIdAndSourceIdList.length, userId);
        for (String trackingIdAndSourceId : trackingIdAndSourceIdList) {
            String[] trackingIdList = trackingIdAndSourceId.trim().split(",");
            String trackingId = null;
            String sourceSysId = null;
            if(trackingIdList.length==2){
                trackingId = trackingIdList[0];
                sourceSysId =  trackingIdList[1];
            } else {
                logger.error(String.format("The format of Tracking id and source system id : %s is not correct.", trackingIdAndSourceId));
                if(errorMsg.length()>0) {
                    errorMsg.append("\n");
                }
                errorMsg.append(String.format("The format of Tracking id and source system id : %s is not correct.", trackingIdAndSourceId));
                continue;
            }
            Message message = auditingServiceImpl.getNackOriginalMessage(trackingId,sourceSysId);
            logger.info("End of getting the message for user {} by tracking id {} and source sys id {}.", userId, trackingId,sourceSysId);
            replayAuditedRTMsg(message);
        }
        return Response.ok(errorMsg.toString().length()>0?errorMsg.toString():"ok").build();
    }

}
