package com.scb.razor.mls.auditing;

/**
 * event to be posted to eventbus. 
 * subclasses expected to be defined in their own module package separately.
 * *DO NOT* define them centrally in a independent package
 * @author 1510954
 */
public interface BusEvent {
}
