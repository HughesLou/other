package com.scb.razor.mls.auditing.lucene;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.FieldType;
import org.apache.lucene.document.LongField;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.document.Field.Store;
import org.apache.lucene.document.FieldType.NumericType;
import org.apache.lucene.index.DocValuesType;
import org.apache.lucene.index.IndexOptions;

import com.google.common.base.Function;
import com.google.common.base.Objects;

public class ToDocument {

    public static Function<Map<String, Object>, Document> mlsExceptionToDocument() {
        return new Function<Map<String,Object>, Document>() {
            public Document apply(Map<String, Object> input) {
                return fromMlsException(input);
            }
        }; 
    }

    public static Function<Map<String, Object>, Document> murexExceptionToDocument() {
        return new Function<Map<String,Object>, Document>() {
            public Document apply(Map<String, Object> input) {
                return fromMurexException(input);
            }
        }; 
    }
    
    public static String readOriginalTrackingId(String trackingId) {
        Matcher m = NACK_TRACKINGID.matcher(trackingId);
        if(m.find()) {
            return m.group(1);
        }
        return trackingId;
    }
    
    private static String WHITESPACE = " ";
    
    private static Pattern NACK_TRACKINGID = Pattern.compile("^[^_]+_[^_]+_(.*)_[^_]+_[^_]+$");
    
    private static FieldType LONG_SORT_NOSTORE = new FieldType();
    
    static {
        LONG_SORT_NOSTORE.setOmitNorms(true);
        LONG_SORT_NOSTORE.setIndexOptions(IndexOptions.DOCS);
        LONG_SORT_NOSTORE.setStored(false);
        LONG_SORT_NOSTORE.setTokenized(false);
        LONG_SORT_NOSTORE.setDocValuesType(DocValuesType.NUMERIC);//key point 1
        LONG_SORT_NOSTORE.setNumericType(NumericType.LONG);//key point 2
        LONG_SORT_NOSTORE.freeze();
    }
    
    public static Document fromMlsException(Map<String, Object> map) {
        String id = String.valueOf(map.get("id"));
        String guid = String.valueOf(map.get("guid"));
        String creator = String.valueOf(map.get("creator"));
        String status = String.valueOf(map.get("status"));
        String type = String.valueOf(map.get("type"));
        String trackingId = (String)map.get("JPP_trackingId");
        String description = String.valueOf(map.get("description"));
        Date createdtimestamp = (Timestamp)map.get("createdtimestamp");
        
        Map<String, String> properties = new HashMap<String, String>();
        for(Entry<String, Object> en : map.entrySet()) {
            String key = en.getKey();
            Object value = en.getValue();
            if(value == null) {
                continue;
            }
            if(Objects.equal("id", key)) {
                continue;
            }
            if(Objects.equal("guid", key)) {
                continue;
            }
            if(Objects.equal("creator", key)) {
                continue;
            }
            if(Objects.equal("status", key)) {
                continue;
            }
            if(Objects.equal("type", key)) {
                continue;
            }
            if(Objects.equal("description", key)) {
                continue;
            }
            if(Objects.equal("createdtimestamp", key)) {
                continue;
            }
            properties.put(key, (String)value);
        }
        
        Document doc = new Document();
        StringBuilder text = new StringBuilder();
        if(id != null) {
            doc.add(new StringField("id", id, Store.YES));
            text.append(WHITESPACE).append(id);
            text.append(WHITESPACE).append("MLS-" + id);//friendlyId
        }
        if(guid != null) {
            doc.add(new StringField("guid", guid, Store.NO));
            text.append(WHITESPACE).append(guid);
        }
        if(creator != null) {
            doc.add(new StringField("creator", creator, Store.NO));
            text.append(WHITESPACE).append(creator);
        }
        if(status != null) {
            doc.add(new StringField("status", status, Store.YES));
            text.append(WHITESPACE).append(status);
        }
        if(type != null) {
            doc.add(new StringField("type", type, Store.NO));
            text.append(WHITESPACE).append(type);
        }
        if(description != null) {
            doc.add(new TextField("description", description, Store.NO));
            text.append(WHITESPACE).append(description);
        }
        if(createdtimestamp != null) {
            doc.add(new LongField("createdtimestamp", createdtimestamp.getTime()/1000L , LONG_SORT_NOSTORE));
            doc.add(new LongField("create_timestamp", createdtimestamp.getTime()/1000L , LONG_SORT_NOSTORE));
//            text.append(WHITESPACE).append(createdtimestamp);
        }
        if(trackingId != null) {
            String otid = readOriginalTrackingId(trackingId);
            doc.add(new StringField("tracking_id", trackingId, Store.YES));
            doc.add(new StringField("original_tracking_id", otid, Store.YES));
            text.append(WHITESPACE).append(trackingId);
            text.append(WHITESPACE).append(otid);
            if(otid.indexOf("|") > 0) {////trackingId is like MX_FXCASH_43906701|2|NOTNEW _67494547_1467616074949, and 43906701 is the trade id needs to be searchable
                String tid = otid.split("\\|")[0];
                doc.add(new StringField("original_trade_id", tid, Store.NO));
                text.append(WHITESPACE).append(tid);
            }
        }
        for(Entry<String, String> en : properties.entrySet()) {
            String key = en.getKey(), value = en.getValue();
            key = key.contains(" ") ? key.replaceAll(" +", "_") : key;
            if(Objects.equal(key, "JPP_arrivalTimestamp")) {
                continue;
            }
            if(Objects.equal(key, "Stack_Trace")) {
                doc.add(new TextField(key, value, Store.NO));
                continue;
            }
            if(Objects.equal(key, "JPP_trackingId")) {
                doc.add(new StringField("original_tracking_id", readOriginalTrackingId(value), Store.YES));
            }
            doc.add(new StringField(key, value, Store.NO));
            text.append(WHITESPACE).append(value);
        }
        doc.add(new TextField("text", text.toString(), Store.NO));
        doc.add(new StringField("xtype", "mls", Store.NO));
        return doc;
    }
    
    public static Document fromMurexException(Map<String, Object> map) {
        String id = null;
        String tracking_id = null;
        String source_sys_id = null;
        String status = null;
        String content_type = null;
        Date   create_timestamp = null;
        String reference_id = null;
        String channel = null;
        String correlation_id = null;
        String delivery_mode = null;
        String destination = null;
        String expiration = null;
        String jms_msg_id = null;
        String priority = null;
        Date   jms_timestamp = null;
        String type = null;
        Map<String, String> properties = new HashMap<>();
        
        for(Entry<String, Object> en : map.entrySet()) {
            String key = en.getKey();
            Object value = en.getValue();
            if(value == null) {
                continue;
            }
            if(Objects.equal("id", key)) {
                id = String.valueOf(value);
                continue;
            }
            if(Objects.equal("tracking_id", key)) {
                tracking_id = (String)value;
                continue;
            }
            if(Objects.equal("source_sys_id", key)) {
                source_sys_id = (String)value;
                continue;
            }
            if(Objects.equal("status", key)) {
                status = (String)value;
                continue;
            }
            if(Objects.equal("content_type", key)) {
                content_type = (String)value;
                continue;
            }
            if(Objects.equal("create_timestamp", key)) {
                create_timestamp = (Timestamp)value;
                continue;
            }
            if(Objects.equal("reference_id", key)) {
                reference_id = (String)value;
                continue;
            }
            if(Objects.equal("channel", key)) {
                channel = (String)value;
                continue;
            }
            if(Objects.equal("correlation_id", key)) {
                correlation_id = (String)value;
                continue;
            }
            if(Objects.equal("delivery_mode", key)) {
                delivery_mode = (String)value;
                continue;
            }
            if(Objects.equal("destination", key)) {
                destination = (String)value;
                continue;
            }
            if(Objects.equal("expiration", key)) {
                expiration = (String)value;
                continue;
            }
            if(Objects.equal("jms_msg_id", key)) {
                jms_msg_id = (String)value;
                continue;
            }
            if(Objects.equal("priority", key)) {
                priority = (String)value;
                continue;
            }
            if(Objects.equal("jms_timestamp", key)) {
                jms_timestamp = (Timestamp)value;
                continue;
            }
            if(Objects.equal("type", key)) {
                type = (String)value;
                continue;
            }
            properties.put(key, (String)value);
        }
        Document doc = new Document();
        
        StringBuilder text = new StringBuilder();
        if(id != null) {
            doc.add(new StringField("id", id, Store.YES));
            text.append(WHITESPACE).append(id);
        }
        if(tracking_id != null) {
            doc.add(new StringField("tracking_id", tracking_id, Store.YES));
            text.append(WHITESPACE).append(tracking_id);
        }
        if(source_sys_id != null) {
            doc.add(new StringField("source_sys_id", source_sys_id, Store.NO));
            text.append(WHITESPACE).append(source_sys_id);
        }
        if(status != null) {
            doc.add(new StringField("status", status, Store.YES));
            text.append(WHITESPACE).append(status);
        }
        if(content_type != null) {
            doc.add(new StringField("content_type", content_type, Store.NO));
            text.append(WHITESPACE).append(content_type);
        }
        if(create_timestamp != null) {
            doc.add(new LongField("create_timestamp", create_timestamp.getTime()/1000L , LONG_SORT_NOSTORE));
            text.append(WHITESPACE).append(create_timestamp);
        }
        if(reference_id != null) {
            doc.add(new StringField("reference_id", reference_id, Store.NO));
            text.append(WHITESPACE).append(reference_id);
        }
        if(channel != null) {
            doc.add(new StringField("channel", channel, Store.NO));
            text.append(WHITESPACE).append(channel);
        }
        if(correlation_id != null) {
            doc.add(new StringField("correlation_id", correlation_id, Store.NO));
            text.append(WHITESPACE).append(correlation_id);
        }
        if(delivery_mode != null) {
            doc.add(new StringField("delivery_mode", delivery_mode, Store.NO));
            text.append(WHITESPACE).append(delivery_mode);
        }
        if(destination != null) {
            doc.add(new StringField("destination", destination, Store.NO));
            text.append(WHITESPACE).append(destination);
        }
        if(expiration != null) {
            doc.add(new StringField("expiration", expiration, Store.NO));
            text.append(WHITESPACE).append(expiration);
        }
        if(jms_msg_id != null) {
//            do not index 
//            doc.add(new StringField("jms_msg_id", jms_msg_id, Store.NO));
//            text.append(WHITESPACE).append(jms_msg_id);
        }
        if(priority != null) {
            doc.add(new StringField("priority", priority, Store.NO));
            text.append(WHITESPACE).append(priority);
        }
        if(jms_timestamp != null) {
            doc.add(new LongField("jms_timestamp", jms_timestamp.getTime()/1000L, Store.NO));
            text.append(WHITESPACE).append(jms_timestamp);
        }
        if(type != null) {
            doc.add(new StringField("type", type, Store.NO));
            text.append(WHITESPACE).append(type);
        }
        
        boolean isNack = false, isAck = false;
        
        for(Entry<String, String> en : properties.entrySet()) {
            if(en.getValue() == null) {
                continue;
            }
            if("arrivalTimestamp".equals(en.getKey())) {
                //do not index
                continue;
            }
            if("messageType".equals(en.getKey())) {
                if("NACK".equals(en.getValue())) {
                    isNack = true;
                }
                if("ACK".equals(en.getValue())) {
                    isAck = true;
                }
            }
            doc.add(new StringField(en.getKey(), en.getValue(), Store.NO));
            if("true".equalsIgnoreCase(en.getValue())) {
                text.append(WHITESPACE).append(en.getKey());
            } else {
                text.append(WHITESPACE).append(en.getValue());
            }
        }
        
        if(tracking_id != null && isNack || isAck) {
            //nack tracking id = interfaceid + origin tracking id + doc id + timestamp
            String oid = readOriginalTrackingId(tracking_id);
            doc.add(new StringField("original_tracking_id", oid, Store.YES));
            text.append(WHITESPACE).append(oid);
            if(oid.indexOf("|") > 0) {//trackingId is like MX_FXCASH_43906701|2|NOTNEW _67494547_1467616074949, and 43906701 is the trade id needs to be searchable
                String tid = oid.split("\\|")[0];
                doc.add(new StringField("original_trade_id", tid, Store.NO));
                text.append(WHITESPACE).append(tid);
            }
        }
        
        doc.add(new TextField("text", text.toString(), Store.NO));
        doc.add(new StringField("xtype", "murex", Store.NO));
        return doc;
    }
}
