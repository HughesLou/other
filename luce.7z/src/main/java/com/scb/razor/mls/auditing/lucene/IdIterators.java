package com.scb.razor.mls.auditing.lucene;

import java.io.Closeable;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.sql.DataSource;

import com.google.common.base.Function;
import com.google.common.base.Objects;
import com.google.common.base.Predicate;
import com.google.common.collect.Iterators;
import com.google.common.collect.UnmodifiableIterator;

public class IdIterators {

    public static <T> Iterator<T> fromList(List<T> ids) {
        return ids.iterator();
    }
    
    /**
     * @return an {@link Iterator} that is {@link Closeable}, you are responsible to close it after read all.
     */
    public static <T> Iterator<T> fromResultSet(ResultSet rs, Function<ResultSet, T> readIdFunction) {
        return new ResultSetIdIterator<T>(rs, readIdFunction);
    }
    
    /**
     * @return an {@link Iterator} that is {@link Closeable}, you are responsible to close it after read all.
     */
    public static <T> Iterator<T> fromQuery(String sql, DataSource dataSource, Function<ResultSet, T> readIdFunction) throws SQLException {
        Connection conn = dataSource.getConnection();
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(sql);
        ResultSetIdIterator<T> iter = new ResultSetIdIterator<T>(rs, readIdFunction);
        iter.conn = conn;
        return iter;
    }

    private static Pattern NAMED_PARAM_PTN = Pattern.compile(":(\\w+)");
    /**
     * @return an {@link Iterator} that is {@link Closeable}, you are responsible to close it after read all.
     */
    public static <T> Iterator<T> fromNamedParamQuery(String sql, Map<String, Object> params, DataSource dataSource, Function<ResultSet, T> readIdFunction) throws SQLException {
        //TODO utilize spring-jdbc's facility 
        Matcher m = NAMED_PARAM_PTN.matcher(sql);
        Map<Integer, String> pos = new HashMap<Integer, String>();
        int count=0;
        while(m.find()) {
            count++;
            pos.put(count, m.group(1));
        }
        Connection conn = dataSource.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql.replaceAll(":\\w+", "?"));
        for(int i = 1; i <= pos.size(); i++){
            String name = pos.get(i);
            Object value = params.get(name);
            if(value == null) {
                throw new NullPointerException();
            } else if(value instanceof Timestamp) {
                stmt.setTimestamp(i, (Timestamp)value);
            } else if(value instanceof Long) {
                stmt.setLong(i, (Long)value);
            } else if(value instanceof String) {
                stmt.setString(i, (String)value);
            } else if(value instanceof Integer) {
                stmt.setInt(i, (Integer)value);
            } else {
                throw new RuntimeException("unsupported parameter : " + name);
            }
        }
        ResultSet rs = stmt.executeQuery();
        ResultSetIdIterator<T> iter = new ResultSetIdIterator<T>(rs, readIdFunction);
        iter.conn = conn;
        return iter;
    }
    
    public static <T> Iterator<T> excepts(Iterator<T> original, final List<T> exceptIds) {
        return Iterators.filter(original, new Predicate<T>() {
            public boolean apply(T input) {
                for(T t : exceptIds) {
                    if(Objects.equal(t, input)) {
                        return false;
                    }
                }
                return true;
            }
        });
    }
    
    /**
     * NOT thread-safe
     * @author 1510954
     */
    public static class ResultSetIdIterator<T> extends UnmodifiableIterator<T> implements Closeable{
        
        private ResultSet rs;
        
        private boolean ready = false, consumed = false;
        
        private Function<ResultSet, T> readIdFunction;
        
        Connection conn;
        
        private T current;
        
        private void computeNext() {
            try {
                boolean exist = rs.next();
                current = exist ? readIdFunction.apply(rs) : null;
                consumed = false;
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
        
        public ResultSetIdIterator(ResultSet rs, Function<ResultSet, T> func) {
            this.rs = rs;
            this.readIdFunction = func;
        }

        public boolean hasNext() {
            if(!ready) {
                computeNext(); //TODO should not early call next when testing availability
                ready = true;
            }
            if(consumed)
                computeNext();
            if(current == null) {
                try {// read to last, close resource
                    close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                return false;
            }
            return true;
        }

        public T next() {
            try {
                if(!ready) {
                    computeNext();
                    ready = true;
                    return current;
                }
                if(consumed)
                    computeNext();  
                return current;
            } finally {
                consumed = true;
            }
        }

        public static Function<ResultSet, Long> getLongFunction(final String columnName) {
            return new Function<ResultSet, Long>() {
                public Long apply(ResultSet input) {
                    try {
                        return input.getLong(columnName);
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }
                }
            };
        }
        
        public static Function<ResultSet, String> getStringFunction(final String columnName) {
            return new Function<ResultSet, String>() {
                public String apply(ResultSet input) {
                    try {
                        return input.getString(columnName);
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }
                }
            };
        }

        @Override
        public void close() throws IOException {
            try {
                rs.close();
                if(conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                throw new IOException(e);
            }
        }
    }
}
