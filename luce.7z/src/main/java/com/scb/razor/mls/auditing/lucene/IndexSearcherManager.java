package com.scb.razor.mls.auditing.lucene;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.SearcherManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * Lucene can search back in time.
 * 
 * you are responsible to close the IndexReader while back in time.
 * 
 * when do you close it ?
 * Answer : when no one use it any more
 * 
 * <pre><code>
 * IndexSearcherManager ism = ...
 * IndexSearcher is = ism.acquire();
 * try {
 *   //do the search
 * } finally {
 *   is.release();
 * }
 * </code></pre>
 * 
 * P.S. lucene has its own {@link SearcherManager}, the purpose is different from this one 
 * {@link SearcherManager} is trying to update existing {@link IndexSearcher} instance to
 * search with latest index, this one is to make sure {@link IndexReader} is eventually
 * closed after {@link IndexSearcher} has been used ({@link #release(IndexSearcher)}).
 * In situation that old reader not be closed, index files will grow without limit.
 * I used to see 7k index files due to this issue -- and normally it should be around 100 files
 * @author 1510954
 */
public class IndexSearcherManager {
    
    private final static Logger log = LoggerFactory.getLogger(IndexSearcherManager.class);

    private IndexSearcher latest;
    
    private Map<IndexSearcher, AtomicInteger> history = new ConcurrentHashMap<>();
    
    private CountDownLatch ready = new CountDownLatch(1);
    
    private Semaphore writer = new Semaphore(1);
    
    /**
     * get latest indexSearcher, never return null
     * @throws RuntimeException if interrupted waiting indexSearcher to be ready
     */
    public IndexSearcher acquire() {
        try {
            ready.await();//10x slower than "ready.countDown()", when count=0
        } catch (InterruptedException e) {
            log.error("interrupted while acquiring indexSearcher, will return null", e);
            throw new RuntimeException(e);
        }
        IndexSearcher is = latest;
        history.get(is).incrementAndGet();
        return is;
    }
    
    public void release(IndexSearcher indexSearcher) {
        try {
            writer.acquire();
        }catch(InterruptedException e) {
            log.error("interrupted while trying to release indexSearcher, it might cause index file leak", e);
            return;
        }
        try {
            int count = history.get(indexSearcher).decrementAndGet();
            if(indexSearcher != latest && count == 0) {
                //hey you ! mission complete, bye
                try {
                    indexSearcher.getIndexReader().close();
                } catch (Exception e) {
                    log.warn("fail to close indexreader when no one use, it might cause index file leak", e);
                    //no need to throw to outside
                } finally {
                    history.remove(indexSearcher);
                }
            }
            if(count < 0) {
                throw new RuntimeException("release only what you acquired");
            }
        } finally {
            writer.release();
        }
    }

    public void setIndexSearcher(IndexSearcher indexSearcher) {
        
        if(indexSearcher == null) {
            throw new NullPointerException();
        }
        try {
            writer.acquire();
        }catch(InterruptedException e) {
            log.error("interrupted while trying to update indexSearcher, by pass this new value", e);
            return;
        }
        try {
            if(history.containsKey(indexSearcher)) {
                log.warn("this indexSearcher already set before, will ignore this call");
                return;
            }
            history.put(indexSearcher, new AtomicInteger(0));
            this.latest = indexSearcher;
            //perf of this line :
            //execute 1 billion times for each of "ready.countDown()" and "obj = null"
            //"ready.countDown()" takes 4 seconds, "obj == null" takes 0.2 second
            //take these numbers, compare with the frequency of setIndexSearcher :
            //conclusion : no perf issue here
            //P.S. according to javadoc "If the current count equals zero then nothing happens."
            ready.countDown();
        } finally {
            writer.release();
        }
    }
}
