/*
 * Copyright (c) 2015. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.service.impl;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.scb.razor.mls.common.service.CacheService;
import com.scb.razor.mls.auditing.service.MessagePropertyService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.*;

import static com.scb.razor.mls.persistent.utils.PersistentConstants.KEY;

/**
 * Description:
 * Author: 1466811
 * Date:   1:47 PM 8/6/15
 */
@Service
public class CacheServiceImpl implements CacheService<String> {

    private static final Logger LOGGER = LoggerFactory.getLogger(CacheServiceImpl.class);
    @Autowired
    private MessagePropertyService messagePropertyServiceImpl = null;
    @Value("${cacheTimeoutMinutes}")
    private long cacheTimeoutMinutes = 60;
    private LoadingCache<String, Set<String>> elements;

    @Override
    @Transactional(readOnly = true)
    public void initCache() {
        elements = CacheBuilder.newBuilder().refreshAfterWrite(cacheTimeoutMinutes, TimeUnit.MINUTES)
                .build(new CacheLoader<String, Set<String>>() {
                    public Set<String> load(final String type) {
                        return getElements(type);
                    }
                });
    }

    @Override
    public Set<String> get(String key) {
        try {
            return elements.get(key);
        } catch (ExecutionException e) {
            LOGGER.error("Error when getting keys", e);
            throw new RuntimeException("There was an error getting keys.", e);
        }
    }

    private Set<String> getElements(String type) {
        if (type.equals(KEY)) {
            return new TreeSet<>(messagePropertyServiceImpl.getPropertyKeys());
        }
        return new TreeSet<>();
    }
}
