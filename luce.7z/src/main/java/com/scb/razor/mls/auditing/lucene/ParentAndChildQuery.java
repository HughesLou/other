package com.scb.razor.mls.auditing.lucene;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.google.common.base.Function;
import com.google.common.base.Functions;
import com.google.common.base.Joiner;
import com.google.common.base.Objects;
import com.google.common.collect.Iterators;
import com.google.common.collect.UnmodifiableIterator;

//TODO give class a good name
public abstract class ParentAndChildQuery<ID> {

    protected DataSource dataSource;
    
    protected int batchSize = 1000;
    
    protected JdbcTemplate jdbcTemplate;
    
    public abstract <T> T query(List<ID> ids, Function<List<Map<String, Object>>, T> trans);
    
    public List<Map<String, Object>> query(List<ID> ids) {
        return query(ids, Functions.<List<Map<String, Object>>>identity());
    }
    
    public Iterator<List<Map<String, Object>>> query(Iterator<ID> ids) {
        
        final UnmodifiableIterator<List<ID>> iter = Iterators.partition(ids, batchSize);
        
        return new UnmodifiableIterator<List<Map<String, Object>>>(){
            public boolean hasNext() {
                return iter.hasNext();
            }
            public List<Map<String, Object>> next() {
                List<ID> idlist = iter.next();
                return query(idlist);
            }};
    }
    
    /**
     * This assumes the processing speed is faster than input speed, or the data will be cumulated in the linkedblockingqueue, and may further lead to OOM
     * 
     * @param executorService need to have at least 2 threads available
     * @param parallelFactor max concurrent queries
     * @return an iterable batches of transformed result
     */
    public Iterator<List<Map<String, Object>>> query(final Iterator<ID> ids, final ExecutorService executorService, final int parallelFactor) {
        
        if(ids.hasNext() == false) {
            return Iterators.emptyIterator();
        }

        //TODO add more doc to explain code. concurrent is difficult
        final AtomicBoolean finished = new AtomicBoolean(false);
        final CountDownLatch started = new CountDownLatch(1);
        final LinkedBlockingQueue<Future<List<Map<String, Object>>>> queue = new LinkedBlockingQueue<Future<List<Map<String,Object>>>>();
        
        executorService.submit(new Runnable() {//it has to in another thread, #ids is stream and not fit in memory
            public void run() {
                final UnmodifiableIterator<List<ID>> iter = Iterators.partition(ids, batchSize);
                final Semaphore permits = new Semaphore(parallelFactor);//restrict the rate of concurrent queries
                while(iter.hasNext()) {
                    try {
                        permits.acquire();
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                    final List<ID> next = iter.next();//about thread-safety : only one thread is calling this, no problem
                    Future<List<Map<String, Object>>> future = executorService.submit(new Callable<List<Map<String, Object>>>() {
                        public List<Map<String, Object>> call() {
                            try {
                                return query(next);
                            } finally {
                                permits.release();
                            }
                        }
                    });
                    try {
                        queue.put(future);//TODO : throttle the input speed
                        started.countDown();
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                }
                finished.set(true);
                started.countDown();//useful if while loop never get executed
            }
        });
        return new UnmodifiableIterator<List<Map<String, Object>>>(){
            
            public boolean hasNext() {
                try {
                    started.await();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                if(finished.get()) {
                    return !queue.isEmpty();
                }
                return true;//TODO simply return true doesn't feel right, from my gut feeling. but for now it achieve best result
            }
            public List<Map<String, Object>> next() {
                if(finished.get() && queue.isEmpty()) {
                    throw new NoSuchElementException();
                }
                try {
                    return queue.take().get();
                } catch (InterruptedException | ExecutionException e) {
                    throw new RuntimeException(e);
                }
            }};
    }

    public DataSource getDataSource() {
        return dataSource;
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public int getBatchSize() {
        return batchSize;
    }

    public void setBatchSize(int batchSize) {
        this.batchSize = batchSize;
    }

    public JdbcTemplate getJdbcTemplate() {
        if(jdbcTemplate == null) {
            jdbcTemplate = new JdbcTemplate(dataSource);
        }
        return jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
    
    public static class MessageQuery extends ParentAndChildQuery<Long>{
        
        private String sqlTemplate = "SELECT ID , TRACKING_ID , SOURCE_SYS_ID , STATUS , CONTENT_TYPE , CREATE_TIMESTAMP , REFERENCE_ID , CHANNEL , CORRELATION_ID , DELIVERY_MODE , DESTINATION , EXPIRATION , JMS_MSG_ID , PRIORITY , REDELIVERED , REPLY_TO , JMS_TIMESTAMP , TYPE FROM MESSAGE WHERE ID IN (:ids)";
        
        public <T> T query(List<Long> ids, Function<List<Map<String, Object>>, T> trans) {
            
            List<Map<String, Object>> all = new ArrayList<Map<String,Object>>();
            
            UnmodifiableIterator<List<Long>> iter = Iterators.partition(ids.iterator(), batchSize);
            while(iter.hasNext()) {
                List<Long> ids2 = iter.next();
                String sql = sqlTemplate.replace(":ids", Joiner.on(",").join(ids2));
                
                List<Map<String, Object>> messages = getJdbcTemplate().query(sql, new RowMapper<Map<String, Object>>(){
                    public Map<String, Object> mapRow(ResultSet rs, int rowNum) throws SQLException {
                        Map<String, Object> map = new HashMap<String, Object>();
                        map.put("id",               rs.getLong("ID"));
                        map.put("tracking_id",      rs.getString("TRACKING_ID"));
                        map.put("source_sys_id",    rs.getString("SOURCE_SYS_ID"));
                        map.put("status",           rs.getString("STATUS"));
                        map.put("content_type",     rs.getString("CONTENT_TYPE"));
                        map.put("create_timestamp", rs.getTimestamp("CREATE_TIMESTAMP"));
                        map.put("reference_id",     rs.getString("REFERENCE_ID"));
                        map.put("channel",          rs.getString("CHANNEL"));
                        map.put("correlation_id",   rs.getString("CORRELATION_ID"));
                        map.put("delivery_mode",    rs.getString("DELIVERY_MODE"));
                        map.put("destination",      rs.getString("DESTINATION"));
                        map.put("expiration",       rs.getString("EXPIRATION"));
                        map.put("jms_msg_id",       rs.getString("JMS_MSG_ID"));
                        map.put("priority",         rs.getString("PRIORITY"));
                        map.put("redelivered",      rs.getString("REDELIVERED"));
                        map.put("reply_to",         rs.getString("REPLY_TO"));
                        map.put("jms_timestamp",    rs.getTimestamp("JMS_TIMESTAMP"));
                        map.put("type",             rs.getString("TYPE"));
                        return map;
                    }});
                
                String sql2 = "SELECT MESSAGE_ID, KEY, VALUE FROM MESSAGE_PROPERTY WHERE MESSAGE_ID IN(:ids)".replace(":ids", Joiner.on(",").join(ids2));
                List<Map<String, Object>> props = getJdbcTemplate().query(sql2, new RowMapper<Map<String, Object>>(){
                    public Map<String, Object> mapRow(ResultSet rs, int rowNum) throws SQLException {
                        Map<String, Object> map = new HashMap<String, Object>();
                        map.put("message_id", rs.getLong("MESSAGE_ID"));
                        map.put("key",        rs.getString("KEY"));
                        map.put("value",      rs.getString("VALUE"));
                        return map;
                    }});
                for(Map<String, Object> m : messages) {
                    for(Map<String, Object> p : props) {
                        if(Objects.equal(p.get("message_id"), m.get("id"))) {
                            m.put((String)p.get("key"), p.get("value"));
                        }
                    }
                }
                all.addAll(messages);
            }
            return trans.apply(all);
        }
    }
    
    public static class TicketQuery extends ParentAndChildQuery<Long>{

        private String sqlTemplate = "SELECT ID, GUID, CREATOR, STATUS, TYPE, DESCRIPTION, CREATEDTIMESTAMP FROM SCB_TICKET WHERE ID IN (:ids)";
        
        public <T> T query(List<Long> ids, Function<List<Map<String, Object>>, T> trans) {
            
            List<Map<String, Object>> all = new ArrayList<Map<String,Object>>();
            
            UnmodifiableIterator<List<Long>> iter = Iterators.partition(ids.iterator(), batchSize);
            while(iter.hasNext()) {
                List<Long> ids2 = iter.next();
                String sql = sqlTemplate.replace(":ids", Joiner.on(",").join(ids2));
                
                List<Map<String, Object>> messages = getJdbcTemplate().query(sql, new RowMapper<Map<String, Object>>(){
                    public Map<String, Object> mapRow(ResultSet rs, int rowNum) throws SQLException {
                        Map<String, Object> map = new HashMap<String, Object>();
                        map.put("id",               rs.getLong("ID"));
                        map.put("guid",             rs.getString("GUID"));
                        map.put("creator",          rs.getString("CREATOR"));
                        map.put("status",           rs.getString("STATUS"));
                        map.put("type",             rs.getString("TYPE"));
                        map.put("description",      rs.getString("DESCRIPTION"));
                        map.put("createdtimestamp", rs.getTimestamp("CREATEDTIMESTAMP"));
                        return map;
                    }});
                
                String sql2 = "SELECT TICKET_ID AS MESSAGE_ID, TAGNAME AS KEY, TAGVALUE AS VALUE FROM SCB_TICKET_TAG WHERE TICKET_ID IN(:ids)".replace(":ids", Joiner.on(",").join(ids2));
                List<Map<String, Object>> props = getJdbcTemplate().query(sql2, new RowMapper<Map<String, Object>>(){
                    public Map<String, Object> mapRow(ResultSet rs, int rowNum) throws SQLException {
                        Map<String, Object> map = new HashMap<String, Object>();
                        map.put("message_id", rs.getLong("MESSAGE_ID"));
                        map.put("key",        rs.getString("KEY"));
                        map.put("value",      rs.getString("VALUE"));
                        return map;
                    }});
                for(Map<String, Object> m : messages) {
                    for(Map<String, Object> p : props) {
                        if(Objects.equal(p.get("message_id"), m.get("id"))) {
                            String key = (String) p.get("key"), value = (String) p.get("value");
                            if(key != null && value != null) {
//                                key = key.contains(" ") ? key.replaceAll(" +", "_") : key;
                                m.put(key, value);
                            }
                        }
                    }
                }
                all.addAll(messages);
            }
            
            return trans.apply(all);
        }
    }
}
