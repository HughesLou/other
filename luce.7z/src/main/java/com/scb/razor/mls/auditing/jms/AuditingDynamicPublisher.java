/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.jms;

import com.scb.sabre.ticketing.configuration.JMSSecurityConfiguration;
import com.scb.sabre.ticketing.jms.JMSConnection;
import com.webmethods.jms.WmJMSFactory;
import com.webmethods.jms.impl.WmTextMessageImpl;
import org.slf4j.LoggerFactory;

import javax.jms.*;
import java.util.Map;

public class AuditingDynamicPublisher {

    private static final org.slf4j.Logger log = LoggerFactory.getLogger(AuditingDynamicPublisher.class);
    private final JMSSecurityConfiguration configuration;
    private MessageProducer messageProducer;
    private Connection connection = null;
    private String  destinationName = null;
    public AuditingDynamicPublisher(JMSSecurityConfiguration configuration) {
        this.configuration = configuration;
    }

    public void createProducer(String destinationName) {
        log.info(String.format("Initialising topic of auditing message publisher that is set to: %s", destinationName));
        this.destinationName = destinationName;
        try {
            connection = getConnection(configuration);
            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            Destination destination= WmJMSFactory.getTopic(destinationName);
            messageProducer = session.createProducer(destination);
            /*
            JMSConnection jmsConnection = new JMSConnection();
            connection = jmsConnection.getTopicConnection(exceptionConfigurationData, sslConfiguration, false);

            Topic topic = WmJMSFactory.getTopic(topicName);
            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            messageProducer = session.createProducer(topic);
            */
            log.info("Auditing message publisher is now live.");
        } catch (Exception e) {
            if(connection!=null){
                try {
                    connection.close();
                } catch (JMSException e1) {
                    e1.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                }
            } else {
                log.error("Failed to create connection to the destination: {}",this.destinationName);
            }
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    public void publishMessage(String messageType, String message, Map<String, String> jmsProperties,com.scb.razor.mls.persistent.model.Message messageObj,String destinationName) {
        try {
            log.info("Publishing message: " + message);
            createProducer(destinationName);
            sendMessage(messageType, message, jmsProperties,messageObj);
            log.info("Publishing message successfully!");
        } catch (JMSException e) {
            throw new RuntimeException("Unable to publish message", e);
        } finally {
            closeConnection();
        }
    }

    private void sendMessage(String messageType, String messageContents,
                             Map<String, String> jmsProperties,com.scb.razor.mls.persistent.model.Message messageObj) throws JMSException {
        WmTextMessageImpl message = new WmTextMessageImpl();
        message.setText(messageContents);
        if (jmsProperties != null && !jmsProperties.isEmpty()) {
            for (Map.Entry<String, String> property : jmsProperties.entrySet()) {
                if(!"JMSXDeliveryCount".equals(property.getKey()))
                    message.setStringProperty(property.getKey(), property.getValue());
            }
            message.setJMSDeliveryMode(messageObj.getDeliveryMode());
            message.setJMSCorrelationID(messageObj.getCorrelationId());
            message.setJMSExpiration(messageObj.getExpiration());
            message.setJMSMessageID(messageObj.getJmsMessageId());
            message.setJMSPriority(messageObj.getPriority());
            message.setJMSRedelivered(messageObj.getRedelivered());
            message.setJMSTimestamp(messageObj.getJmsTimeStamp().getTime());
            message.setJMSType(messageObj.getType());
            message.setStringProperty("trackingId",messageObj.getTrackingId());
//            message.setJMSReplyTo(messageObj.getReplyTo());
//            message.setJMSDestination(messageObj.getDestination());
        }
        messageProducer.send(message);

    }

    private Connection getConnection(final JMSSecurityConfiguration config)
            throws JMSException {
        JMSConnection jmsConnection = getJmsConnection();

        return jmsConnection.getTopicConnection(config, config.getSslConfiguration(), false);
    }

    JMSConnection getJmsConnection() {
        return new JMSConnection();
    }

    private void closeConnection(){
            try {
                if(connection!=null)
                    connection.close();
            } catch (JMSException e1) {
                log.error("Failed to close connection to the destination: {}",this.destinationName);
            }

    }
}
