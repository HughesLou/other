/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.model;

import java.net.URI;

public class ArgumentLink implements java.io.Serializable {

    private static final long serialVersionUID = 419732776570738701L;
    private String name;
    private String description;
    private String href;

    /**
     * the construct, generate the url link for every LoggingEvent
     *
     * @param uriInfo     the client uri
     * @param name        the name of argument
     * @param description the description of argument
     * @param id          the user id
     */
    public ArgumentLink(final URI uriInfo, final String name, final String description, final String id) {
        this.name = name;
        this.description = description;
        this.href = uriInfo.toString() + "Auditing/Argument?id=" + id;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }

    public String getHref() {
        return href;
    }

    public void setHref(final String href) {
        this.href = href;
    }
}
