/*
 * Copyright (c) 2015. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.constant;

/**
 * Description:
 * Author: 1466811
 * Date:   4:38 PM 1/12/15
 */
public class AuditingConstants {

    public static final String RT_MESSAGE_TYPR = "messageType";
    public static final String RT_LE_ID = "leId";
    public static final String RT_IMETA_ID = "imetaId";
    public static final String RT_NACK = "NACK";
    public static final String RT_EXPORT_FILE_NAME = "auditingRT_";
    public static final int RT_EXPORT_NUM = 100;
    public static final int SXSSF_WORKBOOK_FLUSH_NUM = 1000;
}
