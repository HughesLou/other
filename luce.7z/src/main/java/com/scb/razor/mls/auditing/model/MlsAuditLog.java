/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.model;

import com.scb.razor.mls.auditing.builder.MlsAuditLogBuilder;
import com.scb.razor.mls.persistent.utils.PersistentConstants.AuditLogAction;

import java.util.Date;

/**
 * Description:
 * Author: 1466811
 * Date:   12:12 PM 4/9/14
 */
public class MlsAuditLog implements java.io.Serializable {

    private static final long serialVersionUID = -1303019830414553137L;
    private Long id;
    private String detail;
    private Date createdDate;
    private long entityId;
    private String userId;
    private AuditLogAction action;

    public MlsAuditLog() {
    }

    public MlsAuditLog(MlsAuditLogBuilder builder) {
        this.id = builder.getId();
        this.detail = builder.getDetail();
        this.createdDate = builder.getCreatedDate();
        this.entityId = builder.getEntityId();
        this.userId = builder.getUserId();
        this.action = builder.getAction();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public AuditLogAction getAction() {
        return action;
    }

    public void setAction(AuditLogAction action) {
        this.action = action;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public long getEntityId() {
        return entityId;
    }

    public void setEntityId(long entityId) {
        this.entityId = entityId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
