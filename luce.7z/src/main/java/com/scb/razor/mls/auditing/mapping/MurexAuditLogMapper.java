/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.mapping;

import com.scb.razor.mls.auditing.builder.MlsMurexAuditLogBuilder;
import com.scb.razor.mls.auditing.model.MlsMurexAuditLog;
import com.scb.razor.mls.persistent.model.MurexAudit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: 1466811
 * Date:   12:23 PM 4/9/14
 */
@Component
public class MurexAuditLogMapper {

    private static final Logger logger = LoggerFactory.getLogger(MurexAuditLogMapper.class);

    /**
     * map MurexAudit to MlsMurexAuditLogBuilder
     *
     * @param murexAudit the data searched from database
     *
     * @return the MlsMurexAuditLogBuilder which is used to built MlsMurexAuditLog
     */
    public MlsMurexAuditLogBuilder mapToMlsMurexAuditLog(MurexAudit murexAudit) {
        MlsMurexAuditLogBuilder mlsMurexAuditLogBuilder = new MlsMurexAuditLogBuilder();

        mlsMurexAuditLogBuilder.setId(murexAudit.getId());
        mlsMurexAuditLogBuilder.setUserId(murexAudit.getUserId());
        mlsMurexAuditLogBuilder.setUploadFileName(murexAudit.getUploadFileName());
        mlsMurexAuditLogBuilder.setUploadServerType(murexAudit.getUploadServerType());
        mlsMurexAuditLogBuilder.setUploadFileType(murexAudit.getUploadFileType());
        mlsMurexAuditLogBuilder.setCreatedDate(murexAudit.getCreateTimeStamp());
        mlsMurexAuditLogBuilder.setComments(murexAudit.getComments());

        logger.debug("Mapping Murex Audit Log {} successfully!", murexAudit.getId());

        return mlsMurexAuditLogBuilder;
    }

    /**
     * get the list of MlsAuditLog from a list of AuditLog
     *
     * @param murexAudits the list of MurexAudit searched from database
     *
     * @return the list of MlsMurexAuditLog
     */
    public List<MlsMurexAuditLog> mapToMlsMurexAuditLogCollection(List<MurexAudit> murexAudits) {
        List<MlsMurexAuditLog> mlsMurexAuditLogs = new ArrayList<>();

        for (MurexAudit murexAudit : murexAudits) {
            mlsMurexAuditLogs.add(mapToMlsMurexAuditLog(murexAudit).build());
        }

        return mlsMurexAuditLogs;
    }
}
