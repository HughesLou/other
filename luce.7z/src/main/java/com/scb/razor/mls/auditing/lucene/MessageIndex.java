package com.scb.razor.mls.auditing.lucene;

import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.apache.lucene.analysis.core.WhitespaceAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryparser.flexible.standard.StandardQueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.NumericRangeQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Sort;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.SimpleFSDirectory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Component;

import com.google.common.base.Joiner;
import com.google.common.eventbus.Subscribe;
import com.google.common.io.Files;
import com.scb.razor.mls.auditing.WorkingDirectory;

/**
 *  
 * @author 1510954
 */
@Component
public class MessageIndex implements InitializingBean, DisposableBean {
    
    private final static Logger log = LoggerFactory.getLogger(MessageIndex.class);
    
    @Resource
    private WorkingDirectory workingDirectory;
    
    @Resource
    private DataSource dataSource;
    
    @Resource
    private TaskScheduler taskScheduler;
    
    @Resource
    private ExecutorService executorService;
    
    private IndexWriter indexWriter;
    
    private IndexSearcherManager indexSearcherManager = new IndexSearcherManager();
    
    private CountDownLatch indexed;
    
    @Subscribe
    public void onMessageEntityChange(MessageEntityChangedEvent evt) {
        
        if(indexed.getCount() > 0) {
            return; //TODO throw away is not a good option, which cause inconsistent between db and lucene. But queue up those events (when index not ready) may affects performance
        }
        
        Set<Long> ids = evt.getMessageIds();
        
        //TODO it might be a good option to cache those for a while and do a big batch
        
        List<Term> terms = new ArrayList<>();
        for(Long id : ids) {
            terms.add(new Term("id", id.toString()));
        }
        
        //TODO frequency control : events is stream like, but query db/ write index are not.
        try {
            indexWriter.deleteDocuments(terms.toArray(new Term[terms.size()]));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        
        JdbcTemplate jt = new JdbcTemplate(dataSource);
        MessageResultSetExtractor rse = new MessageResultSetExtractor();
        rse.setDataSource(dataSource);
        rse.setExecutorService(executorService);
        rse.setIndexWriter(indexWriter);
        rse.setCommitOnFinish(false);//due to its expected frequency, it would be wise not to commit, leave that job to taskScheduler
        //pay attention : this is not async, if event volume increase, it may become thread blocker, that block eventbus's threads
        jt.query("SELECT ID , TRACKING_ID , SOURCE_SYS_ID , STATUS , CONTENT_TYPE , CREATE_TIMESTAMP , REFERENCE_ID , CHANNEL , CORRELATION_ID , DELIVERY_MODE , DESTINATION , EXPIRATION , JMS_MSG_ID , PRIORITY , REDELIVERED , REPLY_TO , JMS_TIMESTAMP , TYPE FROM MESSAGE WHERE ID IN(" + Joiner.on(",").join(ids) + ")", rse);
        
        log.info("onMessageEntityChange with {} entity changes, {} indexed document update", ids.size(), rse.getCount());
        
        onIndexChanged();
    }
    
    public int count(Query q) {
        IndexSearcher is = indexSearcherManager.acquire();
        try {
            return is.count(q);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            indexSearcherManager.release(is);
        }
    }
    
    public List<Long> searchMessageIds(Query q, int start, int limit, Sort sort) throws IOException {
        
        List<Long> ids = new ArrayList<>();
        
        IndexSearcher indexSearcher = indexSearcherManager.acquire();
        try {
            TopDocs topdocs = null;
            if(sort == null) {
                topdocs = indexSearcher.search(q, start + limit);
            } else {
                topdocs = indexSearcher.search(q, start + limit, sort);
            }
            for(int i = start; i < topdocs.totalHits & i < (start + limit); i++) {
                Document doc = indexSearcher.doc(topdocs.scoreDocs[i].doc);
                ids.add(Long.valueOf(doc.get("id")));
            }
            
            return ids;
        } finally {
            indexSearcherManager.release(indexSearcher);
        }
    }
    
    public List<Long> searchMessageIds(Query q, int start, int limit) throws IOException {
        return searchMessageIds(q, start, limit, null);
    }
    
    public Set<String> search(String q) {
        
        StandardQueryParser p = new StandardQueryParser(new WhitespaceAnalyzer());
        
        IndexSearcher indexSearcher = indexSearcherManager.acquire();
        
        try {
            TopDocs hits = indexSearcher.search(p.parse(q, "text"), 20);
            Set<String> ids = new HashSet<>();
            for(int i = 0; i < hits.scoreDocs.length; i++) {
                ids.add(indexSearcher.doc(hits.scoreDocs[i].doc).get("id"));
            }
            return ids;
        }catch(Exception e){
            throw new RuntimeException("fail to search : " + q, e);
        } finally {
            indexSearcherManager.release(indexSearcher);
        }
    }
    
    private void awaitIndex() {
        try {
            indexed.await();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
    
    private Date last;
    
    private List<String> lastSeenIncrement;
    
    private void crawlIncrementalFromDatabase() throws Exception {
        
        awaitIndex();
        
        MessageResultSetExtractor rse = new MessageResultSetExtractor();
        rse.setDataSource(dataSource);
        rse.setExecutorService(executorService);
        rse.setIndexWriter(indexWriter);
        // it is possible later data has same timestamp as #last
        // so to capture those data, as well not duplicate already indexed
        // set this flag to true to achieve, also the sql changed from "timestamp > ?" to "timestamp >= ?"
        // another potential issue CANNOT be fixed here is that , the timestamp value is generated
        // at application side, not db side. due to network lag, it is possible that insertion order
        // is not the same as timestamp order -- in this case incremental crawl turn to garbage -- let's 
        // be optimistic for now
        rse.setRecordLastSeenIncrement(true);
        rse.setLastSeenIncrement(lastSeenIncrement);
        rse.setRecordAckAndNack(true);
        
        JdbcTemplate jt = new JdbcTemplate(dataSource);
        jt.query("SELECT ID , TRACKING_ID , SOURCE_SYS_ID , STATUS , CONTENT_TYPE , CREATE_TIMESTAMP , REFERENCE_ID , CHANNEL , CORRELATION_ID , DELIVERY_MODE , DESTINATION , EXPIRATION , JMS_MSG_ID , PRIORITY , REDELIVERED , REPLY_TO , JMS_TIMESTAMP , TYPE FROM MESSAGE WHERE CREATE_TIMESTAMP>=?", new Object[]{getLastDate()}, rse);
        if(rse.getCount() > 0) {
            setLastDate(rse.getMax());
            lastSeenIncrement = rse.getLastSeenIncrement();
            log.debug("lastSeenIncrement {}, ack {}, nack {}", lastSeenIncrement == null ? -1 : lastSeenIncrement.size(), rse.getAcks() == null ? -1 : rse.getAcks().size(), rse.getNacks() == null ? -1 : rse.getNacks().size());
            onIndexChanged();
        }
    }
    
    private void setLastDate(Date d) {
        if(d == null) {
            throw new NullPointerException();
        }
        last = d;
        try {
            Files.write(new String(d.getTime() + "").getBytes(), new File(indexFolder, ".last"));
        }catch(Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    private Date getLastDate() {
        if(last != null) {
            return last;
        }
        try {
            last = new Date(Long.parseLong(new String(Files.toByteArray(new File(indexFolder, ".last")))));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return last;
    }
    
    private void houseKeeping() throws Exception {
        
        awaitIndex();
        
        JdbcTemplate jt = new JdbcTemplate(dataSource);
        Timestamp min = jt.queryForObject("SELECT MIN(CREATE_TIMESTAMP) FROM MESSAGE", Timestamp.class);
        if(min == null) {
            log.error("housekeeping error : min timestamp is null");
            return;
        }
        long seconds = min.getTime()/1000L;
        
        log.info("min timestamp from database is {}, will cleanup index with create_timestamp less than {}s", min, seconds);
        indexWriter.deleteDocuments(NumericRangeQuery.newLongRange("create_timestamp", 0L, seconds, true, false));
        
        onIndexChanged();
    }
    
    private File indexFolder;

    @Override
    public void afterPropertiesSet() throws Exception {
        
        indexFolder = workingDirectory.getSubFile("index");
        
        if(indexFolder.exists() == false) {
            indexFolder.mkdirs();
            log.info("create dirs {}", indexFolder.getAbsolutePath());
        }
        final File readyfile = new File(indexFolder, ".ready");
        
        boolean ready = readyfile.exists() ? true : false; 
        
        if(indexWriter == null) {
            FSDirectory dir = SimpleFSDirectory.open(indexFolder.toPath());
            WhitespaceAnalyzer analyzer = new WhitespaceAnalyzer();
            indexWriter = new IndexWriter(dir, new IndexWriterConfig(analyzer));
            log.info("indexwriter created with dir={}, analyzer={}", dir, analyzer);
        }
        log.info("indexWriter is {}", indexWriter);
        
        indexed = new CountDownLatch(ready ? 0 : 1);
        
        if(ready == false) {
            File[] files = indexFolder.listFiles();
            if(files.length > 1) {
                log.info("whole db crawl : clean up index folder {} to do indexAll", indexFolder);
                for(File f : files) {
                    if("write.lock".equals(f.getName()) == false) {//do not delete indexWriter
                        f.delete();
                    }
                }
            }
            log.info("whole db crawl : create task and submit to executor to crawl all messages in database");
            executorService.submit(new Runnable(){
                @Override
                public void run() {
                    MessageResultSetExtractor rse = new MessageResultSetExtractor();
                    rse.setDataSource(dataSource);
                    rse.setExecutorService(executorService);
                    rse.setIndexWriter(indexWriter);
                    rse.setRecordLastSeenIncrement(true);
                    JdbcTemplate jt = new JdbcTemplate(dataSource);
                    String sql = "SELECT ID , TRACKING_ID , SOURCE_SYS_ID , STATUS , CONTENT_TYPE , CREATE_TIMESTAMP , REFERENCE_ID , CHANNEL , CORRELATION_ID , DELIVERY_MODE , DESTINATION , EXPIRATION , JMS_MSG_ID , PRIORITY , REDELIVERED , REPLY_TO , JMS_TIMESTAMP , TYPE FROM MESSAGE";
                    log.info("whole db crawl : sql used to crawl : {}", sql);
                    try {
                        jt.query(sql, rse);
                        log.info("whole db crawl : result {} messages, {} max date", rse.getCount(), rse.getMax());
                        setLastDate(rse.getMax());// a little trick to prevent incremental indexing index this already indexed last seen timestamp
                        lastSeenIncrement = rse.getLastSeenIncrement();
                        Files.touch(readyfile);
                        indexSearcherManager.setIndexSearcher(new IndexSearcher(DirectoryReader.open(new SimpleFSDirectory(indexFolder.toPath()))));
                        indexed.countDown();
                    } catch (Exception e) {
                        log.error("whole db crawl : failed", e);
                    }
                }
            });
        } else {
            indexSearcherManager.setIndexSearcher(new IndexSearcher(DirectoryReader.open(new SimpleFSDirectory(indexFolder.toPath()))));
        }
        
        String crawlCron = "*/30 * * * * *";
        taskScheduler.schedule(new Runnable() {
            @Override
            public void run() {
                if(indexed.getCount() > 0) {
                    log.info("index not ready, will bypass this incremental indexing schedule");
                    return;//TODO find a better way, to bypass current schedule when index is not ready yet
                }
                try {
                    log.debug("check database for incremental indexing");
                    crawlIncrementalFromDatabase();
                } catch (Exception e) {
                    log.error("fail to craw database", e);
                    throw new RuntimeException(e);
                }
            }
        }, new CronTrigger(crawlCron));
        log.info("crawl database (incremental) scheduled as {}", crawlCron);
        
        String houseKeepingCron = "0 0 23 * * *"; // everyday at 23:00, do housekeeping
        taskScheduler.schedule(new Runnable() {
            @Override
            public void run() {
                if(indexed.getCount() > 0) {
                    log.info("index not ready, will bypass this housekeeping schedule");
                    return;//TODO find a better way, to bypass current schedule when index is not ready yet
                }
                try {
                    houseKeeping();
                } catch (Exception e) {
                    log.error("housekeeping exception : " + e.getMessage(), e);
                }
            }
        }, new CronTrigger(houseKeepingCron));
        log.info("housekeeping scheduled as {}", houseKeepingCron);
    }
    
    //update indexSearcher on index changed
    //@Subscribe
    public void onIndexChanged(/*IndexChangedEvent evt*/) {
        IndexSearcher indexSearcher = indexSearcherManager.acquire();
        try {
            //indexSearcher can search 'back in time', so here is the logic to keep it latest 
            DirectoryReader oldReader = (DirectoryReader)indexSearcher.getIndexReader();
            try {
                DirectoryReader r = DirectoryReader.openIfChanged(oldReader, indexWriter);
                if(r != null) {
                    //head up : although the doc say "though, the current implementation never returns null"
                    //it is not true, it do return null if no change
                    //this boost perf under frequent read
                    indexSearcherManager.setIndexSearcher(new IndexSearcher(r));
                }
            }catch(Exception e) {
                throw new RuntimeException(e);
            }
        } finally {
            indexSearcherManager.release(indexSearcher);
        }
    }

    @Override
    public void destroy() throws Exception {
        if(indexWriter != null && indexed != null && indexed.getCount() == 0) {
            log.info("closing indexWriter {}", indexWriter);
            indexWriter.close();//assert commitOnClose=true
        }
    }

    public IndexWriter getIndexWriter() {
        return indexWriter;
    }

    public void setIndexWriter(IndexWriter indexWriter) {
        this.indexWriter = indexWriter;
    }

    public DataSource getDataSource() {
        return dataSource;
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public TaskScheduler getTaskScheduler() {
        return taskScheduler;
    }

    public void setTaskScheduler(TaskScheduler taskScheduler) {
        this.taskScheduler = taskScheduler;
    }

    public ExecutorService getExecutorService() {
        return executorService;
    }

    public void setExecutorService(ExecutorService executorService) {
        this.executorService = executorService;
    }

    public IndexSearcherManager getIndexSearcherManager() {
        return indexSearcherManager;
    }

    public void setIndexSearcherManager(IndexSearcherManager indexSearcherManager) {
        this.indexSearcherManager = indexSearcherManager;
    }
}
