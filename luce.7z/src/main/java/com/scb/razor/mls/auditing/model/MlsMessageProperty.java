/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.model;

/**
 * Description:
 * Author: 1466811
 */
public class MlsMessageProperty implements java.io.Serializable {

    private static final long serialVersionUID = 7071101458916797528L;
    private String key;
    private String value;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
