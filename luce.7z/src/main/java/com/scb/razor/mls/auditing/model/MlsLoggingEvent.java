/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.model;

import com.scb.razor.mls.auditing.builder.MlsLoggingEventBuilder;

import java.util.Date;

/**
 * Description:
 * Author: 1466811
 */
public class MlsLoggingEvent implements java.io.Serializable {

    private static final long serialVersionUID = -2463891795375401399L;
    private long id;
    private String systemId;
    private String tradeRef;
    private Date date;
    private ArgumentLink argumentLink;

    public MlsLoggingEvent() {
    }

    public MlsLoggingEvent(MlsLoggingEventBuilder builder) {
        this.id = builder.getId();
        this.systemId = builder.getSystemId();
        this.tradeRef = builder.getTradeRef();
        this.date = builder.getDate();
        this.argumentLink = builder.getArgumentLink();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getSystemId() {
        return systemId;
    }

    public void setSystemId(String systemId) {
        this.systemId = systemId;
    }

    public String getTradeRef() {
        return tradeRef;
    }

    public void setTradeRef(String tradeRef) {
        this.tradeRef = tradeRef;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public ArgumentLink getArgumentLink() {
        return argumentLink;
    }

    public void setArgumentLink(ArgumentLink argumentLink) {
        this.argumentLink = argumentLink;
    }
}
