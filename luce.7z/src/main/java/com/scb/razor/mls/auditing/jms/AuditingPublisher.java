/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.jms;

import com.scb.sabre.ticketing.configuration.JMSSecurityConfiguration;
import com.scb.sabre.ticketing.jms.JMSConnection;
import com.webmethods.jms.WmJMSFactory;
import com.webmethods.jms.impl.WmTextMessageImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jms.*;
import java.util.Map;

public class AuditingPublisher {

    private static final Logger log = LoggerFactory.getLogger(AuditingPublisher.class);
    private final JMSSecurityConfiguration configuration;
    private final String destinationName;
    private MessageProducer messageProducer;
    public AuditingPublisher(JMSSecurityConfiguration configuration, String destinationName) {
        this.configuration = configuration;
        this.destinationName = destinationName;
    }

    public void init() {
        log.info(String.format("Initialising topic of auditing message publisher that is set to: %s", destinationName));
        Connection connection = null;
        try {
            connection = getConnection(configuration);
            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            Destination destination= WmJMSFactory.getTopic(destinationName);
            messageProducer = session.createProducer(destination);
            /*
            JMSConnection jmsConnection = new JMSConnection();
            connection = jmsConnection.getTopicConnection(exceptionConfigurationData, sslConfiguration, false);

            Topic topic = WmJMSFactory.getTopic(topicName);
            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            messageProducer = session.createProducer(topic);
            */
            log.info("Auditing message publisher is now live.");
        } catch (Exception e) {
            if(connection!=null)
                try {
                    connection.close();
                } catch (JMSException e1) {
                    e1.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                }
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    public void publishMessage(String messageType, String message, Map<String, String> jmsProperties,com.scb.razor.mls.persistent.model.Message messageObj) {
        try {
            log.info("Publishing message: " + message);
            sendMessage(messageType, message, jmsProperties,messageObj);
            log.info("Publishing message successfully!");
        } catch (JMSException e) {
            throw new RuntimeException("Unable to publish message", e);
        }
    }

    private void sendMessage(String messageType, String messageContents,
                             Map<String, String> jmsProperties,com.scb.razor.mls.persistent.model.Message messageObj) throws JMSException {
        WmTextMessageImpl message = new WmTextMessageImpl();
        message.setText(messageContents);
        if (jmsProperties != null && !jmsProperties.isEmpty()) {
            for (Map.Entry<String, String> property : jmsProperties.entrySet()) {
                if(!"JMSXDeliveryCount".equals(property.getKey()))
                    message.setStringProperty(property.getKey(), property.getValue());
            }
            message.setJMSDeliveryMode(messageObj.getDeliveryMode());
            message.setJMSCorrelationID(messageObj.getCorrelationId());
            message.setJMSExpiration(messageObj.getExpiration());
            message.setJMSMessageID(messageObj.getJmsMessageId());
            message.setJMSPriority(messageObj.getPriority());
            message.setJMSRedelivered(messageObj.getRedelivered());
            message.setJMSTimestamp(messageObj.getJmsTimeStamp().getTime());
            message.setJMSType(messageObj.getType());
            message.setStringProperty("trackingId",messageObj.getTrackingId());
//            message.setJMSReplyTo(messageObj.getReplyTo());
//            message.setJMSDestination(messageObj.getDestination());
            String sourceSysIdInLowerCase = messageObj.getSourceSysId().getAlias().toLowerCase();
            message.setStringProperty("ReplayDestination",sourceSysIdInLowerCase+"-replay");
        }
        messageProducer.send(message);
    }

    private Connection getConnection(final JMSSecurityConfiguration config)
            throws JMSException {
        JMSConnection jmsConnection = getJmsConnection();

        return jmsConnection.getTopicConnection(config, config.getSslConfiguration(), false);
    }

    JMSConnection getJmsConnection() {
        return new JMSConnection();
    }
}
