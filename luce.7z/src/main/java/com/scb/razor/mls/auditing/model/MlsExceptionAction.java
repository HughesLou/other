/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.model;

import com.scb.razor.mls.auditing.builder.MlsExceptionActionBuilder;
import com.scb.razor.mls.persistent.utils.PersistentConstants.AuditLogAction;

import java.util.Date;

/**
 * Description:
 * Author: 1466811
 * Date:   11:57 AM 4/15/14
 */
public class MlsExceptionAction implements java.io.Serializable {

    private static final long serialVersionUID = 3241648491571351575L;
    private Long id;
    private AuditLogAction action;
    private String actor;
    private Date createdDate;
    private String comments;
    private String ticketId;

    public MlsExceptionAction() {
    }

    public MlsExceptionAction(MlsExceptionActionBuilder builder) {
        this.id = builder.getId();
        this.action = builder.getAction();
        this.actor = builder.getActor();
        this.createdDate = builder.getCreatedDate();
        this.comments = builder.getComments();
        this.ticketId = builder.getTicketId();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public AuditLogAction getAction() {
        return action;
    }

    public void setAction(AuditLogAction action) {
        this.action = action;
    }

    public String getActor() {
        return actor;
    }

    public void setActor(String actor) {
        this.actor = actor;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getTicketId() {
        return ticketId;
    }

    public void setTicketId(String ticketId) {
        this.ticketId = ticketId;
    }
}
