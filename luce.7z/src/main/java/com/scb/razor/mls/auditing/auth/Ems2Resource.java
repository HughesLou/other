package com.scb.razor.mls.auditing.auth;

import java.io.ByteArrayInputStream;
import java.lang.reflect.Field;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

import javax.ws.rs.core.UriBuilder;

import org.codehaus.jackson.jaxrs.JacksonJsonProvider;
import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.scb.sabre.ticketing.security.Entitlement;
import com.scb.sabre.ticketing.security.EntitlementsResponse;
import com.scb.sabre.ticketing.security.Entity;
import com.scb.sabre.ticketing.security.Role;
import com.scb.sabre.ticketing.security.RolesResponse;
import com.scb.sabre.ticketing.security.User;
import com.scb.sabre.ticketing.security.UsersResponse;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientRequest;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.client.filter.ClientFilter;
import com.sun.jersey.core.header.InBoundHeaders;
import com.sun.jersey.spi.MessageBodyWorkers;

@Component
public class Ems2Resource implements InitializingBean {
    
    private final static Logger log = LoggerFactory.getLogger(Ems2Resource.class);

    @Value("http://${emsHostPort}/")
    private String baseUrl;//http://uklvadsab14.uk.standardchartered.com:16080
    
    private Client client;
    
    private WebResource rootResource;
    
    @Value("${emsCacheTimeoutSeconds}")
    private Integer cacheTimeoutSeconds;
    
    private ClientFilter clientFilter;
    
    public List<Entitlement> getEntitlementsByEntityNameAndLoginId(String entityName, String userLoginId) {
        WebResource r = rootResource.path("entitlements/entity/name").path(entityName).path("user").path(userLoginId);
        EntitlementsResponse resp = r.get(EntitlementsResponse.class);
        return resp.getEntitlements();
    }
    
    public Entity getEntityByName(String entityName) {
        return rootResource.path("entity").path(entityName).get(Entity.class);
    }
    
    public List<Role> getRolesByEntityName(String entityName) {
        Entity entity = getEntityByName(entityName);
        if(entity == null) {
            return null;
        }
        return getRolesByEntityId("" + entity.getId());
    }
    
    public List<Role> getRolesByEntityId(String entityId) {
        RolesResponse resp = rootResource.path("entity").path(entityId).path("roles").get(RolesResponse.class);
        return resp.getRoles();
    }
    
    public List<User> getUsersByRoleId(String roleId) {
        UsersResponse resp = rootResource.path("user/role").path(roleId).get(UsersResponse.class);
        return resp.getUsers();
    }
    
    public List<User> getUsersByEntityName(String entityName) {
        List<Role> roles = getRolesByEntityName(entityName);
        List<User> result = new ArrayList<User>();
        for(Role role : roles) {
            List<User> users = getUsersByRoleId(role.getId() + "");
            result.addAll(users);
        }
        return result;
    }
    
    public void invalidateCache() {
        if(clientFilter == null || !(clientFilter instanceof CacheResponseClientFilter)) {
            log.warn("cache not found");
            return;
        }
        CacheResponseClientFilter cf = (CacheResponseClientFilter) clientFilter;
        cf.getCache().invalidateAll();
    }
    
    @Override
    public void afterPropertiesSet() throws Exception {
        
        if(rootResource == null) {
            if(baseUrl == null) {
                throw new NullPointerException();
            }
            log.info("base url {}", baseUrl);
            if(client == null) {
                if(clientFilter == null) {
                    if(cacheTimeoutSeconds == null || cacheTimeoutSeconds < 0) {
                        cacheTimeoutSeconds = 900;//default 1.5 hrs to timeout
                    }
                    if(cacheTimeoutSeconds == 0) {
                        log.info("cache disabled due to that cacheTimeoutSeconds==0");
                    }
                    final Cache<String, ClientResponse> cache = CacheBuilder.newBuilder()
                            .expireAfterWrite(cacheTimeoutSeconds, TimeUnit.SECONDS)
                            .build();
                    log.info("cache timeout {} seconds (after write)", cacheTimeoutSeconds);
                    CacheResponseClientFilter cf = new CacheResponseClientFilter();
                    cf.setCache(cache);
                    clientFilter = cf;
                }
                log.info("client filter {} ", clientFilter);
                
                ObjectMapper om = new ObjectMapper();
                om.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
                ClientConfig cc = new DefaultClientConfig();
                cc.getSingletons().add(new JacksonJsonProvider(om));//read json response
                client = Client.create(cc);
                client.setFollowRedirects(true);
                //cache may cause inconsistency
                //due to request time difference of cached entries, cache doesn't have a view at time
                //for example, Role read at time t1, but Entitlement read at t2. Role may change during period
                //It works only for read-only data, or data have infrequent change (and cache must be invalidated if change occur)
                client.addFilter(clientFilter);
            }
            log.info("jersey client {}", client);
            URI uri = UriBuilder.fromUri(baseUrl).path("/ems2/rest").build();
            rootResource = client.resource(uri);
        }
        log.info("root resource {}", rootResource);
    }

    public String getBaseUrl() {
        return baseUrl;
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public WebResource getRootResource() {
        return rootResource;
    }

    public void setRootResource(WebResource rootResource) {
        this.rootResource = rootResource;
    }

    public Integer getCacheTimeoutSeconds() {
        return cacheTimeoutSeconds;
    }

    public void setCacheTimeoutSeconds(Integer cacheTimeoutSeconds) {
        this.cacheTimeoutSeconds = cacheTimeoutSeconds;
    }

    public ClientFilter getClientFilter() {
        return clientFilter;
    }

    public void setClientFilter(ClientFilter clientFilter) {
        this.clientFilter = clientFilter;
    }
}

class CacheResponseClientFilter extends ClientFilter {
    
    private final static Logger log = LoggerFactory.getLogger(CacheResponseClientFilter.class);
    
    private Cache<String, ClientResponse> cache;
    
    private static Field workersField, bufField;
    
    static {
        try {
            workersField = ClientResponse.class.getDeclaredField("workers");
            bufField = ByteArrayInputStream.class.getDeclaredField("buf");
            workersField.setAccessible(true);
            bufField.setAccessible(true);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new RuntimeException(e);
        }
    }
    
    private Map<String, Semaphore> entryPoint = new HashMap<>();
    
    private Semaphore all = new Semaphore(1);

    public ClientResponse handle(ClientRequest cr) throws ClientHandlerException {
        String key = cr.getMethod() + cr.getURI();
        ClientResponse cachedResp = cache.getIfPresent(key);
        if(cachedResp != null) {
            return cloneResponse(cachedResp);//return fresh copy for every request
        }
        Semaphore permit = null;
        try {
            all.acquire();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        try {
            permit = entryPoint.get(key);
            if(permit == null) {
                permit = new Semaphore(1);
                entryPoint.put(key, permit);
            }
        } finally {
            all.release();
        }
        try {
            permit.acquire();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        try {
            cachedResp = cache.getIfPresent(key);
            if(cachedResp != null) {
                return cloneResponse(cachedResp);//return fresh copy for every request
            }
            log.info("request : {} {} ", cr.getMethod(), cr.getURI());
            ClientResponse resp = getNext().handle(cr);
            resp.bufferEntity();//turn it into ByteArrayInputStream
            log.info("response : {}", resp.getEntity(String.class));
            if(resp.getStatus() < 300)
                cache.put(key, resp);//cache only when it is a normal response
            return cloneResponse(resp);
        } finally {
            permit.release();
        }
    }
    
    private ClientResponse cloneResponse(ClientResponse cachedResp) {
        MessageBodyWorkers workers;
        byte[] buf;
        try {
            workers = (MessageBodyWorkers)workersField.get(cachedResp);
            buf = (byte[])bufField.get(cachedResp.getEntityInputStream());
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
        ClientResponse resp = new ClientResponse(cachedResp.getStatus(), (InBoundHeaders)cachedResp.getHeaders(), new ByteArrayInputStream(buf), workers);
        return resp;//return fresh copy for every request
    }
    
    public Cache<String, ClientResponse> getCache() {
        return cache;
    }

    public void setCache(Cache<String, ClientResponse> cache) {
        this.cache = cache;
    }
}
