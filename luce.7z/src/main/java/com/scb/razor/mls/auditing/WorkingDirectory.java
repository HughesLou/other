package com.scb.razor.mls.auditing;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

public class WorkingDirectory {
    
    private File workdir;
    
    public WorkingDirectory(){}
    
    public WorkingDirectory(File workdir) {
        this.workdir = workdir;
    }

    public File getAsFile() {
        return workdir;
    }

    public Path getAsPath() {
        return workdir.toPath();
    }
    
    public File getSubFile(String name) {
        return new File(workdir, name);
    }
    
    public Path getSubPath(String name) {
        return getSubFile(name).toPath();
    }
    
    public File getCacheFolder() {
        return new File(workdir, "cache");
    }
    
    public void writeStringToFile(String s, String relativePath) throws IOException {
        Files.copy(new ByteArrayInputStream(s.getBytes()), new File(workdir, relativePath).toPath(), StandardCopyOption.REPLACE_EXISTING);
    }
}
