/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.service.impl;

import com.scb.razor.mls.auditing.mapping.*;
import com.scb.razor.mls.auditing.model.*;
import com.scb.razor.mls.auditing.service.AuditingService;
import com.scb.razor.mls.common.service.CacheService;
import com.scb.razor.mls.common.constants.MLS;
import com.scb.razor.mls.persistent.dao.*;
import com.scb.razor.mls.persistent.model.*;
import com.scb.razor.mls.persistent.search.AuditingSearchCriteria;
import com.scb.razor.mls.persistent.utils.PersistentConstants.AuditLogAction;
import com.scb.sabre.ticketing.security.IEntitlementService;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.annotation.PostConstruct;

import static com.scb.razor.mls.persistent.utils.PersistentConstants.AUTHORIZED_ITEM_S;
import static com.scb.razor.mls.persistent.utils.PersistentConstants.KEY;

@Service
public class AuditingServiceImpl implements AuditingService {

    @Autowired
    private MessageDao messageDaoImpl = null;
    @Autowired
    private LoggingEventDao loggingEventDaoImpl = null;
    @Autowired
    private StaticMappingAuditDao staticMappingAuditDaoImpl = null;
    @Autowired
    private ExceptionActionDao exceptionActionDaoImpl = null;
    @Autowired
    private MurexAuditDao murexAuditDaoImpl = null;
    @Autowired
    private IEntitlementService auditingEntitlementsService = null;
    @Autowired
    private MessageMapper messageMapper = null;
    @Autowired
    private LoggingEventMapper loggingEventMapper = null;
    @Autowired
    private AuditLogMapper auditLogMapper = null;
    @Autowired
    private ExceptionActionMapper exceptionActionMapper = null;
    @Autowired
    private CacheService cacheServiceImpl = null;
    @Autowired
    private MurexAuditLogMapper murexAuditLogMapper = null;
    @Value("${message.authorizedField:}")
    private String authorizedField = null;

    @Autowired
    private SessionFactory sessionFactory;
    
    public List<MlsMessage> listMessages(List<Long> ids, String userId, URI uri) {
        if(ids == null || ids.isEmpty()) {
            return new ArrayList<>();
        }
        HibernateTemplate ht = new HibernateTemplate(sessionFactory);
        @SuppressWarnings("unchecked")
        List<Message> messages = ht.findByNamedParam("from Message where id in (:ids)", "ids", ids);
        return messageMapper.mapToMlsMessageCollection(messages, uri, userId);
    }
    
    @PostConstruct
    public void init() {
        cacheServiceImpl.initCache();
    }

    /**
     * get the list of mlsMessages
     *
     * @param searchCriteria the searching criteria
     * @param userId         the user id
     * @param uri            the client uri
     *
     * @return the list of mlsMessages
     */
    @Override
    @Transactional(readOnly = true)
    public List<MlsMessage> listMessages(AuditingSearchCriteria searchCriteria, String userId, URI uri) {
        List<String> authorizedInfo = new ArrayList<>(auditingEntitlementsService.getEntitlements(userId));
        if (null == authorizedInfo || authorizedInfo.isEmpty())
            return new ArrayList<>();
        else {
            searchCriteria.setAuthorizedInfo(authorizedInfo);
            List<Message> messages = messageDaoImpl.listMessages(searchCriteria);
            return messageMapper.mapToMlsMessageCollection(messages, uri, userId);
        }
    }

    /**
     * get the mlsMessage by id
     *
     * @param id tracking id
     *
     * @return the mlsMessage by id
     */
    @Transactional(readOnly = true)
    public MlsMessage getMessageById(String id) {
        AuditingSearchCriteria searchCriteria = new AuditingSearchCriteria();
        searchCriteria.setId(id);
        searchCriteria.setMaxResults(20);
        List<Message> messages = messageDaoImpl.listMessages(searchCriteria);
        if (null == messages || 0 == messages.size()) {
            return null;
        } else {
            return messageMapper.mapToMlsMessage(messages.get(0), null, null).build();
        }
    }

    @Transactional(readOnly = true)
    public Message getMessageByIdentity(long id) {
        Message message = messageDaoImpl.findById(id);
        message.getMessageProperties();
        return message;
    }

    @Override
    @Transactional(readOnly = true)
    public Message getNackOriginalMessage(String trackingId,String sourceSysId) {
        Message message = messageDaoImpl.getNackOriginalMessage(trackingId,sourceSysId);
        message.getMessageProperties();
        return message;
    }

    /**
     * get the amount of searched mlsMessages
     *
     * @param searchCriteria the searching criteria
     * @param userId         the user id
     *
     * @return the amount of available mlsMessages
     */
    @Override
    @Transactional(readOnly = true)
    public Long getMessagesAmount(AuditingSearchCriteria searchCriteria, String userId) {
        List<String> authorizedInfo = new ArrayList<>(auditingEntitlementsService.getEntitlements(userId));
        if (null == authorizedInfo || authorizedInfo.isEmpty())
            return 0L;
        else
            return Long.valueOf(messageDaoImpl.getMessageAmount(searchCriteria).longValue());
    }

    /**
     * get the all available SourceSysId
     *
     * @param userId the user id
     *
     * @return the list of available SourceSysId
     */
    @Override
    @Transactional(readOnly = true)
    public Set<String> getAvailableSourceSysIds(String userId) {
        if (authorizedField.equalsIgnoreCase(AUTHORIZED_ITEM_S)) {
            return auditingEntitlementsService.getEntitlements(userId);
        } else {
            return new TreeSet<>(MLS.Interface.names());
        }
    }

    /**
     * get the all available Status
     *
     * @return the list of available Status
     */
    @Override
    public Set<String> getAvailableStatuses() {
        TreeSet<String> statuses = new TreeSet<>();
        for (Message.Status status : Message.Status.values()) {
            statuses.add(status.toString());
        }
        return statuses;
    }

    @Override
    public Set<String> getAvailableChannels() {
        TreeSet<String> channels = new TreeSet<>();
        for (Message.Channel channel : Message.Channel.values()) {
            channels.add(channel.toString());
        }
        return channels;
    }

    /**
     * get the all available Key
     *
     * @return the list of available Key
     */
    @Override
    public Set<String> getAvailableKeys() {
        return cacheServiceImpl.get(KEY);
    }

    /**
     * get the available actions from Audit Log
     *
     * @return the ordered set of actions
     */
    @Override
    @Transactional(readOnly = true)
    public List<String> getAvailableActions() {
        List<String> availableActions = new ArrayList<>();
        for (AuditLogAction auditLogAction : staticMappingAuditDaoImpl.getActions()) {
            availableActions.add(auditLogAction.toString());
        }
        return availableActions;
    }

    /**
     * get actions from Exception Action
     *
     * @return the ordered set of actions
     */
    @Override
    @Transactional(readOnly = true)
    public List<String> getExceptionActions() {
        List<String> availableActions = new ArrayList<>();
        for (AuditLogAction auditLogAction : exceptionActionDaoImpl.getActions()) {
            availableActions.add(auditLogAction.toString());
        }
        return availableActions;
    }

    /**
     * get the list of mlsLoggingEvents
     *
     * @param searchCriteria the searching criteria
     * @param uri            the client uri
     *
     * @return the list of mlsLoggingEvents
     */
    @Override
    @Transactional(readOnly = true)
    public List<MlsLoggingEvent> listLoggingEvents(AuditingSearchCriteria searchCriteria, URI uri) {
        List<LoggingEvent> loggingEvents = loggingEventDaoImpl.listLoggingEvents(searchCriteria);
        return loggingEventMapper.mapToMlsLoggingEventCollection(loggingEvents, uri);
    }

    /**
     * get the amount of searched mlsLoggingEvents
     *
     * @param searchCriteria the searching criteria
     *
     * @return the amount of available mlsLoggingEvents
     */
    @Override
    @Transactional(readOnly = true)
    public Long getLoggingEventsAmount(AuditingSearchCriteria searchCriteria) {
        return loggingEventDaoImpl.getLoggingEventsAmount(searchCriteria);
    }

    /**
     * get the list of MlsAuditLog
     *
     * @param searchCriteria the searching criteria
     *
     * @return the list of MlsAuditLog
     */
    @Override
    @Transactional(readOnly = true)
    public List<MlsAuditLog> listAuditLogs(AuditingSearchCriteria searchCriteria) {
        List<StaticMappingAudit> auditLogs = staticMappingAuditDaoImpl.listAuditLog(searchCriteria);
        return auditLogMapper.mapToMlsAuditLogCollection(auditLogs);
    }

    /**
     * get the amount of searched mlsAuditLogs
     *
     * @param searchCriteria the searching criteria
     *
     * @return the amount of available mlsAuditLogs
     */
    @Override
    @Transactional(readOnly = true)
    public Long getAuditLogsAmount(AuditingSearchCriteria searchCriteria) {
        return staticMappingAuditDaoImpl.getAuditLogAmount(searchCriteria);
    }

    /**
     * get the list of MlsExceptionAction
     *
     * @param searchCriteria the searching criteria
     *
     * @return the list of MlsExceptionAction
     */
    @Override
    @Transactional(readOnly = true)
    public List<MlsExceptionAction> listExceptionActions(AuditingSearchCriteria searchCriteria) {
        List<ExceptionAction> exceptionActions = exceptionActionDaoImpl.listExceptionAction(searchCriteria);
        return exceptionActionMapper.mapToMlsExceptionActionCollection(exceptionActions);
    }

    /**
     * get the amount of searched MlsExceptionAction
     *
     * @param searchCriteria the searching criteria
     *
     * @return the amount of available MlsExceptionAction
     */
    @Override
    @Transactional(readOnly = true)
    public Long getExceptionActionsAmount(AuditingSearchCriteria searchCriteria) {
        return exceptionActionDaoImpl.getExceptionActionAmount(searchCriteria);
    }

    @Override
    @Transactional(readOnly = true)
    public Long getMurexAuditAmount(AuditingSearchCriteria searchCriteria) {
        return murexAuditDaoImpl.getMurexAuditAmount(searchCriteria);
    }

    @Override
    @Transactional(readOnly = true)
    public List<MlsMurexAuditLog> listMurexAudit(AuditingSearchCriteria searchCriteria) {
        List<MurexAudit> murexAudits = murexAuditDaoImpl.listMurexAuditLog(searchCriteria);
        return murexAuditLogMapper.mapToMlsMurexAuditLogCollection(murexAudits);
    }
}
