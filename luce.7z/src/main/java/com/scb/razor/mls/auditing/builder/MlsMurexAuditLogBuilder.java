/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.builder;

import com.scb.razor.mls.auditing.model.MlsMurexAuditLog;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * Description:
 * Author: 1466811
 * Date:   12:14 PM 4/9/14
 */
@Component
public class MlsMurexAuditLogBuilder {

    private Long id;
    private String userId;
    private String uploadFileName;
    private String uploadServerType;
    private String uploadFileType;
    private Date createdDate;
    private String comments;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUploadFileName() {
        return uploadFileName;
    }

    public void setUploadFileName(String uploadFileName) {
        this.uploadFileName = uploadFileName;
    }

    public String getUploadServerType() {
        return uploadServerType;
    }

    public void setUploadServerType(String uploadServerType) {
        this.uploadServerType = uploadServerType;
    }

    public String getUploadFileType() {
        return uploadFileType;
    }

    public void setUploadFileType(String uploadFileType) {
        this.uploadFileType = uploadFileType;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public MlsMurexAuditLog build() {
        return new MlsMurexAuditLog(this);
    }
}
