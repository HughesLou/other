/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.mapping;

import com.scb.razor.mls.auditing.builder.MlsMessageBuilder;
import com.scb.razor.mls.auditing.model.Action;
import com.scb.razor.mls.auditing.model.ContentLink;
import com.scb.razor.mls.auditing.model.MlsMessage;
import com.scb.razor.mls.auditing.model.MlsMessageProperty;
import com.scb.razor.mls.persistent.model.Message;
import com.scb.razor.mls.persistent.model.MessageProperty;
import com.scb.sabre.ticketing.security.Entitlement;
import com.scb.sabre.ticketing.security.EntitlementsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.zip.GZIPInputStream;

import static com.scb.razor.mls.auditing.constant.AuditingConstants.RT_MESSAGE_TYPR;
import static com.scb.razor.mls.auditing.constant.AuditingConstants.RT_NACK;

/**
 * Description:
 * Author: 1466811
 */
@Component
public class MessageMapper {

    private static final Logger logger = LoggerFactory.getLogger(MessageMapper.class);
    private final static String ACTION_VIEW = "View";
    @Resource
    private EntitlementsService auditingEntitlementsService = null;

    public EntitlementsService getAuditingEntitlementsService() {
        return auditingEntitlementsService;
    }
	
    /**
     * map message to MlsMessageBuilder
     *
     * @param message   the data searched from database
     * @param uriPrefix the client uri
     *
     * @return the MlsMessageBuilder which is used to built MlsMessage
     */
    public MlsMessageBuilder mapToMlsMessage(Message message, URI uriPrefix,String userId) {
        MlsMessageBuilder mlsMessageBuilder = new MlsMessageBuilder();
        String description = "";
        List<MlsMessageProperty> mlsMessageProperties = mapProperties(new ArrayList<>(message.getMessageProperties()));
        for (MlsMessageProperty property : mlsMessageProperties) {
           if(property.getKey().equals(RT_MESSAGE_TYPR)) {
               if(property.getValue().equals(RT_NACK)) {
                   if(Message.Status.RECEIVED.equals(message.getStatus())){
                       try {
                           JAXBContext jaxbContext = JAXBContext.newInstance(AuditingRTContent.class);
                           Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
                           Message.ContentType contentType = message.getContentType();
                           byte[] messageContent = message.getContent();
                           AuditingRTContent content = null;
                           if(contentType!=null && (Message.ContentType.COMPRESSED_BINARY==contentType || Message.ContentType.COMPRESSED_TEXT==message.getContentType())){
                               content = (AuditingRTContent) jaxbUnmarshaller.unmarshal(new GZIPInputStream(new ByteArrayInputStream(messageContent)));
                           }else{
                               content = (AuditingRTContent) jaxbUnmarshaller.unmarshal(new ByteArrayInputStream(messageContent));
                           }
                           description = content.getResponsePayload().getNack().getDescription();
                       } catch (JAXBException e) {
                           logger.error("Error happened during extracting description from NACK message",e);
                       } catch (IOException e) {
                           logger.error("Decompress Error happened during extracting description from compressed NACK message",e);
                       }
                       mlsMessageBuilder.setDescription(description);
                   }
               }
           }
        }

        mlsMessageBuilder.setId(message.getId());
        mlsMessageBuilder.setTrackingId(message.getTrackingId());
        if (null != message.getSourceSysId())
            mlsMessageBuilder.setSourceSysId(message.getSourceSysId().name());
        mlsMessageBuilder.setStatus(message.getStatus());
        mlsMessageBuilder.setContentType(message.getContentType());
        mlsMessageBuilder.setCreateTimeStamp(message.getCreateTimeStamp());
        mlsMessageBuilder.setCorrelationId(message.getCorrelationId());
        mlsMessageBuilder.setDeliveryMode(message.getDeliveryMode());
        mlsMessageBuilder.setDestination(message.getDestination());
        mlsMessageBuilder.setExpiration(message.getExpiration());
        mlsMessageBuilder.setMessageId(message.getJmsMessageId());
        mlsMessageBuilder.setPriority(message.getPriority());
        mlsMessageBuilder.setRedelivered(message.getRedelivered());
        mlsMessageBuilder.setReplyTo(message.getReplyTo());
        mlsMessageBuilder.setTimeStamp(message.getJmsTimeStamp());
        mlsMessageBuilder.setType(message.getType());
        mlsMessageBuilder.setReferenceId(message.getReferenceId());
        mlsMessageBuilder.setChannel(message.getChannel() == null ? null : message.getChannel().toString());
        if(uriPrefix != null) {
            ContentLink contentLink = new ContentLink(uriPrefix, message.getContentType()==null?null: message.getContentType().getValue(),
                    "Message content", "Message content", message.getId().toString());
            mlsMessageBuilder.setContentLink(contentLink);
        }

        mlsMessageBuilder.setMessageProperties(mlsMessageProperties);
        if(uriPrefix != null) {
            if(userId!=null && !userId.isEmpty()){
                List<Entitlement> entitlements = auditingEntitlementsService.getEntitlementsFor(userId);
                Set<Action> availableActions = new TreeSet<>();
                for (Entitlement entitlement : entitlements) {
                        String subject = entitlement.getSubject().getName();
                        if(!subject.isEmpty() && subject.equalsIgnoreCase(message.getSourceSysId().name())) {
                            String actionName = entitlement.getAction().getName();
                            if (!actionName.isEmpty() && !actionName.equalsIgnoreCase(ACTION_VIEW)){
                                Action action = new Action(uriPrefix, String.valueOf(message.getId()), actionName,
                                        actionName.toUpperCase());
                                availableActions.add(action);
                            }
                        }
                }
                mlsMessageBuilder.setAvailableActions(availableActions);
            }
        }

        logger.debug("Mapping message {} successfully!", message.getId());

        return mlsMessageBuilder;
    }

    /**
     * get the list of MlsMessage from a list of Message
     *
     * @param messages the list of Message searched from database
     * @param uri      the client uri
     *
     * @return the list of MlsMessage
     */
    public List<MlsMessage>     mapToMlsMessageCollection(List<Message> messages, URI uri, String userId) {
        List<MlsMessage> mlsMessages = new ArrayList<>();

        for (Message message : messages) {
            mlsMessages.add(mapToMlsMessage(message, uri,userId).build());
        }

        return mlsMessages;
    }

    /**
     * get the list of MlsMessageProperty from MessageProperty
     *
     * @param messageProperties the properties of message
     *
     * @return a list of MlsMessageProperty
     */
    private List<MlsMessageProperty> mapProperties(List<MessageProperty> messageProperties) {
        List<MlsMessageProperty> mlsMessageProperties = new ArrayList<>();
        for (MessageProperty messageProperty : messageProperties) {
            MlsMessageProperty mlsMessageProperty = new MlsMessageProperty();
            mlsMessageProperty.setKey(messageProperty.getKey());
            mlsMessageProperty.setValue(messageProperty.getValue());
            mlsMessageProperties.add(mlsMessageProperty);
        }
        return mlsMessageProperties;
    }
}
