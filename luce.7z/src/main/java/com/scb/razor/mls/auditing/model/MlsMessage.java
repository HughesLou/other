/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.model;

import com.scb.razor.mls.auditing.builder.MlsMessageBuilder;
import com.scb.razor.mls.persistent.model.Message;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 * Description:
 * Author: 1466811
 */
public class MlsMessage implements java.io.Serializable {

    private static final long serialVersionUID = -8889713596823357728L;
    private long id;
    private String trackingId;
    private String sourceSysId;
    private String description;
    private Message.Status status;
    private Message.ContentType contentType;
    private Date createTimeStamp;
    private ContentLink contentLink;
    private String correlationId;
    private Integer deliveryMode;
    private String destination;
    private Long expiration;
    private String messageId;
    private Integer priority;
    private Boolean redelivered;
    private String replyTo;
    private Date timeStamp;
    private String type;
    private String referenceId;
    private String channel;
    private List<MlsMessageProperty> properties = new ArrayList<MlsMessageProperty>();
    private Set<Action> actions;	

    public MlsMessage() {
    }

    public MlsMessage(MlsMessageBuilder builder) {
        this.id = builder.getId();
        this.trackingId = builder.getTrackingId();
        this.sourceSysId = builder.getSourceSysId();
        this.description = builder.getDescription();
        this.status = builder.getStatus();
        this.contentType = builder.getContentType();
        this.createTimeStamp = builder.getCreateTimeStamp();
        this.contentLink = builder.getContentLink();
        this.properties = builder.getMessageProperties();
        this.actions = builder.getAvailableActions();
        this.correlationId = builder.getCorrelationId();
        this.deliveryMode = builder.getDeliveryMode();
        this.destination = builder.getDestination();
        this.expiration = builder.getExpiration();
        this.messageId = builder.getMessageId();
        this.priority = builder.getPriority();
        this.redelivered = builder.isRedelivered();
        this.replyTo = builder.getReplyTo();
        this.timeStamp = builder.getTimeStamp();
        this.type = builder.getType();
        this.referenceId = builder.getReferenceId();
        this.channel = builder.getChannel();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTrackingId() {
        return trackingId;
    }

    public void setTrackingId(String trackingId) {
        this.trackingId = trackingId;
    }

    public String getSourceSysId() {
        return sourceSysId;
    }

    public void setSourceSysId(String sourceSysId) {
        this.sourceSysId = sourceSysId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Message.Status getStatus() {
        return status;
    }

    public void setStatus(Message.Status status) {
        this.status = status;
    }

    public ContentLink getContentLink() {
        return contentLink;
    }

    public void setContentLink(ContentLink contentLink) {
        this.contentLink = contentLink;
    }

    public List<MlsMessageProperty> getProperties() {
        return properties;
    }

    public void setProperties(List<MlsMessageProperty> properties) {
        this.properties = properties;
    }

    public Message.ContentType getContentType() {
        return contentType;
    }

    public void setContentType(Message.ContentType contentType) {
        this.contentType = contentType;
    }

    public Date getCreateTimeStamp() {
        return createTimeStamp;
    }

    public void setCreateTimeStamp(Date createTimeStamp) {
        this.createTimeStamp = createTimeStamp;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public Integer getDeliveryMode() {
        return deliveryMode;
    }

    public void setDeliveryMode(Integer deliveryMode) {
        this.deliveryMode = deliveryMode;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public Long getExpiration() {
        return expiration;
    }

    public void setExpiration(Long expiration) {
        this.expiration = expiration;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    public Boolean isRedelivered() {
        return redelivered;
    }

    public void setRedelivered(Boolean redelivered) {
        this.redelivered = redelivered;
    }

    public String getReplyTo() {
        return replyTo;
    }

    public void setReplyTo(String replyTo) {
        this.replyTo = replyTo;
    }

    public Date getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(Date timeStamp) {
        this.timeStamp = timeStamp;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(String referenceId) {
        this.referenceId = referenceId;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }
}
