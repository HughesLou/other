package com.scb.razor.mls.auditing.rest

import javax.ws.rs.core.MultivaluedMap;

import org.junit.Ignore;

import com.sun.jersey.api.client.Client
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.core.DefaultResourceConfig
import com.sun.jersey.api.container.httpserver.HttpServerFactory
import com.sun.jersey.core.util.MultivaluedMapImpl

import spock.lang.Specification;


class ActionPerformingAgentWebServiceTest extends Specification  {
    
    def restfulSrv
    def agentUrl
    def targetSrv
    
    def setup() {
        restfulSrv = HttpServerFactory.create("http://localhost:0/", new DefaultResourceConfig(ActionPerformingAgentWebService.class))
        restfulSrv.start()
        agentUrl = "http://localhost:${restfulSrv.address.port}/agent/actions"
        targetSrv = com.sun.net.httpserver.HttpServer.create(new InetSocketAddress(0), 0)
        targetSrv.start()
        targetSrv.createContext("/", {ex ->
            def uri = ex.getRequestURI()
            println(uri.getPath())
            def resp = ""
            switch(uri.getPath()) {
                case "/test" :
                    resp = "hello query : ${uri.query}"
                    break
                default :
                    resp = "default"
                    break
                
            }
            ex.getResponseHeaders().add("Content-Type", "application/json");
            ex.sendResponseHeaders(200, resp.getBytes().length)
            ex.getResponseBody().write(resp.getBytes())
            ex.getResponseBody().close()
        })
    }
    
    def cleanup() {
        restfulSrv.stop(1)
        targetSrv.stop(1)
    }
    def "test proxy function"() {
        given :
            def r = new Client().resource(agentUrl)
        
        when :
            def resp1 = r.queryParams(toQueryParams(["__target": agentUrl, "__action": "replay", "__id": "123", "__xtype": "murex"]))
                         .post(ClientResponse.class)
            def resp2 = r.queryParams(toQueryParams([:]))
                         .post(ClientResponse.class)
        
        then :
            resp1.status == 400 //called itself            resp2.status == 400 //missing mandatory param    }
    
    def "test query parameter not starts with __ will be passed to target"() {
        def r = new Client().resource(agentUrl);
        def targetUrl = "http://localhost:${targetSrv.address.port}/test"
        
        when :
            def resp1 = r.queryParams(toQueryParams(["__target": agentUrl, "__action": "replay", "__id": "123", "__xtype": "murex"]))
                         .post(ClientResponse.class)
            def resp2 = r.queryParams(toQueryParams([:]))
                         .post(ClientResponse.class)
            def resp3 = r.queryParams(toQueryParams(["__target": targetUrl, "__action": "replay", "__id": "123", "__xtype": "murex", q: "random123"]))
                         .post(ClientResponse.class)
        
        then :
            resp1.status == 400 //called itself
            resp2.status == 400 //missing mandatory param
            resp3.status == 200
            resp3.getEntity(String.class) == "hello query : q=random123"
        
    }
    
    @Ignore
    def "test liveExceptionStore's exception won't affect response"() {
        
    }
    
    def toQueryParams(map) {
        MultivaluedMap<String, String> params = new MultivaluedMapImpl()
        map.each { k,v -> params.putSingle(k, v)}
        return params
    }
}
