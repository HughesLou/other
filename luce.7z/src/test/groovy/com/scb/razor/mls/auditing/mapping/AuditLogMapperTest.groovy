/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.mapping

import com.scb.razor.mls.persistent.model.StaticMappingAudit
import spock.lang.Shared
import spock.lang.Specification

import static com.scb.razor.mls.persistent.utils.PersistentConstants.AuditLogAction

/**
 * Description:
 * Author: 1466811
 * Date:   4:31 PM 5/14/14
 */
class AuditLogMapperTest extends Specification {
    @Shared auditLogMapper;
    @Shared auditLog;
    @Shared id;

    def setupSpec() {
        auditLogMapper = new AuditLogMapper()

        id = new Long(1000L);
        auditLog = new StaticMappingAudit(id);
        auditLog.setAction(AuditLogAction.create);
        auditLog.setDetail("TEST")
        auditLog.setUserId("1466811");
        auditLog.setCreatedDate(Calendar.getInstance().getTime());
        auditLog.setEntityId(1000L);
    }

    /**
     * Test method for mapToMlsAuditLog()
     */
    def "Map an auditLog to MlsAuditLogBuilder"() {
        given: "accept the auditLog"
        def mlsAuditLogBuilder = auditLogMapper.mapToMlsAuditLog(auditLog);

        expect: "the MlsExceptionActionBuilder is not null"
        mlsAuditLogBuilder != null;
    }

    /**
     * Test method for mapToMlsExceptionActionCollection()
     */
    def "Map an auditLog list to MlsAuditLog list"() {
        given: "accept the auditLog list"
        def auditLogs = new ArrayList<StaticMappingAudit>();
        auditLogs.add((StaticMappingAudit) auditLog);

        when:
        def mlsAuditLogs = auditLogMapper.mapToMlsAuditLogCollection(auditLogs);

        then: "the size is 1"
        mlsAuditLogs.size() == 1;
    }
}
