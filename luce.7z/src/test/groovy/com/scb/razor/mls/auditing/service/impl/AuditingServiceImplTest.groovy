/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.service.impl

import com.scb.razor.mls.auditing.mapping.AuditLogMapper
import com.scb.razor.mls.auditing.mapping.ExceptionActionMapper
import com.scb.razor.mls.auditing.mapping.LoggingEventMapper
import com.scb.razor.mls.auditing.mapping.MessageMapper
import com.scb.razor.mls.auditing.model.MlsAuditLog
import com.scb.razor.mls.auditing.model.MlsExceptionAction
import com.scb.razor.mls.auditing.model.MlsLoggingEvent
import com.scb.razor.mls.auditing.model.MlsMessage
import com.scb.razor.mls.common.constants.MLS
import com.scb.razor.mls.persistent.dao.impl.*
import com.scb.razor.mls.persistent.model.ExceptionAction
import com.scb.razor.mls.persistent.model.LoggingEvent
import com.scb.razor.mls.persistent.model.Message
import com.scb.razor.mls.persistent.model.StaticMappingAudit
import com.scb.razor.mls.persistent.search.AuditingSearchCriteria
import com.scb.sabre.ticketing.security.EntitlementsService
import spock.lang.Shared
import spock.lang.Specification

import static com.scb.razor.mls.persistent.utils.PersistentConstants.AuditLogAction
import static org.mockito.Matchers.any
import static org.mockito.Matchers.anyString
import static org.mockito.Mockito.mock
import static org.mockito.Mockito.when

/**
 * Description:
 * Author: 1466811
 * Date:   5:58 PM 5/16/14
 */
class AuditingServiceImplTest extends Specification {
    @Shared messageDaoImpl;
    @Shared loggingEventDaoImpl
    @Shared auditLogDaoImpl
    @Shared exceptionActionDaoImpl
    @Shared auditingEntitlementsService

    @Shared AuditingServiceImpl auditingServiceImpl;
    @Shared AuditingSearchCriteria searchCriteria;
    @Shared String userId;
    @Shared URI uri;
    @Shared testString;

    def setupSpec() {
        auditingEntitlementsService = mock(EntitlementsService.class);
        messageDaoImpl = mock(MessageDaoImpl.class);
        loggingEventDaoImpl = mock(LoggingEventDaoImpl.class);
        auditLogDaoImpl = mock(StaticMappingAuditDaoImpl.class);
        exceptionActionDaoImpl = mock(ExceptionActionDaoImpl.class);

        auditingServiceImpl = new AuditingServiceImpl();
        searchCriteria = new AuditingSearchCriteria();
        searchCriteria.setFirstResult(0);
        searchCriteria.setMaxResults(20);
        userId = "1466811";
        uri = new URI("http://localhost:8094/mls-auditing-service/");
        testString = "TEST_DATA";

        def entitlements = new HashSet<String>();
        entitlements.add(testString);
        when(auditingEntitlementsService.getEntitlements(anyString())).thenReturn(entitlements);

        def field0 = AuditingServiceImpl.class.getDeclaredField("messageDaoImpl");
        field0.setAccessible(true);
        field0.set(auditingServiceImpl, messageDaoImpl);
        def field1 = AuditingServiceImpl.class.getDeclaredField("loggingEventDaoImpl");
        field1.setAccessible(true);
        field1.set(auditingServiceImpl, loggingEventDaoImpl);
        def field2 = AuditingServiceImpl.class.getDeclaredField("staticMappingAuditDaoImpl");
        field2.setAccessible(true);
        field2.set(auditingServiceImpl, auditLogDaoImpl);
        def field3 = AuditingServiceImpl.class.getDeclaredField("exceptionActionDaoImpl");
        field3.setAccessible(true);
        field3.set(auditingServiceImpl, exceptionActionDaoImpl);
        def field4 = AuditingServiceImpl.class.getDeclaredField("auditingEntitlementsService");
        field4.setAccessible(true);
        field4.set(auditingServiceImpl, auditingEntitlementsService);
    }

    /**
     * Test method for listMessages()
     */
    def "list the Messages by search criteria"() {
        given:
        def mlsMessages = new ArrayList<MlsMessage>();
        mlsMessages.add(new MlsMessage());
        def messageMapper = mock(MessageMapper.class);
        def field = AuditingServiceImpl.class.getDeclaredField("messageMapper");
        field.setAccessible(true);
        field.set(auditingServiceImpl, messageMapper);

        when:
        when(messageDaoImpl.listMessages(any(AuditingSearchCriteria.class))).thenReturn(new ArrayList<Message>());
        when(messageMapper.mapToMlsMessageCollection(any(ArrayList.class), any(URI.class), any(String.class)))
                .thenReturn(mlsMessages);
        def result = auditingServiceImpl.listMessages(searchCriteria, userId, uri);

        then:
        result.size() == 1;
    }

    /**
     * Test method for getMessagesAmount()
     */
    def "get the amount of Messages by search criteria"() {
        given:
        def result = 5L;
        when(messageDaoImpl.getMessageAmount(any(AuditingSearchCriteria.class))).thenReturn(new Long(result));

        when:
        def amount = auditingServiceImpl.getMessagesAmount(searchCriteria, userId);

        then:
        amount.longValue() == result;
    }

    /**
     * Test method for getAvailableSourceSysIds()
     */
    def "get the available SourceSysIds by search criteria"() {
        given:
        def authorizedField = "SOURCE_SYS_ID";
        def field = AuditingServiceImpl.class.getDeclaredField("authorizedField");
        field.setAccessible(true);
        field.set(auditingServiceImpl, authorizedField);

        when:
        def results = auditingServiceImpl.getAvailableSourceSysIds(userId);

        then:
        results.contains(testString);

        when:
        authorizedField = "test_data";
        field.set(auditingServiceImpl, authorizedField);
        results = auditingServiceImpl.getAvailableSourceSysIds(userId);

        then:
        results.equals(MLS.Interface.names());
    }

    /**
     * Test method for getAvailableStatuses()
     */
    def "get the available Statuses by search criteria"() {
        given:
        def results = auditingServiceImpl.getAvailableStatuses();

        expect:
        results.contains(Message.Status.DELIVERED.toString());
        results.contains(Message.Status.RECEIVED.toString());
    }

    /**
     * Test method for getAvailableKeys()
     */
    /*def "get the available Keys by search criteria"() {
        given:
        def keys = new HashSet<String>();
        keys.add((String) testString);

        def messagePropertyDaoImpl = mock(MessagePropertyDaoImpl.class);
        def field = AuditingServiceImpl.class.getDeclaredField("messagePropertyDaoImpl");
        field.setAccessible(true);
        field.set(auditingServiceImpl, messagePropertyDaoImpl);
        when(messagePropertyDaoImpl.getPropertyKeys()).thenReturn(keys);

        when:
        def results = auditingServiceImpl.getAvailableKeys();

        then:
        results.contains(testString);
    }*/

    /**
     * Test method for getAvailableActions()
     */
    def "get the available Actions by search criteria"() {
        given:
        def actions = new ArrayList<String>();
        testString = "create";
        actions.add((AuditLogAction) testString);
        when(auditLogDaoImpl.getActions()).thenReturn(actions);

        when:
        def results = auditingServiceImpl.getAvailableActions();

        then:
        results.contains(testString);
    }

    /**
     * Test method for getExceptionActions()
     */
    def "get the ExceptionActions by search criteria"() {
        given:
        def actions = new ArrayList<String>();
        testString = "create";
        actions.add((AuditLogAction) testString);
        when(exceptionActionDaoImpl.getActions()).thenReturn(actions);

        when:
        def results = auditingServiceImpl.getExceptionActions();

        then:
        results.contains(testString);
    }

    /**
     * Test method for listLoggingEvents()
     */
    def "list the LoggingEvents by search criteria"() {
        given:
        def loggingEvents = new ArrayList<LoggingEvent>();
        loggingEvents.add(new LoggingEvent(new Long(11L)));
        def mlsLoggingEvents = new ArrayList<MlsLoggingEvent>();
        mlsLoggingEvents.add(new MlsLoggingEvent());

        def loggingEventMapper = mock(LoggingEventMapper.class);
        def field = AuditingServiceImpl.class.getDeclaredField("loggingEventMapper");
        field.setAccessible(true);
        field.set(auditingServiceImpl, loggingEventMapper);

        when(loggingEventDaoImpl.listLoggingEvents(searchCriteria)).thenReturn(loggingEvents);
        when(loggingEventMapper.mapToMlsLoggingEventCollection(any(ArrayList.class),
                any(URI.class))).thenReturn(mlsLoggingEvents);

        when:
        List<MlsLoggingEvent> events = auditingServiceImpl.listLoggingEvents(searchCriteria, uri);

        then:
        events.size() == 1;
    }

    /**
     * Test method for getLoggingEventsAmount()
     */
    def "get the amount of LoggingEvents by search criteria"() {
        given:
        def result = new Long(5L);
        when(loggingEventDaoImpl.getLoggingEventsAmount(searchCriteria)).thenReturn(result);

        when:
        def amount = auditingServiceImpl.getLoggingEventsAmount(searchCriteria);

        then:
        amount.equals(result);
    }

    /**
     * Test method for listAuditLogs()
     */
    def "list the AuditLogs by search criteria"() {
        given:
        def auditLogs = new ArrayList<StaticMappingAudit>();
        auditLogs.add(new StaticMappingAudit(new Long(111L)));
        def mlsAuditLogs = new ArrayList<MlsAuditLog>();
        mlsAuditLogs.add(new MlsAuditLog());

        def auditLogMapper = mock(AuditLogMapper.class);
        def field = AuditingServiceImpl.class.getDeclaredField("auditLogMapper");
        field.setAccessible(true);
        field.set(auditingServiceImpl, auditLogMapper);

        when(auditLogDaoImpl.listAuditLog(searchCriteria)).thenReturn(auditLogs);
        when(auditLogMapper.mapToMlsAuditLogCollection(auditLogs)).thenReturn(mlsAuditLogs);

        when:
        List<MlsLoggingEvent> events = auditingServiceImpl.listAuditLogs(searchCriteria);

        then:
        events.size() == 1;
    }

    /**
     * Test method for getAuditLogsAmount()
     */
    def "get the amount of AuditLogs by search criteria"() {
        given:
        def result = new Long(55L);
        when(auditLogDaoImpl.getAuditLogAmount(searchCriteria)).thenReturn(result);

        when:
        def amount = auditingServiceImpl.getAuditLogsAmount(searchCriteria);

        then:
        amount.equals(result);
    }

    /**
     * Test method for listExceptionActions()
     */
    def "list the ExceptionActions by search criteria"() {
        given:
        def exceptionActions = new ArrayList<ExceptionAction>();
        exceptionActions.add(new ExceptionAction(new Long(1111L)));
        def mlsExceptionActions = new ArrayList<MlsExceptionAction>();
        mlsExceptionActions.add(new MlsExceptionAction());

        def exceptionActionMapper = mock(ExceptionActionMapper.class);
        def field = AuditingServiceImpl.class.getDeclaredField("exceptionActionMapper");
        field.setAccessible(true);
        field.set(auditingServiceImpl, exceptionActionMapper);

        when(exceptionActionDaoImpl.listExceptionAction(searchCriteria)).thenReturn(exceptionActions);
        when(exceptionActionMapper.mapToMlsExceptionActionCollection(exceptionActions))
                .thenReturn(mlsExceptionActions);

        when:
        List<MlsLoggingEvent> events = auditingServiceImpl.listExceptionActions(searchCriteria);

        then:
        events.size() == 1;
    }

    /**
     * Test method for getExceptionActionsAmount()
     */
    def "get the amount of ExceptionActions by search criteria"() {
        given:
        def result = new Long(555L);
        when(exceptionActionDaoImpl.getExceptionActionAmount(searchCriteria)).thenReturn(result);

        when:
        def amount = auditingServiceImpl.getExceptionActionsAmount(searchCriteria);

        then:
        amount.equals(result);
    }

    def "full test"() {
        given:
        when(auditingEntitlementsService.getEntitlements(anyString())).thenReturn(new HashSet<String>());

        when:
        def result0 = auditingServiceImpl.listMessages(searchCriteria, userId, uri);
        def result1 = auditingServiceImpl.getMessagesAmount(searchCriteria, userId);

        then:
        result0.isEmpty()
        result1.equals(new Long(0l))
    }
}
