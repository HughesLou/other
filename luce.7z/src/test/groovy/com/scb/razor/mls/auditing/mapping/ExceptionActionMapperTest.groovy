/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.mapping

import com.scb.razor.mls.persistent.model.ExceptionAction
import spock.lang.Shared
import spock.lang.Specification

import static com.scb.razor.mls.persistent.utils.PersistentConstants.AuditLogAction

/**
 * Description:
 * Author: 1466811
 * Date:   4:30 PM 5/14/14
 */
class ExceptionActionMapperTest extends Specification {
    @Shared exceptionActionMapper;
    @Shared exceptionAction;
    @Shared id;

    def setupSpec() {
        exceptionActionMapper = new ExceptionActionMapper()

        id = new Long(1000L);
        exceptionAction = new ExceptionAction(id);
        exceptionAction.setAction(AuditLogAction.create);
        exceptionAction.setActive(1L);
        exceptionAction.setActor("1466811");
        exceptionAction.setAuditDate(Calendar.getInstance().getTime());
        exceptionAction.setCreatedDate(Calendar.getInstance().getTime());
        exceptionAction.setGuid("testGUID");
        exceptionAction.setTicketId(1000L);
        exceptionAction.setComments("test");
        exceptionAction.setParams("testParams");
        exceptionAction.setReason("testReason");
    }

    /**
     * Test method for mapToMlsExceptionAction()
     */
    def "Map an exceptionAction to MlsExceptionActionBuilder"() {
        given: "accept the exceptionAction"
        def mlsExceptionActionBuilder = exceptionActionMapper.mapToMlsExceptionAction(exceptionAction);

        expect: "the MlsExceptionActionBuilder is not null"
        mlsExceptionActionBuilder != null;
    }

    /**
     * Test method for mapToMlsExceptionActionCollection()
     */
    def "Map an exceptionAction list to MlsExceptionAction list"() {
        given: "accept the exceptionAction list"
        def exceptionActions = new ArrayList<ExceptionAction>();
        exceptionActions.add((ExceptionAction) exceptionAction);

        when:
        def mlsExceptionActions = exceptionActionMapper.mapToMlsExceptionActionCollection(exceptionActions);

        then: "the size is 1"
        mlsExceptionActions.size() == 1;
    }
}
