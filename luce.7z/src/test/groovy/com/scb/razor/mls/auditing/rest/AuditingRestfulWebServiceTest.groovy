/*
 * Copyright (c) 2014. Standard Chartered Bank. All rights reserved.
 */

package com.scb.razor.mls.auditing.rest

import com.scb.razor.mls.auditing.service.impl.AuditingServiceImpl
import com.scb.razor.mls.auditing.ws.AuditingQueryParameterParser
import com.scb.razor.mls.persistent.search.AuditingSearchCriteria
import com.scb.sabre.ticketing.security.Action
import com.scb.sabre.ticketing.security.Entitlement
import com.scb.sabre.ticketing.security.EntitlementsService
import com.scb.sabre.ticketing.security.Subject
import spock.lang.Shared
import spock.lang.Specification

import javax.ws.rs.core.Response

import static com.scb.razor.mls.persistent.utils.PersistentConstants.AuditLogAction
import static org.mockito.Matchers.*
import static org.mockito.Mockito.*

/**
 * Description:
 * Author: 1466811
 * Date:   2:06 PM 5/16/14
 */
class AuditingRestfulWebServiceTest extends Specification {
    @Shared
    String userId;
    @Shared
    AuditingRestfulWebService service;
    @Shared
    AuditingServiceImpl auditingServiceImpl;
    @Shared
    AuditingQueryParameterParser auditingQueryParameterParser;
    @Shared
    EntitlementsService auditingEntitlementsService;

    def setupSpec() {
        userId = "1466811";
        service = new AuditingRestfulWebService();
        auditingServiceImpl = spy(new AuditingServiceImpl());
        auditingQueryParameterParser = spy(new AuditingQueryParameterParser());
        auditingEntitlementsService = mock(EntitlementsService.class);

        def field = AuditingRestfulWebService.class.getDeclaredField("auditingServiceImpl");
        field.setAccessible(true);
        field.set(service, auditingServiceImpl);

        def parser = AuditingRestfulWebService.class.getDeclaredField("auditingQueryParameterParser");
        parser.setAccessible(true);
        parser.set(service, auditingQueryParameterParser);

        def entitlementService = AuditingRestfulWebService.class.getDeclaredField("auditingEntitlementsService");
        entitlementService.setAccessible(true);
        entitlementService.set(service, auditingEntitlementsService);

        def list = new ArrayList()
        list.add("RT")
        list.add("EOD")
        list.add("Static")
        list.add("Exception")
        list.add("Murex")
        def excludedAuthorizedField = AuditingRestfulWebService.class.getDeclaredField("excludedAuthorizedField")
        excludedAuthorizedField.setAccessible(true)
        excludedAuthorizedField.set(service, list)
    }

    /**
     * Test method for getAvailableSourceSysIds()
     */
    def "get available source sys id"() {
        given:
        def source = "TEST";
        def sourceSysIds = new HashSet<String>();
        sourceSysIds.add(source);
        sourceSysIds.add("EOD");
        sourceSysIds.add("RT");
        sourceSysIds.add("Static");

        when:
        doReturn(sourceSysIds).when(auditingServiceImpl).getAvailableSourceSysIds(userId)
        def response = service.getAvailableSourceSysIds(userId);

        then:
        response.getStatus().equals(Response.Status.OK.statusCode)
        ((Set<String>) response.getEntity()).size() == 1;
        ((Set<String>) response.getEntity()).contains(source);
    }

    /**
     * Test method for getAvailableStatuses()
     */
    def "get available statuses"() {
        given:
        def status = "OK";
        def statuses = new HashSet<String>();
        statuses.add(status);

        when:
        doReturn(statuses).when(auditingServiceImpl).getAvailableStatuses()
        def response = service.getAvailableStatuses(userId);

        then:
        response.getStatus().equals(Response.Status.OK.statusCode)
        ((Set<String>) response.getEntity()).contains(status);
    }

    /**
     * Test method for getAvailableKeys()
     */
    def "get available keys"() {
        given:
        def key = "KEY";
        def keys = new HashSet<String>();
        keys.add(key);

        when:
        doReturn(keys).when(auditingServiceImpl).getAvailableKeys()
        def response = service.getAvailableKeys(userId);

        then:
        response.getStatus().equals(Response.Status.OK.statusCode)
        ((Set<String>) response.getEntity()).contains(key);
    }

    /**
     * Test method for getLoggingEventsAmount()
     */
    def "get the amount of LoggingEvent"() {
        given:
        def amount = new Long(100L);
        def systemId = "Tracking_Id";
        def tradeRef = "CTPY";
        def searchCriteria = new AuditingSearchCriteria();
        searchCriteria.setTrackingId(systemId);
        searchCriteria.setSourceSysId(tradeRef);

        when:
        doReturn(searchCriteria).when(auditingQueryParameterParser).buildSearchCriteria(any(Map.class));
        doReturn(amount).when(auditingServiceImpl).getLoggingEventsAmount(searchCriteria)
        def response = service.getLoggingEventsAmount(userId, systemId, tradeRef, "15-07-2014", "25-07-2014");
        doReturn(null).when(auditingQueryParameterParser).buildSearchCriteria(anyMap())
        def response0 = service.getLoggingEventsAmount(null, null, null, null, null);

        then:
        response.getStatus().equals(Response.Status.OK.statusCode)
        ((Long) response.getEntity()).equals(amount);
        response0.getStatus().equals(Response.Status.OK.statusCode)
        0 == ((Long) response0.getEntity()).intValue();
    }

    /**
     * Test method for getMessagesAmount()
     */
    def "get the amount of Messages"() {
        given:
        def amount = new Long(100L);
        def trackingId = "Tracking_Id";
        def sourceSysId = "CTPY";
        def wildcard = "true";
        def searchCriteria = new AuditingSearchCriteria();
        searchCriteria.setTrackingId(trackingId);
        searchCriteria.setSourceSysId(sourceSysId);

        when:
        doReturn(searchCriteria).when(auditingQueryParameterParser).buildSearchCriteria(anyMap())
        doReturn(amount).when(auditingServiceImpl).getMessagesAmount(
                any(AuditingSearchCriteria.class), anyString())
        def response0 = service.getMessagesAmount(null, false, trackingId, wildcard, sourceSysId, null, null, null, null, null);
        def response1 = service.getMessagesAmount(userId, false, trackingId, wildcard, sourceSysId, "Y", null, "TEST",
                "15-07-2014", "25-07-2014");
        doReturn(null).when(auditingQueryParameterParser).buildSearchCriteria(anyMap())
        def response2 = service.getMessagesAmount(userId, false, null, wildcard, null, null, null, null, null, null);

        then:
        response0.getStatus().equals(Response.Status.INTERNAL_SERVER_ERROR.statusCode)
        response1.getStatus().equals(Response.Status.OK.statusCode)
        ((Long) response1.getEntity()).equals(amount)
        response2.getStatus().equals(Response.Status.OK.statusCode)
        0 == ((Long) response2.getEntity()).intValue();
    }

    /**
     * Test method for getActionsInfo()
     */
    def "get Actions info"() {
        given:
        def entitlements = new ArrayList<Entitlement>();
        def subject = "EOD";
        def actionName = "ACTION";
        def entitlement = new Entitlement();
        def sub = new Subject();
        def action = new Action();
        sub.setName(subject);
        action.setName(actionName)
        entitlement.setAction(action);
        entitlement.setId(100L);
        entitlement.setSubject(sub);
        entitlements.add(entitlement);

        when:
        doReturn(entitlements).when(auditingEntitlementsService).getEntitlementsFor(anyString())
        def response = service.getActionsInfo(userId, subject);

        then:
        response.getStatus().equals(Response.Status.OK.statusCode)
        ((Set<String>) response.getEntity()).contains(actionName);
    }

    /**
     * Test method for getActions()
     */
    def "get available Actions"() {
        given:
        def action = "resubmit";
        def actions = new ArrayList<String>();
        actions.add(action)

        when:
        doReturn(actions).when(auditingServiceImpl).getAvailableActions()
        def response = service.getActions(userId);

        then:
        response.getStatus().equals(Response.Status.OK.statusCode)
        ((List<String>) response.getEntity()).contains(action);
    }

    /**
     * Test method for getAuditLogsAmount()
     */
    def "get the amount of AuditLogs"() {
        given:
        def amount = new Long(101L);
        def searchCriteria = new AuditingSearchCriteria();
        searchCriteria.setUserId(userId);

        when:
        doReturn(searchCriteria).when(auditingQueryParameterParser).buildSearchCriteria(anyMap())
        doReturn(amount).when(auditingServiceImpl).getAuditLogsAmount(any(AuditingSearchCriteria.class))
        def response = service.getAuditLogsAmount(userId, userId, "create", "100", "test_detail",
                "15-07-2014", "25-07-2014");
        doReturn(null).when(auditingQueryParameterParser).buildSearchCriteria(anyMap())
        def response0 = service.getAuditLogsAmount(null, null, null, null, null, null, null);

        then:
        response.getStatus().equals(Response.Status.OK.statusCode)
        ((Long) response.getEntity()).equals(amount);
        response0.getStatus().equals(Response.Status.OK.statusCode)
        0 == ((Long) response0.getEntity()).intValue();
    }

    /**
     * Test method for getExceptionActions()
     */
    def "get available ExceptionActions"() {
        given:
        def action = "ACTION_TEST";
        def actions = new ArrayList<String>();
        actions.add(action)

        when:
        doReturn(actions).when(auditingServiceImpl).getExceptionActions()
        def response = service.getExceptionActions(userId);

        then:
        response.getStatus().equals(Response.Status.OK.statusCode)
        ((List<String>) response.getEntity()).contains(action);
    }

    /**
     * Test method for getExceptionActionsAmount()
     */
    def "get the amount of ExceptionActions"() {
        given:
        def amount = new Long(102L);
        def action = "ACTION_TEST";
        def searchCriteria = new AuditingSearchCriteria();
        searchCriteria.setAction(AuditLogAction.create);

        when:
        doReturn(searchCriteria).when(auditingQueryParameterParser).buildSearchCriteria(anyMap())
        doReturn(amount).when(auditingServiceImpl).getExceptionActionsAmount(any(AuditingSearchCriteria.class))
        def response = service.getExceptionActionsAmount(userId, userId, action, "100", "test_comments",
                "15-07-2014", "25-07-2014");
        doReturn(null).when(auditingQueryParameterParser).buildSearchCriteria(anyMap())
        def response0 = service.getExceptionActionsAmount(null, null, null, null, null, null, null);

        then:
        response.getStatus().equals(Response.Status.OK.statusCode)
        ((Long) response.getEntity()).equals(amount);
        response0.getStatus().equals(Response.Status.OK.statusCode)
        0 == ((Long) response0.getEntity()).intValue();
    }
}
