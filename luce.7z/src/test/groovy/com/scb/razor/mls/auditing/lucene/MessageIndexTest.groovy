package com.scb.razor.mls.auditing.lucene

import java.lang.Thread.UncaughtExceptionHandler;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.sql.DataSource
import javax.ws.rs.core.MultivaluedMap
import javax.ws.rs.core.UriBuilder
import javax.ws.rs.core.UriInfo;

import org.apache.lucene.index.Term
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.MatchAllDocsQuery
import org.apache.lucene.search.TermQuery
import org.apache.lucene.search.BooleanClause.Occur;
import org.junit.Before;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource
import org.springframework.jdbc.datasource.SingleConnectionDataSource
import org.springframework.scheduling.TaskScheduler
import org.springframework.scheduling.concurrent.ConcurrentTaskExecutor
import org.springframework.scheduling.concurrent.ConcurrentTaskScheduler

import com.google.common.io.Files;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.scb.razor.mls.auditing.WorkingDirectory
import com.scb.razor.mls.auditing.auth.Ems2Resource
import com.scb.razor.mls.auditing.lucene.exceptions.LiveExceptionStore;
import com.scb.razor.mls.auditing.lucene.exceptions.ActionPerformEvent.MurexExceptionActionPerformEvent;
import com.scb.razor.mls.auditing.rest.AuditingRestfulWebService
import com.sun.jersey.core.util.MultivaluedMapImpl;

import spock.lang.Ignore
import spock.lang.Specification;

class MessageIndexTest extends Specification {
    
    DataSource dataSource;
    
    ExecutorService executorService;
    
    TaskScheduler taskScheduler;
    
    ScheduledExecutorService scheduledExecutor;
    
    WorkingDirectory workingDirectory;
    
    String ems2Url;
    
    MessageIndex mi
    
    def ems2
    
    def idseq = 1;
    
    def setup() {
        
        if(executorService != null) {
            executorService.shutdownNow();
        }
        if(scheduledExecutor != null) {
            scheduledExecutor.shutdownNow();
        }
        ThreadFactoryBuilder b = new ThreadFactoryBuilder();
        b.setNameFormat("mls-thread-%d");
        b.setDaemon(true);
        b.setUncaughtExceptionHandler({t, e -> e.printStackTrace()} as UncaughtExceptionHandler)
        executorService = Executors.newFixedThreadPool(10, b.build());
        scheduledExecutor = Executors.newScheduledThreadPool(2, b.build());
        taskScheduler = new ConcurrentTaskScheduler(executorService, scheduledExecutor);
        
        dataSource = new SingleConnectionDataSource(
            url     : "jdbc:h2:mem:",
            username: "sa",
            password: "",
            driverClassName: "org.h2.Driver",
            suppressClose: true
            );
        
        JdbcTemplate jt = new JdbcTemplate(dataSource);
        jt.update("create table MESSAGE (ID number(19,0) not null, IS_ALERT NUMBER DEFAULT 0, CHANNEL varchar2(20 char), CONTENT blob, CONTENT_TYPE varchar2(20 char), CORRELATION_ID varchar2(100 char), CREATE_TIMESTAMP timestamp, DELIVERY_MODE number(10,0), DESTINATION varchar2(255 char), EXPIRATION number(19,0), JMS_MSG_ID varchar2(100 char), JMS_TIMESTAMP timestamp, PRIORITY number(10,0), REDELIVERED char(1 char), REFERENCE_ID varchar2(50 char), REPLY_TO varchar2(255 char), SOURCE_SYS_ID varchar2(20 char), STATUS varchar2(20 char), TRACKING_ID varchar2(100 char), TYPE varchar2(20 char), primary key (ID) )");
        jt.execute("create table MESSAGE_PROPERTY (ID number(19,0) not null, CREATE_TIMESTAMP timestamp, KEY varchar2(50 char), VALUE varchar2(255 char), MESSAGE_ID number(19,0) not null, primary key (ID) )");
        jt.execute("CREATE TABLE SCB_TICKET (   GUID VARCHAR2(50 ), TYPE VARCHAR2(50 ), ACTOR VARCHAR2(50 ), VIEWGROUP VARCHAR2(50 ), ACTORGROUP VARCHAR2(50 ), METADATA CLOB, METADATATAG VARCHAR2(255 ), METADATATYPE VARCHAR2(255 ), DESCRIPTION VARCHAR2(2000 ), AVAILABLE_ACTIONS VARCHAR2(255 ), AUDITTIMESTAMP TIMESTAMP (6), CREATOR VARCHAR2(50 ), CREATEDTIMESTAMP TIMESTAMP (6), ID NUMBER, IS_COMPLETE NUMBER DEFAULT 0, STATUS VARCHAR2(50 ), IS_ALERT NUMBER DEFAULT 0 )");
        jt.execute("CREATE TABLE SCB_TICKET_TAG (   ID NUMBER, TICKET_ID NUMBER, TAGNAME VARCHAR2(255 ), TAGVALUE VARCHAR2(4000 ), CREATEDTIMESTAMP TIMESTAMP )");
        workingDirectory = new WorkingDirectory(Files.createTempDir())
        
        mi = new MessageIndex(
            dataSource : dataSource,
            workingDirectory : workingDirectory,
            executorService : executorService,
            taskScheduler: taskScheduler
        )
        
        def srv = com.sun.net.httpserver.HttpServer.create(new InetSocketAddress(0), 0)
        srv.start()
        ems2Url = "http://localhost:${srv.address.port}/"
        srv.createContext("/", { ex ->
            def uri = ex.getRequestURI().toString();
            def resp = ""
            switch(uri) {
                case "/ems2/rest/entity/RAZOR_MLS_EXCEPTION" :
                    resp = '{"name":"RAZOR_MLS_EXCEPTION","locked":true,"id":451064}';
                    break;
                case "/ems2/rest/entity/451064/roles" :
                    resp = '{"count":6,"roles":[{"name":"DEV","entity":{"name":"RAZOR_MLS_EXCEPTION","locked":true,"id":451064},"id":519159},{"name":"EMS2_ADMIN","entity":{"name":"RAZOR_MLS_EXCEPTION","locked":true,"id":451064},"id":451147},{"name":"FMO","entity":{"name":"RAZOR_MLS_EXCEPTION","locked":true,"id":451064},"id":451149},{"name":"FMO_ADMIN","entity":{"name":"RAZOR_MLS_EXCEPTION","locked":true,"id":451064},"id":531450},{"name":"PSRD","entity":{"name":"RAZOR_MLS_EXCEPTION","locked":true,"id":451064},"id":527503},{"name":"PSS","entity":{"name":"RAZOR_MLS_EXCEPTION","locked":true,"id":451064},"id":519151}]}';
                    break;
                case "/ems2/rest/user/role/519159" :
                    resp = '{"count":15,"users":[{"loginId":"1439970","fullName":"Sarah Zhao","lineManagerId":null,"lineManagerName":null,"id":437458},{"loginId":"1466811","fullName":"Zhiwei Lu","lineManagerId":null,"lineManagerName":null,"id":437492},{"loginId":"1470797","fullName":"Xi Zhang","lineManagerId":null,"lineManagerName":null,"id":437495},{"loginId":"1478480","fullName":"Min Li","lineManagerId":null,"lineManagerName":null,"id":437497},{"loginId":"1394207","fullName":"Ji Wang","lineManagerId":null,"lineManagerName":null,"id":437498},{"loginId":"1439115","fullName":"YiFan Zhang","lineManagerId":null,"lineManagerName":null,"id":437499},{"loginId":"1439153","fullName":"Bi Hai Tian","lineManagerId":null,"lineManagerName":null,"id":520000},{"loginId":"1453731","fullName":"Wenfeng Jiang","lineManagerId":null,"lineManagerName":null,"id":520014},{"loginId":"1408677","fullName":"Rakesh Chimanpure","lineManagerId":null,"lineManagerName":null,"id":2099},{"loginId":"1403768","fullName":"Christine Haiou Zhu","lineManagerId":null,"lineManagerName":null,"id":528610},{"loginId":"1425145","fullName":"Krishna Raju K V","lineManagerId":null,"lineManagerName":null,"id":546553},{"loginId":"1168721","fullName":"Vikranth S","lineManagerId":null,"lineManagerName":null,"id":546554},{"loginId":"1535027","fullName":"Ferry Van Het Groenewoud","lineManagerId":null,"lineManagerName":null,"id":546557},{"loginId":"1506618","fullName":"Hon Haw Chong","lineManagerId":null,"lineManagerName":null,"id":546555},{"loginId":"1462612","fullName":"Abhishek Gupta","lineManagerId":null,"lineManagerName":null,"id":546556}]}';
                    break;
                case "/ems2/rest/entitlements/entity/name/RAZOR_MLS_EXCEPTION/user/1439970" :
                    resp = '{"count":1,"entitlements":[{"subject":{"name":"RT|ALM_MX3|TechnicalException","entity":{"name":"RAZOR_MLS_EXCEPTION","locked":true,"id":451064},"longName":"/RT|ALM_MX3|TechnicalException","id":527564},"action":{"name":"view","entity":{"name":"RAZOR_MLS_EXCEPTION","locked":true,"id":451064},"id":451176},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_EXCEPTION","locked":true,"id":451064},"id":519159},"id":527610}]}';
                    break;
                case "/ems2/rest/entitlements/entity/name/RAZOR_MLS_EXCEPTION/user/1439971" :
                    resp = '{"count":2,"entitlements":[{"subject":{"name":"RT|ALM_MX3|TechnicalException","entity":{"name":"RAZOR_MLS_EXCEPTION","locked":true,"id":451064},"longName":"/RT|ALM_MX3|TechnicalException","id":527564},"action":{"name":"view","entity":{"name":"RAZOR_MLS_EXCEPTION","locked":true,"id":451064},"id":451176},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_EXCEPTION","locked":true,"id":451064},"id":519159},"id":527610},{"subject":{"name":"RT|ALM_MX3|MalformattedException","entity":{"name":"RAZOR_MLS_EXCEPTION","locked":true,"id":451064},"longName":"/RT|ALM_MX3|MalformattedException","id":527564},"action":{"name":"view","entity":{"name":"RAZOR_MLS_EXCEPTION","locked":true,"id":451064},"id":451172},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_EXCEPTION","locked":true,"id":451062},"id":519153},"id":527612}]}';
                    break;
                case "/ems2/rest/entitlements/entity/name/RAZOR_MLS_AUDITING/user/1439970" :
                    resp = '{"entitlements":[{"action":{"name":"Mark as Resolved","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":543700},"subject":{"name":"FX_REALM","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/FX_REALM","id":527551},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":543582},{"action":{"name":"Mark as Resolved","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":543700},"subject":{"name":"ALM_REALM","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/ALM_REALM","id":527554},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":543571},{"action":{"name":"Mark as Resolved","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":543700},"subject":{"name":"ALM_MX3","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/ALM_MX3","id":527553},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":543568},{"action":{"name":"Mark as Resolved","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":543700},"subject":{"name":"FX_MX3","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/FX_MX3","id":527552},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":543579},{"action":{"name":"Mark as Resolved","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":543700},"subject":{"name":"FX_SSI","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/FX_SSI","id":519245},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":543583},{"action":{"name":"Mark as Resolved","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":543700},"subject":{"name":"FX_PDC","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/FX_PDC","id":519244},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":543581},{"action":{"name":"Mark as Resolved","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":543700},"subject":{"name":"FX_OUT","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/FX_OUT","id":519243},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":543580},{"action":{"name":"Mark as Resolved","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":543700},"subject":{"name":"FX_IN","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/FX_IN","id":519242},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":543578},{"action":{"name":"Mark as Resolved","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":543700},"subject":{"name":"FRTP","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/FRTP","id":519241},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":543577},{"action":{"name":"Mark as Resolved","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":543700},"subject":{"name":"Exception","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/Exception","id":519240},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":543576},{"action":{"name":"Mark as Resolved","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":543700},"subject":{"name":"EOD","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/EOD","id":519239},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":543575},{"action":{"name":"Mark as Resolved","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":543700},"subject":{"name":"CTPY","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/CTPY","id":519238},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":543574},{"action":{"name":"Mark as Resolved","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":543700},"subject":{"name":"CALENDAR","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/CALENDAR","id":519237},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":543573},{"action":{"name":"Mark as Resolved","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":543700},"subject":{"name":"ALM_SSI","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/ALM_SSI","id":519236},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":543572},{"action":{"name":"Mark as Resolved","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":543700},"subject":{"name":"ALM_PDC","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/ALM_PDC","id":519235},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":543570},{"action":{"name":"Mark as Resolved","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":543700},"subject":{"name":"ALM_OUT","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/ALM_OUT","id":519234},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":543569},{"action":{"name":"Mark as Resolved","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":543700},"subject":{"name":"ALM_IN","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/ALM_IN","id":519233},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":543567},{"action":{"name":"Replay","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":527450},"subject":{"name":"ALM_REALM","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/ALM_REALM","id":527554},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":527625},{"action":{"name":"Replay","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":527450},"subject":{"name":"FX_IN","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/FX_IN","id":519242},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":527633},{"action":{"name":"Replay","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":527450},"subject":{"name":"FX_REALM","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/FX_REALM","id":527551},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":527636},{"action":{"name":"Replay","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":527450},"subject":{"name":"FX_PDC","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/FX_PDC","id":519244},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":527635},{"action":{"name":"Replay","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":527450},"subject":{"name":"ALM_IN","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/ALM_IN","id":519233},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":527620},{"action":{"name":"Replay","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":527450},"subject":{"name":"CTPY","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/CTPY","id":519238},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":527629},{"action":{"name":"Replay","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":527450},"subject":{"name":"FRTP","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/FRTP","id":519241},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":527632},{"action":{"name":"Replay","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":527450},"subject":{"name":"ALM_OUT","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/ALM_OUT","id":519234},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":527623},{"action":{"name":"Replay","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":527450},"subject":{"name":"FX_OUT","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/FX_OUT","id":519243},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":527634},{"action":{"name":"Replay","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":527450},"subject":{"name":"FX_MX3","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/FX_MX3","id":527552},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":527630},{"action":{"name":"Replay","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":527450},"subject":{"name":"ALM_PDC","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/ALM_PDC","id":519235},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":527624},{"action":{"name":"Replay","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":527450},"subject":{"name":"ALM_MX3","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/ALM_MX3","id":527553},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":527621},{"action":{"name":"Replay","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":527450},"subject":{"name":"FX_SSI","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/FX_SSI","id":519245},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":527638},{"action":{"name":"Replay","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":527450},"subject":{"name":"ALM_SSI","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/ALM_SSI","id":519236},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":527627},{"action":{"name":"Replay","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":527450},"subject":{"name":"CALENDAR","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/CALENDAR","id":519237},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":527628},{"action":{"name":"View","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":451181},"subject":{"name":"ALM_MX3","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/ALM_MX3","id":527553},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":527622},{"action":{"name":"View","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":451181},"subject":{"name":"ALM_OUT","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/ALM_OUT","id":519234},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":520846},{"action":{"name":"View","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":451181},"subject":{"name":"FX_PDC","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/FX_PDC","id":519244},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":520856},{"action":{"name":"View","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":451181},"subject":{"name":"ALM_IN","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/ALM_IN","id":519233},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":520845},{"action":{"name":"View","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":451181},"subject":{"name":"FX_REALM","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/FX_REALM","id":527551},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":527637},{"action":{"name":"View","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":451181},"subject":{"name":"ALM_PDC","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/ALM_PDC","id":519235},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":520847},{"action":{"name":"View","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":451181},"subject":{"name":"ALM_SSI","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/ALM_SSI","id":519236},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":520848},{"action":{"name":"View","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":451181},"subject":{"name":"FX_SSI","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/FX_SSI","id":519245},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":520857},{"action":{"name":"View","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":451181},"subject":{"name":"ALM_REALM","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/ALM_REALM","id":527554},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":527626},{"action":{"name":"View","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":451181},"subject":{"name":"FX_OUT","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/FX_OUT","id":519243},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":520855},{"action":{"name":"View","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":451181},"subject":{"name":"FX_IN","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/FX_IN","id":519242},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":520854},{"action":{"name":"View","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":451181},"subject":{"name":"FX_MX3","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/FX_MX3","id":527552},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":527631},{"action":{"name":"View","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":451181},"subject":{"name":"FRTP","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/FRTP","id":519241},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":520853},{"action":{"name":"View","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":451181},"subject":{"name":"Exception","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/Exception","id":519240},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":520852},{"action":{"name":"View","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":451181},"subject":{"name":"Murex","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/Murex","id":527550},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":527639},{"action":{"name":"View","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":451181},"subject":{"name":"EOD","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/EOD","id":519239},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":520851},{"action":{"name":"View","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":451181},"subject":{"name":"Static","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/Static","id":519247},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":520859},{"action":{"name":"View","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":451181},"subject":{"name":"CTPY","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/CTPY","id":519238},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":520850},{"action":{"name":"View","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":451181},"subject":{"name":"RT","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/RT","id":519246},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":520858},{"action":{"name":"View","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":451181},"subject":{"name":"SWIFT","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/SWIFT","id":529855},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":532500},{"action":{"name":"View","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":451181},"subject":{"name":"CALENDAR","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"longName":"/CALENDAR","id":519237},"role":{"name":"DEV","entity":{"name":"RAZOR_MLS_AUDITING","locked":true,"id":451069},"id":519167},"id":520849}],"count":53}';
                    break;
                
            }
            ex.getResponseHeaders().add("Content-Type", "application/json");
            ex.sendResponseHeaders(200, resp.getBytes().length)
            ex.getResponseBody().write(resp.getBytes())
            ex.getResponseBody().close()
        })
        ems2 = new Ems2Resource(baseUrl: ems2Url)
        ems2.afterPropertiesSet()
    }
    
    def cleanup() {
//        scheduledExecutor.shutdown();
//        executorService.shutdown();
//        executorService.awaitTermination(10, TimeUnit.SECONDS)
//        mi.destroy()
        workingDirectory.getAsFile().listFiles().each { f ->
            f.deleteOnExit()
        }
    }
    
    def "test index and count"() {
        
        given : 
            insertMessage([id: 123, channel: 'DISPATCH', create_timestamp: new Date(), status: 'RECEIVED'], [:])
            mi.afterPropertiesSet();
        
        when :
            int count1 = mi.count(new TermQuery(new Term("status", "RECEIVED")));
            int count2 = mi.count(new TermQuery(new Term("status", "received")));
        
        then :
            count1 == 1
            count2 == 0
    }
    
    def "test Message change will be flushed to index directory immediately"() {
        given :
            insertMessage([id: 123, channel: 'DISPATCH', create_timestamp: new Date(), status: 'RECEIVED', source_sys_id: 'FRTP'], [:])
            mi.afterPropertiesSet();
            AuditingRestfulWebService restful = new AuditingRestfulWebService(
                messageIndex: mi,
                ems2: ems2
                );
            def jt = new JdbcTemplate(dataSource);
            
        when :
            def count1 = restful.search("DELIVERED", "count", toURIInfo([user: "1439970"], null));
            jt.update("UPDATE MESSAGE SET STATUS='DELIVERED'")
            mi.onMessageEntityChange(MessageEntityChangedEvent.create([123L].toSet()))
            def count2 = restful.search("DELIVERED", "count", toURIInfo([user: "1439970"], null));
            
        then :
            count1 == 0
            count2 == 1
    }
    
    def "test restful count AuditingRestfulWebService#search "() {
        
        given :
            insertMessage([id: 123, channel: 'DISPATCH', create_timestamp: new Date(), status: 'RECEIVED', source_sys_id: 'FRTP'], [:])
            mi.afterPropertiesSet();
            AuditingRestfulWebService restful = new AuditingRestfulWebService(
                messageIndex: mi,
                ems2: ems2
                );
            
        when :
            def count1 = restful.search("RECEIVED",         "count", toURIInfo([user: "1439970"], null));
            def count2 = restful.search("123",              "count", toURIInfo([user: "1439970"], null));
            def count3 = restful.search("status:RECEIVED",  "count", toURIInfo([user: "1439970"], null));
            def count4 = restful.search("status:received",  "count", toURIInfo([user: "1439970"], null));
            def count5 = restful.search(" ",                "count", toURIInfo([user: "1439970"], null));
            
        then :
            count1 == 1
            count2 == 1
            count3 == 1
            count4 == 0
            count5 == 1
    }
    
    def "test restful list AuditingRestfulWebService#search"() {
        
        given :
            insertMessage([id: 123, channel: 'DISPATCH', create_timestamp: new Date(), status: 'RECEIVED', source_sys_id: 'FRTP'], [:])
            insertMessage([id: 222, channel: 'DISPATCH', create_timestamp: new Date(System.currentTimeMillis() - 100000000), status: 'RECEIVED', source_sys_id: 'FRTP'], [:])
            insertMessage([id: 12345, channel: 'REQUEST', create_timestamp: new Date(), status: 'DELIVERED', source_sys_id: 'FRTP'], [:])
            mi.afterPropertiesSet();
            AuditingRestfulWebService restful = new AuditingRestfulWebService(
                messageIndex: mi,
                ems2: ems2
                );
            
        when :
            def list1 = restful.search("RECEIVED",          "ids", toURIInfo([firstResult: 0, maxResults: 20, sort: "create_timestamp", user: "1439970"], null));
            def list2 = restful.search("RECEIVED",          "ids", toURIInfo([firstResult: 0, maxResults: 20, sort: "-create_timestamp", user: "1439970"], null));
            def list3 = restful.search("status:RECEIVED",   "ids", toURIInfo([firstResult: 0, maxResults: 20, user: "1439970"], null));
            def list4 = restful.search("status:DELIVERED",  "ids", toURIInfo([firstResult: 0, maxResults: 20, user: "1439970"], null));
            def list5 = restful.search(null,                "ids", toURIInfo([firstResult: 0, maxResults: 20, user: "1439970"], null));
            def list6 = restful.search("  ",                "ids", toURIInfo([firstResult: 0, maxResults: 20, user: "1439970"], null));
            def list7 = restful.search("  ",                "ids", toURIInfo([user: "1439970"], null));
            
        then :
            list1 == [222, 123]
            list2 == [123, 222]
            list3.size() == 2
            list4 == [12345L]
            list5.size() == 3
            list6.size() == 3
            list7.size() == 3
    }
    
    def "test restful search by any property"() {
        
        given :
            insertMessage([id: 123, channel: 'DISPATCH', create_timestamp: new Date(), status: 'RECEIVED', source_sys_id: 'FRTP'], [prop123:'value123'])
            mi.afterPropertiesSet();
            AuditingRestfulWebService restful = new AuditingRestfulWebService(
                messageIndex: mi,
                ems2: ems2
                );
            
        when :
            def c1 = restful.search(null, "count", toURIInfo([user: "1439970", prop123: 'value123'], null));
            def c2 = restful.search(null, "count", toURIInfo([user: "1439970", prop123In: 'value123,value234'], null));
            def c3 = restful.search(null, "count", toURIInfo([user: "1439970", prop222: 'value123'], null));
            
        then :
            c1 == 1
            c2 == 1
            c3 == 0
    }
    
    def "test restful AuditingRestfulWebService#getMessageAmount"() {
        
        given :
            insertMessage([id: 123, channel: 'DISPATCH', create_timestamp: new Date(), status: 'RECEIVED', source_sys_id: 'FRTP'], [:])
            insertMessage([id: 222, channel: 'DISPATCH', create_timestamp: new Date(System.currentTimeMillis() - 100000000), status: 'RECEIVED', source_sys_id: 'FRTP'], [:])
            insertMessage([id: 12345, channel: 'DISPATCH', create_timestamp: new Date(), status: 'DELIVERED', source_sys_id: 'FX_IN'], [S2BX_ID: 's2bx123', messageType: 'nack'])
            mi.afterPropertiesSet();
            AuditingRestfulWebService restful = new AuditingRestfulWebService(
                messageIndex: mi,
                ems2: ems2
                );
            
        when :
            def resp1 = restful.getMessagesAmount("fakeuser1", true, null, "false", null, "RECEIVED", null, null, null, null);
            def resp2 = restful.getMessagesAmount("fakeuser1", true, null, "false", null, null, null, "S2BX_ID;EQUALS;s2bx123", null, null);
            def resp3 = restful.getMessagesAmount("fakeuser1", true, null, "false", null, null, null, "S2BX_ID;EQUALS;s2bx123;OR;S2BX_ID;EQUALS;888", null, null);
            def resp4 = restful.getMessagesAmount("fakeuser1", true, null, "false", null, null, null, null, new Date().format("dd-MM-yyyy"), null);
            def resp5 = restful.getMessagesAmount("fakeuser1", true, null, "false", null, null, null, null, null, new Date().format("dd-MM-yyyy"));
            
        then :
            resp1.entity == 2
            resp2.entity == 1
            resp2.entity == 1
            resp4.entity == 2
            resp5.entity == 1
    }

    def "test first incremental indexing after initial indexing"() {
        given :
            def last = new Date()
            insertMessage([id: 123, channel: 'DISPATCH', create_timestamp: last, status: 'RECEIVED'], [:])
            mi.afterPropertiesSet();
            
        when :
            def count1 = mi.count(new MatchAllDocsQuery())
            
            insertMessage([id: 1234, channel: 'DISPATCH', create_timestamp: last, status: 'RECEIVED'], [:])//new data inserted into db with same last date
            mi.crawlIncrementalFromDatabase()
            def count2 = mi.count(new MatchAllDocsQuery())
            
            then :
                count1 == 1
                count2 == 2
    }
    
    def "test incremental update from database"() {
        
        given :
            def last = new Date()
            insertMessage([id: 123, channel: 'DISPATCH', create_timestamp: last,          status: 'RECEIVED'], [:])
            mi.afterPropertiesSet();
            
        when : 
            def count1 = mi.count(new MatchAllDocsQuery())
            
            insertMessage([id: 1235, channel: 'DISPATCH', create_timestamp: last.plus(1), status: 'RECEIVED'], [:])//new data inserted into db with same last date
            mi.crawlIncrementalFromDatabase()
            def count3 = mi.count(new MatchAllDocsQuery())
            
            insertMessage([id: 1236, channel: 'DISPATCH', create_timestamp: last.plus(1), status: 'RECEIVED'], [:])//new data inserted into db with same last date
            mi.crawlIncrementalFromDatabase()
            def count4 = mi.count(new MatchAllDocsQuery())
            
        then : 
            count1 == 1
//            count2 == 2
            count3 == 2
            count4 == 3
    }
    
    def "test house keeping"() {
        
        given :
            def last = new Date()
            insertMessage([id: 123, channel: 'DISPATCH', create_timestamp: last,          status: 'RECEIVED'], [:])
            insertMessage([id: 122, channel: 'DISPATCH', create_timestamp: last.minus(3), status: 'RECEIVED'], [:])
            mi.afterPropertiesSet();
            
        when : 
            def count1 = mi.count(new MatchAllDocsQuery())
            deleteData(122L);
            def count2 = mi.count(new MatchAllDocsQuery())
            mi.houseKeeping()
            def count3 = mi.count(new MatchAllDocsQuery())
            
        then : 
            count1 == 2
            count2 == 2
            count3 == 1
    }
    
    def "test old index reader will eventually be closed"() {
//        this is an indirect test, through count of files
        given :
            def last = new Date()
            insertMessage([id: 123, channel: 'DISPATCH', create_timestamp: last,          status: 'RECEIVED'], [:])
            insertMessage([id: 122, channel: 'DISPATCH', create_timestamp: last.minus(3), status: 'RECEIVED'], [:])
            mi.afterPropertiesSet();
            
        when :
            def c1 = mi.count(new MatchAllDocsQuery())
            insertMessage([id: 125, channel: 'DISPATCH', create_timestamp: last.plus(1), status: 'RECEIVED'], [:])
            mi.crawlIncrementalFromDatabase()
            def c2 = mi.count(new MatchAllDocsQuery())
            def fc1 = mi.indexFolder.listFiles().length
            deleteData(122L)
            mi.houseKeeping()
            def c3 = mi.count(new MatchAllDocsQuery())
            def fc2 = mi.indexFolder.listFiles().length
            
        then :
            c1 == 2
            c2 == 3
            c3 == 2
            fc2 <= fc1
    }
    
    def "test live store"() {
        given :
            insertMessage([id: 123L, tracking_id: 'FX_CASH_oid-123_123_456', channel: 'DISPATCH', create_timestamp: new Date(), status: 'RECEIVED', source_sys_id: 'FX_IN'], [S2BX_ID: 's2bx123', messageType: 'NACK']);
            insertTicket([id: 4444L, creator: '1510954', guid: 's', status:'Submitted', type:'TechnicalException', createdtimestamp: new Date(), description:'describe'], ["Interface ID": "ALM_MX3", "Application ID": "RT", "JPP_trackingId":"tid123"]);
            mi.afterPropertiesSet();
            def live = new LiveExceptionStore(
                messageIndex : mi,
                dataSource: dataSource,
                workingDirectory : workingDirectory,
                executorService: executorService,
                taskScheduler : taskScheduler)
            live.afterPropertiesSet()
            def restful = new AuditingRestfulWebService(messageIndex: mi, liveExceptionStore: live, ems2: ems2)
            
        when :
            def c1 = mi.count(new MatchAllDocsQuery())
            def d1 = live.count(new MatchAllDocsQuery())
            def d2 = live.count(new TermQuery(new Term("Application_ID", "RT")))
            def resp1 = restful.search(null, "ids", toURIInfo([user: "1439970", xtype: 'mls', firstResult: 0, maxResults: 20, sort: "createdtimestamp"], null))
            def resp2 = restful.search(null, "ids", toURIInfo([user: "1439970", xtype: 'murex', firstResult: 0, maxResults: 20, sort: "create_timestamp"], null))
            live.onActionPerformed(new MurexExceptionActionPerformEvent(action: 'replay', targetId: '123'))
            def resp3 = restful.search(null, "ids", toURIInfo([user: "1439970", status: 'replayed', xtype: 'murex', firstResult: 0, maxResults: 20, sort: "create_timestamp"], null))
            def resp4 = restful.search(null, "idAndStatus", toURIInfo([user: "1439970", status: 'new', xtype:'mls'], null))
            def resp5 = restful.search(null, "count", toURIInfo([user: "1439970", status: 'new', xtype:'mls', customFilter: 'Application ID;EQUALS;RT'], null))
            def resp6 = restful.search(null, "count", toURIInfo([user: "1439970", status: 'new', xtype:'mls', customFilter: 'Application ID;EQUALS;NONEXISTING'], null))
            
        then :
            c1 == 1
            d1 == 2
            d2 == 1
            resp1 == [4444]
            resp2 == [123]
            resp3 == [123]
            resp4.findAll{it.id == 4444 && it.status == 'new'}.size() == 1
            resp5 == 1
            resp6 == 0
    }
    
    def "test live store search by tradeId"() {
        given :
            insertMessage([id: 123L, tracking_id: 'MX_FXCASH_43906701|2|NOTNEW _67494547_1467616074949', channel: 'DISPATCH', create_timestamp: new Date(), status: 'RECEIVED', source_sys_id: 'FRTP'], [messageType: 'NACK']);
            insertMessage([id: 234L, tracking_id: 'MX_FXCASH_43906701 _67494547_1467616074949', channel: 'DISPATCH', create_timestamp: new Date().plus(1), status: 'RECEIVED', source_sys_id: 'FRTP'], [messageType: 'NACK']);
            mi.afterPropertiesSet();
            def live = new LiveExceptionStore(
                messageIndex : mi,
                dataSource: dataSource,
                workingDirectory : workingDirectory,
                executorService: executorService,
                taskScheduler : taskScheduler)
            live.afterPropertiesSet()
            def restful = new AuditingRestfulWebService(messageIndex: mi, liveExceptionStore: live, ems2: ems2)
            
        when :
            def c1 = restful.search("43906701", "ids", toURIInfo([user: "1439970", xtype: 'murex', firstResult: 0, maxResults: 20, sort: "-create_timestamp"], null))
            def c2 = restful.search("43906701|2|NOTNEW", "ids", toURIInfo([user: "1439970", xtype: 'murex', firstResult: 0, maxResults: 20, sort: "-create_timestamp"], null))
            
        then :
            c1 == [234, 123]
            c2 == [123]
    }
    
    def "test live store permission for viewing mls exception"() {
        given :
            insertMessage([id: 123L, tracking_id: 'MX_FXCASH_43906701|2|NOTNEW _67494547_1467616074949', channel: 'DISPATCH', create_timestamp: new Date(), status: 'RECEIVED', source_sys_id: 'FRTP'], [messageType: 'NACK']);
            insertTicket([id: 1L, creator: '1510954', guid: 's1', status:'Submitted', type:'TechnicalException', createdtimestamp: new Date(), description:'describe'], ["Interface ID": "ALM_MX3", "Application ID": "RT", "JPP_trackingId":"tid123"])
            insertTicket([id: 2L, creator: '1510954', guid: 's2', status:'Submitted', type:'MalformattedException', createdtimestamp: new Date().plus(1), description:'describe'], ["Interface ID": "ALM_MX3", "Application ID": "RT", "JPP_trackingId":"tid122"])
            mi.afterPropertiesSet();
            def live = new LiveExceptionStore(
                messageIndex : mi,
                dataSource: dataSource,
                workingDirectory : workingDirectory,
                executorService: executorService,
                taskScheduler : taskScheduler)
            live.afterPropertiesSet()
            def restful = new AuditingRestfulWebService(messageIndex: mi, liveExceptionStore: live, ems2: ems2)
            
        when :
            def c1 = restful.search("", "ids", toURIInfo([user: "1439970", xtype: 'mls', firstResult: 0, maxResults: 20, sort: "-createdtimestamp"], null))
            def c2 = restful.search("", "ids", toURIInfo([user: "1439971", xtype: 'mls', firstResult: 0, maxResults: 20, sort: "-createdtimestamp"], null))
            
        then :
            c1 == [1] //1439970 has only permisson to view TechnicalException
            c2 == [2, 1] //1439971 has permission to view both TechnicalException and MalformattedException
    }
    
    def insertMessage(value, properties) {
        if(!value["id"]) value["id"] = ++idseq
        def a = [], b = [], c = []
        value.each {k, v -> a.push(k); b.push(v); c.push("?")}
        def jt = new JdbcTemplate(dataSource)
        jt.update("INSERT INTO MESSAGE (" + a.join(",") + ") values (" + c.join(",") + ")", b.toArray())
        properties.eachWithIndex {entry,i -> jt.update("insert into MESSAGE_PROPERTY (ID, MESSAGE_ID, KEY, VALUE) values(?, ?, ?, ?)", ++idseq, value["id"], entry.key, entry.value)}
    }
    
    def insertTicket(Map value, Map properties) {
        if(!value["id"]) value["id"] = ++idseq
        def a = [], b = [], c = []
        value.each {k, v -> a.push(k); b.push(v); c.push("?")}
        def jt = new JdbcTemplate(dataSource)
        jt.update("INSERT INTO SCB_TICKET (" + a.join(",") + ") values (" + c.join(",") + ")", b.toArray())
        properties.eachWithIndex {entry,i -> jt.update("insert into SCB_TICKET_TAG (ID, TICKET_ID, TAGNAME, TAGVALUE) values(?, ?, ?, ?)", ++idseq, value["id"], entry.key, entry.value)}
    }
    
    def deleteData(Long id) {
        def jt = new JdbcTemplate(dataSource)
        jt.update("DELETE MESSAGE WHERE ID=?", id);
        jt.update("DELETE MESSAGE_PROPERTY WHERE MESSAGE_ID=?", id);
    }
    
    def toURIInfo(Map<String, String> queryParams, URI uri) {
        return [
            getQueryParameters: {
                MultivaluedMapImpl impl = new MultivaluedMapImpl();
                queryParams.each { entry ->
                    impl.putSingle(entry.key, entry.value)
                }
                return impl
            },
            getAbsolutePath : {return uri == null ? URI.create("http://localhost/test?abc") : uri},
            getRequestUri : {return uri == null ? URI.create("http://localhost/test?abc") : uri}
        ] as UriInfo
    }
}
