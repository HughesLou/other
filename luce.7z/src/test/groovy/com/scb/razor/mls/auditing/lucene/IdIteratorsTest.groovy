package com.scb.razor.mls.auditing.lucene

import java.sql.ResultSet
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;

import spock.lang.Specification;

class IdIteratorsTest extends Specification {

    def "test #fromList"() {
        given : 
            def a = IdIterators.fromList(new ArrayList<Long>())
            def b = IdIterators.fromList(Arrays.asList(1L))
            def c = IdIterators.fromList(Arrays.asList("1L", "2L"))
        
        when :
            def a_has = a.hasNext()
            def b_has = b.hasNext()
            def c_has = c.hasNext()
            def b_1 = b.next()
            def c_1 = c.next()
            def b_has_2 = b.hasNext()
            def c_has_2 = c.hasNext()
            
        then :
            a_has == false
            b_has == true
            c_has == true
            b_1 == 1L
            c_1 == "1L"
            b_has_2 == false
            c_has_2 == true
    }
    
    def "test #excepts"() {
        given : 
            def a = IdIterators.fromList(Arrays.asList("1L", "2L"))
            def b = IdIterators.excepts(a, Arrays.asList("1L"))
            
        when :
            def b_has = b.hasNext()
            def b_1 = b.next()
            def b_has_2 = b.hasNext()
            
        then :
            b_has == true
            b_1 == "2L"
            b_has_2 == false
    }
    
    def "test #fromQuery"() {
        given :
            def ds = new SingleConnectionDataSource(
                driverClassName: "org.h2.Driver",
                username: "sa",
                password: "sa",
                url: "jdbc:h2:mem:;MODE=Oracle;DB_CLOSE_ON_EXIT=FALSE"
            )
            def jt = new JdbcTemplate(ds);
            jt.execute("create table aaa (id int primary key, kkey varchar(255), kvalue varchar(255))");
            jt.execute("insert into aaa values(1, 'k', 'v')")
            jt.execute("insert into aaa values(2, 'k2', 'v2')")
            
        when :
            def a = IdIterators.fromQuery("select id from aaa", ds, {ResultSet rs-> rs.getInt("id")})
            def a_has = a.hasNext()
            def a_1 = a.next()
            def a_has_2 = a.hasNext()
            def a_2 = a.next()
            def a_has_3 = a.hasNext()
        
        then : 
            a_has == true
            a_has_2 == true
            a_has_3 == false
            a_1 == 1
            a_2 == 2
    }
    
    def "test #fromNamedParamQuery"() {
        given :
            def ds = new SingleConnectionDataSource(
                driverClassName: "org.h2.Driver",
                username: "sa",
                password: "sa",
                url: "jdbc:h2:mem:xtest;MODE=Oracle;DB_CLOSE_ON_EXIT=FALSE"
            )
            def jt = new JdbcTemplate(ds);
            jt.execute("create table aaa (id int primary key, kkey varchar(255), kvalue varchar(255))");
            jt.execute("insert into aaa values(1, 'k', 'v')")
            jt.execute("insert into aaa values(2, 'k2', 'v2')")
            
        when :
            def a = IdIterators.fromNamedParamQuery("select id from aaa where kkey=:key", ["key":"k"],ds, {ResultSet rs-> rs.getInt("id")})
            def a_has = a.hasNext()
            def a_1 = a.next()
            def a_has_2 = a.hasNext()
        
        then : 
            a_has == true
            a_has_2 == false
            a_1 == 1
    }
    
    def "test jdbc connection will be closed after use"() {
        given :
            def ds = new SingleConnectionDataSource(
                driverClassName: "org.h2.Driver",
                username: "sa",
                password: "sa",
                url: "jdbc:h2:mem:xtest;MODE=Oracle;DB_CLOSE_ON_EXIT=FALSE",
                suppressClose: false
            )
            def conn = ds.getConnection()
            def jt = new JdbcTemplate(ds)
            jt.execute("create table aaa (id int primary key, kkey varchar(255), kvalue varchar(255))")
            jt.execute("insert into aaa values(1, 'k', 'v')")
            
        when :
            def c1 = conn.isClosed()
            def a = IdIterators.fromNamedParamQuery("select id from aaa where kkey=:key", ["key":"k"],ds, {ResultSet rs-> rs.getInt("id")})
            def c2 = conn.isClosed()
            while(a.hasNext()) {
                a.next()
            }
            def c3 = conn.isClosed()
        
        then :
            c1 == false
            c2 == false
            c3 == true
    }
}
