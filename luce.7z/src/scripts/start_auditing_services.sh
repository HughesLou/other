#!/bin/bash
export JETTY_INSTALL_ROOT=/razorapp/scb/mls/tools/jetty
export APP_INSTALL_ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
export APP_COMMON_CONFIG=$APP_INSTALL_ROOT/../../../mls-config
export APP_CONFIG=$APP_INSTALL_ROOT/configuration

cd $APP_INSTALL_ROOT

/usr/local/java/jdk1.7.0_25_64/bin/java -DmlsConfig=$APP_COMMON_CONFIG -Dconfiguration=$APP_CONFIG \
    -Dlog4j.auditing.config.location=$APP_CONFIG -Xmx512M -Xms512M -XX:-ReduceInitialCardMarks \
    -XX:MaxPermSize=256M -Duser.timezone=GMT -Djetty.home=$JETTY_INSTALL_ROOT \
    -Dorg.apache.jasper.compiler.disablejsr199=true -Dapp.install.root=$APP_INSTALL_ROOT \
    -Dauditing-services=yes -jar $JETTY_INSTALL_ROOT/start.jar $APP_CONFIG/jetty.xml > /dev/null 2>&1 &