#!/bin/bash
pkill -f auditing-service
