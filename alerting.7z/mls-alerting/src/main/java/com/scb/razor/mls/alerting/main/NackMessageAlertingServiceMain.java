package com.scb.razor.mls.alerting.main;

import com.scb.razor.mls.alerting.service.impl.NackMessageAlertingServiceImpl;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Created with IntelliJ IDEA.
 * User: 1439970
 * Date: 3/27/15
 * Time: 9:34 AM
 * To change this template use File | Settings | File Templates.
 */
public class NackMessageAlertingServiceMain {
    public static void main(String[] args)
    {
        @SuppressWarnings("resource")
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
                "classpath:applicationContext-alerting-nack.xml");
        context.refresh();
        context.registerShutdownHook();

        final ScheduledExecutorService nackScheduler = Executors.newSingleThreadScheduledExecutor();
        final NackMessageAlertingServiceImpl nackMessageAlertingService = context.getBean(NackMessageAlertingServiceImpl.class);
        nackScheduler.scheduleAtFixedRate(new Runnable() {
            public void run()
            {
                nackMessageAlertingService.nackMessageAlerting();
            }
        }, Long.parseLong(nackMessageAlertingService.getInitialDelay()), Long.parseLong(nackMessageAlertingService.getAlertingInterval()), TimeUnit.SECONDS);
    }
}
