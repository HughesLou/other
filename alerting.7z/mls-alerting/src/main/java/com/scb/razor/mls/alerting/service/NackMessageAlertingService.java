package com.scb.razor.mls.alerting.service;

import com.scb.razor.mls.persistent.model.Message;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
* Created with IntelliJ IDEA.
* User: 1439970
* Date: 3/24/15
* Time: 4:07 PM
* To change this template use File | Settings | File Templates.
*/
public interface NackMessageAlertingService {
    /**
     * Get message map which key is source system id and
     * value is the list of nack messages
     * @return
     */
    Map<String,Set<Message>> getNackMessageMapNeedToAlert();

    void nackMessageAlerting();

    List<Message> getNackMessagesNeedToAlert();

}
