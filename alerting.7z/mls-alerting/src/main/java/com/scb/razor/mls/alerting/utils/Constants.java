package com.scb.razor.mls.alerting.utils;

import com.scb.razor.mls.common.constants.MLS;

/**
 * TODO: Briefly explain what this class does
 * 
 * @author: 1467422
 */
public class Constants
{
    public static final String EXCEPTION_STATUS_SUBMITTED = "'Submitted'";
    public static final String TECHNICAL_EXCEPTION = "Technical Exception";
    public static final String STATIC_MAPPING_DATA_MISSING_EXCEPTION = "Static Mapping Data Missing";
    public static final String MALFORMATTED_EXCEPTION = "Malformatted Exception";

    public static final String APPLICATION_ID = "Application ID";
    public static final String INTERFACE_ID = "Interface ID";
    public static final String JPP_TRACKINGID = "JPP_trackingId";
    public static final String JPP_CAPTURESYSTEM = "JPP_captureSystem";
    public static final String JPP_BOOKINGSYSTEM = "JPP_bookingSystem";
    public static final String JPP_SENDER = "JPP_sender";
    public static final String JPP_S2BX_ID = "JPP_S2BX_ID";

    public static final String TRACKINGID = "trackingId";
    public static final String CAPTURESYSTEM = "captureSystem";
    public static final String BOOKINGSYSTEM = "bookingSystem";
    public static final String SENDER = "sender";
    public static final String S2BX_ID = "S2BX_ID";

    public static final String MUREX = "Murex";
    public static final String MXG2000 = "MXG2000";
    public static final String UNKNOWN = "Unknown";

    public static final String[] INTERFACE_ID_WITH_CAPTURE_SYSTEM = {MLS.Interface.ALM_OUT.name(),MLS.Interface.FX_OUT.name(),
                                                                     MLS.Interface.ALM_MX3.name(),MLS.Interface.FX_MX3.name(),
                                                                     MLS.Interface.ALM_IN.name(),MLS.Interface.FX_IN.name()};
    public static final String[] INTERFACE_ID_WITH_BOOKING_SYSTEM = {MLS.Interface.ALM_REALM.name(),
                                                                     MLS.Interface.FX_REALM.name()};
    public static final String[] INTERFACE_ID_WITH_SENDER = {MLS.Interface.ALM_SSI.name(),MLS.Interface.FX_SSI.name(),
                                                             MLS.Interface.CALENDAR.name(),MLS.Interface.CTPY.name()};

    public static final String NACK_MESSAGE_TYPE = "NACK";
}
