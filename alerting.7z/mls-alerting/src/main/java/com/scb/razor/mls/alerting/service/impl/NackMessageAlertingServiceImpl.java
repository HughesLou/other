package com.scb.razor.mls.alerting.service.impl;

import com.scb.razor.mls.alerting.service.NackMessageAlertingService;
import com.scb.razor.mls.common.constants.MLS;
import com.scb.razor.mls.common.mail.service.MailService;
import com.scb.razor.mls.common.message.MlsMessage;
import com.scb.razor.mls.persistent.dao.MessageDao;
import com.scb.razor.mls.persistent.model.Message;
import com.scb.razor.mls.persistent.model.MessageProperty;
import com.scb.razor.mls.persistent.search.AuditingSearchCriteria;
import org.apache.commons.lang.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

import static com.scb.razor.mls.alerting.utils.Constants.*;

/**
* Created with IntelliJ IDEA.
* User: 1439970
* Date: 3/24/15
* Time: 5:28 PM
* To change this template use File | Settings | File Templates.
*/
@Service
public class NackMessageAlertingServiceImpl implements NackMessageAlertingService
{

    private static final Logger logger       = LoggerFactory.getLogger(AlertingServiceImpl.class);

    @Value("${alertingInterval}")
    private String alertingInterval = null;

    @Value("${initialDelay}")
    private String initialDelay = null;

    @Autowired
    private MessageDao messageDaoImpl = null;

    public void setMessageDaoImpl(MessageDao messageDaoImpl) {
        this.messageDaoImpl = messageDaoImpl;
    }

    @Autowired
    @Qualifier(value="mailServiceMlsMesLinuxImpl")
    private MailService<MlsMessage> mailServiceMlsMesLinuxImpl = null;

    public String getAlertingInterval() {
        return alertingInterval;
    }

    public String getInitialDelay() {
        return initialDelay;
    }

    @Transactional(readOnly = true)
    public List<Message> getNackMessagesNeedToAlert()
    {
        AuditingSearchCriteria auditingSearchCriteria = new AuditingSearchCriteria();
        auditingSearchCriteria.setAlert(false);
        auditingSearchCriteria.setMessageType(NACK_MESSAGE_TYPE);
        List<Message> nackMessageListNeedAlert = messageDaoImpl.searchNackMessageNeedToAlert(auditingSearchCriteria);
        return nackMessageListNeedAlert;
    }

    @Transactional
    public void nackMessageAlerting()
    {
        final List<Message> messagesMapNeedAlert = getNackMessagesNeedToAlert();
        final List<MlsMessage> mlsMessageList = new ArrayList<>();

        if (!messagesMapNeedAlert.isEmpty())
        {
            int updateAmount;
            final Set<Message> mlsMessageSetNeedToUpdate = new HashSet<>();

            aggregateMessageToMlsMessageTemp(messagesMapNeedAlert, mlsMessageList);
            Set<String> nackMessagesWithSendingSuccessful= mailServiceMlsMesLinuxImpl.sendSimpleEMail(mlsMessageList);

            Set<Message> messageSetNeedToUpdate = getmessagesNeedToBeUpdated(messagesMapNeedAlert, nackMessagesWithSendingSuccessful);
            mlsMessageSetNeedToUpdate.addAll(messageSetNeedToUpdate);

            //batchly update exception flag in the database from unalerted to alerted.
            logger.info("Starting with batchly updating the alert flags to true for the messages and size is {}",
            mlsMessageSetNeedToUpdate.size());

            for(Message message : mlsMessageSetNeedToUpdate){
                message.setAlert(true);
            }
            updateAmount = messageDaoImpl.updateMessageAlert(mlsMessageSetNeedToUpdate);

            logger.info("Batchly update the alert flag of messages successfully with the amount {}",updateAmount);
        }
    }

    private void aggregateMessageToMlsMessageTemp(List<Message> messageList, List<MlsMessage> mlsMessageList)
    {
        for(Message message : messageList){

            MlsMessage mlsMessage = new MlsMessage();

            mlsMessage.setId(message.getId());
            mlsMessage.setTrackingId(message.getTrackingId());
            mlsMessage.setSourceSysId(message.getSourceSysId().name());
            mlsMessage.setStatus(message.getStatus().name());
            mlsMessage.setTimeStamp(message.getCreateTimeStamp());
            mlsMessage.setChannel(message.getChannel().name());

            setCaptureSystemAndDealId(message, mlsMessage);

            mlsMessageList.add(mlsMessage);
        }
    }

    private void setCaptureSystemAndDealId(Message message, MlsMessage mlsMessage) {
        String fieldName = null;
        String sourceSysId = mlsMessage.getSourceSysId();
        mlsMessage.setDealId(message.getTrackingId());

        if(ArrayUtils.contains(INTERFACE_ID_WITH_CAPTURE_SYSTEM, sourceSysId))
            fieldName = CAPTURESYSTEM;
        else if(ArrayUtils.contains(INTERFACE_ID_WITH_BOOKING_SYSTEM, sourceSysId))
            fieldName = BOOKINGSYSTEM;
        else if(ArrayUtils.contains(INTERFACE_ID_WITH_SENDER, sourceSysId))
            fieldName = SENDER;

        for(MessageProperty messageProperty : message.getMessageProperties()) {
            String key = messageProperty.getKey();
            String value = messageProperty.getValue();

            if(key.equals(S2BX_ID) && mlsMessage.getDealId() == null)
                mlsMessage.setDealId(value);
            else if(key.equals(fieldName))
                mlsMessage.setCaptureSystem(value);
        }

        if(mlsMessage.getDealId() == null)
            mlsMessage.setDealId(UNKNOWN);
        if(mlsMessage.getCaptureSystem() == null) {
            if(sourceSysId.equals(MLS.Interface.ALM_PDC.name()) ||
                    sourceSysId.equals(MLS.Interface.FX_PDC.name())) {
                mlsMessage.setCaptureSystem(MUREX);
            } else if(sourceSysId.equals(MLS.Interface.FRTP.name())) {
                mlsMessage.setCaptureSystem(MXG2000);
            } else if(sourceSysId.equals(MLS.Interface.ALM_IN.name()) ||
                    sourceSysId.equals(MLS.Interface.FX_IN.name())) {
                for(MessageProperty messageProperty : message.getMessageProperties()) {
                    String key = messageProperty.getKey();
                    String value = messageProperty.getValue();

                    if(key.equals(SENDER))
                        mlsMessage.setCaptureSystem(value);
                }
            } else if(sourceSysId.equals(MLS.Interface.FX_OUT.name()) ||
                    sourceSysId.equals(MLS.Interface.ALM_OUT.name())) {
                for(MessageProperty messageProperty : message.getMessageProperties()) {
                    String key = messageProperty.getKey();
                    String value = messageProperty.getValue();

                    if(key.equals(BOOKINGSYSTEM))
                        mlsMessage.setCaptureSystem(value);
                }
            } else {
                mlsMessage.setCaptureSystem(UNKNOWN);
            }
        }

    }

    private Set<Message> getmessagesNeedToBeUpdated(List<Message> messageList, Set<String> mlsMessageIdList)
    {
        Set<Message> messagesNeedToBeUpdated = new HashSet<Message>();
        for(Message message : messageList){
            String messageId = String.valueOf(message.getId());
            if(mlsMessageIdList.contains(messageId)){
                messagesNeedToBeUpdated.add(message);
            }
        }
        return messagesNeedToBeUpdated;
    }

    public Map<String, Set<Message>> getNackMessageMapNeedToAlert() {
        // TODO Auto-generated method stub
        return null;
    }
}
