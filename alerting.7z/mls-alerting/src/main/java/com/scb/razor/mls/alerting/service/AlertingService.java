package com.scb.razor.mls.alerting.service;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;

import com.scb.sabre.ticketing.domain.TicketDM;

/**
 * TODO: Briefly explain what this class does
 * 
 * @author: 1467422
 */  
public interface AlertingService
{

    /**
     * Get exceptions map which key is exception category and
     * value is the list of MLS exceptions
     * @return
     */
    Map<String,Set<TicketDM>> getExceptionsMapNeedToAlert();
    
    void exceptionAlerting(ExecutorService executorService);
    
    List<TicketDM> getExceptionsNeedToAlert();

}
