package com.scb.razor.mls.alerting.main;

import com.scb.razor.mls.alerting.service.*;
import com.scb.razor.mls.alerting.service.impl.*;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * TODO: Briefly explain what this class does
 * 
 * @author: 1467422
 */
public class AlertingServiceMain
{
    public static void main(String[] args)
    {
        @SuppressWarnings("resource")
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
                "classpath:applicationContext-alerting.xml");
        context.refresh();
        context.registerShutdownHook();

        final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
        final AlertingServiceImpl alertingService = (AlertingServiceImpl)context.getBean(AlertingService.class);
        final ExecutorService executorService = Executors.newFixedThreadPool(1);
        scheduler.scheduleAtFixedRate(new Runnable() {
            public void run()
            {
                alertingService.exceptionAlerting(executorService);
            }
        }, Long.parseLong(alertingService.getInitialDelay()), Long.parseLong(alertingService.getAlertingInterval()), TimeUnit.SECONDS);
    }
}
