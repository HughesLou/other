package com.scb.razor.mls.alerting.service.impl;

import com.scb.razor.mls.alerting.service.AlertingService;
import com.scb.razor.mls.common.constants.MLS;
import com.scb.razor.mls.common.exception.ExceptionCategory;
import com.scb.razor.mls.common.exception.MlsException;
import com.scb.razor.mls.common.mail.service.MailService;
import com.scb.sabre.ticketing.domain.TicketDM;
import com.scb.sabre.ticketing.domain.TicketTagDM;
import com.scb.sabre.ticketing.domain.repository.TicketRepository;
import com.scb.sabre.ticketing.domain.repository.TicketSearchCriteria;
import org.apache.commons.lang.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;

import static com.scb.razor.mls.alerting.utils.Constants.*;
import static com.scb.razor.mls.common.constants.CommonConsts.EXCEPTION_ID_PREFIX;

@Service
public class AlertingServiceImpl implements AlertingService
{

    private static final Logger logger       = LoggerFactory.getLogger(AlertingServiceImpl.class);

    @Value("${technical.exception.action.message}")
    private String technicalActionRequired = null;

    @Value("${static.mapping.data.missing.action.message}")
    private String staticMappingDataMissingActionRequired = null;

    @Value("${malformatted.exception.action.message}")
    private String malformattedActionRequired = null;

    @Value("${unclassified.exception.action.message}")
    private String unclassifiedActionRequired = null;

    @Value("${alertingInterval}")
    private String alertingInterval;
    
    @Value("${initialDelay}")
    private String initialDelay;
    
    @Autowired
    private TicketRepository        ticketRepository;

    private TransactionTemplate  transactionTemplate;
    
    @Autowired
    @Qualifier(value="mailServiceMlsExpLinuxImpl")
    private MailService<MlsException> mailServiceMlsExpLinuxImpl = null;
//    @Autowired
//    @Qualifier("mailServiceMlsExpWindowsImpl")
//    private MailService<MlsException> mailServiceMlsExpWindowsImpl;
    
    public TicketRepository getTicketRepository() {
		return ticketRepository;
	}

	public void setTicketRepository(TicketRepository ticketRepository) {
		this.ticketRepository = ticketRepository;
	}

	public TransactionTemplate getTransactionTemplate() {
		return transactionTemplate;
	}

    public void setTransactionManager(PlatformTransactionManager transactionManager) {
        this.transactionTemplate = new TransactionTemplate(transactionManager);
    }

//	public MailService<MlsException> getMailServiceSailExpLinuxImpl() {
//		return mailServiceSailExpLinuxImpl;
//	}
//
//	public void setMailServiceSailExpLinuxImpl(
//			MailService<MlsException> mailServiceSailExpLinuxImpl) {
//		this.mailServiceSailExpLinuxImpl = mailServiceSailExpLinuxImpl;
//	}

	public String getAlertingInterval() {
		return alertingInterval;
	}
	
	public String getInitialDelay() {
		return initialDelay;
	}

	/**
     * @see
     * com.scb.razor.mls.alerting.service.AlertingService#getExceptionsMapNeedToAlert()
     */
//    public Map<String, Set<TicketDM>> getExceptionsMapNeedToAlert()
//    {
//    	TicketSearchCriteria ticketSearchCriteria = new TicketSearchCriteria();
//    	ticketSearchCriteria.setAlert(false);
//    	List<String> statuses = new ArrayList<String>();
//    	statuses.add(EXCEPTION_STATUS_SUBMITTED);
//    	ticketSearchCriteria.setStatuses(statuses);
//        List<TicketDM> mlsExceptionListNeedAlert = ticketRepository.searchTicketsNeedToAlert(ticketSearchCriteria);
//        Map<String,Set<TicketDM>> exceptionMapNeedAlert = new HashMap<String,Set<TicketDM>>();
//        String exceptionCategory = null;
//        for(TicketDM mlsException : mlsExceptionListNeedAlert){
//            exceptionCategory = mlsException.getType();
//            if(!exceptionMapNeedAlert.keySet().contains(exceptionCategory)){
//            	Set<TicketDM> mlsExceptionList = new HashSet<TicketDM>();
//            	mlsExceptionList.add(mlsException);
//                exceptionMapNeedAlert.put(exceptionCategory, mlsExceptionList);
//            } else {
//                exceptionMapNeedAlert.get(exceptionCategory).add(mlsException);
//            }
//        }
//        return exceptionMapNeedAlert;
//    }
    @Transactional(readOnly = true)
    public List<TicketDM> getExceptionsNeedToAlert()
    {
    	TicketSearchCriteria ticketSearchCriteria = new TicketSearchCriteria();
        List<String> statuses = new ArrayList<>();
    	statuses.add(EXCEPTION_STATUS_SUBMITTED);

    	ticketSearchCriteria.setStatuses(statuses);
        ticketSearchCriteria.setAlert(false);

        List<TicketDM> mlsExceptionListNeedAlert = ticketRepository.searchTicketsNeedToAlert(ticketSearchCriteria);


        return mlsExceptionListNeedAlert;
    }

    /**
     * 
     * @see
     * com.scb.razor.mls.alerting.service.AlertingService#exceptionAlerting
     * (java.util.Map)
     */
//    public void exceptionAlerting()
//    {
//        final Map<String, Set<TicketDM>> exceptionMapNeedAlert = getExceptionsMapNeedToAlert();
//        if (!exceptionMapNeedAlert.isEmpty())
//        {
//            @SuppressWarnings("unchecked")
//            final CountDownLatch counter = new CountDownLatch(exceptionMapNeedAlert.size());
//            Set<String> exceptionCategories =  exceptionMapNeedAlert.keySet();
//
//            final Set<TicketDM> mlsExceptionSetNeedToUpdate = new HashSet<TicketDM>();
//            
//            final ExecutorService executorService = Executors.newFixedThreadPool(exceptionMapNeedAlert.size());
//            for (final String exceptionCategory : exceptionCategories)
//            {
//                executorService.execute(new Runnable() {
//                    public void run()
//                    {
//                    	TicketDM mlsExceptionTemp = new TicketDM();
//                        Set<TicketDM> mlsExceptionSet = exceptionMapNeedAlert.get(exceptionCategory);
////                        aggregateMlsExceptionToMlsExceptionTemp(mlsExceptionSet, mlsExceptionTemp);
//                        mailServiceSailExpLinuxImpl.sendMail(mlsExceptionTemp);
//                        mlsExceptionSetNeedToUpdate.addAll(mlsExceptionSet);
//                        counter.countDown();
//                    }
//                });
//            }
//            int updateAmount;
//            try
//            {
//                counter.await();
//                    //batchly update exception flag in the database from unalerted to alerted.
////                    exceptionDao
//                logger.info("Starting with batchly updating the alert flags to true for the tickets and size is {}",mlsExceptionSetNeedToUpdate.size());
//                transactionTemplate.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
//                updateAmount = transactionTemplate.execute(new TransactionCallback<Integer>() {
//                    public Integer doInTransaction(final TransactionStatus status)
//                    {
//                        return ticketRepository.batchUpdateException(mlsExceptionSetNeedToUpdate);
//                    }
//                });
//                logger.info("Batchly update the alert flag of tickets successfully with the amount {}",updateAmount);
//            }
//            catch (InterruptedException e)
//            {
//                e.printStackTrace();
//            }
//            
//        }
//    }
    
    public void exceptionAlerting(final ExecutorService executorService)
    {
        final List<TicketDM> exceptionMapNeedAlert = getExceptionsNeedToAlert();
        final List<MlsException> mlsExceptionList = new ArrayList<>();
        if (!exceptionMapNeedAlert.isEmpty())
        {
            @SuppressWarnings("unchecked")
            final CountDownLatch counter = new CountDownLatch(1);

            final Set<TicketDM> mlsExceptionSetNeedToUpdate = new HashSet<TicketDM>();

            executorService.execute(new Runnable() {
                public void run() {
                    aggregateMlsExceptionToMlsExceptionTemp(exceptionMapNeedAlert, mlsExceptionList);
                    Set<String> exceptionsWithSendingSuccessful = mailServiceMlsExpLinuxImpl.sendSimpleEMail(mlsExceptionList);
                    Set<TicketDM> ticketSetNeedToUpdate = getTicketsNeedToBeUpdated(exceptionMapNeedAlert, exceptionsWithSendingSuccessful);
                    mlsExceptionSetNeedToUpdate.addAll(ticketSetNeedToUpdate);
                    counter.countDown();
                }
            });
            int updateAmount;
            try
            {
                counter.await();
                    //batchly update exception flag in the database from unalerted to alerted.
//                    exceptionDao
                logger.info("Starting with batchly updating the alert flags to true for the tickets and size is {}",mlsExceptionSetNeedToUpdate.size());
                transactionTemplate.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
                updateAmount = transactionTemplate.execute(new TransactionCallback<Integer>() {
                    public Integer doInTransaction(final TransactionStatus status)
                    {
                    	for(TicketDM ticket : mlsExceptionSetNeedToUpdate){
                    		ticket.setAlert(true);
                    	}
                        return ticketRepository.batchUpdateException(mlsExceptionSetNeedToUpdate);
                    }
                });
                logger.info("Batchly update the alert flag of tickets successfully with the amount {}",updateAmount);
            }
            catch (InterruptedException e)
            {
                e.printStackTrace();
            }
            
        }
    }

    private void aggregateMlsExceptionToMlsExceptionTemp(List<TicketDM> ticketList, List<MlsException> mlsExceptionList)
    {
    	for(TicketDM ticketDM : ticketList){

    		MlsException mlsException = new MlsException();

            //Set exception category and action required to MlsException.
            if(ticketDM.getType() != null) {
                if(ticketDM.getType().equals(ExceptionCategory.TechnicalException.toString())) {
                    mlsException.setMlsExceptionCategory(TECHNICAL_EXCEPTION);
                    mlsException.setActionRequired(technicalActionRequired);
                }else if(ticketDM.getType().equals(ExceptionCategory.StaticMappingDataMissing.toString())) {
                    mlsException.setMlsExceptionCategory(STATIC_MAPPING_DATA_MISSING_EXCEPTION);
                    mlsException.setActionRequired(staticMappingDataMissingActionRequired);
                }else if(ticketDM.getType().equals(ExceptionCategory.MalformattedException.toString())) {
                    mlsException.setMlsExceptionCategory(MALFORMATTED_EXCEPTION);
                    mlsException.setActionRequired(malformattedActionRequired);
                }else{
                    mlsException.setMlsExceptionCategory(ticketDM.getType());
                    mlsException.setActionRequired(unclassifiedActionRequired);
                }
            }else {
                logger.error("The type of exception {} should not be null!",EXCEPTION_ID_PREFIX+String.valueOf(ticketDM.getId()));
                continue;
            }

            //Set raised time to MlsException.
	        Calendar calendar = Calendar.getInstance();
	        calendar.setTime(ticketDM.getCreatedTimestamp());
	        mlsException.setRaisedTime(calendar);

            //Set applicationId and interfaceId to MlsException
            for(TicketTagDM ticketTagDM : ticketDM.getTicketTags()) {
                String tagName = ticketTagDM.getTagName();
                String tagValue = ticketTagDM.getTagValue();
                switch (tagName) {
                    case APPLICATION_ID:
                        mlsException.setApplicationId(tagValue);
                        break;
                    case INTERFACE_ID:
                        mlsException.setInterfaceId(tagValue);
                        break;
                    default:
                }
            }

            //Set captureSystem and dealId to MlsException
            setCaptureSystemAndDealId(ticketDM, mlsException);

            //Set other attributes to MlsException.
            mlsException.setExceptionId(EXCEPTION_ID_PREFIX+String.valueOf(ticketDM.getId()));
            mlsException.setExceptionSummary(ticketDM.getDescription());

            mlsExceptionList.add(mlsException);
    	}
    }

    private void setCaptureSystemAndDealId(TicketDM ticketDM, MlsException mlsException) {
        String fieldName = null;
        String interfaceId = mlsException.getInterfaceId();

        if(ArrayUtils.contains(INTERFACE_ID_WITH_CAPTURE_SYSTEM, interfaceId))
            fieldName = JPP_CAPTURESYSTEM;
        else if(ArrayUtils.contains(INTERFACE_ID_WITH_BOOKING_SYSTEM, interfaceId))
            fieldName = JPP_BOOKINGSYSTEM;
        else if(ArrayUtils.contains(INTERFACE_ID_WITH_SENDER, interfaceId))
            fieldName = JPP_SENDER;

        for(TicketTagDM ticketTagDM : ticketDM.getTicketTags()) {
            String tagName = ticketTagDM.getTagName();
            String tagValue = ticketTagDM.getTagValue();

            if(tagName.equals(JPP_TRACKINGID))
                mlsException.setDealId(tagValue);
            else if(tagName.equals(JPP_S2BX_ID))
                mlsException.setDealId(tagValue);
            else if(tagName.equals(fieldName))
                mlsException.setCaptureSystem(tagValue);
        }

        if(mlsException.getDealId() == null)
            mlsException.setDealId(UNKNOWN);
        if(mlsException.getCaptureSystem() == null) {
            if(MLS.Interface.ALM_PDC.name().equals(interfaceId) ||
                    MLS.Interface.FX_PDC.name().equals(interfaceId)) {
                mlsException.setCaptureSystem(MUREX);
            } else if(MLS.Interface.FRTP.name().equals(interfaceId)) {
                mlsException.setCaptureSystem(MXG2000);
            } else if(MLS.Interface.ALM_IN.name().equals(interfaceId) ||
                    MLS.Interface.FX_IN.name().equals(interfaceId)) {
                for(TicketTagDM ticketTagDM : ticketDM.getTicketTags()) {
                    String tagName = ticketTagDM.getTagName();
                    String tagValue = ticketTagDM.getTagValue();

                    if(tagName.equals(JPP_SENDER))
                        mlsException.setCaptureSystem(tagValue);
                }
            } else if(MLS.Interface.FX_OUT.name().equals(interfaceId) ||
                    MLS.Interface.ALM_OUT.name().equals(interfaceId)) {
                for(TicketTagDM ticketTagDM : ticketDM.getTicketTags()) {
                    String tagName = ticketTagDM.getTagName();
                    String tagValue = ticketTagDM.getTagValue();

                    if(tagName.equals(JPP_BOOKINGSYSTEM))
                        mlsException.setCaptureSystem(tagValue);
                }
            } else {
                mlsException.setCaptureSystem(UNKNOWN);
            }
        }
    }

    private Set<TicketDM> getTicketsNeedToBeUpdated(List<TicketDM> ticketList, Set<String> mlsExceptionIdList)
    {
    	Set<TicketDM> ticketsNeedToBeUpdated = new HashSet<TicketDM>();
    	for(TicketDM ticketDM : ticketList){
    		String ticketId = String.valueOf(ticketDM.getId());
    		if(mlsExceptionIdList.contains(ticketId)){
    			ticketsNeedToBeUpdated.add(ticketDM);
    		}
    	}
    	return ticketsNeedToBeUpdated;
    }
    
	public Map<String, Set<TicketDM>> getExceptionsMapNeedToAlert() {
		// TODO Auto-generated method stub
		return null;
	}
}
