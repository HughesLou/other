#!/bin/bash
kill -9 $(ps -ef | grep "main.NackMessageAlerting" | grep -v grep | awk '{print $2}')