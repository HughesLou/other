#!/bin/bash
export APP_INSTALL_ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
export APP_COMMON_CONFIG=$APP_INSTALL_ROOT/../../../mls-config

classpath=$APP_INSTALL_ROOT
for jar in `ls $APP_INSTALL_ROOT/lib`; do
    classpath=$classpath:$APP_INSTALL_ROOT/lib/$jar
done

classpath=$APP_COMMON_CONFIG:$APP_INSTALL_ROOT/configuration:$classpath
export CLASSPATH=$classpath
main_class="com.scb.razor.mls.alerting.main.AlertingServiceMain"

cd $APP_INSTALL_ROOT

/usr/local/java/jdk1.7.0_25_64/bin/java -Xmx512M -Dservice=exceptionAlerting $main_class > /dev/null 2>&1 &