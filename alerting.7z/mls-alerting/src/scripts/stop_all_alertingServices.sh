#!/bin/bash
./stop_alertingService.sh
./stop_nackMessageAlertingService.sh