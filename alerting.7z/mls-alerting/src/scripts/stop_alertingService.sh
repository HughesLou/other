#!/bin/bash
kill -9 $(ps -ef | grep "main.AlertingService" | grep -v grep | awk '{print $2}')