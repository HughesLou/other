#!/bin/bash
./start_alertingService.sh
./start_nackMessageAlertingService.sh