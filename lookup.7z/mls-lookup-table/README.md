#MLS-LOOKUP-TABLE


##Description:
maintain murex lookup table with 4 eye checking


##Build:


##Log: