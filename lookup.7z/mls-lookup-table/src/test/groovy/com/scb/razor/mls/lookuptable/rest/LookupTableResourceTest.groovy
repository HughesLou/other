package com.scb.razor.mls.lookuptable.rest

import com.google.common.cache.LoadingCache
import com.google.common.collect.Table
import com.scb.razor.mls.lookuptable.constant.Constants
import com.scb.razor.mls.lookuptable.model.Permission
import com.scb.razor.mls.lookuptable.model.Type
import com.scb.razor.mls.lookuptable.model.Type0
import com.scb.razor.mls.lookuptable.service.CacheService
import org.apache.commons.dbcp2.BasicDataSource
import org.springframework.jdbc.core.JdbcTemplate
import spock.lang.Shared
import spock.lang.Specification

/**
 * Created by 1466811 on 8/22/2016.
 */
class LookupTableResourceTest extends Specification {
    @Shared
    LookupTableResource lookupTableResource

    void setup() {
        BasicDataSource almDataSource = new BasicDataSource(
                driverClassName: "oracle.jdbc.OracleDriver",
                username: "MX3_ALM_UAT_72",
                password: "MX3_ALM_UAT_72_123",
                url: "jdbc:oracle:thin:@uklpdudasa-scan.uk.standardchartered.com:1622/" +
                        "MX3_ALM_FI_UAT.uk.standardchartered.com",
                minIdle: 5,
                maxIdle: 10,
                initialSize: 5,
                logAbandoned: true)
        BasicDataSource fxDataSource = new BasicDataSource(
                driverClassName: "oracle.jdbc.OracleDriver",
                username: "MX3_FX_UAT_72",
                password: "MX3_FX_UAT_72_123",
                url: "jdbc:oracle:thin:@uklpdudasa-scan.uk.standardchartered.com:1622/" +
                        "MX3_FX_FI_UAT.uk.standardchartered.com",
                minIdle: 5,
                maxIdle: 10,
                initialSize: 5,
                logAbandoned: true)
        LoadingCache<Constants.MUREX_INSTANCE, Map<Integer, Type>> types
        LoadingCache<Constants.MUREX_INSTANCE, Table<String, Type0, Permission>> rights
        CacheService cacheService = new CacheService(
                almJdbcTemplate: new JdbcTemplate(almDataSource),
                fxJdbcTemplate: new JdbcTemplate(fxDataSource),
                types: types,
                rights: rights
        )
        lookupTableResource = new LookupTableResource(
                cacheService: cacheService,
                profileSql: "select T3.M_LABEL from MX_GROUP_DBF T3 where T3.M_REFERENCE in " +
                        "(select M_GROUP_ID from MX_USER_GROUP_DBF T1, MX_USER_DBF T2 " +
                        "where T1.M_USER_ID = T2.M_REFERENCE and T2.M_LABEL='%s')",
                valueSql: "select * from (select T.*, ROWNUM RN from (" +
                        "select * from %s where M__INDEX_=%s) T where ROWNUM <= %s ) where RN >= %s",
                countSql: "select count(*) from %s where M__INDEX_=%s"
        )
    }

    void cleanup() {

    }

    def "Profiles"() {

    }

    def "Types"() {

    }

    def "Values"() {

    }
}
