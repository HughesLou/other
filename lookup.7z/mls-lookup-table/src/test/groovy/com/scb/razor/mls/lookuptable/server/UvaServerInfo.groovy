package com.scb.razor.mls.lookuptable.server

import javax.ws.rs.GET
import javax.ws.rs.Path
import javax.ws.rs.Produces
import javax.ws.rs.QueryParam
import javax.ws.rs.core.MediaType

public class UvaServerInfo extends AbstractRestfulServer {
    
    @Path("/ums/servlet")
    public static class UvaResource {
        
        @GET
        @Path("Verify")
        public Object verify(@QueryParam("userId") String userId,
                             @QueryParam("challenge") String challenge,
                             @QueryParam("hash") String hash,
                             @QueryParam("appName") String appName) {
            return "{\"status\":\"YES\"}"
        }
        
        @GET
        @Path("JSONLoginServlet")
        @Produces(MediaType.APPLICATION_JSON)
        public Object login(@QueryParam("LOGON_ID") String userId,
                            @QueryParam("PASSWORD") String passwd) {
            return null
        }
    }

    @Override
    protected String getURI() {
        return "http://localhost:8027/"
    }

    @Override
    protected Class[] getResourceClasses() {
        return [UvaResource.class]
    }
}