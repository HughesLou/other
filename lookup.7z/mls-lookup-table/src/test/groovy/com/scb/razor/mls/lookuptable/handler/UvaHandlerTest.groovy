package com.scb.razor.mls.lookuptable.handler

import com.google.common.cache.CacheBuilder
import com.google.common.cache.CacheLoader
import com.scb.razor.mls.security.entitlement.UvaDetails
import com.scb.scc.auth.UvaAuthenticationService
import io.netty.handler.codec.http.FullHttpRequest
import io.netty.handler.codec.http.HttpHeaders
import spock.lang.Specification

import static com.scb.razor.mls.security.entitlement.UvaUserDetailsProviderImpl.*;
import static org.mockito.Matchers.anyString
import static org.mockito.Mockito.doReturn
import static org.mockito.Mockito.mock

/**
 * Created by 1466811 on 8/8/2016.
 */
class UvaHandlerTest extends Specification {
    UvaHandler uvaHandler

    void setup() {
        uvaHandler = new UvaHandler(
                cache: CacheBuilder.newBuilder().build(new CacheLoader<UvaDetails, Boolean>() {
                    @Override
                    Boolean load(UvaDetails key) throws Exception {
                        return Boolean.TRUE
                    }
                }),
                uvaAuthenticationService: mock(UvaAuthenticationService.class))
    }

    void cleanup() {
        uvaHandler = null
    }

    def "Pass"() {
        given:
        FullHttpRequest request = mock(FullHttpRequest.class)
        HttpHeaders httpHeaders = mock(HttpHeaders.class)

        when:
        doReturn(true).when(uvaHandler.@uvaAuthenticationService).verify(anyString(), anyString(), anyString())
        doReturn(httpHeaders).when(request).headers()
        doReturn("1466811").when(httpHeaders).get(USER_ID)
        doReturn("ODJmMmY2ZTA5OGVhMTczMGM1ODM5Mjk1MWQyNzI4NmJiZTIxYzRjOA").when(httpHeaders).get(HASH)
        doReturn("OTE3MkMwOUQtRDk3OS1CQ0ZCLTExQUUtNjBDMkE0Mzk0MTFD").when(httpHeaders).get(CHALLENGE)

        then:
        uvaHandler.pass(request)
    }
}