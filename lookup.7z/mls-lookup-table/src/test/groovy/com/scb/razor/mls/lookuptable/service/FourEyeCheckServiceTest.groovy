package com.scb.razor.mls.lookuptable.service

import com.scb.razor.mls.lookuptable.cli.LookupTableMain
import com.scb.razor.mls.lookuptable.model.PendingChange
import com.scb.razor.mls.lookuptable.model.PendingChangeActionVO
import com.scb.razor.mls.lookuptable.server.AbstractRestfulServer
import com.scb.razor.mls.lookuptable.server.UvaServerInfo
import com.sun.jersey.api.client.Client
import com.sun.jersey.api.client.WebResource
import com.sun.jersey.api.client.config.ClientConfig
import com.sun.jersey.api.client.config.DefaultClientConfig
import groovy.json.JsonSlurper
import io.netty.handler.codec.http.HttpResponseStatus
import org.codehaus.jackson.jaxrs.JacksonJsonProvider
import org.codehaus.jackson.map.DeserializationConfig
import org.codehaus.jackson.map.ObjectMapper
import org.junit.ClassRule
import spock.lang.Shared
import spock.lang.Specification

import static com.scb.razor.mls.security.entitlement.UvaUserDetailsProviderImpl.*;

/**
 * Created by 1466811 on 8/8/2016.
 */
class FourEyeCheckServiceTest extends Specification {
    def srv

    Client client

    URI basePath

    @Shared
    @ClassRule
    AbstractRestfulServer uvaServerInfo = new UvaServerInfo();

    def setup() {
        basePath = URI.create("http://localhost:8097/")

        srv = new LookupTableMain(
                jerseyScan: "com.scb.razor.mls.lookuptable.rest",
                httpBindPath: basePath)
        srv.start()

        ObjectMapper om = new ObjectMapper();
        om.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ClientConfig cc = new DefaultClientConfig();
        cc.getSingletons().add(new JacksonJsonProvider(om));//read json response
        client = Client.create(cc);
    }

    def cleanup() {
        srv.stop()
    }

    def "test approve a change that inserting an entity"() {
        given:
        WebResource r1 = client.resource(basePath).path("changes")
        WebResource r2 = client.resource(basePath).path("lookups")
        def json = new JsonSlurper()
        def user = "1466811"
        def challenge = "OTE3MkMwOUQtRDk3OS1CQ0ZCLTExQUUtNjBDMkE0Mzk0MTFD"
        def hash = "ODJmMmY2ZTA5OGVhMTczMGM1ODM5Mjk1MWQyNzI4NmJiZTIxYzRjOA=="

        when:
        def resp1 = r1.header(USER_ID, user).header(CHALLENGE, challenge).header(HASH, hash).entity('''
                    {"requester": user,
                    "change": '{"op":"insert", "value":"12"}',
                    "_type": "LookupTablePendingChange"}''', "application/json").post(PendingChange.class)
        def resp2 = r2.header(USER_ID, user).header(CHALLENGE, challenge).header(HASH, hash).get(String.class)
        def resp3 = r1.path("actions").header(USER_ID, user).header(CHALLENGE, challenge).header(HASH, hash)
                .entity(new PendingChangeActionVO(changeId: resp1.id, requester:
                user, action: "approve"), "application/json").post(String.class)
        def resp4 = r2.header(USER_ID, user).header(CHALLENGE, challenge).header(HASH, hash).get(String.class)
        r1.get(String.class)
        println("==" + resp3)
        then:
        Exception exception = thrown()
        exception.message.contains(HttpResponseStatus.UNAUTHORIZED.toString())
        resp1.createAt != null
        json.parseText(resp2).size() == 0
        json.parseText(resp4).size() == 1
    }

    def "test reject a change"() {

    }

    def stringify(obj) {
        ObjectMapper om = new ObjectMapper()
        return om.writeValueAsString(obj)
    }

    void testPerformAction() {

    }

    void testUpdateStatus() {

    }

    void testOnApplicationEvent() {

    }

    void testGetApprovers() {

    }

    void testSetApprovers() {

    }
}
