package com.scb.razor.mls.lookuptable.service

import com.scb.razor.mls.lookuptable.constant.Constants
import org.apache.commons.dbcp2.BasicDataSource
import org.springframework.jdbc.core.JdbcTemplate
import spock.lang.Shared
import spock.lang.Specification

/**
 * Created by 1466811 on 8/22/2016.
 */
class CacheServiceTest extends Specification {
    @Shared
    CacheService cacheService

    void setup() {
        BasicDataSource almDataSource = new BasicDataSource(
                driverClassName: "oracle.jdbc.OracleDriver",
                username: "MX3_ALM_UAT_72",
                password: "MX3_ALM_UAT_72_123",
                url: "jdbc:oracle:thin:@uklpdudasa-scan.uk.standardchartered.com:1622/" +
                        "MX3_ALM_FI_UAT.uk.standardchartered.com",
                minIdle: 5,
                maxIdle: 10,
                initialSize: 5,
                logAbandoned: true)
        BasicDataSource fxDataSource = new BasicDataSource(
                driverClassName: "oracle.jdbc.OracleDriver",
                username: "MX3_FX_UAT_72",
                password: "MX3_FX_UAT_72_123",
                url: "jdbc:oracle:thin:@uklpdudasa-scan.uk.standardchartered.com:1622/" +
                        "MX3_FX_FI_UAT.uk.standardchartered.com",
                minIdle: 5,
                maxIdle: 10,
                initialSize: 5,
                logAbandoned: true)
        cacheService = new CacheService(
                almJdbcTemplate: new JdbcTemplate(almDataSource),
                fxJdbcTemplate: new JdbcTemplate(fxDataSource),
                cacheTimeoutMinutes: 3,
                typeSql: "select M_ID, M_LABEL, M_DESCRIPT, M_HEADER, M_BODY from RTG_TYP_DBF " +
                        "order by M_LABEL, M_IDENTITY",
                groupSql: "select min(TIMESTAMP), min(M__INDEX_), M_LABEL from %s group by " +
                        "M_LABEL order by M_LABEL",
                columnSql: "select M_ID, M_LABEL, M_CTITLE, M_BRWFRML, M_TYPID from RTG_COL_DBF, " +
                        "RTG_RCOL_DBF where M_ID = M_COLID order by M_COLRANK",
                rightSql: "select T2.M_SPBGROUP, T2.M_USER, T2.M_UDR_TYPE, T2.M_UDR_GROUP, " +
                        "T2.M_ACCESS, T2.M_UPDATE, T2.M_INSERT, T2.M_SUPPRESS, T3.M_ID, T3.M_DESCRIPT " +
                        "from UDRRGT_H_DBF T1 ,UDRRGT_B_DBF T2, RTG_TYP_DBF T3 where " +
                        "(T1.M_LABEL = 'GLOBALRIGHTS                                   ' and " +
                        "T1.M_PERMUTID = 0.) and T1.M__INDEX_ = T2.M__INDEX_ and " +
                        "T3.M_LABEL(+) = T2.M_UDR_TYPE order by M_SPBGROUP desc, M_UDR_TYPE desc, M_UDR_GROUP desc"
        )
        cacheService.init()
    }

    void cleanup() {
        cacheService = null
    }

    def "Test All Methods"() {
        given:
        def murex = Constants.MUREX_INSTANCE.FX;
        def label = "EBBS"
        def profile = "CONFIG"

        expect:
        cacheService.getAllType(murex).size() > 0
        cacheService.getTypeByLabel(murex, label).getLabel().equals(label)
        cacheService.getRights(murex, profile).size() > 0
    }
}