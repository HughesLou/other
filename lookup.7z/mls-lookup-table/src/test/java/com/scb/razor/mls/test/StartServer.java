package com.scb.razor.mls.test;

import com.scb.razor.mls.lookuptable.cli.LookupTableMain;
import org.junit.Test;

import java.net.URI;

/**
 * Created by 1466811 on 8/18/2016.
 */
public class StartServer {
    public static void main(String[] args) throws Exception {
        new StartServer().testStart();
    }

    @Test
    public void testStart() throws Exception {
        LookupTableMain m = new LookupTableMain();
        m.setJerseyScan("com.scb.razor.mls.lookuptable.rest");
        m.setHttpBindPath(URI.create("http://localhost:8097/"));
        m.start();
        m.join();
    }
}
