package com.scb.razor.mls.test;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufInputStream;
import io.netty.buffer.ByteBufOutputStream;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.http.DefaultFullHttpResponse;
import io.netty.handler.codec.http.FullHttpRequest;
import io.netty.handler.codec.http.FullHttpResponse;
import io.netty.handler.codec.http.HttpHeaderNames;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.netty.handler.codec.http.HttpServerCodec;
import io.netty.handler.codec.http.HttpUtil;
import io.netty.handler.codec.http.HttpVersion;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import io.netty.handler.codec.http.websocketx.WebSocketFrame;
import io.netty.handler.codec.http.websocketx.WebSocketServerProtocolHandler;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;
import io.netty.handler.stream.ChunkedWriteHandler;
import io.netty.util.CharsetUtil;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URI;

import javax.annotation.Resource;
import javax.ws.rs.GET;
import javax.ws.rs.Path;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import com.scb.razor.mls.lookuptable.cli.LookupTableMain;
import com.sun.jersey.api.core.DefaultResourceConfig;
import com.sun.jersey.api.core.ResourceConfig;
import com.sun.jersey.core.header.InBoundHeaders;
import com.sun.jersey.spi.container.ContainerRequest;
import com.sun.jersey.spi.container.ContainerResponse;
import com.sun.jersey.spi.container.ContainerResponseWriter;
import com.sun.jersey.spi.container.WebApplication;
import com.sun.jersey.spi.container.WebApplicationFactory;
import com.sun.jersey.spi.resource.Singleton;
import com.sun.jersey.spi.spring.container.SpringComponentProviderFactory;

public class JerseyOnNetty {
    
    public static void main(String[] args) throws Exception {
        
        new JerseyOnNetty().testRunServer();
    }
    
    @Test
    public void test2() throws Exception {
        LookupTableMain.main(null);
    }

    //http://stackoverflow.com/questions/36415821/missing-upgrade-serve-both-http-and-ws-on-netty-4-x
    public void testRunServer() throws Exception {
        
        long start = System.currentTimeMillis();
        AnnotationConfigApplicationContext springContext = new AnnotationConfigApplicationContext(JerseyOnNetty.class, TestResource.class);
        System.out.println("spring initialized " + (System.currentTimeMillis() - start));
        
        DefaultResourceConfig conf = new DefaultResourceConfig(TestResource.class);
        final WebApplication app = WebApplicationFactory.createWebApplication();
        SpringComponentProviderFactory iocFactory = new SpringComponentProviderFactory(conf, springContext);
        app.initiate(conf, iocFactory);
        System.out.println("jersey initialized " + (System.currentTimeMillis() - start));
        
        Object obj = conf.getProperties().get(ResourceConfig.PROPERTY_CONTAINER_NOTIFIER);
        System.out.println("jersey container notifier : " + obj);

        EventLoopGroup bossGroup = new NioEventLoopGroup(1);
        EventLoopGroup workerGroup = new NioEventLoopGroup();
        try {
            ServerBootstrap b = new ServerBootstrap();
            b.option(ChannelOption.SO_BACKLOG, 1024);
            b.group(bossGroup, workerGroup)
                .channel(NioServerSocketChannel.class)
                .handler(new LoggingHandler(LogLevel.INFO))
                .childHandler(new ChannelInitializer<SocketChannel>() {
                    protected void initChannel(SocketChannel ch) throws Exception {
                        final ChannelPipeline p = ch.pipeline();
                        p.addLast(new ChannelInboundHandlerAdapter(){
                            public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
                                ByteBuf buf = (ByteBuf) msg;
                                if(buf.readableBytes() < 10) {//command
                                    System.out.println("command received : " + buf.toString(CharsetUtil.UTF_8));
                                    ctx.writeAndFlush(Unpooled.wrappedBuffer("received, bye".getBytes()));
                                    ctx.close();
//                                    new Exception().printStackTrace();
                                } else {
                                    p.addLast(new HttpServerCodec());
                                    p.addLast(new HttpObjectAggregator(65536));
                                    p.addLast(new WebSocketServerProtocolHandler("/websocket", null, true));
                                    p.addLast(new ChunkedWriteHandler());
                                    p.addLast(new SimpleChannelInboundHandler<FullHttpRequest>(){
                                        protected void channelRead0(final ChannelHandlerContext ctx, FullHttpRequest req) throws Exception {
                                            
                                            final boolean keepAlive = HttpUtil.isKeepAlive(req);
                                            URI requestUri = URI.create(req.uri());
                                            URI base = URI.create(String.format("%s://%s:%s/", requestUri.getScheme(), requestUri.getHost(), requestUri.getPort()));
                                            InBoundHeaders headers = new InBoundHeaders();
                                            for(String key : req.headers().names()) {
                                                headers.put(key, req.headers().getAll(key));
                                            }
                                            ContainerRequest cr = new ContainerRequest(app, 
                                                    req.method().name(), 
                                                    base, 
                                                    requestUri, 
                                                    headers, 
                                                    new ByteBufInputStream(req.content()));
                                            final FullHttpResponse resp = new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.OK);
                                            app.handleRequest(cr, new ContainerResponseWriter(){
                                                public OutputStream writeStatusAndHeaders(long contentLength, ContainerResponse response) throws IOException {
                                                    resp.setStatus(HttpResponseStatus.valueOf(response.getStatus()));
                                                    for(String key : response.getHttpHeaders().keySet()) {
                                                        resp.headers().set(key, response.getHttpHeaders().get(key));
                                                    }
                                                    return new ByteBufOutputStream(resp.content());
                                                }
                                                public void finish() throws IOException {
                                                    if(keepAlive) {
                                                        System.out.println(resp.content().readableBytes());
                                                        resp.headers().set("Connection", "keep-alive");
                                                        resp.headers().setInt(HttpHeaderNames.CONTENT_LENGTH, resp.content().readableBytes());
//                                                      ctx.channel().writeAndFlush(resp);
                                                        ctx.writeAndFlush(resp);
                                                    } else {
//                                                      ctx.channel().writeAndFlush(resp).addListener(ChannelFutureListener.CLOSE);
                                                        ctx.writeAndFlush(resp).addListener(ChannelFutureListener.CLOSE);
                                                    }
                                                }
                                            });
                                        }
                                        public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
                                            cause.printStackTrace();
                                            ctx.close();
                                        }
                                    });
                                    p.addLast(new SimpleChannelInboundHandler<WebSocketFrame>(){
                                        protected void channelRead0(ChannelHandlerContext ctx, WebSocketFrame msg) throws Exception {
                                            if(msg instanceof TextWebSocketFrame) {
                                                TextWebSocketFrame txtFrame = (TextWebSocketFrame) msg;
                                                System.out.println(txtFrame.text());
                                                ctx.channel().writeAndFlush(new TextWebSocketFrame("hello"));
                                            } else {
                                                throw new UnsupportedOperationException("support only text frame");
                                            }
                                        }
                                    });
                                    ctx.pipeline().remove(this);//remove multiplexer, it is HTTP request
                                    ctx.fireChannelRead(msg);
                                }
                            }
                        });
                    }
                    public void channelReadComplete(ChannelHandlerContext ctx) {
                        ctx.flush();
                    }
                    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
                        cause.printStackTrace();
                        ctx.close();
                    }
                });

            Channel ch = b.bind(8080).sync().channel();
            System.out.println("netty started in " + (System.currentTimeMillis() - start));

            ch.closeFuture().sync();
        } finally {
            bossGroup.shutdownGracefully();
            workerGroup.shutdownGracefully();
        }
    }
    
    @Component
    @Singleton
    @Path("/test")
    public static class TestResource {
        
        @Autowired
        @Resource
        private JerseyOnNetty test;
        
        @GET
        public String helloNetty() {
            return "hello netty" + test;
        }
    }
}
