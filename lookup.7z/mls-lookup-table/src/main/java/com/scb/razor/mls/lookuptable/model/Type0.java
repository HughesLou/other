package com.scb.razor.mls.lookuptable.model;

/**
 * Created by 1466811 on 8/15/2016.
 */
public class Type0 implements Comparable<Object> {
    private int id;
    private String label;
    private String group;
    private String description;

    public Type0() { }

    public Type0(String label) {
        this.label = label;
    }

    public Type0(String label, String group) {
        this.label = label;
        this.group = group;
    }

    public Type0(String label, String group, String description) {
        this.label = label;
        this.group = group;
        this.description = description;
    }

    public Type0(int id, String label, String group, String description) {
        this.id = id;
        this.label = label;
        this.group = group;
        this.description = description;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public int compareTo(Object o) {
        if (o instanceof Type0) {
            return label.compareTo(((Type0) o).label);
        }
        throw new ClassCastException("Cannot compare Type0 with "
                + o.getClass().getName());
    }
}
