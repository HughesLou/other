package com.scb.razor.mls.lookuptable.handler;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.scb.razor.mls.security.entitlement.UvaDetails;
import com.scb.scc.auth.UvaAuthenticationService;
import io.netty.handler.codec.http.FullHttpRequest;
import io.netty.handler.codec.http.HttpHeaders;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.io.IOException;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import static com.scb.razor.mls.security.entitlement.UvaUserDetailsProviderImpl.*;

/**
 * Created by 1466811 on 8/5/2016.
 */

@Service
public class UvaHandler {
    LoadingCache<UvaDetails, Boolean> cache;
    private Logger LOGGER = LoggerFactory.getLogger(UvaHandler.class);
    @Resource
    private UvaAuthenticationService uvaAuthenticationService = null;

    public boolean pass(FullHttpRequest request) {
        UvaDetails uvaDetails = getUserDetails(request);
        boolean result = false;
        if (null != uvaDetails) {
            try { result = cache.get(uvaDetails); } catch (ExecutionException e) {
                LOGGER.warn("Error during getting value", e);
            }
            LOGGER.info(String.format("UVA Authentication {} for user {}, challenge: {}, hash: {}",
                    result ? "PASSED" : "FAILED",
                    uvaDetails.getUserId(), uvaDetails.getChallenge(), uvaDetails.getHash()));
        }

        return result;
    }

    @PostConstruct
    public void init() {
        cache = CacheBuilder.newBuilder().expireAfterWrite(10, TimeUnit.MINUTES)
                .build(new CacheLoader<UvaDetails, Boolean>() {
                    public Boolean load(UvaDetails key) throws IOException {
                        LOGGER.info(String.format("Cache expired: Re-verifying UVA Authentication " +
                                        "for user Id: %s, challenge: %s, hash: %s",
                                key.getUserId(), key.getChallenge(), key.getHash()));

                        final boolean verified = uvaAuthenticationService.verify(key.getUserId(),
                                key.getChallenge(), key.getHash());
                        LOGGER.info(String.format("User: %s UVA Verification Returned: %s",
                                key.getUserId(), verified));
                        return Boolean.valueOf(verified);
                    }
                });
    }

    private UvaDetails getUserDetails(FullHttpRequest request) {
        HttpHeaders httpHeaders = request.headers();

        String sessionKey = httpHeaders.get(SESSIONKEY);
        String hash = httpHeaders.get(HASH);
        String user = httpHeaders.get(USER_ID);
        String challenge = httpHeaders.get(CHALLENGE);

        if (sessionKey != null && user != null && challenge == null && hash == null) {
            String guid = UUID.randomUUID().toString();
            challenge = Base64.encodeBase64String(guid.getBytes());
            String tmp = DigestUtils.shaHex(sessionKey + guid);
            hash = Base64.encodeBase64String(tmp.getBytes());
        }
        LOGGER.info("get sessionkey:" + sessionKey);
        if (StringUtils.isEmpty(user) || StringUtils.isEmpty(hash) || StringUtils.isEmpty(challenge)) {
            LOGGER.warn("There is no UVA User/Hash/Challenge available on the current request.");
            return null;
        } else {
            return new UvaDetails(user, challenge, hash);
        }
    }
}