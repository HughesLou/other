package com.scb.razor.mls.lookuptable.rest;

import java.util.Date;

import javax.annotation.Resource;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Component;

import com.google.common.base.Function;
import com.scb.razor.mls.lookuptable.service.FourEyeCheckService;
import com.scb.razor.mls.lookuptable.model.LookupTablePendingChange;
import com.scb.razor.mls.lookuptable.model.PendingChange;
import com.scb.razor.mls.lookuptable.model.PendingChangeActionVO;

@Component
@Path("/changes")
public class PendingChangeResource extends EntitySubResource{

    @Resource
    private SessionFactory sessionFactory;
    
    @Resource
    private FourEyeCheckService fourEyeCheckService;
    
    @Path("/lookups")
    public EntitySubResource lookupTableSubResource() {
        EntitySubResource sub = new EntitySubResource();
        sub.setEntityClass(LookupTablePendingChange.class);
        HibernateTemplate ht = new HibernateTemplate(sessionFactory);
        sub.setHibernateTemplate(ht);
        sub.afterPropertiesSet();
        return sub;
    }
    
    @POST
    @Path("/actions")
    @Consumes(MediaType.APPLICATION_JSON)
    public Object submitChange(PendingChangeActionVO vo) {
        
        if(vo.getAction() == null || vo.getChangeId() == null) {
            return Response.status(Status.BAD_REQUEST).entity("Missing Required input").build();
        }
        vo.setChange(null);//not allowed from client
        fourEyeCheckService.performAction(vo);
        return Response.ok().build();
    }
    
    private Function<Object, Void> prePersist = new Function<Object, Void>(){
        public Void apply(Object input) {
            PendingChange pc = (PendingChange) input;
            Date now = new Date();
            pc.setCreateAt(now);
            pc.setStatus(PendingChange.STATUS_NEW);
            pc.setStatusAt(now);
            return null;
        }};
    
    @Override
    public void afterPropertiesSet() {
        setEntityClass(PendingChange.class);
        HibernateTemplate ht = new HibernateTemplate(sessionFactory);
        ht.setAlwaysUseNewSession(true);
        setHibernateTemplate(ht);
        setPrePersist(prePersist);
        super.afterPropertiesSet();
    }
}
