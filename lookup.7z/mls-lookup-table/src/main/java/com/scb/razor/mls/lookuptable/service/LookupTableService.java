package com.scb.razor.mls.lookuptable.service;

import java.util.Date;

import javax.annotation.Resource;

import com.scb.razor.mls.lookuptable.model.LookupTable;
import com.scb.razor.mls.lookuptable.model.LookupTablePendingChange;
import com.scb.razor.mls.lookuptable.model.PendingChange;
import com.scb.razor.mls.lookuptable.model.PendingChangeActionVO;
import org.codehaus.jettison.json.JSONObject;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Component;

@Component
public class LookupTableService implements ChangeApprover{
    
    private final static Logger log = LoggerFactory.getLogger(LookupTableService.class);
    
    @Resource
    private SessionFactory sessionFactory;

    public boolean accept(PendingChangeActionVO vo) {
        return vo.getChange() instanceof LookupTablePendingChange;
    }

    public void apply(PendingChangeActionVO vo) {
        
        LookupTablePendingChange change = (LookupTablePendingChange)vo.getChange();
        
        String op = null, key = null, value = null;
        try {
            JSONObject json = new JSONObject(change.getChange());
            op = json.optString("op", "update");//if op == null, op = 'update'
            key = json.optString("key");
            value = json.optString("value");
        } catch (Exception e) {
            throw new RuntimeException("fail to read change string as json " + e.getMessage(), e);
        }
        log.debug("op={}, key={}, value={}", op, key, value);
        
        HibernateTemplate ht = new HibernateTemplate(sessionFactory);
        
        if("insert".equals(op)) { //insert expect no refId, only delete and update expect one
            if("reject".equals(vo.getAction())) {
                change.setStatus(PendingChange.STATUS_REJECTED);
                change.setStatusAt(new Date());
                ht.update(change);
            } else if ("approve".equals(vo.getAction())) {
                LookupTable t = new LookupTable();
                t.setStatus(LookupTable.STATUS_ACTIVE);
                ht.save(t);//TODO should return this newly created id
            } else {
                throw new RuntimeException("unknown action " + vo.getAction());
            }
            return;
        }
        
        if(change.getRefId() == null) {
            throw new RuntimeException("an id refering to LookupTable is required");
        }
        
        LookupTable entity = ht.get(LookupTable.class, change.getRefId());
        
        if(entity == null) {
            throw new RuntimeException("not found lookup table entity id=" + change.getRefId());
        }
        
        if(entity.getStatus() != LookupTable.STATUS_PENDING) {
            throw new RuntimeException("lookup table entity not in pending status");
        }
        
        if("reject".equals(vo.getAction())) {
            entity.setStatus(LookupTable.STATUS_ACTIVE);
            ht.save(entity);
            return;
        }
        
        if("approve".equals(vo.getAction()) == false) {
            throw new RuntimeException("unrecognized action " + vo.getAction());
        }
        
        //approve
        if("update".equals(op)) {
            entity.setStatus(LookupTable.STATUS_ACTIVE);
            //entity.setValue()
            ht.update(entity);
            return;
        }
        
        if("delete".equals(op)) {
            ht.delete(entity);
            return;
        }
        
        throw new RuntimeException("unknown op " + op);
    }
}
