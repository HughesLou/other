package com.scb.razor.mls.lookuptable.model;

public class PendingChangeActionVO {

    private String requester;

    private String changeId;

    private String action;//'approve', 'reject'

    private PendingChange change;

    public String getRequester() {
        return requester;
    }

    public void setRequester(String requester) {
        this.requester = requester;
    }

    public String getChangeId() {
        return changeId;
    }

    public void setChangeId(String changeId) {
        this.changeId = changeId;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public PendingChange getChange() {
        return change;
    }

    public void setChange(PendingChange change) {
        this.change = change;
    }
}
