package com.scb.razor.mls.lookuptable.model;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.persistence.Column;
import java.util.Date;

/**
 * For 4 eye checking, all changes to entity will be pending until someone else approve
 *
 * @author 1510954
 */
@Entity
@Table(name = "PENDING_CHANGE")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "CATEGORY", length = 100)
public class PendingChange {

    public final static int
            STATUS_NEW = 1,
            STATUS_REJECTED = 2,
            STATUS_APPROVED = 3,
            STATUS_FAILED = 4, //exception happened while applying this change
            STATUS_TIMEOUT = 5;
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "ID")
    private String id;
    @Column(name = "CHANGE")
    private String change;
    @Column(name = "REQUESTER")
    private String requester;
    @Column(name = "STATUS")
    private Integer status;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATED_AT", insertable = false)
    private Date createAt;
    @Column(name = "STATUS_AT")
    private Date statusAt;//when is it approved/rejected/timeout ?
    @Column(name = "VALID_TIL")
    private Date validTil;//change expire time. assert : #validTil > createAt

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getChange() {
        return change;
    }

    public void setChange(String change) {
        this.change = change;
    }

    public String getRequester() {
        return requester;
    }

    public void setRequester(String requester) {
        this.requester = requester;
    }

    public Date getCreateAt() {
        return createAt;
    }

    public void setCreateAt(Date createAt) {
        this.createAt = createAt;
    }

    public Date getValidTil() {
        return validTil;
    }

    public void setValidTil(Date validTil) {
        this.validTil = validTil;
    }

    public Date getStatusAt() {
        return statusAt;
    }

    public void setStatusAt(Date statusAt) {
        this.statusAt = statusAt;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
