package com.scb.razor.mls.lookuptable.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import com.scb.razor.mls.lookuptable.model.PendingChange;
import com.scb.razor.mls.lookuptable.model.PendingChangeActionVO;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Component;

@Component
public class FourEyeCheckService implements ApplicationListener<ContextRefreshedEvent> {
    
    private final static Logger log = LoggerFactory.getLogger(FourEyeCheckService.class);

    private List<ChangeApprover> approvers = new ArrayList<>();
    
    @Resource
    private SessionFactory sessionFactory;
    
    public void performAction(PendingChangeActionVO vo) {
        
        log.debug("performing action {}", vo);
        PendingChange change = vo.getChange();
        if(change == null) {
            if(vo.getChangeId() == null) {
                throw new RuntimeException("must specify changeId");
            }
            HibernateTemplate ht = new HibernateTemplate(sessionFactory);
            change = ht.get(PendingChange.class, vo.getChangeId());
            vo.setChange(change);
        }
        if(change == null) {
            throw new RuntimeException("change not found");
        }
        
        ChangeApprover selection = null;
        for(ChangeApprover approver : approvers) {
            if(approver.accept(vo)) {
                selection = approver;
            }
        }
        if(selection == null) {
            throw new RuntimeException("no handler for this change " + change.getId());
        }
        log.debug("{} selected to handle {}", selection, change);
        
        try {
            selection.apply(vo);
        } catch (Exception e) {
            updateStatus(change, PendingChange.STATUS_FAILED);
            throw new RuntimeException("handle change failed, " + e.getMessage(), e);
        }
        //TODO audit log
    }
    
    public void updateStatus(PendingChange entity, int status) {
        entity.setStatus(status);
        entity.setStatusAt(new Date());
        HibernateTemplate ht = new HibernateTemplate(sessionFactory);
        ht.update(entity);
    }

    public void onApplicationEvent(ContextRefreshedEvent event) {
        ApplicationContext ctx = event.getApplicationContext();
        Map<String, ChangeApprover> beans = ctx.getBeansOfType(ChangeApprover.class);
        approvers.addAll((Collection<? extends ChangeApprover>) beans.values());
        log.info("{} approvers {}", approvers.size(), approvers);
    }

    public List<ChangeApprover> getApprovers() {
        return approvers;
    }

    public void setApprovers(List<ChangeApprover> approvers) {
        this.approvers = approvers;
    }
}
