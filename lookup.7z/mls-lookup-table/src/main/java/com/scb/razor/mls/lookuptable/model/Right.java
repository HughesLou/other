package com.scb.razor.mls.lookuptable.model;

/**
 * Created by 1466811 on 8/15/2016.
 */
public class Right {
    private String spbGroup;
    private String user;
    private Type0 type0;
    private Permission permission;

    public String getSpbGroup() {
        return spbGroup;
    }

    public void setSpbGroup(String spbGroup) {
        this.spbGroup = spbGroup;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public Type0 getType0() {
        return type0;
    }

    public void setType0(Type0 type0) {
        this.type0 = type0;
    }

    public Permission getPermission() {
        return permission;
    }

    public void setPermission(Permission permission) {
        this.permission = permission;
    }
}
