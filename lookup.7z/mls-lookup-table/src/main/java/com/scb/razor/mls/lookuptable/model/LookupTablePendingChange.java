package com.scb.razor.mls.lookuptable.model;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("LOOKUP_TABLE")
public class LookupTablePendingChange extends PendingChange {

    @Column(name = "P1")
    private String refId;//which record to apply this change to ?

    @Column(name = "P2")
    private String propertyA;

    public String getRefId() {
        return refId;
    }

    public void setRefId(String refId) {
        this.refId = refId;
    }

    public String getPropertyA() {
        return propertyA;
    }

    public void setPropertyA(String propertyA) {
        this.propertyA = propertyA;
    }
}
