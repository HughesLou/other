package com.scb.razor.mls.lookuptable.service;

import com.scb.razor.mls.lookuptable.model.PendingChangeActionVO;

public interface ChangeApprover {
    
    boolean accept(PendingChangeActionVO change);
    
    void apply(PendingChangeActionVO change);
}

