package com.scb.razor.mls.lookuptable.model;

/**
 * Created by 1466811 on 8/15/2016.
 */
public class Type1 extends Type {
    private Permission permission;

    public Permission getPermission() {
        return permission;
    }

    public void setPermission(Permission permission) {
        this.permission = permission;
    }
}
