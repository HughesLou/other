package com.scb.razor.mls.lookuptable.model;

/**
 * Created by 1466811 on 8/11/2016.
 */
public class Group {
    private int index;
    private String label;
    private float timestamp;

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public float getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(float timestamp) {
        this.timestamp = timestamp;
    }

}
