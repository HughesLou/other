package com.scb.razor.mls.lookuptable.model;

/**
 * Created by 1466811 on 8/11/2016.
 */
public class BrowserFormula {
    private String name;

    public BrowserFormula(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
