package com.scb.razor.mls.lookuptable.rest;

import com.google.common.collect.ImmutableMap;
import com.scb.razor.mls.lookuptable.constant.Constants.MUREX_INSTANCE;
import com.scb.razor.mls.lookuptable.model.Group;
import com.scb.razor.mls.lookuptable.model.Type;
import com.scb.razor.mls.lookuptable.model.Type0;
import com.scb.razor.mls.lookuptable.service.CacheService;
import com.scb.razor.mls.lookuptable.utils.DBUtil;
import org.apache.commons.lang3.EnumUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriInfo;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.google.common.base.MoreObjects.firstNonNull;
import static com.scb.razor.mls.lookuptable.constant.Constants.MUREX_INSTANCE.FX;
import static com.scb.razor.mls.lookuptable.constant.Constants.TABLE_SUBFIX;

@Component
@Path("/lookups")
public class LookupTableResource {

    private final static Logger logger = LoggerFactory.getLogger(LookupTableResource.class);
    @Resource
    private CacheService cacheService;
    @Value("${profile.sql}")
    private String profileSql;
    @Value("${value.sql}")
    private String valueSql;
    @Value("${value.count.sql}")
    private String countSql;

    @GET
    @Path("/profiles")
    @Produces(MediaType.APPLICATION_JSON)
    public Object profiles(@Context final UriInfo ui,
                           @QueryParam("instance") final String instance) {
        String userId = ui.getQueryParameters().getFirst("user");
        logger.info("Start to get profiles for user {} from Murex {} instance", userId, instance);

        MUREX_INSTANCE murex = EnumUtils.getEnum(MUREX_INSTANCE.class, instance);
        if (murex == null) {
            return Response.status(Status.BAD_REQUEST).entity("invalid parameter 'instance'");
        }

        JdbcTemplate template = FX.name().equals(instance) ?
                cacheService.getFxJdbcTemplate() : cacheService.getAlmJdbcTemplate();
        List<Map<String, String>> profiles = DBUtil.loadData(template, String.format(profileSql, userId));
        List<String> results = new ArrayList<>();
        for (Map<String, String> profile : profiles) {
            results.addAll(profile.values());
        }
        logger.info("Get profiles for user {}", userId);
        return results;
    }

    @GET
    @Path("/types")
    @Produces(MediaType.APPLICATION_JSON)
    public Object types(@QueryParam("view") @DefaultValue("list") final String view,
                        @Context final UriInfo ui,
                        @QueryParam("instance") final String instance,
                        @QueryParam("profile") final String profile) {
        if (view.contains("+") || view.contains(" ") || view.contains(",")) {
            //view=list+count  => {list:[...], count:20}
            //http://stackoverflow.com/questions/2678551/when-to-encode-space-to-plus-or-20
            String[] views = view.split("[+ ,]");
            HashMap<String, Object> map = new HashMap<>();
            for (String v : views) {
                Object rtn = types(v, ui, instance, profile);
                if (rtn instanceof Response) {
                    return rtn;//an error happened
                }
                map.put(v, rtn);
            }
            return map;
        }

        String userId = ui.getQueryParameters().getFirst("user");
        logger.info("Start to get rights for user {} from Murex {} instance", userId, instance);
        MUREX_INSTANCE murex = EnumUtils.getEnum(MUREX_INSTANCE.class, instance);
        if (murex == null) {
            return Response.status(Status.BAD_REQUEST).entity("invalid parameter 'instance'");
        }
        List<Type0> type0s = cacheService.getRights(murex, profile);
        logger.info("Get rights for user {}", userId);

        if ("count".equals(view)) {
            logger.info("Count of rights is {}", type0s.size());
            return ImmutableMap.of("count", type0s.size());
        }

        //default view=list
        if (!"list".equals(view)) {
            return Response.status(Status.BAD_REQUEST).entity("unknown parameter view=" + view).build();
        }
        return type0s;
    }

    @GET
    @Path("/values")
    @Produces(MediaType.APPLICATION_JSON)
    public Object values(@QueryParam("instance") final String instance,
                         @QueryParam("type") final String type,
                         @QueryParam("group") final String group,
                         @QueryParam("view") @DefaultValue("schema") final String view,
                         @Context final UriInfo ui) {
        if (type == null) {
            return Response.status(Status.BAD_REQUEST).entity("missing mandatory parameter 'type'").build();
        }
        MUREX_INSTANCE murex = EnumUtils.getEnum(MUREX_INSTANCE.class, instance);
        if (murex == null) {
            return Response.status(Status.BAD_REQUEST).entity("invalid parameter 'instance'");
        }

        if (view.contains("+") || view.contains(" ") || view.contains(",")) {
            //view=list+count  => {list:[...], count:20}
            //http://stackoverflow.com/questions/2678551/when-to-encode-space-to-plus-or-20
            String[] views = view.split("[+ ,]");
            HashMap<String, Object> map = new HashMap<>();
            for (String v : views) {
                Object rtn = values(instance, type, group, v, ui);
                if (rtn instanceof Response) {
                    return rtn;//an error happened
                }
                map.put(v, rtn);
            }
            return map;
        }

        if (type == null) {
            return Response.status(Status.BAD_REQUEST).entity("missing mandatory parameter 'type'").build();
        }

        Type t = cacheService.getTypeByLabel(murex, type);

        if ("schema".equals(view)) {
            return ImmutableMap.of(
                    "columns", t.getColumns()/*,
                    "formulas", Arrays.asList(
                            ImmutableMap.of("mx.viewFields.choices.static.organization.parties", Arrays.asList("option1", "option2", "option3")),
                            ImmutableMap.of("mx.viewFields.choices.trade.yesNo", Arrays.asList("Yes", "No", ""))
                    )*/);
        }

        if (group == null) {
            return Response.status(Status.BAD_REQUEST).entity("missing mandatory parameter 'group'").build();
        }

        JdbcTemplate template = FX.equals(instance) ?
                cacheService.getFxJdbcTemplate() : cacheService.getAlmJdbcTemplate();
        String body = t.getBody() + TABLE_SUBFIX;
        List<Group> groups = t.getGroups();
        int index = Integer.MIN_VALUE;
        for (Group g : groups) {
            if (group.equals(g.getLabel())) {
                index = g.getIndex();
                break;
            }
        }
        if (Integer.MIN_VALUE == index) {
            return Response.status(Status.BAD_REQUEST).entity("there is no such group for the current type").build();
        }

        if ("count".equals(view)) {
            return DBUtil.getResultCount(template, String.format(countSql, body, index));
        }

        if (!"list".equals(view)) {
            return Response.status(Status.BAD_REQUEST).entity("unknown parameter view=" + view).build();
        }

        String firstResult = firstNonNull(ui.getQueryParameters().getFirst("firstResult"), "0");
        String maxResults = firstNonNull(ui.getQueryParameters().getFirst("maxResults"), "20");
        logger.info("first={}, max={}", firstResult, maxResults);

        return DBUtil.loadData(template,
                String.format(valueSql, body, index, firstResult + maxResults, firstResult), true);
    }
}