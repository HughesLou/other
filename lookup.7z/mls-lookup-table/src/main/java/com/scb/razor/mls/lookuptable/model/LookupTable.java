package com.scb.razor.mls.lookuptable.model;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.persistence.Column;

@Entity
@Table(name = "LOOKUP_TABLE")
public class LookupTable {

    public static int
            STATUS_ACTIVE = 1,
            STATUS_PENDING = 2, // should support active_pending and inactive_pending ?
            STATUS_INACTIVE = 4;
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "ID")
    private String id;
    @Column(name = "STATUS")
    private Integer status;
    @Column(name = "CHANGE_ID")
    private String changeId;// pending change id
    @Column(name = "KEY")
    private String key;
    @Column(name = "VALUE")
    private String value;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getChangeId() {
        return changeId;
    }

    public void setChangeId(String changeId) {
        this.changeId = changeId;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
