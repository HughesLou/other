package com.scb.razor.mls.lookuptable.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**
 * complete db table mapping. this is for schema-gen only,
 * for use in constructing business logic, use {@link PendingChange} and its subclasses
 *
 * @author 1510954
 */
@Entity
@Table(name = "PENDING_CHANGE")
public class PendingChangeDatabaseTable {

    @Id
    private String id;

    @Column(name = "CATEGORY")
    private String cagetory;

    @Column(name = "CHANGE", length = 2000, nullable = false, updatable = false)
    private String change;

    @Column(name = "P1")
    private String p1;// value derived from #change, to make it search friendly

    @Column(name = "P2")
    private String p2;

    @Column(name = "P3")
    private String p3;

    @Column(name = "P4")
    private String p4;

    @Column(name = "P5")
    private String p5;

    @Column(name = "P6")
    private String p6;

    @Column(name = "P7")
    private String p7;

    @Column(name = "P8")
    private String p8;

    @Column(name = "P9")
    private String p9;

    @Column(name = "REQUESTER")
    private String requester;

    @Column(name = "STATUS")
    private int status;

    @Column(name = "CREATE_AT")
    private Date createAt;

    @Column(name = "STATUS_AT")
    private Date statusAt;

    @Column(name = "VALID_TIL")
    private Date validTil;//change expire time. assert : #validTil > createAt

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCagetory() {
        return cagetory;
    }

    public void setCagetory(String cagetory) {
        this.cagetory = cagetory;
    }

    public String getChange() {
        return change;
    }

    public void setChange(String change) {
        this.change = change;
    }

    public String getP1() {
        return p1;
    }

    public void setP1(String p1) {
        this.p1 = p1;
    }

    public String getP2() {
        return p2;
    }

    public void setP2(String p2) {
        this.p2 = p2;
    }

    public String getP3() {
        return p3;
    }

    public void setP3(String p3) {
        this.p3 = p3;
    }

    public String getP4() {
        return p4;
    }

    public void setP4(String p4) {
        this.p4 = p4;
    }

    public String getP5() {
        return p5;
    }

    public void setP5(String p5) {
        this.p5 = p5;
    }

    public String getP6() {
        return p6;
    }

    public void setP6(String p6) {
        this.p6 = p6;
    }

    public String getP7() {
        return p7;
    }

    public void setP7(String p7) {
        this.p7 = p7;
    }

    public String getP8() {
        return p8;
    }

    public void setP8(String p8) {
        this.p8 = p8;
    }

    public String getP9() {
        return p9;
    }

    public void setP9(String p9) {
        this.p9 = p9;
    }

    public String getRequester() {
        return requester;
    }

    public void setRequester(String requester) {
        this.requester = requester;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public Date getCreateAt() {
        return createAt;
    }

    public void setCreateAt(Date createAt) {
        this.createAt = createAt;
    }

    public Date getValidTil() {
        return validTil;
    }

    public void setValidTil(Date validTil) {
        this.validTil = validTil;
    }
}
