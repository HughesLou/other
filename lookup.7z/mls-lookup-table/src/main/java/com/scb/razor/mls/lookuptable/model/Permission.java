package com.scb.razor.mls.lookuptable.model;

/**
 * Created by 1466811 on 8/15/2016.
 */
public class Permission {
    private boolean access;
    private boolean update;
    private boolean insert;
    private boolean suppress;

    public Permission(boolean access, boolean update, boolean insert, boolean suppress) {
        this.access = access;
        this.update = update;
        this.insert = insert;
        this.suppress = suppress;
    }

    public boolean isAccess() {
        return access;
    }

    public void setAccess(boolean access) {
        this.access = access;
    }

    public boolean isUpdate() {
        return update;
    }

    public void setUpdate(boolean update) {
        this.update = update;
    }

    public boolean isInsert() {
        return insert;
    }

    public void setInsert(boolean insert) {
        this.insert = insert;
    }

    public boolean isSuppress() {
        return suppress;
    }

    public void setSuppress(boolean suppress) {
        this.suppress = suppress;
    }

    public boolean hasPermission() {
        return access || update || insert || suppress;
    }
}
