package com.scb.razor.mls.lookuptable.constant;

/**
 * Created by 1466811 on 8/5/2016.
 */
public class Constants {
    public final static String TABLE_SUBFIX = "_DBF";
    public enum MUREX_INSTANCE {
        ALM, FX
    }
}