package com.scb.razor.mls.lookuptable.utils;

import com.scb.razor.mls.lookuptable.model.*;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.*;

/**
 * Created by 1466811 on 8/12/2016.
 */
public class DBUtil {
    private static final Logger log = LoggerFactory.getLogger(DBUtil.class);

    public static int getResultCount(JdbcTemplate template, String sql) {
        log.info("Execute sql {}", sql);
        List<Map<String, Object>> numberRs = new ArrayList<>();
        try {
            numberRs = template.queryForList(sql);
        } catch (DataAccessException e) {
            log.error("data access error", e);
        }
        int count = 0;
        if (numberRs != null && numberRs.size() > 0) {
            for (Map<String, Object> map : numberRs) {
                count = Integer.valueOf(map.values().toArray()[0].toString());
            }
        }
        return count;
    }

    public static List<Map<String, String>> loadData(JdbcTemplate template, String sql) {
        return loadData(template, sql, false);
    }

    public static List<Map<String, String>> loadData(JdbcTemplate template, String sql,
                                                     final boolean removePrefix) {
        log.info("Execute sql {}", sql);
        ResultSetExtractor<List<Map<String, String>>> rch = new ResultSetExtractor<List<Map<String, String>>>() {
            @Override
            public List<Map<String, String>> extractData(ResultSet rs) throws SQLException,
                    DataAccessException {
                List<Map<String, String>> dataMapList = new ArrayList<>();
                ResultSetMetaData mata = rs.getMetaData();
                int count = mata.getColumnCount();
                while (rs.next()) {
                    Map<String, String> map = new HashMap<>();
                    for (int i = 0; i < count; i++) {
                        String key = mata.getColumnName(i + 1);
                        if (removePrefix) {
                            key.replace("M_", StringUtils.EMPTY);
                        }
                        map.put(key, rs.getString(mata.getColumnName(i + 1)));
                    }
                    dataMapList.add(map);
                }
                return dataMapList;
            }
        };
        List<Map<String, String>> dataMapList = template.query(sql, rch);
        return dataMapList;
    }

    public static Map<Integer, Type> loadType(JdbcTemplate template, String sql) {
        log.info("Execute sql {}", sql);
        ResultSetExtractor<Map<Integer, Type>> rse = new ResultSetExtractor<Map<Integer, Type>>() {
            @Override
            public Map<Integer, Type> extractData(ResultSet rs) throws SQLException, DataAccessException {
                Map<Integer, Type> data = new TreeMap<>();
                while (rs.next()) {
                    Type type = new Type();
                    type.setId(rs.getInt(1));
                    type.setLabel(StringUtils.trim(rs.getString(2)));
                    type.setDescription(StringUtils.trim(rs.getString(3)));
                    type.setHeader(StringUtils.trim(rs.getString(4)));
                    type.setBody(StringUtils.trim(rs.getString(5)));

                    data.put(type.getId(), type);
                }
                return data;
            }
        };
        Map<Integer, Type> dataMapList = template.query(sql, rse);
        return dataMapList;
    }

    public static List<Group> loadGroup(JdbcTemplate template, String sql) {
        log.info("Execute sql {}", sql);
        ResultSetExtractor<List<Group>> rse = new ResultSetExtractor<List<Group>>() {
            @Override
            public List<Group> extractData(ResultSet rs) throws SQLException, DataAccessException {
                List<Group> data = new ArrayList<>();
                while (rs.next()) {
                    Group group = new Group();
                    group.setTimestamp(rs.getFloat(1));
                    group.setIndex(rs.getInt(2));
                    group.setLabel(StringUtils.trim(rs.getString(3)));

                    data.add(group);
                }
                return data;
            }
        };
        List<Group> dataMapList = template.query(sql, rse);
        return dataMapList;
    }

    public static Map<String, List<Column>> loadColumn(JdbcTemplate template, String sql) {
        log.info("Execute sql {}", sql);
        ResultSetExtractor<Map<String, List<Column>>> rse = new ResultSetExtractor<Map<String, List<Column>>>() {
            @Override
            public Map<String, List<Column>> extractData(ResultSet rs) throws SQLException, DataAccessException {
                Map<String, List<Column>> data = new TreeMap<>();
                while (rs.next()) {
                    Column column = new Column();
                    column.setId(rs.getInt(1));
                    column.setLabel(StringUtils.trim(rs.getString(2)));
                    column.setTitle(StringUtils.trim(rs.getString(3)));
                    column.setBrowserFormula(StringUtils.trim(rs.getString(4)));
                    String typeId = rs.getString(5);

                    if (data.keySet().contains(typeId)) {
                        data.get(typeId).add(column);
                    } else {
                        List<Column> columns = new ArrayList<>();
                        columns.add(column);
                        data.put(typeId, columns);
                    }
                }
                return data;
            }
        };
        Map<String, List<Column>> dataMapList = template.query(sql, rse);
        return dataMapList;
    }

    public static List<Right> loadRight(JdbcTemplate template, String sql) {
        log.info("Execute sql {}", sql);
        ResultSetExtractor<List<Right>> rse = new ResultSetExtractor<List<Right>>() {
            @Override
            public List<Right> extractData(ResultSet rs) throws SQLException, DataAccessException {
                List<Right> data = new ArrayList<>();
                while (rs.next()) {
                    Right right = new Right();
                    right.setSpbGroup(StringUtils.trim(rs.getString(1)));
                    right.setUser(StringUtils.trim(rs.getString(2)));
                    right.setType0(new Type0(rs.getInt(9), StringUtils.trim(rs.getString(3)),
                            StringUtils.trim(rs.getString(4)), StringUtils.trim(rs.getString(10))));
                    right.setPermission(new Permission(0 != rs.getInt(5),
                            0 != rs.getInt(6), 0 != rs.getInt(7), 0 != rs.getInt(8)));
                    data.add(right);
                }
                return data;
            }
        };
        return template.query(sql, rse);
    }
}