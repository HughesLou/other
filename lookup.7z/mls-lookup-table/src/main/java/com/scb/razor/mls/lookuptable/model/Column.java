package com.scb.razor.mls.lookuptable.model;

/**
 * Created by 1466811 on 8/11/2016.
 */
public class Column {
    private int id;
    private String label;
    private String title;
    private String browserFormula;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBrowserFormula() {
        return browserFormula;
    }

    public void setBrowserFormula(String browserFormula) {
        this.browserFormula = browserFormula;
    }
}
