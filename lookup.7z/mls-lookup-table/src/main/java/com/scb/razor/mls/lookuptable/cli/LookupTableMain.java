package com.scb.razor.mls.lookuptable.cli;

import com.scb.razor.mls.lookuptable.handler.UvaHandler;
import com.sun.jersey.api.core.DefaultResourceConfig;
import com.sun.jersey.api.core.PackagesResourceConfig;
import com.sun.jersey.api.core.ResourceConfig;
import com.sun.jersey.core.header.InBoundHeaders;
import com.sun.jersey.spi.container.*;
import com.sun.jersey.spi.spring.container.SpringComponentProviderFactory;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufInputStream;
import io.netty.buffer.ByteBufOutputStream;
import io.netty.buffer.Unpooled;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.http.*;
import io.netty.handler.codec.http.cors.CorsConfig;
import io.netty.handler.codec.http.cors.CorsConfigBuilder;
import io.netty.handler.codec.http.cors.CorsHandler;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import io.netty.handler.codec.http.websocketx.WebSocketFrame;
import io.netty.handler.codec.http.websocketx.WebSocketServerProtocolHandler;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;
import io.netty.handler.stream.ChunkedWriteHandler;
import io.netty.util.CharsetUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URI;
import java.util.concurrent.CountDownLatch;

public class LookupTableMain {

    private final static Logger log = LoggerFactory.getLogger(LookupTableMain.class);

    public static void main(String[] args) throws Exception {

        log.info("start app");

        LookupTableMain m = new LookupTableMain();
        m.setJerseyScan("com.scb.razor.mls.lookuptable.rest");
        m.setHttpBindPath(URI.create("http://localhost:8097/"));
        m.start();
    }

    private String jerseyScan;

    private URI httpBindPath;

    private Channel serverChannel;

    private ConfigurableApplicationContext springContext;

    public Channel start() throws Exception {
        long start = System.currentTimeMillis();
        springContext = new ClassPathXmlApplicationContext("applicationContext.xml");
//        AnnotationConfigApplicationContext springContext = new AnnotationConfigApplicationContext(springScan.split(","));
        log.info("spring initialized in {}ms", (System.currentTimeMillis() - start));

        DefaultResourceConfig conf = new PackagesResourceConfig(jerseyScan.split(","));
        conf.getFeatures().put("com.sun.jersey.api.json.POJOMappingFeature", true);
        final WebApplication app = WebApplicationFactory.createWebApplication();
        SpringComponentProviderFactory iocFactory = new SpringComponentProviderFactory(conf, springContext);
        app.initiate(conf, iocFactory);
        log.info("jersey initialized in {}ms", (System.currentTimeMillis() - start));

        Object obj = conf.getProperties().get(ResourceConfig.PROPERTY_CONTAINER_NOTIFIER);
        log.info("jersey container notifier : " + obj);

        final UvaHandler uvaHandler = springContext.getBean(UvaHandler.class);

        EventLoopGroup bossGroup = new NioEventLoopGroup(1);
        EventLoopGroup workerGroup = new NioEventLoopGroup();
        ServerBootstrap b = new ServerBootstrap();
        b.option(ChannelOption.SO_BACKLOG, 1024);
        b.group(bossGroup, workerGroup)
                .channel(NioServerSocketChannel.class)
                .handler(new LoggingHandler(LogLevel.INFO))
                .childHandler(new ChannelInitializer<SocketChannel>() {
                    protected void initChannel(SocketChannel ch) throws Exception {
                        final ChannelPipeline p = ch.pipeline();
                        p.addLast(new ChannelInboundHandlerAdapter() {
                            public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
                                ByteBuf buf = (ByteBuf) msg;
                                if (buf.readableBytes() < 10) {//command
                                    String command = buf.toString(CharsetUtil.UTF_8);
                                    if ("SHUTDOWN".equals(command)) {
                                        LookupTableMain.this.stop();
                                        ctx.writeAndFlush(Unpooled.wrappedBuffer("bye".getBytes()));
                                    }
                                    ctx.close();
                                } else {
                                    final CorsConfig corsConfig = CorsConfigBuilder.forAnyOrigin().allowedRequestHeaders(HttpHeaderNames.CONTENT_TYPE.toString(), HttpHeaderNames.ACCEPT.toString()).allowedRequestMethods(HttpMethod.GET, HttpMethod.POST, HttpMethod.DELETE, HttpMethod.PUT, HttpMethod.OPTIONS).allowNullOrigin().allowCredentials().build();
                                    p.addLast(new HttpServerCodec());
                                    p.addLast(new HttpObjectAggregator(65536));
                                    p.addLast(new WebSocketServerProtocolHandler("/websocket", null, true));
                                    p.addLast(new ChunkedWriteHandler());
                                    p.addLast(new CorsHandler(corsConfig));
                                    p.addLast(new JerseyHandler(app, uvaHandler));
                                    p.addLast(new SimpleChannelInboundHandler<WebSocketFrame>() {
                                        protected void channelRead0(ChannelHandlerContext ctx, WebSocketFrame msg)
                                                throws Exception {
                                            if (msg instanceof TextWebSocketFrame) {
                                                TextWebSocketFrame txtFrame = (TextWebSocketFrame) msg;
                                                System.out.println(txtFrame.text());
                                                ctx.channel().writeAndFlush(new TextWebSocketFrame("hello"));
                                            } else {
                                                throw new UnsupportedOperationException("support only text frame");
                                            }
                                        }
                                    });
                                    ctx.pipeline().remove(this);//remove multiplexer, it is HTTP request
                                    ctx.fireChannelRead(msg);
                                }
                            }
                        });
                    }

                    public void channelReadComplete(ChannelHandlerContext ctx) {
                        ctx.flush();
                    }

                    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
                        log.error(cause.getMessage(), cause);
                        ctx.close();
                    }
                });

        serverChannel = b.bind(httpBindPath.getPort()).sync().channel();
        log.info("netty initialized in {}ms", (System.currentTimeMillis() - start));

        return serverChannel;
    }

    private CountDownLatch stop = new CountDownLatch(1);

    public void join() throws Exception {
        stop.await();
    }

    public void stop() throws Exception {
        serverChannel.close().sync();
        springContext.stop();
        stop.countDown();
    }

    public String getJerseyScan() {
        return jerseyScan;
    }

    public void setJerseyScan(String jerseyScan) {
        this.jerseyScan = jerseyScan;
    }

    public URI getHttpBindPath() {
        return httpBindPath;
    }

    public void setHttpBindPath(URI httpBindPath) {
        this.httpBindPath = httpBindPath;
    }
}

class JerseyHandler extends SimpleChannelInboundHandler<FullHttpRequest> {

    private WebApplication app;
    private UvaHandler uvaHandler;

    public JerseyHandler(WebApplication app, UvaHandler uvaHandler) {
        this.app = app;
        this.uvaHandler = uvaHandler;
    }

    protected void channelRead0(final ChannelHandlerContext ctx, FullHttpRequest req) throws Exception {

        if (!uvaHandler.pass(req)) {
            // Response.Status.UNAUTHORIZED
            ctx.writeAndFlush(new DefaultFullHttpResponse(HttpVersion.HTTP_1_1,
                    HttpResponseStatus.UNAUTHORIZED));
            ctx.close();
            return;
        }

        final boolean keepAlive = HttpUtil.isKeepAlive(req);
        URI requestUri = URI.create(req.uri());
        URI base = URI.create(String.format("%s://%s:%s/",
                requestUri.getScheme(), requestUri.getHost(), requestUri.getPort()));
        InBoundHeaders headers = new InBoundHeaders();
        for (String key : req.headers().names()) {
            headers.put(key, req.headers().getAll(key));
        }
        ContainerRequest cr = new ContainerRequest(app,
                req.method().name(),
                base,
                requestUri,
                headers,
                new ByteBufInputStream(req.content()));
        final FullHttpResponse resp = new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.OK);
        app.handleRequest(cr, new ContainerResponseWriter() {
            public OutputStream writeStatusAndHeaders(long contentLength, ContainerResponse response)
                    throws IOException {
                resp.setStatus(HttpResponseStatus.valueOf(response.getStatus()));
                for (String key : response.getHttpHeaders().keySet()) {
                    resp.headers().set(key, response.getHttpHeaders().get(key));
                }
                return new ByteBufOutputStream(resp.content());
            }

            public void finish() throws IOException {
                if (keepAlive) {
                    resp.headers().set(HttpHeaderNames.CONNECTION, "keep-alive");
                    resp.headers().setInt(HttpHeaderNames.CONTENT_LENGTH, resp.content().readableBytes());
                    ctx.writeAndFlush(resp);
                } else {
                    ctx.writeAndFlush(resp).addListener(ChannelFutureListener.CLOSE);
                }
            }
        });
    }

    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
        cause.printStackTrace();
        ctx.close();
    }
}