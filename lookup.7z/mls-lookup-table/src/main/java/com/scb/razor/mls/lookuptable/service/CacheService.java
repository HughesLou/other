package com.scb.razor.mls.lookuptable.service;

import com.google.common.base.Supplier;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.collect.Maps;
import com.google.common.collect.Table;
import com.google.common.collect.Tables;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.ListenableFutureTask;
import com.scb.razor.mls.lookuptable.model.*;
import com.scb.razor.mls.lookuptable.utils.DBUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.*;

import static com.scb.razor.mls.lookuptable.constant.Constants.MUREX_INSTANCE;
import static com.scb.razor.mls.lookuptable.constant.Constants.MUREX_INSTANCE.FX;
import static com.scb.razor.mls.lookuptable.constant.Constants.TABLE_SUBFIX;

/**
 * Created by 1466811 on 8/12/2016.
 */
@Service
public class CacheService {
    private static final Logger log = LoggerFactory.getLogger(CacheService.class);
    @Resource
    private JdbcTemplate almJdbcTemplate;
    @Resource
    private JdbcTemplate fxJdbcTemplate;
    @Value("${cacheTimeoutMinutes}")
    private long cacheTimeoutMinutes = 15;
    @Value("${type.sql}")
    private String typeSql;
    @Value("${group.sql}")
    private String groupSql;
    @Value("${column.sql}")
    private String columnSql;
    @Value("${right.sql}")
    private String rightSql;
    private LoadingCache<MUREX_INSTANCE, Map<Integer, Type>> types;
    private LoadingCache<MUREX_INSTANCE, Table<String, Type0, Permission>> rights;
    private ExecutorService executor = Executors.newFixedThreadPool(2);

    @PostConstruct
    public void init() {
        log.info("Start to initialize the cache.");
        types = CacheBuilder.newBuilder().refreshAfterWrite(cacheTimeoutMinutes, TimeUnit.MINUTES)
                .build(new CacheLoader<MUREX_INSTANCE, Map<Integer, Type>>() {
                    public Map<Integer, Type> load(final MUREX_INSTANCE instance) {
                        return loadTypesForEntity(instance);
                    }

                    public ListenableFuture<Map<Integer, Type>> reload(final MUREX_INSTANCE instance,
                                                                       Map<Integer, Type> previous) {
                        ListenableFutureTask<Map<Integer, Type>> task =
                                ListenableFutureTask.create(new Callable<Map<Integer, Type>>() {
                                    public Map<Integer, Type> call() {
                                        return loadTypesForEntity(instance);
                                    }
                                });
                        executor.execute(task);
                        return task;
                    }
                });

        rights = CacheBuilder.newBuilder().refreshAfterWrite(cacheTimeoutMinutes, TimeUnit.MINUTES)
                .build(new CacheLoader<MUREX_INSTANCE, Table<String, Type0, Permission>>() {
                    public Table<String, Type0, Permission> load(final MUREX_INSTANCE instance) {
                        return loadRightsForEntity(instance);
                    }

                    public ListenableFuture<Table<String, Type0, Permission>> reload(final MUREX_INSTANCE instance,
                                                                                     Table<String, Type0, Permission> previous) {
                        ListenableFutureTask<Table<String, Type0, Permission>> task =
                                ListenableFutureTask.create(new Callable<Table<String, Type0, Permission>>() {
                                    public Table<String, Type0, Permission> call() {
                                        return loadRightsForEntity(instance);
                                    }
                                });
                        executor.execute(task);
                        return task;
                    }
                });

        try {
            for (MUREX_INSTANCE instance : MUREX_INSTANCE.values()) {
                types.get(instance);
                rights.get(instance);
            }
        } catch (ExecutionException e) {
            throw new RuntimeException("There was an error fetching the Types.", e);
        }
    }

    public List<Type> getAllType(MUREX_INSTANCE instance) {
        try {
            return new ArrayList<>(types.get(instance).values());
        } catch (ExecutionException e) {
            log.error("Error when getting types from {}", instance);
            throw new RuntimeException(e);
        }
    }

    public Type getTypeByLabel(MUREX_INSTANCE instance, String label) {
        Map<Integer, Type> typeMap;
        try {
            typeMap = types.get(instance);
        } catch (ExecutionException e) {
            log.error("Error when getting types from {} by label {}", instance, label);
            throw new RuntimeException(e);
        }

        for (Type type : typeMap.values()) {
            if (label.equals(type.getLabel())) {
                return type;
            }
        }
        return null;
    }

    private Map<Integer, Type> loadTypesForEntity(MUREX_INSTANCE instance) {
        log.info("Start to load types for instance {}.", instance);

        JdbcTemplate template = FX.equals(instance) ? fxJdbcTemplate : almJdbcTemplate;

        Map<Integer, Type> typeMap = DBUtil.loadType(template, typeSql);

        Map<String, List<Column>> map = DBUtil.loadColumn(template, columnSql);
        for (Type type : typeMap.values()) {
            type.setGroups(DBUtil.loadGroup(template,
                    String.format(groupSql, type.getHeader() + TABLE_SUBFIX)));
            type.setColumns(map.get(String.valueOf(type.getId())));
        }

        log.info("Types loading for instance {} is done.", instance);
        return typeMap;
    }

    private Table<String, Type0, Permission> loadRightsForEntity(MUREX_INSTANCE instance) {
        log.info("Start to load types for instance {}.", instance);

        JdbcTemplate template = FX.equals(instance) ? fxJdbcTemplate : almJdbcTemplate;

        List<Right> rights = DBUtil.loadRight(template, rightSql);
        // add default all permissions
        Right defaultRight = new Right();
        defaultRight.setSpbGroup(StringUtils.EMPTY);
        defaultRight.setType0(new Type0(StringUtils.EMPTY, StringUtils.EMPTY));
        defaultRight.setPermission(new Permission(true, true, true, true));
        rights.add(defaultRight);

        Table<String, Type0, Permission> table = Tables.newCustomTable(
                Maps.<String, Map<Type0, Permission>>newTreeMap(),
                new Supplier<Map<Type0, Permission>>() {
                    public Map<Type0, Permission> get() {
                        return Maps.newTreeMap();
                    }
                });

        // defined rights with profile
        for (Right right : rights) {
            String profile = right.getSpbGroup();
            Type0 type0 = right.getType0();
            Permission permission = right.getPermission();
            String label = type0.getLabel();

            if (StringUtils.isBlank(type0.getGroup())) {
                if (StringUtils.isBlank(type0.getLabel())) {
                    List<Type> types = getAllType(instance);
                    for (Type type : types) {
                        label = type.getLabel();
                        int id = type.getId();
                        String description = type.getDescription();
                        for (Group group : type.getGroups()) {
                            Type0 type01 = new Type0(id, label, group.getLabel(), description);
                            if (!table.contains(profile, type01)) {
                                table.put(profile, type01, permission);
                            }
                        }
                    }
                } else {
                    Type type = getTypeByLabel(instance, label);
                    if (null != type) {
                        int id = type0.getId();
                        String description = type0.getDescription();
                        for (Group group : type.getGroups()) {
                            Type0 type01 = new Type0(id, label, group.getLabel(), description);
                            if (!table.contains(profile, type01)) {
                                table.put(profile, type01, permission);
                            }
                        }
                    }
                }
            } else {
                table.put(profile, type0, permission);
            }
        }

        log.info("Rights loading for instance {} is done.", instance);
        return table;
    }

    public List<Type0> getRights(MUREX_INSTANCE instance, String profile) {
        List<Type0> results = new ArrayList<>();
        try {
            Map<Type0, Permission> colMap = rights.get(instance).row(profile);
            for (Type0 type0 : colMap.keySet()) {
                if (colMap.get(type0).isAccess()) {
                    results.add(type0);
                }
            }
            Map<Type0, Permission> allProfileMap = rights.get(instance).row(StringUtils.EMPTY);
            for (Type0 type0 : allProfileMap.keySet()) {
                if (allProfileMap.get(type0).isAccess() && !results.contains(type0)) {
                    results.add(type0);
                }
            }

            return results;
        } catch (ExecutionException e) {
            log.error("Error when getting rights from {} by profile {}", instance, profile);
            throw new RuntimeException(e);
        }
    }

    public JdbcTemplate getAlmJdbcTemplate() {
        return almJdbcTemplate;
    }

    public JdbcTemplate getFxJdbcTemplate() {
        return fxJdbcTemplate;
    }
}