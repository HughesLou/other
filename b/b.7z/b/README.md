bootstrap for Razor

refer to bootstrap for Sabre http://stash.uk.standardchartered.com:7990/projects/CD/repos/bootstrap/browse
version based on 19 Feb 2016.