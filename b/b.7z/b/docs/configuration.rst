Configuration files
======================

In order to configure build automation, developer need to edit two files:

.. toctree::
    :maxdepth: 2

    configs/project
    configs/jobs
