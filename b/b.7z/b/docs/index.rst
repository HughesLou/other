.. FMSD CD Bootstrap documentation master file, created by
   sphinx-quickstart on Tue Sep 10 14:30:58 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

FMSD CD build automation
=============================================

Contents:

.. toctree::
    :maxdepth: 3

    Configuration files <configuration>
    Data Objects <dataobject>
    Various helper objects and functions <utils/utils>

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

