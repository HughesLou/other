Data Objects
======================

Configuration items in project.yaml referring to a Python objects, which used to store environment specific settings.
Objects also have methods, which are used by orchestration to configure project.

.. toctree::
    :maxdepth: 2

    data_object/git_object
    data_object/jenkins
    data_object/jenkinsjobs
    data_object/jenkinsviews
    data_object/project
    data_object/versions
    data_object/virtualenv

