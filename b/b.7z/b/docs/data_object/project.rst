Project
=============

Project is a root object and used to define the name of the project and which environments are valid for that project.

Project object represents environment domain object for specific environment

.. automodule:: project
   :members:

