Git Objects
===========

Git objects are used to define Git repository location.

.. automodule:: git_object
   :members:
