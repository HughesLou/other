Jenkins views
=============

Jenkins views objects are used to define which views will be created in Jenkins

.. automodule:: jenkinsviews
   :members:

