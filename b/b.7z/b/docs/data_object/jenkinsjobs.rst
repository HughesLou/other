Jenkins Jobs
============

Jenkins jobs objects are used to define which jobs will be created in Jenkins

.. automodule:: jenkinsjobs
   :members:

