Virtualenv
=============

Virtualenv is used to define which Python virtualenv is going to be used by project

.. automodule:: virtualenv
   :members:

