Versions
=============

Versions objects are used to define how version of binaries is going to be calculated

.. automodule:: versions
   :members:

