Jenkins Instance
================

Jenkins objects are used to define jenkins settings

.. automodule:: jenkins
   :members:

