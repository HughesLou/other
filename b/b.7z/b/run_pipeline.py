import sys
import os
import os.path
import argparse
from os.path import join as jp
here = os.path.dirname(__file__)
sys.path.append('/devshared/home/maleksey/src')
sys.path.append(os.path.abspath(os.path.normpath(os.path.dirname(__file__))))

import logging

from jenkinsapi import jenkins

from jenkinsflow.jobcontrol import serial
from jenkinsflow.unbuffered import UnBuffered
# Unbuffered output does not work well in Jenkins/Hudson, so in case
# this is run from a jenkins/hudson job, we want unbuffered output
sys.stdout = UnBuffered(sys.stdout)


import os.path

def import_file(path_to_module):    
    """Note: path to module must be a relative path starting from a directory in sys.path"""
    module_dir, module_file = os.path.split(path_to_module)
    module_name, _module_ext = os.path.splitext(module_file)
    module_package = ".".join(module_dir.split(os.path.sep)) + '.' + module_name

    module_obj = __import__(module_package, fromlist=['*'])
    module_obj.__file__ = path_to_module
    return module_obj

def main(branch_name, folder_name, which_pipeline,
        jenkins_url='http://sabrebuild1.uk.standardchartered.com:8080/',
        jenkins_user='jenkins', 
        jenkins_password='8e59d14fd18134a02d17a0703ca90e88'):

    if not jenkins_url:
        jenkins_url = 'http://sabrebuild1.uk.standardchartered.com:8080/'

    if not jenkins_user:
        jenkins_user = 'jenkins'

    if not jenkins_password:
        jenkins_password = '8e59d14fd18134a02d17a0703ca90e88'

    if not which_pipeline:
        which_pipeline = 'default'

    logging.basicConfig()
    logging.getLogger("").setLevel(logging.WARNING)

    logging.info('Connecting to Jenkins API')
    print 'DEBUG: jenkins_url=', jenkins_url
    api = jenkins.Jenkins(jenkins_url, username=jenkins_user, 
            password=jenkins_password)
    logging.info('Connected to Jenkins. Starting flow...')

    pipelines = import_file('%s/pipelines.py' % folder_name)

    pipeline = getattr(pipelines, which_pipeline)
    
    pipeline(api, job_name_prefix='%s-' % folder_name, branch_name=branch_name)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(
            description='Runs flow pipeline for a project')
    parser.add_argument('branch', help='Branch name')
    parser.add_argument('project', help='Project name')
    parser.add_argument('pipeline', 
            help='Pipeline to run (default is named"default")', 
            dest='which_pipeline')
    parser.add_argument('-j', '--jenkinsurl', 
                        help='Jenkins URL', required=False)
    parser.add_argument('-u', '--jenkinsuser', 
                        help='User to connect to Jenkins', default='',
                        required=False)
    parser.add_argument('-p', '--jenkinspassword', 
                        help='Jenkins user password', default='', 
                        required=False)
    parser.add_argument('-l', '--loglevel', 
                        help='Logging level', default='INFO', required=False)

    args = parser.parse_args()

    args.loglevel = getattr(logging, args.loglevel.upper(), logging.INFO)
    logging.basicConfig(level=args.loglevel)
    logger = logging.getLogger()

    main(args.branch, args.project, args.which_pipeline, args.jenkinsurl, args.jenkinsuser, args.jenkinspassword)

