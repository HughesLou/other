"""
Usage:
    support.py deletejobs [--jenkins-url URL]

Options:
    --jenkins-url URL    Jenkins URL [default: http://sabrebuild1.uk.standardchartered.com:8180/]
"""
from docopt import docopt
from jenkinsapi.jenkins import Jenkins
import logging

logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s %(filename)s'
                           '[line:%(lineno)d] %(levelname)s %(message)s',
                    datefmt='%a, %d %b %Y %H:%M:%S')
logger = logging.getLogger(__name__)


if __name__ == '__main__':
    args = docopt(__doc__)

    if args['deletejobs']:
        j = Jenkins(args['--jenkins-url'])
        logger.info('Connected to %s', args['--jenkins-url'])

        all_jobs = sorted(j.keys(), key=str.lower)
        logger.info('Number of jobs to be deleted: %s', len(all_jobs))
        for job in all_jobs:
            j.delete_job(job)
            if job not in j:
                logger.info('Job %s has been deleted' % job)
