#!/bin/bash
echo "INFO: Checking if dump files are avaialble"
export ORACLE_HOME=/sabreadm/oracle/product/client11gR2
export LD_LIBRARY_PATH=/sabreadm/oracle/product/client11gR2/lib
export PATH=$PATH:$ORACLE_HOME/bin

function info() {
  echo "INFO: $1"
}

function error() {
  echo "ERROR: $1"
}

info "Checking dump integrity"

if [ "${DMPDATE}" == "" ]; then 
    export DMPDATE=`date '+%d-%h-%Y'`
fi

DMPDATE=`echo $DMPDATE||sed 's/ //g'`
DUMP_FILE="expdp-tds2-prod-tdsuser-$DMPDATE.dmp"

$ORACLE_HOME/bin/impdp userid=DEVAPPSDBA/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" dumpfile=$DUMP_FILE directory=$DATA_DIR sqlfile=validate_tds2.sql

if [ $? -eq 0 ]; then
   info "Dump validated."
else
   error "Dump is invalid."
   exit 1
fi

info "Performing schema clean"

$ORACLE_HOME/bin/sqlplus -s DEVAPPSDBA[$TARGET_SCHEMA_NAME]/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" << EOF1
WHENEVER sqlerror EXIT sql.sqlcode
WHENEVER oserror EXIT failure
set serveroutput on size unlimited

show user;

PROMPT "User Objects BEFORE clean"
select object_type ,count(*) from all_objects where owner='$TARGET_SCHEMA_NAME' group by object_type;

declare
  procedure exec_immediate (p_sql in varchar2) is
  begin
    execute immediate p_sql;
  exception
    when others then
      dbms_output.put_line(SUBSTR(p_sql,1,200));
  end exec_immediate;
begin
  --drop constraints
  for vc in (
    select
      'alter table '||table_name||' '||
      'drop constraint '||constraint_name||' CASCADE ' sqltext
    from user_constraints
    where constraint_type = 'R'
  )
  loop
    exec_immediate (vc.sqltext);
  end loop;

  --drop objects
  for vc in (
    select
      'drop'||chr(32)||object_type||chr(32)||'"'||object_name||'"'||chr(32)||
      DECODE(object_type,'TABLE',' PURGE','TYPE',' FORCE',NULL) sqltext
    from user_objects
    --where
    --  object_type IN
    --  ('VIEW','PACKAGE','FUNCTION','PROCEDURE', 'SEQUENCE','SYNONYM','TABLE','TRIGGER','TYPE')
    order by
      DECODE(object_type,'TYPE',9,'TABLE',8,1),object_name
  )
  loop
    exec_immediate (vc.sqltext);
  end loop;
end;
/

PROMPT "User Objects AFTER clean"
select object_type || ' - REMAINING' as object_type ,count(*) from all_objects where owner='$TARGET_SCHEMA_NAME' group by object_type;

select case when count(*) > 0 then (select 'ORA-00054: Schema Not Clean' from dual ) 
else (select 'Schema Clean Successful' from dual) end case_cnt,object_name from 
all_objects where owner='$TARGET_SCHEMA_NAME' group by object_name;

DECLARE
   after_clean EXCEPTION;
   cnt_num NUMBER;
BEGIN
   DECLARE  ---------- sub-block begins
      after_clean EXCEPTION;  -- this declaration prevails
      cnt_num NUMBER;
   BEGIN
       select count(*) into cnt_num from all_objects where owner='$TARGET_SCHEMA_NAME';
       
      IF cnt_num > 0 THEN
         RAISE after_clean;  -- this is not handled
      END IF;
   END;  ------------- sub-block ends
EXCEPTION
  WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Schema Clean Not Successful');
        raise_application_error(-20101, 'Terminating as Schema clean not successful');
END;
/
EOF1

declare -a my_arr=()
my_arr=(`$ORACLE_HOME/bin/sqlplus -s DEVAPPSDBA/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" << EOF9
set pagesize 0 feedback off verify off heading off echo off
SELECT count(*) from all_objects where owner='$TARGET_SCHEMA_NAME';
exit;
EOF9`);

if [[ ${#my_arr[@]} -gt 1 ]]; then
  echo ${#my_arr[@]} 
  error "Schema Clean Not Successful.."
  exit 1
fi

info "Importing metadata"

info "Importing metadata from $DUMP_FILE"
$ORACLE_HOME/bin/impdp \
userid= DEVAPPSDBA/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" \
logfile=IMPDP-TDS2-PROD_dumpimport-$TARGET_SCHEMA_NAME.log \
directory=$DATA_DIR \
content=METADATA_ONLY \
parallel=4 \
remap_schema=TDSUSER:$TARGET_SCHEMA_NAME \
dumpfile=$DUMP_FILE \
table_exists_action=REPLACE \
exclude=INDEX,CONSTRAINT

if [ "${REFRESH_TYPE}" != "METADATA" ]; then
  info "Importing data from $DUMP_FILE"
  echo $ORACLE_HOME/bin/impdp \
  userid= DEVAPPSDBA/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" \
  logfile=IMPDP-TDS2-PROD_dumpimport-$TARGET_SCHEMA_NAME.log \
  directory=$DATA_DIR \
  content=ALL \
  parallel=4 \
  remap_schema=TDSUSER:$TARGET_SCHEMA_NAME \
  dumpfile=$DUMP_FILE \
  exclude=INDEX,CONSTRAINT table_exists_action=REPLACE

  $ORACLE_HOME/bin/impdp \
  userid= DEVAPPSDBA/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" \
  logfile=IMPDP-TDS2-PROD_dumpimport-$TARGET_SCHEMA_NAME.log \
  directory=$DATA_DIR \
  content=ALL \
  parallel=4 \
  remap_schema=TDSUSER:$TARGET_SCHEMA_NAME \
  dumpfile=$DUMP_FILE \
  exclude=INDEX,CONSTRAINT table_exists_action=REPLACE
else
  info "Not importing data"
fi

$ORACLE_HOME/bin/sqlplus DEVAPPSDBA/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" << EOF2
WHENEVER sqlerror EXIT sql.sqlcode
WHENEVER oserror EXIT failure
set serveroutput on
show user;
alter user $TARGET_SCHEMA_NAME account unlock;
exit;
EOF2

info "Recompiling objects"

$ORACLE_HOME/bin/sqlplus DEVAPPSDBA/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" << EOF3
WHENEVER oserror EXIT failure
set serveroutput on

EXEC DBMS_UTILITY.compile_schema(schema => '$TARGET_SCHEMA_NAME');

PROMPT "List Of Invalid DB Objects On Target Schema"
select object_name, object_type from all_objects where owner='$TARGET_SCHEMA_NAME' and status='INVALID';
exit;
EOF3
