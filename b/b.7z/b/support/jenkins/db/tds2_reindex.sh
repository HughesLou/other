#!/bin/bash
echo "INFO: Performing schema clean"
export ORACLE_HOME=/sabreadm/oracle/product/client11gR2
export LD_LIBRARY_PATH=/sabreadm/oracle/product/client11gR2/lib
export PATH=$PATH:$ORACLE_HOME/bin

echo "Reindex scbtrades"

if [ "$REFRESH_TYPE" == "METADATA" ]; then
    echo "Metadata refresh has been requested. Not doing reindexing."
    exit 0
fi
$ORACLE_HOME/bin/sqlplus -s DEVAPPSDBA[$TARGET_SCHEMA_NAME]/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" << EOF1
WHENEVER sqlerror EXIT sql.sqlcode
WHENEVER oserror EXIT failure
set serveroutput on size unlimited

show user;

-- CONNECT SYS
ALTER SESSION SET EVENTS '10150 TRACE NAME CONTEXT FOREVER, LEVEL 1';
ALTER SESSION SET EVENTS '10904 TRACE NAME CONTEXT FOREVER, LEVEL 1';
ALTER SESSION SET EVENTS '25475 TRACE NAME CONTEXT FOREVER, LEVEL 1';
ALTER SESSION SET EVENTS '10407 TRACE NAME CONTEXT FOREVER, LEVEL 1';
ALTER SESSION SET EVENTS '10851 TRACE NAME CONTEXT FOREVER, LEVEL 1';
ALTER SESSION SET EVENTS '22830 TRACE NAME CONTEXT FOREVER, LEVEL 192 ';
-- new object type path: SCHEMA_EXPORT/TABLE/INDEX/INDEX
-- CONNECT TDSUSER

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_CONTRACT_EVENT_ORIG_ID" ON "SD_CONTRACT_EVENT" ("ORIGINAL_ID", "VERSION")
  PCTFREE 10 INITRANS 2 MAXTRANS 255
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_CONTRACT_EVENT_ORIG_ID" NOPARALLEL';
   dbms_output.put_line('Index SD_CONTRACT_EVENT_ORIG_ID created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_CONTRACT_EVENT_ORIG_ID already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_CONTRACT_EVENT_LEG_ID" ON "SD_CONTRACT_EVENT" ("TRADE_LEG_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_DELIVERABLE_IDENTIFIER" NOPARALLEL';
   dbms_output.put_line('Index SD_DELIVERABLE_IDENTIFIER created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_DELIVERABLE_IDENTIFIER already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_DELIVERABLE_IDENTIFIER" ON "SD_DELIVERABLE" ("ORIG_IDENTIFIER_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_DELIVERABLE_IDENTIFIER" NOPARALLEL';
   dbms_output.put_line('Index SD_DELIVERABLE_IDENTIFIER created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_DELIVERABLE_IDENTIFIER already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_DELIVERABLE_SETTLE_AUDIT" ON "SD_DELIVERABLE" ("AUDIT_TIMESTAMP", "SETTLE_DATE", "BOOK_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_DELIVERABLE_SETTLE_AUDIT" NOPARALLEL';
   dbms_output.put_line('Index SD_DELIVERABLE_SETTLE_AUDIT created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_DELIVERABLE_SETTLE_AUDIT already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_DELIVERABLE_IDX" ON "SD_DELIVERABLE" ("TRADE_LEG_ID", "SETTLE_DATE", "AUDIT_TIMESTAMP") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_DELIVERABLE_IDX" NOPARALLEL';
   dbms_output.put_line('Index SD_DELIVERABLE_IDX created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_DELIVERABLE_IDX already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_TRADE_TRADE_LEG_ID" ON "SD_TRADE_TRADE_LEG" ("TRADE_LEG_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_TRADE_TRADE_LEG_ID" NOPARALLEL';
   dbms_output.put_line('Index SD_TRADE_TRADE_LEG_ID created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_TRADE_TRADE_LEG_ID already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_TRADE_LEG_IDENTIFIER" ON "SD_TRADE_LEG_IDENTIFIER" ("IDENTIFIER", "TRADE_LEG_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_TRADE_LEG_IDENTIFIER" NOPARALLEL';
   dbms_output.put_line('Index SD_TRADE_LEG_IDENTIFIER created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_TRADE_LEG_IDENTIFIER already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_TRADE_LEG_ID_LEG_ID" ON "SD_TRADE_LEG_IDENTIFIER" ("TRADE_LEG_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_TRADE_LEG_ID_LEG_ID" NOPARALLEL';
   dbms_output.put_line('Index SD_TRADE_LEG_ID_LEG_ID created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_TRADE_LEG_ID_LEG_ID already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_TRADE_LEG_INFO" ON "SD_TRADE_LEG_INFO" ("TRADE_LEG_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_TRADE_LEG_INFO" NOPARALLEL';
   dbms_output.put_line('Index SD_TRADE_LEG_INFO created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_TRADE_LEG_INFO already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_PACKAGE_ORIG_ID" ON "SD_TRADE_PACKAGE" ("ORIG_IDENTIFIER_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_PACKAGE_ORIG_ID" NOPARALLEL';
   dbms_output.put_line('Index SD_PACKAGE_ORIG_ID created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_PACKAGE_ORIG_ID already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_TRADE_PACKAGE_TRADE_ID" ON "SD_TRADE_PACKAGE_TRADE" ("TRADE_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_TRADE_PACKAGE_TRADE_ID" NOPARALLEL';
   dbms_output.put_line('Index SD_TRADE_PACKAGE_TRADE_ID created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_TRADE_PACKAGE_TRADE_ID already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_STATE_TRANSITION_STATE" ON "SD_STATE_TRANSITION" ("TRADE_ID", "STATE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_STATE_TRANSITION_STATE" NOPARALLEL';
   dbms_output.put_line('Index SD_STATE_TRANSITION_STATE created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_STATE_TRANSITION_STATE already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_KV_ATTR_TRADEABLE" ON "SD_KV_TRADEABLE_ATTR" ("TRADEABLE_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_KV_ATTR_TRADEABLE" NOPARALLEL';
   dbms_output.put_line('Index SD_KV_ATTR_TRADEABLE created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_KV_ATTR_TRADEABLE already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_TRADE_LEG_ORIGINAL_ID" ON "SD_TRADE_LEG" ("ORIGINAL_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_TRADE_LEG_ORIGINAL_ID" NOPARALLEL';
   dbms_output.put_line('Index SD_TRADE_LEG_ORIGINAL_ID created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_TRADE_LEG_ORIGINAL_ID already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_TRADE_LEG_ORIG_ID" ON "SD_TRADE_LEG" ("ORIG_IDENTIFIER_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_TRADE_LEG_ORIG_ID" NOPARALLEL';
   dbms_output.put_line('Index SD_TRADE_LEG_ORIG_ID created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_TRADE_LEG_ORIG_ID already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_TRADEABLE_UNDERLYING" ON "SD_TRADEABLE" ("UNDERLYING") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_TRADEABLE_UNDERLYING" NOPARALLEL';
   dbms_output.put_line('Index SD_TRADEABLE_UNDERLYING created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_TRADEABLE_UNDERLYING already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_TRADEABLE_HASH" ON "SD_TRADEABLE" ("HASH") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_TRADEABLE_HASH" NOPARALLEL';
   dbms_output.put_line('Index SD_TRADEABLE_HASH created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_TRADEABLE_HASH already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_TRADE_BOOK" ON "SD_TRADE" ("BOOK_ID", "AUDIT_TIMESTAMP_END", "STATUS") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_TRADE_BOOK" NOPARALLEL';
   dbms_output.put_line('Index SD_TRADE_BOOK created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_TRADE_BOOK already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_TRADE_ORIG_ID" ON "SD_TRADE" ("ORIG_IDENTIFIER_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_TRADE_ORIG_ID" NOPARALLEL';
   dbms_output.put_line('Index SD_TRADE_ORIG_ID created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_TRADE_ORIG_ID already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_TRADE_ORIGINAL_ID" ON "SD_TRADE" ("ORIGINAL_ID", "AUDIT_TIMESTAMP", "AUDIT_TIMESTAMP_END") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_TRADE_ORIGINAL_ID" NOPARALLEL';
   dbms_output.put_line('Index SD_TRADE_ORIGINAL_ID created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_TRADE_ORIGINAL_ID already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE UNIQUE INDEX "SD_TRADE_PK" ON "SD_TRADE" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_TRADE_PK" NOPARALLEL';
   dbms_output.put_line('Index SD_TRADE_PK created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_TRADE_PK already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE UNIQUE INDEX "SD_TRADE_ID_VERSION" ON "SD_TRADE" ("ORIGINAL_ID", "VERSION") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_TRADE_ID_VERSION" NOPARALLEL';
   dbms_output.put_line('Index SD_TRADE_ID_VERSION created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_TRADE_ID_VERSION already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_LEGAL_ENTITY_EXT_ID" ON "SD_LEGAL_ENTITY" ("EXTERNAL_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_LEGAL_ENTITY_EXT_ID" NOPARALLEL';
   dbms_output.put_line('Index SD_LEGAL_ENTITY_EXT_ID created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_LEGAL_ENTITY_EXT_ID already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_IDENTIFIER_ID" ON "SD_IDENTIFIER" ("IDENTIFIER") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_IDENTIFIER_ID" NOPARALLEL';
   dbms_output.put_line('Index SD_IDENTIFIER_ID created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_IDENTIFIER_ID already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_IDENTIFIER_SOURCE" ON "SD_IDENTIFIER" ("TRADE_SOURCE_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_IDENTIFIER_SOURCE" NOPARALLEL';
   dbms_output.put_line('Index SD_IDENTIFIER_SOURCE created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_IDENTIFIER_SOURCE already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_TRADE_LEG_CLS_ID" ON "SD_TRADE_LEG" ("CLASS_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_TRADE_LEG_CLS_ID" NOPARALLEL';
   dbms_output.put_line('Index SD_TRADE_LEG_CLS_ID created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_TRADE_LEG_CLS_ID already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_TRADE_LEG_TRDBLE_ID" ON "SD_TRADE_LEG" ("TRADEABLE_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_TRADE_LEG_TRDBLE_ID" NOPARALLEL';
   dbms_output.put_line('Index SD_TRADE_LEG_TRDBLE_ID created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_TRADE_LEG_TRDBLE_ID already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_IDENTIFIER_ID_SOURCE" ON "SD_IDENTIFIER" ("ID", "TRADE_SOURCE_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_IDENTIFIER_ID_SOURCE" NOPARALLEL';
   dbms_output.put_line('Index SD_IDENTIFIER_ID_SOURCE created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_IDENTIFIER_ID_SOURCE already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE UNIQUE INDEX "UK_OBSDATE_UNQ" ON "SD_OBSERVATION_DATE" ("NICKNAME", "OBSERVATION_DATE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 167 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "UK_OBSDATE_UNQ" NOPARALLEL';
   dbms_output.put_line('Index UK_OBSDATE_UNQ created');
exception
   when already_exists then
   dbms_output.put_line('Index UK_OBSDATE_UNQ already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_OBS_DATE_NICKNAME" ON "SD_OBSERVATION_DATE" ("ID", "OBSERVATION_DATE", "NICKNAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 166 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_OBS_DATE_NICKNAME" NOPARALLEL';
   dbms_output.put_line('Index SD_OBS_DATE_NICKNAME created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_OBS_DATE_NICKNAME already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_TRADEABLE_OBS_DATE" ON "SD_TRADEABLE_OBSERVATION_DATE" ("TRADEABLE_ID", "OBSERVATION_DATE_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_TRADEABLE_OBS_DATE" NOPARALLEL';
   dbms_output.put_line('Index SD_TRADEABLE_OBS_DATE created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_TRADEABLE_OBS_DATE already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_TRADE_CTPTY_ID" ON "SD_TRADE" ("STATUS", "CTPTY_ID", "AUDIT_TIMESTAMP_END", "AUDIT_TIMESTAMP") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_TRADE_CTPTY_ID" NOPARALLEL';
   dbms_output.put_line('Index SD_TRADE_CTPTY_ID created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_TRADE_CTPTY_ID already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_TRADE_BOOK_RANGE" ON "SD_TRADE" ("STATUS", "BOOK_ID", "AUDIT_TIMESTAMP_END", "AUDIT_TIMESTAMP") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_TRADE_BOOK_RANGE" NOPARALLEL';
   dbms_output.put_line('Index SD_TRADE_BOOK_RANGE created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_TRADE_BOOK_RANGE already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_TRADE_PRODUCT_ID" ON "SD_TRADE" ("STATUS", "PRODUCT_ID", "AUDIT_TIMESTAMP_END", "AUDIT_TIMESTAMP") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_TRADE_PRODUCT_ID" NOPARALLEL';
   dbms_output.put_line('Index SD_TRADE_PRODUCT_ID created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_TRADE_PRODUCT_ID already exists');
   null;
end;
/

-- new object type path: SCHEMA_EXPORT/TABLE/INDEX/FUNCTIONAL_INDEX/INDEX
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_IDENTIFIER_SPLIT" ON "SD_IDENTIFIER" ( REGEXP_SUBSTR ("IDENTIFIER",'^[^_]*')) 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_IDENTIFIER_SPLIT" NOPARALLEL';
   dbms_output.put_line('Index SD_IDENTIFIER_SPLIT created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_IDENTIFIER_SPLIT already exists');
   null;
end;
/

declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
CREATE INDEX "SD_TL_IDENTIFIER_SPLIT" ON "SD_TRADE_LEG_IDENTIFIER" ( REGEXP_SUBSTR ("IDENTIFIER",'^[^_]*')) 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4;
';
   execute immediate 'ALTER INDEX "SD_TL_IDENTIFIER_SPLIT" NOPARALLEL';
   dbms_output.put_line('Index SD_TL_IDENTIFIER_SPLIT created');
exception
   when already_exists then
   dbms_output.put_line('Index SD_TL_IDENTIFIER_SPLIT already exists');
   null;
end;
/

-- new object type path: SCHEMA_EXPORT/TABLE/CONSTRAINT/CONSTRAINT
-- CONNECT SYS
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_BOOK" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
';
   dbms_output.put_line('Constraint on SD_BOOK created');
exception
   when already_exists then
   dbms_output.put_line('Constraint SD_BOOK already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_CONTRACT_EVENT" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
';
   dbms_output.put_line('Constraint on SD_CONTRACT_EVENT created');
exception
   when already_exists then
   dbms_output.put_line('Constraint SD_CONTRACT_EVENT already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_IDENTIFIER" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
';
   dbms_output.put_line('Constraint on SD_IDENTIFIER created');
exception
   when already_exists then
   dbms_output.put_line('Constraint SD_IDENTIFIER already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_KV_TRADEABLE_ATTR" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
';
   dbms_output.put_line('Constraint on SD_KV_TRADEABLE_ATTR created');
exception
   when already_exists then
   dbms_output.put_line('Constraint SD_KV_TRADEABLE_ATTR already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_LEGAL_ENTITY" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
';
   dbms_output.put_line('Constraint on SD_LEGAL_ENTITY created');
exception
   when already_exists then
   dbms_output.put_line('Constraint SD_LEGAL_ENTITY already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_PRICER_CONFIG" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
';
   dbms_output.put_line('Constraint on SD_PRICER_CONFIG created');
exception
   when already_exists then
   dbms_output.put_line('Constraint SD_PRICER_CONFIG already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_PRODUCT" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
';
   dbms_output.put_line('Constraint on SD_PRODUCT created');
exception
   when already_exists then
   dbms_output.put_line('Constraint SD_PRODUCT already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_SOURCE_SYSTEM" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
';
   dbms_output.put_line('Constraint on SD_SOURCE_SYSTEM created');
exception
   when already_exists then
   dbms_output.put_line('Constraint SD_SOURCE_SYSTEM already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_STATE_TRANSITION" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
';
   dbms_output.put_line('Constraint on SD_STATE_TRANSITION created');
exception
   when already_exists then
   dbms_output.put_line('Constraint SD_STATE_TRANSITION already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_TRADE" ADD CONSTRAINT "SD_TRADE_ID_VERSION" UNIQUE ("ORIGINAL_ID", "VERSION")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
';
   dbms_output.put_line('Constraint on SD_TRADE created');
exception
   when already_exists then
   dbms_output.put_line('Constraint SD_TRADE already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_TRADE" ADD CONSTRAINT "SD_TRADE_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
';
   dbms_output.put_line('Constraint on SD_TRADE created');
exception
   when already_exists then
   dbms_output.put_line('Constraint SD_TRADE already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_TRADEABLE" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
';
   dbms_output.put_line('Constraint on SD_TRADEABLE created');
exception
   when already_exists then
   dbms_output.put_line('Constraint SD_TRADEABLE already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_TRADE_CLASSIFICATION" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
';
   dbms_output.put_line('Constraint on SD_TRADE_CLASSIFICATION created');
exception
   when already_exists then
   dbms_output.put_line('Constraint SD_TRADE_CLASSIFICATION already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_TRADE_LEG" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
';
   dbms_output.put_line('Constraint on SD_TRADE_LEG created');
exception
   when already_exists then
   dbms_output.put_line('Constraint SD_TRADE_LEG already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_DELIVERABLE" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
';
   dbms_output.put_line('Constraint on SD_DELIVERABLE created');
exception
   when already_exists then
   dbms_output.put_line('Constraint SD_DELIVERABLE already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_TRADE_LEG_IDENTIFIER" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
';
   dbms_output.put_line('Constraint on SD_TRADE_LEG_IDENTIFIER created');
exception
   when already_exists then
   dbms_output.put_line('Constraint SD_TRADE_LEG_IDENTIFIER already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_TRADE_LEG_INFO" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
';
   dbms_output.put_line('Constraint on SD_TRADE_LEG_INFO created');
exception
   when already_exists then
   dbms_output.put_line('Constraint SD_TRADE_LEG_INFO already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_TRADE_PACKAGE" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
';
   dbms_output.put_line('Constraint on SD_TRADE_PACKAGE created');
exception
   when already_exists then
   dbms_output.put_line('Constraint SD_TRADE_PACKAGE already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_TRADE_PACKAGE_TRADE" ADD PRIMARY KEY ("PACKAGE_ID", "TRADE_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
';
   dbms_output.put_line('Constraint on SD_TRADE_PACKAGE_TRADE created');
exception
   when already_exists then
   dbms_output.put_line('Constraint SD_TRADE_PACKAGE_TRADE already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_TRADE_TRADE_LEG" ADD PRIMARY KEY ("TRADE_ID", "TRADE_LEG_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
';
   dbms_output.put_line('Constraint on SD_TRADE_TRADE_LEG created');
exception
   when already_exists then
   dbms_output.put_line('Constraint SD_TRADE_TRADE_LEG already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_TRANSITION_ACTION" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
';
   dbms_output.put_line('Constraint on SD_TRANSITION_ACTION created');
exception
   when already_exists then
   dbms_output.put_line('Constraint SD_TRANSITION_ACTION already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_TRANSITION_REASON" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
';
   dbms_output.put_line('Constraint on SD_TRANSITION_REASON created');
exception
   when already_exists then
   dbms_output.put_line('Constraint SD_TRANSITION_REASON already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_TRANSITION_STATE" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
';
   dbms_output.put_line('Constraint on SD_TRANSITION_STATE created');
exception
   when already_exists then
   dbms_output.put_line('Constraint SD_TRANSITION_STATE already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_USER" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
';
   dbms_output.put_line('Constraint on SD_USER created');
exception
   when already_exists then
   dbms_output.put_line('Constraint SD_USER already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_EVENT_MESSAGE_FIELD" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
';
   dbms_output.put_line('Constraint on SD_EVENT_MESSAGE_FIELD created');
exception
   when already_exists then
   dbms_output.put_line('Constraint SD_EVENT_MESSAGE_FIELD already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_OBSERVATION_DATE" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
';
   dbms_output.put_line('Constraint on SD_OBSERVATION_DATE created');
exception
   when already_exists then
   dbms_output.put_line('Constraint SD_OBSERVATION_DATE already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_TRADEABLE_OBSERVATION_DATE" ADD PRIMARY KEY ("OBSERVATION_DATE_ID", "TRADEABLE_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
';
   dbms_output.put_line('Constraint on SD_TRADEABLE_OBSERVATION_DATE created');
exception
   when already_exists then
   dbms_output.put_line('Constraint SD_TRADEABLE_OBSERVATION_DATE already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_OBSERVATION_DATE" ADD CONSTRAINT "UK_OBSDATE_UNQ" UNIQUE ("NICKNAME", "OBSERVATION_DATE")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 167 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
';
   dbms_output.put_line('Constraint on SD_OBSERVATION_DATE created');
exception
   when already_exists then
   dbms_output.put_line('Constraint SD_OBSERVATION_DATE already exists');
   null;
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
end;
/

-- new object type path: SCHEMA_EXPORT/TABLE/CONSTRAINT/REF_CONSTRAINT
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_CONTRACT_EVENT" ADD CONSTRAINT "FK6B55A0BB84796DE5" FOREIGN KEY ("TRADE_LEG_ID")
      REFERENCES "SD_TRADE_LEG" ("ID") ENABLE
';
   dbms_output.put_line('Constraint FK6B55A0BB84796DE5 created');
exception
   when already_exists then
   dbms_output.put_line('Constraint FK6B55A0BB84796DE5 already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_KV_TRADEABLE_ATTR" ADD CONSTRAINT "FKE651DBD8EF79127A" FOREIGN KEY ("TRADEABLE_ID")
      REFERENCES "SD_TRADEABLE" ("ID") ENABLE
';
   dbms_output.put_line('Constraint FKE651DBD8EF79127A created');
exception
   when already_exists then
   dbms_output.put_line('Constraint FKE651DBD8EF79127A already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_STATE_TRANSITION" ADD CONSTRAINT "FK1884861137B7C8BA" FOREIGN KEY ("TRADE_ID")
      REFERENCES "SD_TRADE" ("ID") ENABLE
';
   dbms_output.put_line('Constraint FK1884861137B7C8BA created');
exception
   when already_exists then
   dbms_output.put_line('Constraint FK1884861137B7C8BA already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_TRADE" ADD CONSTRAINT "FK620BA5D6C448AE1C" FOREIGN KEY ("ORIG_IDENTIFIER_ID")
      REFERENCES "SD_IDENTIFIER" ("ID") ENABLE
';
   dbms_output.put_line('Constraint FK620BA5D6C448AE1C created');
exception
   when already_exists then
   dbms_output.put_line('Constraint FK620BA5D6C448AE1C already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_TRADE_LEG" ADD CONSTRAINT "FK85A52005C448AE1C" FOREIGN KEY ("ORIG_IDENTIFIER_ID")
      REFERENCES "SD_IDENTIFIER" ("ID") ENABLE
';
   dbms_output.put_line('Constraint FK85A52005C448AE1C created');
exception
   when already_exists then
   dbms_output.put_line('Constraint FK85A52005C448AE1C already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_TRADE_LEG_IDENTIFIER" ADD CONSTRAINT "FK49B00923B407CB1" FOREIGN KEY ("TRADE_LEG_ID")
      REFERENCES "SD_TRADE_LEG" ("ID") ENABLE
';
   dbms_output.put_line('Constraint FK49B00923B407CB1 created');
exception
   when already_exists then
   dbms_output.put_line('Constraint FK49B00923B407CB1 already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_TRADE_LEG_INFO" ADD CONSTRAINT "FKE27430A8B407CB1" FOREIGN KEY ("TRADE_LEG_ID")
      REFERENCES "SD_TRADE_LEG" ("ID") ENABLE
';
   dbms_output.put_line('Constraint FKE27430A8B407CB1 created');
exception
   when already_exists then
   dbms_output.put_line('Constraint FKE27430A8B407CB1 already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_EVENT_MESSAGE_FIELD" ADD CONSTRAINT "FKE_EMF_E" FOREIGN KEY ("EVENT_MESSAGE_ID")
      REFERENCES "SD_EVENT_MESSAGE" ("ID") ENABLE
';
   dbms_output.put_line('Constraint FKE_EMF_E created');
exception
   when already_exists then
   dbms_output.put_line('Constraint FKE_EMF_E already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_TRADEABLE_OBSERVATION_DATE" ADD CONSTRAINT "FKE_OBSDATE_ID_OBSDATE" FOREIGN KEY ("OBSERVATION_DATE_ID")
      REFERENCES "SD_OBSERVATION_DATE" ("ID") ENABLE
';
   dbms_output.put_line('Constraint FKE_OBSDATE_ID_OBSDATE created');
exception
   when already_exists then
   dbms_output.put_line('Constraint FKE_OBSDATE_ID_OBSDATE already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   execute immediate '
ALTER TABLE "SD_TRADEABLE_OBSERVATION_DATE" ADD CONSTRAINT "FKE_TRADEABLE_ID_TRADEABLE" FOREIGN KEY ("TRADEABLE_ID")
      REFERENCES "SD_TRADEABLE" ("ID") ENABLE
';
   dbms_output.put_line('Constraint FKE_TRADEABLE_ID_TRADEABLE created');
exception
   when already_exists then
   dbms_output.put_line('Constraint FKE_TRADEABLE_ID_TRADEABLE already exists');
   null;
end;
/
EOF1
