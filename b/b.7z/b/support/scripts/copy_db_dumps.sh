#!/bin/bash
readonly ARGS="$@"
readonly DUMP_FILE="/ora_dump/DOUK1DAS/datapump/expdp-tds2-prod-tdsuser-$(date -d "yesterday 13:00 " '+%Y-%b-%d').dmp"
readonly MAX_WAIT=720

fail_mail() {
    local message=$1
    echo $message | mailx -s "TDS2 copy from DEV to UAT status | $HOSTNAME | $(date +%a-%H:%M) " "jay.singh@sc.com"
    exit 1
}

success_mail() {
    echo "Success!" | mailx -s "TDS2 copy from DEV to UAT status | $HOSTNAME | $(date +%a-%H:%M) " "jay.singh@sc.com"
    exit 0
}

timed_sleep() {
    local counter=$1
    local max_time=$2

    sleep 10
    if [ $counter -lt $max_time ]; then
        echo -n "."
    else
        fail_mail "Waited for ${max_time}0 seconds Giving up."
    fi
}

wait_for_file() {
    local counter=0
    echo "Waiting ${MAX_WAIT}0 seconds for file $DUMP_FILE to appear. Each dot represents 10 seconds."
    while true; do
        if [[ -f $DUMP_FILE ]]; then
            break
        else
            let counter=counter+1
            timed_sleep $counter $MAX_WAIT
        fi
    done
    echo "Found file"
}

wait_for_file_closed() {
    local counter=0
    echo "Waiting ${MAX_WAIT}0 seconds for file to be closed. Each dot represents 10 seconds."
    while /usr/sbin/lsof | grep $DUMP_FILE > /dev/null; do
        let counter=counter+1
        timed_sleep $counter $MAX_WAIT
    done
}

copy_file() {
    ssh uklpdufms01a "rm -rf /ora_dump/UOUK1DAS/datapump/*"
    rsync -avz $DUMP_FILE uklpdufms01a:/ora_dump/UOUK1DAS/datapump/
}

main() {
    wait_for_file
    wait_for_file_closed
    copy_file
    success_mail
}

main
