#!/bin/bash

readonly CORTEXVERSION=$1
# Remove trailing slash from URL - Jenkins job will fail if URL has trailing slash
readonly URL=${2%/}
# token value defined in Jenkins job
readonly TOKEN="CORTEX"

# call Jenkins job and append output (if any) to log file
echo "$(date) - Cortex update triggered remotely with parameters: $1 $2"
/usr/bin/curl -sS --data "token=$TOKEN&CORTEXVERSION=$CORTEXVERSION&CORTEXURL=$URL" http://sabrebuild1.uk.standardchartered.com:8080/job/SRM-CortexLatestRelease/buildWithParameters | tee -a /sabrebuild/cortex/cortex_update.log
