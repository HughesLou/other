set echo on;
set serveroutput on;

spool TDS2_Index_Proc_Create.log

create or replace
procedure PROC_CREATE_INDEX (
P_TABLENAME VARCHAR2,
P_INDEXNAME VARCHAR2,
P_FIELDS VARCHAR2,
P_UNIQUE VARCHAR2)
IS
   v_sql VARCHAR2(4000);
   v_errorMsg VARCHAR2(200);
   already_exist EXCEPTION;
   R_RESULT VARCHAR(1000);

BEGIN

   v_sql := 'create ' || p_unique || ' index ' || p_indexname || ' on ' || p_tablename || ' ( ' || p_fields || ' )  TABLESPACE "SABRE_UAT_DATA" PARALLEL 8 NOLOGGING';
   EXECUTE IMMEDIATE v_sql;
   v_sql := 'ALTER INDEX ' || p_indexname || ' NOPARALLEL';
   EXECUTE IMMEDIATE v_sql;

   dbms_output.put_line('Index ' || p_indexname || ' created');
   R_RESULT := 'SUCCESS';

EXCEPTION

  WHEN OTHERS THEN
    if sqlcode = -955 then
       dbms_output.put_line('Index ' || p_indexname || ' already exists.');
       R_RESULT := 'EXISTS';
    else
       v_errorMsg:=SUBSTR(SQLERRM,1,200);
       dbms_output.put_line(v_errorMsg);
       R_RESULT := v_errorMsg;
    end if;

END PROC_CREATE_INDEX;
/
select *
from all_errors
where name = 'PROC_CREATE_INDEX'
order by sequence;
/
create or replace
procedure PROC_CREATE_PK (
P_TABLENAME VARCHAR2,
P_INDEXNAME VARCHAR2,
P_FIELDS VARCHAR2)
IS
   v_sql VARCHAR2(4000);
   v_errorMsg VARCHAR2(200);
   already_exist EXCEPTION;
   only_one_primary_key EXCEPTION;
   R_RESULT VARCHAR(1000);

BEGIN

   v_sql := 'ALTER TABLE ' || p_tablename || ' ADD CONSTRAINT ' || p_indexname || ' PRIMARY KEY (' || p_fields || ') USING INDEX ' || p_indexname || '  ENABLE';
   EXECUTE IMMEDIATE v_sql;

   dbms_output.put_line('Index ' || p_indexname || ' created');
   R_RESULT := 'SUCCESS';

EXCEPTION

  WHEN OTHERS THEN
    if sqlcode = -955 then
       dbms_output.put_line('Constraint ' || p_tablename || ' already exists.');
       R_RESULT := 'EXISTS';
    else
        if sqlcode = -2260 then
           dbms_output.put_line('Constraint ' || p_tablename || ' already exists.');
           R_RESULT := 'EXISTS';
        else
           v_errorMsg:=SUBSTR(SQLERRM,1,200);
           dbms_output.put_line(v_errorMsg);
           R_RESULT := v_errorMsg;
        end if;
    end if;

END PROC_CREATE_PK;
/
select *
from all_errors
where name = 'PROC_CREATE_PK'
order by sequence;
/
create or replace
procedure PROC_CREATE_UNIQUE (
P_TABLENAME VARCHAR2,
P_INDEXNAME VARCHAR2,
P_FIELDS VARCHAR2,
P_USING_INDEX VARCHAR2)
IS
   v_sql VARCHAR2(4000);
   v_errorMsg VARCHAR2(200);
   already_exist EXCEPTION;
   only_one_primary_key EXCEPTION;
   R_RESULT VARCHAR2(1000);

BEGIN

   v_sql := 'ALTER TABLE ' || p_tablename || ' ADD CONSTRAINT ' || p_indexname || ' UNIQUE (' || p_fields || ') USING INDEX ' || p_using_index || '  ENABLE';
   EXECUTE IMMEDIATE v_sql;

   dbms_output.put_line('Index ' || p_indexname || ' created');
   R_RESULT := 'SUCCESS';

EXCEPTION

  WHEN OTHERS THEN
    if sqlcode = -955 then
       dbms_output.put_line('Constraint ' || p_tablename || ' already exists.');
       R_RESULT := 'EXISTS';
    else
        if sqlcode = -2260 then
           dbms_output.put_line('Constraint ' || p_tablename || ' already exists.');
           R_RESULT := 'EXISTS';
        else
           v_errorMsg:=SUBSTR(SQLERRM,1,200);
           dbms_output.put_line(v_errorMsg);
           R_RESULT := v_errorMsg;
        end if;
    end if;

END PROC_CREATE_UNIQUE;
/
select *
from all_errors
where name = 'PROC_CREATE_UNIQUE'
order by sequence;
/
create or replace
procedure PROC_CREATE_FK (
P_TABLENAME VARCHAR2,
P_INDEXNAME VARCHAR2,
P_FIELDS VARCHAR2,
P_REF_TABLE VARCHAR2,
P_REF_FIELDS VARCHAR2)
IS
   v_sql VARCHAR2(4000);
   v_errorMsg VARCHAR2(200);
   already_exist EXCEPTION;
   ref_integrity EXCEPTION;
   R_RESULT VARCHAR2(1000);

BEGIN

   v_sql := 'ALTER TABLE ' || p_tablename || ' ADD CONSTRAINT ' || p_indexname || ' FOREIGN KEY (' || p_fields || ') REFERENCES ' || P_REF_TABLE || ' (' || P_REF_FIELDS || ')  ENABLE';
   EXECUTE IMMEDIATE v_sql;

   dbms_output.put_line('Index ' || p_indexname || ' created');
   R_RESULT := 'SUCCESS';

EXCEPTION

  WHEN OTHERS THEN
    if sqlcode = -955 then
       dbms_output.put_line('Constraint ' || p_tablename || ' already exists.');
       R_RESULT := 'EXISTS';
    else
        if sqlcode = -2298 then
           dbms_output.put_line('Referential integrity problem ' || p_tablename || '.' || p_indexname || '');
           R_RESULT := 'REF_PROBLEM';
        else
           v_errorMsg:=SUBSTR(SQLERRM,1,200);
           dbms_output.put_line(v_errorMsg);
           R_RESULT := v_errorMsg;
        end if;
    end if;

END PROC_CREATE_FK;
/
select *
from all_errors
where name = 'PROC_CREATE_FK'
order by sequence;
/
create or replace
procedure PROC_CREATE_REGEXP_INDEX (
P_TABLENAME VARCHAR2,
P_INDEXNAME VARCHAR2)
IS
   v_sql VARCHAR2(4000);
   v_errorMsg VARCHAR2(200);
   already_exist EXCEPTION;
   R_RESULT VARCHAR(1000);

BEGIN

   v_sql := 'create index ' || p_indexname || ' on ' || p_tablename || ' (REGEXP_SUBSTR("IDENTIFIER", ''^[^_]*'')) TABLESPACE "SABRE_UAT_DATA" PARALLEL 8 NOLOGGING';
   EXECUTE IMMEDIATE v_sql;
   v_sql := 'ALTER INDEX ' || p_indexname || ' NOPARALLEL';
   EXECUTE IMMEDIATE v_sql;

   dbms_output.put_line('Index ' || p_indexname || ' created');
   R_RESULT := 'SUCCESS';

EXCEPTION

  WHEN OTHERS THEN
    if sqlcode = -955 then
       dbms_output.put_line('Index ' || p_indexname || ' already exists.');
       R_RESULT := 'EXISTS';
    else
       v_errorMsg:=SUBSTR(SQLERRM,1,200);
       dbms_output.put_line(v_errorMsg);
       R_RESULT := v_errorMsg;
    end if;

END PROC_CREATE_REGEXP_INDEX;
/
select *
from all_errors
where name = 'PROC_CREATE_REGEXP_INDEX'
order by sequence;
/

spool off;
