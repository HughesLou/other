#!/bin/bash

source support/scripts/db/TDS2/setenv.sh

banner "Recompiling objects"

$ORACLE_HOME/bin/sqlplus DEVAPPSDBA/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" << EOF3
WHENEVER oserror EXIT failure
set serveroutput on

EXEC DBMS_UTILITY.compile_schema(schema => '$TARGET_SCHEMA_NAME');

PROMPT "List Of Invalid DB Objects On Target Schema"
select object_name, object_type from all_objects where owner='$TARGET_SCHEMA_NAME' and status='INVALID';
exit;
EOF3

