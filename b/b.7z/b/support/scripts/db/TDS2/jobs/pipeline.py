import sys
import os
import os.path
from os.path import join as jp
here = os.path.dirname(__file__)

os.unsetenv('http_proxy')
os.environ['http_proxy'] = ''

import logging

from jenkinsapi import jenkins

from jenkinsflow.jobcontrol import serial, parallel
from jenkinsflow.unbuffered import UnBuffered
# Unbuffered output does not work well in Jenkins/Hudson, so in case
# this is run from a jenkins/hudson job, we want unbuffered output
sys.stdout = UnBuffered(sys.stdout)


jenkinsurl = "{project.jenkins.url}"
jenkins_user = "{project.jenkins.user_name}"
jenkins_token = "{project.jenkins.user_token}"

def main():
    logging.basicConfig()
    logging.getLogger("").setLevel(logging.WARNING)
    api = jenkins.Jenkins(jenkinsurl, jenkins_user, jenkins_token)

    with parallel(api, timeout=0, job_name_prefix='{name}_', report_interval=5) as ctrl1:
        ctrl1.invoke_unchecked('docs_{branch}')
        ctrl1.invoke('nose_{branch}')

if __name__ == '__main__':
    main()

