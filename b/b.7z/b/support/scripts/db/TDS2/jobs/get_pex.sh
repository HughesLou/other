#!/bin/bash

set -o errexit
set -o nounset
set -o pipefail

function usage() {
    echo "$0 PEXNAME VERSION"
    echo ""
    echo "PEXNAME - Pex name to download from Nexus"
    echo "VERSION - Version of the PEX"

    echo $@
    exit 1
}

function download() {
    echo "Downloading from Nexus: sabre-devops/tools/virtualenv/$PEXNAME/$VERSION/$PEXNAME-$VERSION.pex"
    wget -nv -O $PEXNAME.pex http://sabrebuild1.uk.standardchartered.com:8081/nexus/content/repositories/sabre-devops/tools/virtualenv/$PEXNAME/$VERSION/$PEXNAME-$VERSION.pex
    chmod u+x $PEXNAME.pex
    echo "Downloaded $PEXNAME.pex"
}

function main() {
    download
    echo "All done."
}

[ $# -lt 2 ] && usage

readonly PEXNAME=$1
readonly VERSION=$2

main
