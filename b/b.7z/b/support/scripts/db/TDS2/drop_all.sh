#!/bin/bash

source support/scripts/db/TDS2/setenv.sh

banner "Performing schema clean"

$ORACLE_HOME/bin/sqlplus -s DEVAPPSDBA[$TARGET_SCHEMA_NAME]/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" << EOF1
WHENEVER sqlerror EXIT sql.sqlcode
WHENEVER oserror EXIT failure
set serveroutput on size unlimited

show user;

PROMPT "User Objects BEFORE clean"
select object_type ,count(*) from all_objects where owner='$TARGET_SCHEMA_NAME' group by object_type;

declare
  procedure exec_immediate (p_sql in varchar2) is
  begin
    execute immediate p_sql;
  exception
    when others then
      dbms_output.put_line(SUBSTR(p_sql,1,200));
  end exec_immediate;
begin
  --drop constraints
  for vc in (
    select
      'alter table '||table_name||' '||
      'drop constraint '||constraint_name||' CASCADE ' sqltext
    from user_constraints
    where constraint_type = 'R'
  )
  loop
    exec_immediate (vc.sqltext);
  end loop;

  --drop objects
  for vc in (
    select
      'drop'||chr(32)||object_type||chr(32)||'"'||object_name||'"'||chr(32)||
      DECODE(object_type,'TABLE',' PURGE','TYPE',' FORCE',NULL) sqltext
    from user_objects
    order by
      DECODE(object_type,'TYPE',9,'TABLE',8,1),object_name
  )
  loop
    exec_immediate (vc.sqltext);
  end loop;

  -- Drop AQ Tables
  for vc in (
    select
     'begin dbms_aqadm.drop_queue_table (queue_table => '''||QUEUE_TABLE||''', force =>TRUE) end;' sqltext
     from user_queue_tables
  )
  loop
    exec_immediate (vc.sqltext);
  end loop;

end;
/

PROMPT "User Objects AFTER clean"
select object_type || ' - REMAINING' as object_type ,count(*) from all_objects where owner='$TARGET_SCHEMA_NAME' group by object_type;

select case when count(*) > 0 then (select 'ORA-00054: Schema Not Clean' from dual )
else (select 'Schema Clean Successful' from dual) end case_cnt,object_name from
all_objects where owner='$TARGET_SCHEMA_NAME' group by object_name;

DECLARE
   after_clean EXCEPTION;
   cnt_num NUMBER;
BEGIN
   DECLARE
      after_clean EXCEPTION;  -- this declaration prevails
      cnt_num NUMBER;
   BEGIN
       select count(*) into cnt_num from all_objects where owner='$TARGET_SCHEMA_NAME';

      IF cnt_num > 0 THEN
         RAISE after_clean;  -- this is not handled
      END IF;
   END;
EXCEPTION
  WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Schema Clean Not Successful');
        raise_application_error(-20101, 'Terminating as Schema clean not successful');
END;
/
EOF1

if [ $? -eq 0 ]; then
   info "Schema Cleaned"
else
   error "Schema was not cleaned. Exiting."
   exit 1
fi

declare -a my_arr=()
my_arr=(`$ORACLE_HOME/bin/sqlplus -s DEVAPPSDBA/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" << EOF9
set pagesize 0 feedback off verify off heading off echo off
SELECT count(*) from all_objects where owner='$TARGET_SCHEMA_NAME';
exit;
EOF9`);

if [[ ${#my_arr[@]} -gt 1 ]]; then
  echo ${#my_arr[@]}
  error "Schema Clean Not Successful.."
  exit 1
fi

