#!/bin/bash

export ORACLE_HOME=/sabreadm/oracle/product/client11gR2
export LD_LIBRARY_PATH=/sabreadm/oracle/product/client11gR2/lib
export PATH=$PATH:$ORACLE_HOME/bin

if [ "${DMPDATE}" == "" ]; then
    export DMPDATE=$(date '+%d-%h-%Y' || sed 's/ //g')
fi

DUMP_FILE="expdp-tds2-prod-tdsuser-$DMPDATE.dmp"

echo "ORACLE_HOME is $ORACLE_HOME"
echo "PATH is $PATH"
echo "TNS_ADMIN is $TNS_ADMIN"

export DB_TYPE=${TARGET_DATABASE:0:1}

if [ "$TABLESPACE" == "" ]; then
    if [ $DB_TYPE == "U" ]; then
        TABLESPACE="SABRE_UAT_DATA"
    else
        TABLESPACE="SABRE_DEV_DATA"
    fi
    export TABLESPACE
fi

function info() {
  echo "INFO: $1"
}

function error() {
  echo "ERROR: $1"
}

function banner() {
  echo "******************************"
  echo "*   $1"
  echo "******************************"
}
