#!/bin/bash

source support/scripts/db/TDS2/setenv.sh

export IMPDATE=`date '+%d-%h-%Y'`

banner "Creating db_information table"

$ORACLE_HOME/bin/sqlplus -s DEVAPPSDBA[$TARGET_SCHEMA_NAME]/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" << EOF1
create table db_information
(
 db_type varchar2(10),
 dump_date date,
 import_date date,
 refresh_date date default sysdate,
 jenkins_job varchar2(30),
 jenkins_build_number number
);

insert into db_information (db_type, dump_date, import_date, jenkins_job, jenkins_build_number)
values ('TDS2', '$DMPDATE', '$IMPDATE, '$JOB_NAME', $BUILD_NUMBER);

EOF1
