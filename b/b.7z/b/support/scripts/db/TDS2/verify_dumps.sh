#!/bin/bash

source support/scripts/db/TDS2/setenv.sh

banner "Checking dump integrity"

echo $ORACLE_HOME/bin/impdp userid=DEVAPPSDBA/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" dumpfile=$DUMP_FILE directory=$DATA_DIR sqlfile=validate_tds2.sql REMAP_SCHEMA=TDSUSER:$TARGET_SCHEMA_NAME REMAP_TABLESPACE=SABRE_PROD_DATA:$TABLESPACE

$ORACLE_HOME/bin/impdp userid=DEVAPPSDBA/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" dumpfile=$DUMP_FILE directory=$DATA_DIR sqlfile=validate_tds2.sql REMAP_SCHEMA=TDSUSER:$TARGET_SCHEMA_NAME REMAP_TABLESPACE=SABRE_PROD_DATA:$TABLESPACE

if [ $? -eq 0 ]; then
   info "Dump validated."
else
   error "Dump is invalid."
   exit 1
fi

