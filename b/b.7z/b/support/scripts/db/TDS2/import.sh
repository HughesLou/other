#!/bin/bash

source support/scripts/db/TDS2/setenv.sh


if [ "${REFRESH_TYPE}" == "METADATA" ]; then
    banner "Importing metadata from $DUMP_FILE"
    echo $ORACLE_HOME/bin/impdp \
    userid= DEVAPPSDBA/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" \
    logfile=IMPDP-TDS2-PROD_dumpimport-$TARGET_SCHEMA_NAME.log \
    directory=$DATA_DIR \
    content=METADATA_ONLY \
    parallel=4 \
    remap_schema=TDSUSER:$TARGET_SCHEMA_NAME \
    REMAP_TABLESPACE=SABRE_PROD_DATA:$TABLESPACE \
    dumpfile=$DUMP_FILE \
  job_name=${JOB_NAME}_${BUILD_NUMBER} \
    table_exists_action=REPLACE \
    exclude=INDEX,CONSTRAINT

    $ORACLE_HOME/bin/impdp \
    userid= DEVAPPSDBA/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" \
    logfile=IMPDP-TDS2-PROD_dumpimport-$TARGET_SCHEMA_NAME.log \
    directory=$DATA_DIR \
    content=METADATA_ONLY \
    parallel=4 \
    remap_schema=TDSUSER:$TARGET_SCHEMA_NAME \
    REMAP_TABLESPACE=SABRE_PROD_DATA:$TABLESPACE \
    dumpfile=$DUMP_FILE \
  job_name=${JOB_NAME}_${BUILD_NUMBER} \
    table_exists_action=REPLACE
    exclude=INDEX,CONSTRAINT
    banner "Not importing data"
else
  banner "Importing data from $DUMP_FILE"
  echo $ORACLE_HOME/bin/impdp \
  userid= DEVAPPSDBA/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" \
  logfile=IMPDP-TDS2-PROD_dumpimport-$TARGET_SCHEMA_NAME.log \
  directory=$DATA_DIR \
  content=ALL \
  remap_schema=TDSUSER:$TARGET_SCHEMA_NAME \
  REMAP_TABLESPACE=SABRE_PROD_DATA:$TABLESPACE \
  dumpfile=$DUMP_FILE \
  transform=oid:n \
  job_name=${JOB_NAME}_${BUILD_NUMBER} \
  table_exists_action=REPLACE \
  PARALLEL=16 \
  exclude=INDEX,CONSTRAINT

  $ORACLE_HOME/bin/impdp \
  userid= DEVAPPSDBA/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" \
  logfile=IMPDP-TDS2-PROD_dumpimport-$TARGET_SCHEMA_NAME.log \
  directory=$DATA_DIR \
  content=ALL \
  remap_schema=TDSUSER:$TARGET_SCHEMA_NAME \
  REMAP_TABLESPACE=SABRE_PROD_DATA:$TABLESPACE \
  dumpfile=$DUMP_FILE \
  transform=oid:n \
  job_name=${JOB_NAME}_${BUILD_NUMBER} \
  table_exists_action=REPLACE \
  PARALLEL=16 \
  exclude=INDEX,CONSTRAINT
fi

if [ $TARGET_SCHEMA_NAME == "TDS2_DAILY_UAT_01" ]; then

$ORACLE_HOME/bin/sqlplus -s DEVAPPSDBA[$TARGET_SCHEMA_NAME]/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" << EOF2
set echo on
show user
set serveroutput on size unlimited
declare
  procedure exec_immediate (p_sql in varchar2) is
  begin
    execute immediate p_sql;
  exception
    when others then
      dbms_output.put_line(SUBSTR(p_sql,1,200));
  end exec_immediate;
begin
  for vc in (
    select
      'grant select on '||object_name||' '||' to ${TARGET_SCHEMA_NAME}_RO' sqltext
    from user_objects
    where object_type in ('TABLE','VIEW')
  )
  loop
    exec_immediate (vc.sqltext);
  end loop;
end;
/
EOF2

fi

$ORACLE_HOME/bin/sqlplus DEVAPPSDBA/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" << EOF2
WHENEVER sqlerror EXIT sql.sqlcode
WHENEVER oserror EXIT failure
set serveroutput on
show user;
alter user $TARGET_SCHEMA_NAME account unlock;
exit;
EOF2

