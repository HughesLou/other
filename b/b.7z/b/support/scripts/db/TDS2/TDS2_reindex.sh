#!/bin/bash

source support/scripts/db/TDS2/setenv.sh

banner "Indexing tables"

sed -i 's/SABRE_UAT_DATA/'"$TABLESPACE"'/g' support/scripts/db/TDS2/reindex.sql

$ORACLE_HOME/bin/sqlplus DEVAPPSDBA[$TARGET_SCHEMA_NAME]/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" @support/scripts/db/TDS2/reindex.sql

git checkout -- support/scripts/db/TDS2/reindex.sql
