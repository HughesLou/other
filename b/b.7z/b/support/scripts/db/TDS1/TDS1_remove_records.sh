#!/bin/bash
echo "INFO: Removing non SABRE records"
export ORACLE_HOME=/sabreadm/oracle/product/client11gR2
export LD_LIBRARY_PATH=/sabreadm/oracle/product/client11gR2/lib
export PATH=$PATH:$ORACLE_HOME/bin

echo "Reindex scbtrades"

$ORACLE_HOME/bin/sqlplus -s DEVAPPSDBA[$TARGET_SCHEMA_NAME]/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" << EOF1
WHENEVER sqlerror EXIT sql.sqlcode
WHENEVER oserror EXIT failure
set serveroutput on size unlimited

set feedback off;

show user;

--- Dropping records we don't need

-- CREATE TABLE "SCB_TRADES_CURRENT_NEW" AS SELECT * FROM SCB_TRADES_CURRENT WHERE "SOURCE_SYSTEM"="SABRE";
-- DROP "SCB_TRADES_CURRENT" PURGE;
-- RENAME "SCB_TRADES_CURRENT_NEW" to "SCB_TRADES_CURRENT";

-- declare already_exists exception;
-- pragma exception_init(already_exists, -955);
-- begin
--    execute immediate '
-- CREATE INDEX "SCB_TRADES_CURRENT_FOR_DROP" ON "SCB_TRADES_CURRENT" ("SOURCE_SYSTEM") TABLESPACE "TDS_DATA" PARALLEL 4
-- ';
--    execute immediate 'ALTER INDEX "SCB_TRADES_CURRENT_FOR_DROP" NOPARALLEL';
--    dbms_output.put_line('Index SCB_TRADES_CURRENT_FOR_DROP created');
-- exception
--    when already_exists then
--    dbms_output.put_line('Index SCB_TRADES_CURRENT_FOR_DROP already exists');
--    null;
-- end;
-- /
-- declare already_exists exception;
-- pragma exception_init(already_exists, -955);
-- begin
--    execute immediate '
-- CREATE INDEX "SCB_TRADE_TAG_FOR_DROP" ON "SCB_TRADE_TAG" ("SOURCE_SYSTEM")  TABLESPACE "TDS_DATA" PARALLEL 4
-- ';
--    execute immediate 'ALTER INDEX "SCB_TRADE_TAG_FOR_DROP" NOPARALLEL';
--    dbms_output.put_line('Index SCB_TRADE_TAG_FOR_DROP created');
-- exception
--    when already_exists then
--    dbms_output.put_line('Index SCB_TRADE_TAG_FOR_DROP already exists');
--    null;
-- end;
-- /
-- declare already_exists exception;
-- pragma exception_init(already_exists, -955);
-- begin
--    execute immediate '
-- CREATE INDEX "SCB_LIFECYCLE_EX_FOR_DROP" ON "SCB_LIFECYCLE_EX" ("SOURCE_SYSTEM")  TABLESPACE "TDS_DATA" PARALLEL 4
-- ';
--    execute immediate 'ALTER INDEX "SCB_LIFECYCLE_EX_FOR_DROP" NOPARALLEL';
--    dbms_output.put_line('Index SCB_LIFECYCLE_EX_FOR_DROP created');
-- exception
--    when already_exists then
--    dbms_output.put_line('Index SCB_LIFECYCLE_EX_FOR_DROP already exists');
--    null;
-- end;
-- /
-- declare
--  already_exists exception;
--  num_constr integer;
-- pragma exception_init(already_exists, -955);
-- begin
--    dbms_output.put_line('SCB_TRADE_STATE.ID');
--    execute immediate '
-- ALTER TABLE "SCB_TRADE_STATE" ADD PRIMARY KEY ("ID")
--   USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255
--   STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
--   PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
--   BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
--   TABLESPACE "TDS_DATA"  ENABLE
--     ';
--     dbms_output.put_line('Constraint created');
-- exception
--    when already_exists then
--    dbms_output.put_line('Constraint already exists');
--    null;
-- end;
-- /
-- declare already_exists exception;
-- pragma exception_init(already_exists, -955);
-- begin
--    execute immediate '
-- CREATE INDEX "SCB_TRADE_STATE_FOR_DROP" ON "SCB_TRADE_STATE" ("SOURCE_SYSTEM")  TABLESPACE "TDS_DATA" PARALLEL 4
-- ';
--    execute immediate 'ALTER INDEX "SCB_TRADE_STATE_FOR_DROP" NOPARALLEL';
--    dbms_output.put_line('Index SCB_TRADE_STATE_FOR_DROP created');
-- exception
--    when already_exists then
--    dbms_output.put_line('Index SCB_TRADE_STATE_FOR_DROP already exists');
--    null;
-- end;
-- /


-- exec DBS_OUTPUT.PUT_LINE('Removing non SABRE records from SCB_TRADES_CURRENT');
DELETE  FROM "SCB_TRADES_CURRENT" WHERE "SOURCE_SYSTEM" != 'SABRE';
-- exec DBS_OUTPUT.PUT_LINE('Removing non SABRE records from SCB_TRADE_TAG');
DELETE  FROM "SCB_TRADE_TAG" WHERE "SOURCE_SYSTEM" != 'SABRE';
-- exec DBS_OUTPUT.PUT_LINE('Removing non SABRE records from SCB_LIFECYCLE_EX');
DELETE  FROM "SCB_LIFECYCLE_EX" WHERE "SOURCE_SYSTEM" != 'SABRE';
-- exec DBS_OUTPUT.PUT_LINE('Removing non SABRE records from SCB_TRADE_STATE');
DELETE  FROM "SCB_TRADE_STATE" WHERE "SOURCE_SYSTEM" != 'SABRE';

-- DROP INDEX "SCB_TRADES_CURRENT_TEMP" FORCE
-- DROP INDEX "SCB_TRADE_TAG" FORCE
-- DROP INDEX "SCB_LIFECYCLE_EX" FORCE
-- DROP INDEX "SCB_TRADE_STATE" FORCE

-- exec dbms_redefinition.can_redef_table(uname=>'$TARGET_SCHEMA_NAME',tname=>'SCB_TRADES_CURRENT');
-- exec dbms_redefinition.start_redef_table(uname=>'$TARGET_SCHEMA_NAME',orig_table=>'SCB_TRADES_CURRENT',int_table=>'SCB_TRADES_CURRENT_TEMP');
-- exec dbms_redefinition.sync_interim_table(uname=>'$TARGET_SCHEMA_NAME',orig_table=>'SCB_TRADES_CURRENT',int_table=>'SCB_TRADES_CURRENT_TEMP');
-- exec dbms_redefinition.finish_redef_table(uname=>'$TARGET_SCHEMA_NAME',orig_table=>'SCB_TRADES_CURRENT',int_table=>'SCB_TRADES_CURRENT_TEMP');

-- exec dbms_redefinition.can_redef_table(uname=>'$TARGET_SCHEMA_NAME',tname=>'SCB_TRADE_TAG');
-- exec dbms_redefinition.start_redef_table(uname=>'$TARGET_SCHEMA_NAME',orig_table=>'SCB_TRADE_TAG',int_table=>'SCB_TRADE_TAG_TEMP');
-- exec dbms_redefinition.sync_interim_table(uname=>'$TARGET_SCHEMA_NAME',orig_table=>'SCB_TRADE_TAG',int_table=>'SCB_TRADE_TAG_TEMP');
-- exec dbms_redefinition.finish_redef_table(uname=>'$TARGET_SCHEMA_NAME',orig_table=>'SCB_TRADE_TAG',int_table=>'SCB_TRADE_TAG_TEMP');
--
-- exec dbms_redefinition.can_redef_table(uname=>'$TARGET_SCHEMA_NAME',tname=>'SCB_LIFECYCLE_EX');
-- exec dbms_redefinition.start_redef_table(uname=>'$TARGET_SCHEMA_NAME',orig_table=>'SCB_LIFECYCLE_EX',int_table=>'SCB_LIFECYCLE_EX_TEMP');
-- exec dbms_redefinition.sync_interim_table(uname=>'$TARGET_SCHEMA_NAME',orig_table=>'SCB_LIFECYCLE_EX',int_table=>'SCB_LIFECYCLE_EX_TEMP');
-- exec dbms_redefinition.finish_redef_table(uname=>'$TARGET_SCHEMA_NAME',orig_table=>'SCB_LIFECYCLE_EX',int_table=>'SCB_LIFECYCLE_EX_TEMP');
--
-- exec dbms_redefinition.can_redef_table(uname=>'$TARGET_SCHEMA_NAME',tname=>'SCB_TRADE_STATE');
-- exec dbms_redefinition.start_redef_table(uname=>'$TARGET_SCHEMA_NAME',orig_table=>'SCB_TRADE_STATE',int_table=>'SCB_TRADE_STATE_TEMP');
-- exec dbms_redefinition.sync_interim_table(uname=>'$TARGET_SCHEMA_NAME',orig_table=>'SCB_TRADE_STATE',int_table=>'SCB_TRADE_STATE_TEMP');
-- exec dbms_redefinition.finish_redef_table(uname=>'$TARGET_SCHEMA_NAME',orig_table=>'SCB_TRADE_STATE',int_table=>'SCB_TRADE_STATE_TEMP');

--- Finished dropping records

EOF1
