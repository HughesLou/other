#!/bin/bash

export ORACLE_HOME=/sabreadm/oracle/product/client11gR2
export LD_LIBRARY_PATH=/sabreadm/oracle/product/client11gR2/lib
export PATH=$PATH:$ORACLE_HOME/bin

$ORACLE_HOME/bin/sqlplus -s DEVAPPSDBA[$TARGET_SCHEMA_NAME]/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" << EOF1
WHENEVER sqlerror EXIT sql.sqlcode
WHENEVER oserror EXIT failure
set serveroutput on size unlimited

show user;


declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SYS_C0015189');
   execute immediate 'create unique index  SYS_C0015189 on SCB_TRADE_STATE(ID)';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/


declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_APPLICATION_PK');
   execute immediate '
CREATE UNIQUE INDEX "EMS_APPLICATION_PK" ON "EMS_APPLICATION" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "EMS_APPLICATION_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_APPLICATION_PATH_PK');
   execute immediate '
CREATE UNIQUE INDEX "EMS_APPLICATION_PATH_PK" ON "EMS_APPLICATION_PATH" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "EMS_APPLICATION_PATH_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_APPLICATION_USER_PK');
   execute immediate '
CREATE UNIQUE INDEX "EMS_APPLICATION_USER_PK" ON "EMS_APPLICATION_USER" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "EMS_APPLICATION_USER_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_ENTITLEMENT_PK');
   execute immediate '
CREATE UNIQUE INDEX "EMS_ENTITLEMENT_PK" ON "EMS_ENTITLEMENT" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "EMS_ENTITLEMENT_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_GROUP_PK');
   execute immediate '
CREATE UNIQUE INDEX "EMS_GROUP_PK" ON "EMS_GROUP" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "EMS_GROUP_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_GROUP_ENTITLEMENT_PK');
   execute immediate '
CREATE UNIQUE INDEX "EMS_GROUP_ENTITLEMENT_PK" ON "EMS_GROUP_ENTITLEMENT" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "EMS_GROUP_ENTITLEMENT_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_NODE_PK');
   execute immediate '
CREATE UNIQUE INDEX "EMS_NODE_PK" ON "EMS_NODE" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 131072 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "EMS_NODE_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('NODE_ATTRIBUTE_PK');
   execute immediate '
CREATE UNIQUE INDEX "NODE_ATTRIBUTE_PK" ON "EMS_NODE_ATTRIBUTE" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 3145728 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "NODE_ATTRIBUTE_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_OPERATION_PK');
   execute immediate '
CREATE UNIQUE INDEX "EMS_OPERATION_PK" ON "EMS_OPERATION" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "EMS_OPERATION_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_OPERATION_SET_PK');
   execute immediate '
CREATE UNIQUE INDEX "EMS_OPERATION_SET_PK" ON "EMS_OPERATION_SET" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "EMS_OPERATION_SET_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_PATH_PK');
   execute immediate '
CREATE UNIQUE INDEX "EMS_PATH_PK" ON "EMS_PATH" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 131072 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "EMS_PATH_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_PATH_ATTRIBUTE_PK');
   execute immediate '
CREATE UNIQUE INDEX "EMS_PATH_ATTRIBUTE_PK" ON "EMS_PATH_ATTRIBUTE" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "EMS_PATH_ATTRIBUTE_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_USER_PK');
   execute immediate '
CREATE UNIQUE INDEX "EMS_USER_PK" ON "EMS_USER" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "EMS_USER_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_USER_ENTITLEMENT_PK');
   execute immediate '
CREATE UNIQUE INDEX "EMS_USER_ENTITLEMENT_PK" ON "EMS_USER_ENTITLEMENT" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "EMS_USER_ENTITLEMENT_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_USER_GROUP_PK');
   execute immediate '
CREATE UNIQUE INDEX "EMS_USER_GROUP_PK" ON "EMS_USER_GROUP" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 131072 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "EMS_USER_GROUP_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRACE_TRADE_ID');
   execute immediate '
CREATE INDEX "SCB_TRACE_TRADE_ID" ON "SCB_TRACE" ("TRADE_ID", "TRADE_VERSION") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 262144 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SCB_TRACE_TRADE_ID" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRACE_MESSAGE_ID');
   execute immediate '
CREATE INDEX "SCB_TRACE_MESSAGE_ID" ON "SCB_TRACE" ("MESSAGE_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 458752 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SCB_TRACE_MESSAGE_ID" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_PORTFOLIO_PK');
   execute immediate '
CREATE UNIQUE INDEX "SCB_PORTFOLIO_PK" ON "SCB_PORTFOLIO" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SCB_PORTFOLIO_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_INSTRUMENT_PK');
   execute immediate '
CREATE UNIQUE INDEX "SCB_INSTRUMENT_PK" ON "SCB_INSTRUMENT" ("INSTRUMENT_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SCB_INSTRUMENT_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_MAPPING_PK');
   execute immediate '
CREATE UNIQUE INDEX "SCB_MAPPING_PK" ON "SCB_MAPPING" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SCB_MAPPING_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADE_FILTERS_PK');
   execute immediate '
CREATE UNIQUE INDEX "SCB_TRADE_FILTERS_PK" ON "SCB_TRADE_FILTERS" ("NAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SCB_TRADE_FILTERS_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADE_STATE_I01');
   execute immediate '
CREATE INDEX "SCB_TRADE_STATE_I01" ON "SCB_TRADE_STATE" ("SOURCE_SYSTEM", "SUB_TRADE_ID", "SUB_TRADE_VERSION") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SCB_TRADE_STATE_I01" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADE_STATE_I02');
   execute immediate '
CREATE INDEX "SCB_TRADE_STATE_I02" ON "SCB_TRADE_STATE" ("SOURCE_SYSTEM", "TRADE_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SCB_TRADE_STATE_I02" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_LIFECYCLE_PK');
   execute immediate '
CREATE UNIQUE INDEX "SCB_LIFECYCLE_PK" ON "SCB_LIFECYCLE" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "SCB_LIFECYCLE_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADE_COLUMNS_PK');
   execute immediate '
CREATE UNIQUE INDEX "SCB_TRADE_COLUMNS_PK" ON "SCB_TRADE_COLUMNS" ("COL_NAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SCB_TRADE_COLUMNS_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_LIFECYCLE_EX_PK');
   execute immediate '
CREATE UNIQUE INDEX "SCB_LIFECYCLE_EX_PK" ON "SCB_LIFECYCLE_EX" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "SCB_LIFECYCLE_EX_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_AUDIT_TIMESTAMP');
   execute immediate '
CREATE INDEX "EMS_AUDIT_TIMESTAMP" ON "EMS_AUDIT_LOG" ("AUDITTIMESTAMP") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "EMS_AUDIT_TIMESTAMP" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADE_TAG_I');
   execute immediate '
CREATE INDEX "SCB_TRADE_TAG_I" ON "SCB_TRADE_TAG" ("SOURCE_SYSTEM", "SUB_TRADE_ID", "STATE", "VALID_FROM") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "SCB_TRADE_TAG_I" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCP_TRADE_TAG_PK');
   execute immediate '
CREATE UNIQUE INDEX "SCP_TRADE_TAG_PK" ON "SCB_TRADE_TAG" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "SCP_TRADE_TAG_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('ENT_CACHE_USERID');
   execute immediate '
CREATE INDEX "ENT_CACHE_USERID" ON "ENT_CACHE" ("USER_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "ENT_CACHE_USERID" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('WM_PROCESS_STATUS_I1');
   execute immediate '
CREATE INDEX "WM_PROCESS_STATUS_I1" ON "WM_PROCESS_STATUS" ("WF_ID", "WF_ACTION", "WF_PATH", "REQUEST_ID", "CUSTOM_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "WM_PROCESS_STATUS_I1" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_LIFECYCLE_X2');
   execute immediate '
CREATE INDEX "SCB_LIFECYCLE_X2" ON "SCB_LIFECYCLE" ("PORTFOLIO_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "SCB_LIFECYCLE_X2" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_LIFECYCLE_X3');
   execute immediate '
CREATE INDEX "SCB_LIFECYCLE_X3" ON "SCB_LIFECYCLE" ("SOURCE_SYSTEM", "SUB_TRADE_ID", "SUB_TRADE_VERSION") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "SCB_LIFECYCLE_X3" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_LIFECYCLE_X4');
   execute immediate '
CREATE INDEX "SCB_LIFECYCLE_X4" ON "SCB_LIFECYCLE" ("INSTRUMENT_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "SCB_LIFECYCLE_X4" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_LIFECYCLE_X5');
   execute immediate '
CREATE INDEX "SCB_LIFECYCLE_X5" ON "SCB_LIFECYCLE" ("EVENT_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "SCB_LIFECYCLE_X5" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_LIFECYCLE_X6');
   execute immediate '
CREATE INDEX "SCB_LIFECYCLE_X6" ON "SCB_LIFECYCLE" ("AUDITTIMESTAMP") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "SCB_LIFECYCLE_X6" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_LIFECYCLE_X7');
   execute immediate '
CREATE INDEX "SCB_LIFECYCLE_X7" ON "SCB_LIFECYCLE" ("EVENT_DATE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "SCB_LIFECYCLE_X7" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_LIFECYCLE_EX_X2');
   execute immediate '
CREATE INDEX "SCB_LIFECYCLE_EX_X2" ON "SCB_LIFECYCLE_EX" ("PORTFOLIO_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "SCB_LIFECYCLE_EX_X2" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_LIFECYCLE_EX_X3');
   execute immediate '
CREATE INDEX "SCB_LIFECYCLE_EX_X3" ON "SCB_LIFECYCLE_EX" ("SOURCE_SYSTEM", "SUB_TRADE_ID", "SUB_TRADE_VERSION") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "SCB_LIFECYCLE_EX_X3" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_LIFECYCLE_EX_X4');
   execute immediate '
CREATE INDEX "SCB_LIFECYCLE_EX_X4" ON "SCB_LIFECYCLE_EX" ("INSTRUMENT_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "SCB_LIFECYCLE_EX_X4" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_LIFECYCLE_EX_X5');
   execute immediate '
CREATE INDEX "SCB_LIFECYCLE_EX_X5" ON "SCB_LIFECYCLE_EX" ("EVENT_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "SCB_LIFECYCLE_EX_X5" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_LIFECYCLE_EX_X6');
   execute immediate '
CREATE INDEX "SCB_LIFECYCLE_EX_X6" ON "SCB_LIFECYCLE_EX" ("AUDITTIMESTAMP") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "SCB_LIFECYCLE_EX_X6" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_LIFECYCLE_EX_X7');
   execute immediate '
CREATE INDEX "SCB_LIFECYCLE_EX_X7" ON "SCB_LIFECYCLE_EX" ("EVENT_DATE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "SCB_LIFECYCLE_EX_X7" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADE_TAG_X2');
   execute immediate '
CREATE INDEX "SCB_TRADE_TAG_X2" ON "SCB_TRADE_TAG" ("TAG_NAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "SCB_TRADE_TAG_X2" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADES_ARCHIVE_PK');
   execute immediate '
CREATE UNIQUE INDEX "SCB_TRADES_ARCHIVE_PK" ON "SCB_TRADES_ARCHIVE" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SCB_ARCH_DATA" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "SCB_TRADES_ARCHIVE_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_EXTERNAL_IDS_PK');
   execute immediate '
CREATE UNIQUE INDEX "SCB_EXTERNAL_IDS_PK" ON "SCB_EXTERNAL_IDS" ("SUB_TRADE_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SCB_EXTERNAL_IDS_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_EXTERNAL_IDS_EXTERNALID');
   execute immediate '
CREATE INDEX "SCB_EXTERNAL_IDS_EXTERNALID" ON "SCB_EXTERNAL_IDS" ("EXTERNAL_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "SCB_EXTERNAL_IDS_EXTERNALID" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_EXTERNAL_IDS_PORT_ROLE_EXT');
   execute immediate '
CREATE UNIQUE INDEX "SCB_EXTERNAL_IDS_PORT_ROLE_EXT" ON "SCB_EXTERNAL_IDS" ("EXTERNAL_ID", "SOURCE_SYSTEM", "PORTFOLIO_ID", "ROLE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "SCB_EXTERNAL_IDS_PORT_ROLE_EXT" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADES_ARCHIVED_PRODS_PK');
   execute immediate '
CREATE UNIQUE INDEX "SCB_TRADES_ARCHIVED_PRODS_PK" ON "SCB_TRADES_ARCHIVED_PRODUCTS" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SCB_ARCH_DATA" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "SCB_TRADES_ARCHIVED_PRODS_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_MIGRATED_BOOKS_PK');
   execute immediate '
CREATE UNIQUE INDEX "SCB_MIGRATED_BOOKS_PK" ON "SCB_MIGRATED_BOOKS" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SCB_MIGRATED_BOOKS_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SMB_PORTFOLIO_ID_UNIQUE');
   execute immediate '
CREATE UNIQUE INDEX "SMB_PORTFOLIO_ID_UNIQUE" ON "SCB_MIGRATED_BOOKS" ("PORTFOLIO_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SMB_PORTFOLIO_ID_UNIQUE" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TICKET_IX1');
   execute immediate '
CREATE INDEX "SCB_TICKET_IX1" ON "SCB_TICKET" ("GUID", "AVAILABLE_ACTIONS") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SCB_TICKET_IX1" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TICKET_PK');
   execute immediate '
CREATE UNIQUE INDEX "SCB_TICKET_PK" ON "SCB_TICKET" ("GUID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SCB_TICKET_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TICKET_ACTION_IX2');
   execute immediate '
CREATE INDEX "SCB_TICKET_ACTION_IX2" ON "SCB_TICKET_ACTION" ("GUID", "ACTIVE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SCB_TICKET_ACTION_IX2" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADES_X2');
   execute immediate '
CREATE INDEX "SCB_TRADES_X2" ON "SCB_TRADES_TABLE" ("PORTFOLIO_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 9437184 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "SCB_TRADES_X2" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADES_X3');
   execute immediate '
CREATE INDEX "SCB_TRADES_X3" ON "SCB_TRADES_TABLE" ("OUR_ACCOUNT") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 7340032 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "SCB_TRADES_X3" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADES_X4');
   execute immediate '
CREATE INDEX "SCB_TRADES_X4" ON "SCB_TRADES_TABLE" ("AUDITTIMESTAMP") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 5242880 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SCB_TRADES_X4" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADES_X5');
   execute immediate '
CREATE INDEX "SCB_TRADES_X5" ON "SCB_TRADES_TABLE" ("PRODUCT_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 14680064 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SCB_TRADES_X5" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADES_PK');
   execute immediate '
CREATE UNIQUE INDEX "SCB_TRADES_PK" ON "SCB_TRADES_TABLE" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 12582912 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SCB_TRADES_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADES_X6');
   execute immediate '
CREATE INDEX "SCB_TRADES_X6" ON "SCB_TRADES_TABLE" ("SOURCE_SYSTEM", "SUB_TRADE_ID", "SUB_TRADE_VERSION") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 6291456 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SCB_TRADES_X6" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADES_X7');
   execute immediate '
CREATE INDEX "SCB_TRADES_X7" ON "SCB_TRADES_TABLE" ("LAST_DATE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 4194304 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SCB_TRADES_X7" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADES_X8');
   execute immediate '
CREATE INDEX "SCB_TRADES_X8" ON "SCB_TRADES_TABLE" ("TRADE_DATE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "SCB_TRADES_X8" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADES_X9');
   execute immediate '
CREATE INDEX "SCB_TRADES_X9" ON "SCB_TRADES_TABLE" ("INSTRUMENT_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SCB_TRADES_X9" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADES_X10');
   execute immediate '
CREATE INDEX "SCB_TRADES_X10" ON "SCB_TRADES_TABLE" ("TRADE_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "SCB_TRADES_X10" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADE_IDSYSSTATE');
   execute immediate '
CREATE INDEX "SCB_TRADE_IDSYSSTATE" ON "SCB_TRADES_TABLE" ("STATE", "SUB_TRADE_ID", "SOURCE_SYSTEM") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "SCB_TRADE_IDSYSSTATE" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADES_IDS_EXTERNALID');
   execute immediate '
CREATE INDEX "SCB_TRADES_IDS_EXTERNALID" ON "SCB_TRADES_TABLE" ("EXTERNAL_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "SCB_TRADES_IDS_EXTERNALID" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADES_PORT_PRODUCT_KEY');
   execute immediate '
CREATE INDEX "SCB_TRADES_PORT_PRODUCT_KEY" ON "SCB_TRADES_TABLE" ("PORTFOLIO_ID", "PRODUCT_ID", "SOURCE_SYSTEM") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "SCB_TRADES_PORT_PRODUCT_KEY" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADES_EXTERNAL_LOOKUP_KEY');
   execute immediate '
CREATE INDEX "SCB_TRADES_EXTERNAL_LOOKUP_KEY" ON "SCB_TRADES_TABLE" ("PORTFOLIO_ID", "PRODUCT_ID", "SOURCE_SYSTEM", "SUB_TRADE_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "SCB_TRADES_EXTERNAL_LOOKUP_KEY" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADES_X16');
   execute immediate '
CREATE INDEX "SCB_TRADES_X16" ON "SCB_TRADES_TABLE" ("PACKAGE_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SCB_TRADES_X16" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADES_X11');
   execute immediate '
CREATE INDEX "SCB_TRADES_X11" ON "SCB_TRADES_TABLE" ("STATE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SCB_TRADES_X11" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADES_X12');
   execute immediate '
CREATE INDEX "SCB_TRADES_X12" ON "SCB_TRADES_TABLE" ("STATUS") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SCB_TRADES_X12" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADES_X14');
   execute immediate '
CREATE INDEX "SCB_TRADES_X14" ON "SCB_TRADES_TABLE" ("SUB_TRADE_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SCB_TRADES_X14" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADES_X13');
   execute immediate '
CREATE INDEX "SCB_TRADES_X13" ON "SCB_TRADES_TABLE" ("TRADE_LINK_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SCB_TRADES_X13" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADES_X15');
   execute immediate '
CREATE INDEX "SCB_TRADES_X15" ON "SCB_TRADES_TABLE" ("SUB_TRADE_ID", "SOURCE_SYSTEM", "PORTFOLIO_ID", "AUDITTIMESTAMP", "STATUS") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SCB_TRADES_X15" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SDP_DATA_TYPE_PK');
   execute immediate '
CREATE UNIQUE INDEX "SDP_DATA_TYPE_PK" ON "SDP_DATA_TYPE" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SDP_DATA_TYPE_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SDP_NAMED_COMMAND_PK');
   execute immediate '
CREATE UNIQUE INDEX "SDP_NAMED_COMMAND_PK" ON "SDP_NAMED_COMMAND" ("OBJECT_ID", "OBJECT_VERSION") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SDP_NAMED_COMMAND_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SDP_NC_IMPL_PK');
   execute immediate '
CREATE UNIQUE INDEX "SDP_NC_IMPL_PK" ON "SDP_NAMED_COMMAND_IMPL" ("OBJECT_ID", "OBJECT_VERSION") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SDP_NC_IMPL_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SDP_NC_PARAM_PK');
   execute immediate '
CREATE UNIQUE INDEX "SDP_NC_PARAM_PK" ON "SDP_NAMED_COMMAND_PARAM" ("ID", "OBJECT_ID", "OBJECT_VERSION") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SDP_NC_PARAM_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SDP_NC_TYPE_PK');
   execute immediate '
CREATE UNIQUE INDEX "SDP_NC_TYPE_PK" ON "SDP_NAMED_COMMAND_TYPE" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SDP_NC_TYPE_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SDP_NC_ENT_PK');
   execute immediate '
CREATE UNIQUE INDEX "SDP_NC_ENT_PK" ON "SDP_NAMED_COMMAND_ENT" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SDP_NC_ENT_PK" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('WM_PROCESS_STATUS_I2');
   execute immediate '
CREATE INDEX "WM_PROCESS_STATUS_I2" ON "WM_PROCESS_STATUS" ("CUSTOM_ID", "AUDITTIMESTAMP", "STATUS") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "WM_PROCESS_STATUS_I2" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('PK_SCB_TICKET');
   execute immediate '
CREATE UNIQUE INDEX "PK_SCB_TICKET" ON "SCB_TICKET" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "PK_SCB_TICKET" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('TICKET_TYPE_IDX');
   execute immediate '
CREATE INDEX "TICKET_TYPE_IDX" ON "SCB_TICKET" ("TYPE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "TICKET_TYPE_IDX" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('IS_COMPLETE_IDX');
   execute immediate '
CREATE INDEX "IS_COMPLETE_IDX" ON "SCB_TICKET" ("IS_COMPLETE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "IS_COMPLETE_IDX" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('PK_SCB_TICKET_ACTION');
   execute immediate '
CREATE UNIQUE INDEX "PK_SCB_TICKET_ACTION" ON "SCB_TICKET_ACTION" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "PK_SCB_TICKET_ACTION" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('PK_SCB_TICKET_CONSEQUENCE');
   execute immediate '
CREATE UNIQUE INDEX "PK_SCB_TICKET_CONSEQUENCE" ON "SCB_TICKET_CONSEQUENCE" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "PK_SCB_TICKET_CONSEQUENCE" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('PK_SCB_TICKET_GROUP');
   execute immediate '
CREATE UNIQUE INDEX "PK_SCB_TICKET_GROUP" ON "SCB_TICKET_GROUP" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE( INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "PK_SCB_TICKET_GROUP" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('PK_SCB_TICKET_TAG');
   execute immediate '
CREATE UNIQUE INDEX "PK_SCB_TICKET_TAG" ON "SCB_TICKET_TAG" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE( INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "PK_SCB_TICKET_TAG" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TICKET_TAG_IDX1');
   execute immediate '
CREATE INDEX "SCB_TICKET_TAG_IDX1" ON "SCB_TICKET_TAG" ("TICKET_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SCB_TICKET_TAG_IDX1" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TICKET_TAG_IDX2');
   execute immediate '
CREATE INDEX "SCB_TICKET_TAG_IDX2" ON "SCB_TICKET_TAG" ("TAGNAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SCB_TICKET_TAG_IDX2" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TICKET_TAG_IDX3');
   execute immediate '
CREATE INDEX "SCB_TICKET_TAG_IDX3" ON "SCB_TICKET_TAG" ("TAGNAME", "TAGVALUE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "SCB_TICKET_TAG_IDX3" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('TDS_STATS_TRADES_CURNT_27_JAN');
   execute immediate '
CREATE INDEX "TDS_STATS_TRADES_CURNT_27_JAN" ON "TDS_STATS_TRADES_CURNT_27_JAN" ("STATID", "TYPE", "C5", "C1", "C2", "C3", "C4", "VERSION") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  TABLESPACE "SYSTEM" PARALLEL 1 
  ';
   execute immediate 'ALTER INDEX "TDS_STATS_TRADES_CURNT_27_JAN" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare already_exists exception;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('STATS_TRADES_CURNT_27_JAN');
   execute immediate '
CREATE INDEX "STATS_TRADES_CURNT_27_JAN" ON "STATS_TRADES_CURNT_27_JAN" ("STATID", "TYPE", "C5", "C1", "C2", "C3", "C4", "VERSION") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA" PARALLEL 4 
  ';
   execute immediate 'ALTER INDEX "STATS_TRADES_CURNT_27_JAN" NOPARALLEL';
   dbms_output.put_line('Index created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_APPLICATION_PK');
   execute immediate '
    ALTER TABLE "EMS_APPLICATION" ADD CONSTRAINT "EMS_APPLICATION_PK" PRIMARY KEY ("ID")
      USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
      STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
      PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
      BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
      TABLESPACE "TDS_DATA"  ENABLE
    ';
        dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_APPLICATION_PATH_PK');
   execute immediate '
ALTER TABLE "EMS_APPLICATION_PATH" ADD CONSTRAINT "EMS_APPLICATION_PATH_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
   dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Index already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_APPLICATION_USER_PK');
   execute immediate '
ALTER TABLE "EMS_APPLICATION_USER" ADD CONSTRAINT "EMS_APPLICATION_USER_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_ENTITLEMENT_PK');
   execute immediate '
ALTER TABLE "EMS_ENTITLEMENT" ADD CONSTRAINT "EMS_ENTITLEMENT_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_GROUP_PK');
   execute immediate '
ALTER TABLE "EMS_GROUP" ADD CONSTRAINT "EMS_GROUP_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_GROUP_ENTITLEMENT_PK');
   execute immediate '
ALTER TABLE "EMS_GROUP_ENTITLEMENT" ADD CONSTRAINT "EMS_GROUP_ENTITLEMENT_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_NODE_PK');
   execute immediate '
ALTER TABLE "EMS_NODE" ADD CONSTRAINT "EMS_NODE_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 131072 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('NODE_ATTRIBUTE_PK');
   execute immediate '
ALTER TABLE "EMS_NODE_ATTRIBUTE" ADD CONSTRAINT "NODE_ATTRIBUTE_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 3145728 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_OPERATION_PK');
   execute immediate '
ALTER TABLE "EMS_OPERATION" ADD CONSTRAINT "EMS_OPERATION_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_OPERATION_SET_PK');
   execute immediate '
ALTER TABLE "EMS_OPERATION_SET" ADD CONSTRAINT "EMS_OPERATION_SET_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_PATH_PK');
   execute immediate '
ALTER TABLE "EMS_PATH" ADD CONSTRAINT "EMS_PATH_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 131072 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_PATH_ATTRIBUTE_PK');
   execute immediate '
ALTER TABLE "EMS_PATH_ATTRIBUTE" ADD CONSTRAINT "EMS_PATH_ATTRIBUTE_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_USER_PK');
   execute immediate '
ALTER TABLE "EMS_USER" ADD CONSTRAINT "EMS_USER_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_USER_ENTITLEMENT_PK');
   execute immediate '
ALTER TABLE "EMS_USER_ENTITLEMENT" ADD CONSTRAINT "EMS_USER_ENTITLEMENT_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_USER_GROUP_PK');
   execute immediate '
ALTER TABLE "EMS_USER_GROUP" ADD CONSTRAINT "EMS_USER_GROUP_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 131072 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('ID');
   execute immediate '
ALTER TABLE "SCB_TRACE" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_PORTFOLIO_PK');
   execute immediate '
ALTER TABLE "SCB_PORTFOLIO" ADD CONSTRAINT "SCB_PORTFOLIO_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_INSTRUMENT_PK');
   execute immediate '
ALTER TABLE "SCB_INSTRUMENT" ADD CONSTRAINT "SCB_INSTRUMENT_PK" PRIMARY KEY ("INSTRUMENT_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_MAPPING_PK');
   execute immediate '
ALTER TABLE "SCB_MAPPING" ADD CONSTRAINT "SCB_MAPPING_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADE_FILTERS_PK');
   execute immediate '
ALTER TABLE "SCB_TRADE_FILTERS" ADD CONSTRAINT "SCB_TRADE_FILTERS_PK" PRIMARY KEY ("NAME")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('ID');
   execute immediate '
ALTER TABLE "SCB_TRADE_STATE" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_LIFECYCLE_PK');
   execute immediate '
ALTER TABLE "SCB_LIFECYCLE" ADD CONSTRAINT "SCB_LIFECYCLE_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADE_COLUMNS_PK');
   execute immediate '
ALTER TABLE "SCB_TRADE_COLUMNS" ADD CONSTRAINT "SCB_TRADE_COLUMNS_PK" PRIMARY KEY ("COL_NAME")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_LIFECYCLE_EX_PK');
   execute immediate '
ALTER TABLE "SCB_LIFECYCLE_EX" ADD CONSTRAINT "SCB_LIFECYCLE_EX_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCP_TRADE_TAG_PK');
   execute immediate '
ALTER TABLE "SCB_TRADE_TAG" ADD CONSTRAINT "SCP_TRADE_TAG_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('ID');
   execute immediate '
ALTER TABLE "WM_PROCESS_STATUS" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SUB_TRADE_ID');
   execute immediate '
ALTER TABLE "SCB_TRADE_OBJECT_VERSION" ADD PRIMARY KEY ("SUB_TRADE_ID", "SUB_TRADE_VERSION", "SOURCE_SYSTEM", "PORTFOLIO_ID", "INSTRUMENT_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADES_ARCHIVE_PK');
   execute immediate '
ALTER TABLE "SCB_TRADES_ARCHIVE" ADD CONSTRAINT "SCB_TRADES_ARCHIVE_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SCB_ARCH_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_EXTERNAL_IDS_PK');
   execute immediate '
ALTER TABLE "SCB_EXTERNAL_IDS" ADD CONSTRAINT "SCB_EXTERNAL_IDS_PK" PRIMARY KEY ("SUB_TRADE_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADES_ARCHIVED_PRODS_PK');
   execute immediate '
ALTER TABLE "SCB_TRADES_ARCHIVED_PRODUCTS" ADD CONSTRAINT "SCB_TRADES_ARCHIVED_PRODS_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SCB_ARCH_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_MIGRATED_BOOKS_PK');
   execute immediate '
ALTER TABLE "SCB_MIGRATED_BOOKS" ADD CONSTRAINT "SCB_MIGRATED_BOOKS_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SMB_PORTFOLIO_ID_UNIQUE');
   execute immediate '
ALTER TABLE "SCB_MIGRATED_BOOKS" ADD CONSTRAINT "SMB_PORTFOLIO_ID_UNIQUE" UNIQUE ("PORTFOLIO_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('PK_SCB_TICKET');
   execute immediate '
ALTER TABLE "SCB_TICKET" ADD CONSTRAINT "PK_SCB_TICKET" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('PK_SCB_TICKET_ACTION');
   execute immediate '
ALTER TABLE "SCB_TICKET_ACTION" ADD CONSTRAINT "PK_SCB_TICKET_ACTION" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('PK_SCB_TICKET_CONSEQUENCE');
   execute immediate '
ALTER TABLE "SCB_TICKET_CONSEQUENCE" ADD CONSTRAINT "PK_SCB_TICKET_CONSEQUENCE" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SCB_TRADES_PK');
   execute immediate '
ALTER TABLE "SCB_TRADES_TABLE" ADD CONSTRAINT "SCB_TRADES_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 12582912 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SDP_DATA_TYPE_PK');
   execute immediate '
ALTER TABLE "SDP_DATA_TYPE" ADD CONSTRAINT "SDP_DATA_TYPE_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SDP_NAMED_COMMAND_PK');
   execute immediate '
ALTER TABLE "SDP_NAMED_COMMAND" ADD CONSTRAINT "SDP_NAMED_COMMAND_PK" PRIMARY KEY ("OBJECT_ID", "OBJECT_VERSION")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SDP_NC_IMPL_PK');
   execute immediate '
ALTER TABLE "SDP_NAMED_COMMAND_IMPL" ADD CONSTRAINT "SDP_NC_IMPL_PK" PRIMARY KEY ("OBJECT_ID", "OBJECT_VERSION")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SDP_NC_PARAM_PK');
   execute immediate '
ALTER TABLE "SDP_NAMED_COMMAND_PARAM" ADD CONSTRAINT "SDP_NC_PARAM_PK" PRIMARY KEY ("ID", "OBJECT_ID", "OBJECT_VERSION")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SDP_NC_TYPE_PK');
   execute immediate '
ALTER TABLE "SDP_NAMED_COMMAND_TYPE" ADD CONSTRAINT "SDP_NC_TYPE_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('SDP_NC_ENT_PK');
   execute immediate '
ALTER TABLE "SDP_NAMED_COMMAND_ENT" ADD CONSTRAINT "SDP_NC_ENT_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('MSGID');
   execute immediate '
ALTER TABLE "SCB_TRADES_AQ_TABLE" ADD PRIMARY KEY ("MSGID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('ID');
   execute immediate '
ALTER TABLE "SCB_TICKET_ACTION_ATTACHMENT" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('TICKET_ACTION_ATTACHMENT_ID');
   execute immediate '
ALTER TABLE "SCB_TICKET_ATTACHMENT_DATA" ADD PRIMARY KEY ("TICKET_ACTION_ATTACHMENT_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('TICKET_ID');
   execute immediate '
ALTER TABLE "SCB_TICKET_METADATA" ADD PRIMARY KEY ("TICKET_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('PK_SCB_TICKET_GROUP');
   execute immediate '
ALTER TABLE "SCB_TICKET_GROUP" ADD CONSTRAINT "PK_SCB_TICKET_GROUP" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE( INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('PK_SCB_TICKET_TAG');
   execute immediate '
ALTER TABLE "SCB_TICKET_TAG" ADD CONSTRAINT "PK_SCB_TICKET_TAG" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE( INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TDS_DATA"  ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_APPLICATION_PATH_R02');
   execute immediate '
ALTER TABLE "EMS_APPLICATION_PATH" ADD CONSTRAINT "EMS_APPLICATION_PATH_R02" FOREIGN KEY ("APPLICATION")
      REFERENCES "EMS_APPLICATION" ("ID") ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('FK_SCB_TAG_TICKET');
   execute immediate '
ALTER TABLE "SCB_TICKET_TAG" ADD CONSTRAINT "FK_SCB_TAG_TICKET" FOREIGN KEY ("TICKET_ID")
      REFERENCES "SCB_TICKET" ("ID") ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_APPLICATION_USER_R02');
   execute immediate '
ALTER TABLE "EMS_APPLICATION_USER" ADD CONSTRAINT "EMS_APPLICATION_USER_R02" FOREIGN KEY ("APPLICATION_ID")
      REFERENCES "EMS_APPLICATION" ("ID") ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_APPLICATION_USER_R01');
   execute immediate '
ALTER TABLE "EMS_APPLICATION_USER" ADD CONSTRAINT "EMS_APPLICATION_USER_R01" FOREIGN KEY ("USER_ID")
      REFERENCES "EMS_USER" ("ID") ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_ENTITLEMENT_R06');
   execute immediate '
ALTER TABLE "EMS_ENTITLEMENT" ADD CONSTRAINT "EMS_ENTITLEMENT_R06" FOREIGN KEY ("OWNER_ID")
      REFERENCES "EMS_USER" ("ID") ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_ENTITLEMENT_R05');
   execute immediate '
ALTER TABLE "EMS_ENTITLEMENT" ADD CONSTRAINT "EMS_ENTITLEMENT_R05" FOREIGN KEY ("PATH_ID")
      REFERENCES "EMS_PATH" ("ID") ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_ENTITLEMENT_R04');
   execute immediate '
ALTER TABLE "EMS_ENTITLEMENT" ADD CONSTRAINT "EMS_ENTITLEMENT_R04" FOREIGN KEY ("VIEW_ID")
      REFERENCES "EMS_APPLICATION_PATH" ("ID") ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_ENTITLEMENT_R03');
   execute immediate '
ALTER TABLE "EMS_ENTITLEMENT" ADD CONSTRAINT "EMS_ENTITLEMENT_R03" FOREIGN KEY ("ACCESS_ID")
      REFERENCES "EMS_APPLICATION_PATH" ("ID") ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_ENTITLEMENT_R02');
   execute immediate '
ALTER TABLE "EMS_ENTITLEMENT" ADD CONSTRAINT "EMS_ENTITLEMENT_R02" FOREIGN KEY ("OPERATION_ID")
      REFERENCES "EMS_OPERATION" ("ID") ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_ENTITLEMENT_R01');
   execute immediate '
ALTER TABLE "EMS_ENTITLEMENT" ADD CONSTRAINT "EMS_ENTITLEMENT_R01" FOREIGN KEY ("APPLICATION_ID")
      REFERENCES "EMS_APPLICATION" ("ID") ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_GROUP_R03');
   execute immediate '
ALTER TABLE "EMS_GROUP" ADD CONSTRAINT "EMS_GROUP_R03" FOREIGN KEY ("OWNER")
      REFERENCES "EMS_USER" ("ID") ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_GROUP_R02');
   execute immediate '
ALTER TABLE "EMS_GROUP" ADD CONSTRAINT "EMS_GROUP_R02" FOREIGN KEY ("PARENT")
      REFERENCES "EMS_GROUP" ("ID") ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_GROUP_R01');
   execute immediate '
ALTER TABLE "EMS_GROUP" ADD CONSTRAINT "EMS_GROUP_R01" FOREIGN KEY ("APPLICATION")
      REFERENCES "EMS_APPLICATION" ("ID") ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_GROUP_ENTITLEMENT_R02');
   execute immediate '
ALTER TABLE "EMS_GROUP_ENTITLEMENT" ADD CONSTRAINT "EMS_GROUP_ENTITLEMENT_R02" FOREIGN KEY ("GROUP_ID")
      REFERENCES "EMS_GROUP" ("ID") ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_GROUP_ENTITLEMENT_R01');
   execute immediate '
ALTER TABLE "EMS_GROUP_ENTITLEMENT" ADD CONSTRAINT "EMS_GROUP_ENTITLEMENT_R01" FOREIGN KEY ("ENTITLEMENT_ID")
      REFERENCES "EMS_ENTITLEMENT" ("ID") ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_NODE_R01');
   execute immediate '
ALTER TABLE "EMS_NODE" ADD CONSTRAINT "EMS_NODE_R01" FOREIGN KEY ("OWNER")
      REFERENCES "EMS_USER" ("ID") ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('APPLICATION');
   execute immediate '
ALTER TABLE "EMS_NODE" ADD CONSTRAINT "EMS_NODE_R02" FOREIGN KEY ("APPLICATION")
      REFERENCES "EMS_APPLICATION" ("ID") ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_NODE_ATTRIBUTE_R01');
   execute immediate '
ALTER TABLE "EMS_NODE_ATTRIBUTE" ADD CONSTRAINT "EMS_NODE_ATTRIBUTE_R01" FOREIGN KEY ("NODE")
      REFERENCES "EMS_NODE" ("ID") ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_OPERATION_R01');
   execute immediate '
ALTER TABLE "EMS_OPERATION" ADD CONSTRAINT "EMS_OPERATION_R01" FOREIGN KEY ("OPERATIONS")
      REFERENCES "EMS_OPERATION_SET" ("ID") ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_OPERATION_SET_R01');
   execute immediate '
ALTER TABLE "EMS_OPERATION_SET" ADD CONSTRAINT "EMS_OPERATION_SET_R01" FOREIGN KEY ("APPLICATION")
      REFERENCES "EMS_APPLICATION" ("ID") ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_PATH_R01');
   execute immediate '
ALTER TABLE "EMS_PATH" ADD CONSTRAINT "EMS_PATH_R01" FOREIGN KEY ("CHILD")
      REFERENCES "EMS_PATH" ("ID") ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_PATH_ATTRIBUTE_R01');
   execute immediate '
ALTER TABLE "EMS_PATH_ATTRIBUTE" ADD CONSTRAINT "EMS_PATH_ATTRIBUTE_R01" FOREIGN KEY ("PATH")
      REFERENCES "EMS_PATH" ("ID") ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_USER_ENTITLEMENT_R02');
   execute immediate '
ALTER TABLE "EMS_USER_ENTITLEMENT" ADD CONSTRAINT "EMS_USER_ENTITLEMENT_R02" FOREIGN KEY ("USER_ID")
      REFERENCES "EMS_USER" ("ID") ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_USER_ENTITLEMENT_R01');
   execute immediate '
ALTER TABLE "EMS_USER_ENTITLEMENT" ADD CONSTRAINT "EMS_USER_ENTITLEMENT_R01" FOREIGN KEY ("ENTITLEMENT_ID")
      REFERENCES "EMS_ENTITLEMENT" ("ID") ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_USER_GROUP_R02');
   execute immediate '
ALTER TABLE "EMS_USER_GROUP" ADD CONSTRAINT "EMS_USER_GROUP_R02" FOREIGN KEY ("GROUP_ID")
      REFERENCES "EMS_GROUP" ("ID") ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('EMS_USER_GROUP_R01');
   execute immediate '
ALTER TABLE "EMS_USER_GROUP" ADD CONSTRAINT "EMS_USER_GROUP_R01" FOREIGN KEY ("USER_ID")
      REFERENCES "EMS_USER" ("ID") ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
declare
 already_exists exception;
 num_constr integer;
pragma exception_init(already_exists, -955);
begin
   dbms_output.put_line('FK_SCB_TICKET');
   execute immediate '
ALTER TABLE "SCB_TICKET_ACTION" ADD CONSTRAINT "FK_SCB_TICKET" FOREIGN KEY ("TICKET_ID")
      REFERENCES "SCB_TICKET" ("ID") ENABLE
    ';
    dbms_output.put_line('Constraint created');
exception
   when already_exists then
   dbms_output.put_line('Constraint already exists');
   null;
end;
/ 
EOF1
