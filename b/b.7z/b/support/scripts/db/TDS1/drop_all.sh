#!/bin/bash
echo "INFO: Performing schema clean"
export ORACLE_HOME=/sabreadm/oracle/product/client11gR2
export LD_LIBRARY_PATH=/sabreadm/oracle/product/client11gR2/lib
export PATH=$PATH:$ORACLE_HOME/bin

echo $ORACLE_HOME/bin/sqlplus -s DEVAPPSDBA[$TARGET_SCHEMA_NAME]/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE"
$ORACLE_HOME/bin/sqlplus -s DEVAPPSDBA[$TARGET_SCHEMA_NAME]/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" << EOF1
WHENEVER sqlerror EXIT sql.sqlcode
WHENEVER oserror EXIT failure
set serveroutput on size unlimited

show user;

PROMPT "User Objects BEFORE clean"
select object_type ,count(*) from all_objects where owner='$TARGET_SCHEMA_NAME' group by object_type;

declare
  procedure exec_immediate (p_sql in varchar2) is
  begin
    execute immediate p_sql;
  exception
    when others then
      dbms_output.put_line(SUBSTR(p_sql,1,200));
  end exec_immediate;
begin
  --drop constraints
  for vc in (
    select
      'alter table '||table_name||' '||
      'drop constraint '||constraint_name||' CASCADE ' sqltext
    from user_constraints
    where constraint_type = 'R'
  )
  loop
    exec_immediate (vc.sqltext);
  end loop;

  --drop objects
  for vc in (
    select
      'drop'||chr(32)||object_type||chr(32)||'"'||object_name||'"'||chr(32)||
      DECODE(object_type,'TABLE',' PURGE','TYPE',' FORCE',NULL) sqltext
    from user_objects
    where 
        object_name != 'TEMP_FILTER'
    --where
    --  object_type IN
    --  ('VIEW','PACKAGE','FUNCTION','PROCEDURE', 'SEQUENCE','SYNONYM','TABLE','TRIGGER','TYPE')
    order by
      DECODE(object_type,'TYPE',9,'TABLE',8,1),object_name
  )
  loop
    exec_immediate (vc.sqltext);
  end loop;
end;
/

--EXECUTE DBMS_AQADM.DROP_QUEUE_TABLE (queue_table => '$TARGET_SCHEMA_NAME.SCB_TRADES_AQ_TABLE', force =>TRUE);
declare
cnt_object number(2);
begin
select count(*) into cnt_object from all_objects where object_name='SCB_TRADES_AQ_TABLE' and owner='$TARGET_SCHEMA_NAME';
if (cnt_object = 1) then
 DBMS_AQADM.DROP_QUEUE_TABLE (queue_table => '$TARGET_SCHEMA_NAME.SCB_TRADES_AQ_TABLE', force =>TRUE);
end if;
end;
/
declare
cnt_object number(2);
begin
select count(*) into cnt_object from all_objects where object_name='SCB_TRADES_AQ_TABLE_SAB' and owner='$TARGET_SCHEMA_NAME';
if (cnt_object = 1) then
 DBMS_AQADM.DROP_QUEUE_TABLE (queue_table => '$TARGET_SCHEMA_NAME.SCB_TRADES_AQ_TABLE_SAB', force =>TRUE);
end if;
end;
/

PROMPT "User Objects AFTER clean"
select object_type || ' - REMAINING' as object_type ,count(*) from all_objects where owner='$TARGET_SCHEMA_NAME' group by object_type;

select case when count(*) > 0 then (select 'ORA-00054: Schema Not Clean' from dual ) 
else (select 'Schema Clean Successful' from dual) end case_cnt,object_name from 
all_objects where owner='$TARGET_SCHEMA_NAME' and object_name!='TEMP_FILTER' group by object_name;

DECLARE
   after_clean EXCEPTION;
   cnt_num NUMBER;
BEGIN
   DECLARE  ---------- sub-block begins
      after_clean EXCEPTION;  -- this declaration prevails
      cnt_num NUMBER;
   BEGIN
       select count(*) into cnt_num from all_objects where owner='$TARGET_SCHEMA_NAME' and object_name!='TEMP_FILTER';
      IF cnt_num > 0 THEN
         RAISE after_clean;  -- this is not handled
      END IF;
   END;  ------------- sub-block ends
EXCEPTION
  WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Schema Clean Not Successful');
        raise_application_error(-20101, 'Terminating as Schema clean not successful');
END;
/
EOF1
