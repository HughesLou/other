#!/bin/bash
function info() {
  echo "INFO: ------------------------"
  echo "INFO: $1"
  echo "INFO: ------------------------"
}

function error() {
  echo "ERROR: ------------------------"
  echo "ERROR: $1"
  echo "ERROR: ------------------------"
}

export ORACLE_HOME=/sabreadm/oracle/product/client11gR2
export LD_LIBRARY_PATH=/sabreadm/oracle/product/client11gR2/lib
export PATH=$PATH:$ORACLE_HOME/bin

if [ "${DMPDATE}" == "" ]; then 
export DMPDATE=`date '+%d-%h-%Y'`
fi

DMPDATE=`echo $DMPDATE||sed 's/ //g'`

if [ "$EXCL_SCB_ARCH" == "true" ]; then
   ADDNL_ARG="EXCLUDE=TABLE:\"IN \(\'SCB_TRADES_ARCHIVE\',\'SCB_TRADES_ARCHIVED_PRODUCTS\'\)\" "
else
   ADDNL_ARG=""
fi

info "ADDNL_ARG=$ADDNL_ARG"

declare -a my_arr=()
my_arr=(`$ORACLE_HOME/bin/sqlplus -s DEVAPPSDBA/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" << EOF9
set pagesize 0 feedback off verify off heading off echo off
SELECT count(*) from all_objects where owner='$TARGET_SCHEMA_NAME';
exit;
EOF9`);

if [[ ${#my_arr[@]} -gt 1 ]]; then
  echo ${#my_arr[@]} 
  error "Schema Clean Not Successful.."
  exit 0
fi

info "Importing metadata"

info "Importing metadata from expdp-prod-tdsuser-scbtrades-$DMPDATE.dmp"
$ORACLE_HOME/bin/impdp \
userid= DEVAPPSDBA/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" \
logfile=IMPDP-PROD_dumpimport-$TARGET_SCHEMA_NAME.log \
directory=$DATA_DIR \
content=METADATA_ONLY \
parallel=4 \
remap_schema=TDSUSER:$TARGET_SCHEMA_NAME \
dumpfile=expdp-prod-tdsuser-scbtrades-$DMPDATE.dmp \
table_exists_action=REPLACE \
exclude=INDEX,CONSTRAINT

info "Importing metadata from expdp-prod-tdsuser-excludescbtrades-$DMPDATE.dmp"

$ORACLE_HOME/bin/impdp \
userid=DEVAPPSDBA/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" \
logfile=IMPDP-excludescbtrades_Network-$TARGET_SCHEMA_NAME.log \
directory=$DATA_DIR \
content=METADATA_ONLY \
parallel=4 \
remap_schema=TDSUSER:$TARGET_SCHEMA_NAME \
remap_tablespace=SCB_ARCH_DATA:TDS_DATA \
dumpfile=expdp-prod-tdsuser-excludescbtrades-$DMPDATE.dmp \
table_exists_action=REPLACE \
exclude=PASSWORD_HISTORY,INDEX,CONSTRAINT \
transform=oid:n 

if [ "${REFRESH_TYPE}" != "METADATA" ]; then
  if [ "$IMPORT_ONLY_TABLES" == "All" ]; then
    info "Importing ALL data"
    IMPORT_SUBSET=""
  else
    info "Importing only $IMPORT_ONLY_TABLES"
    IMPORT_SUBSET="tables=$IMPORT_ONLY_TABLES"
  fi

  info IMPORT_SUBSET=$IMPORT_SUBSET

  if [ "$ONLY_SABRE_ROWS" == "Yes" ]; then
      QUERY_PARAM1=" PARFILE=$WORKSPACE/support/scripts/db/TDS1/scb_trades.par"
      QUERY_PARAM2=" PARFILE=$WORKSPACE/support/scripts/db/TDS1/other_tables.par"
  fi

  info "First - Importing data from expdp-prod-tdsuser-scbtrades-$DMPDATE.dmp"
  echo $ORACLE_HOME/bin/impdp \
  userid= DEVAPPSDBA/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" \
  logfile=IMPDP-PROD_dumpimport-$TARGET_SCHEMA_NAME.log \
  directory=$DATA_DIR \
  content=ALL \
  parallel=4 \
  remap_schema=TDSUSER:$TARGET_SCHEMA_NAME \
  dumpfile=expdp-prod-tdsuser-scbtrades-$DMPDATE.dmp \
  exclude=INDEX,CONSTRAINT table_exists_action=REPLACE $QUERY_PARAM1
  
  $ORACLE_HOME/bin/impdp \
  userid= DEVAPPSDBA/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" \
  logfile=IMPDP-PROD_dumpimport-$TARGET_SCHEMA_NAME.log \
  directory=$DATA_DIR \
  content=ALL \
  parallel=4 \
  remap_schema=TDSUSER:$TARGET_SCHEMA_NAME \
  dumpfile=expdp-prod-tdsuser-scbtrades-$DMPDATE.dmp \
  exclude=INDEX,CONSTRAINT table_exists_action=REPLACE $QUERY_PARAM1
  
  info "Second - Importing data from expdp-prod-tdsuser-excludescbtrades-$DMPDATE.dmp"
  echo $ORACLE_HOME/bin/impdp \
  userid=DEVAPPSDBA/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" \
  logfile=IMPDP-excludescbtrades_Network-$TARGET_SCHEMA_NAME.log \
  directory=$DATA_DIR \
  content=ALL \
  remap_schema=TDSUSER:$TARGET_SCHEMA_NAME \
  remap_tablespace=SCB_ARCH_DATA:TDS_DATA \
  dumpfile=expdp-prod-tdsuser-excludescbtrades-$DMPDATE.dmp \
  exclude=PASSWORD_HISTORY,INDEX,CONSTRAINT \
  TRANSFORM=oid:n table_exists_action=REPLACE $IMPORT_SUBSET $QUERY_PARAM2
  
  $ORACLE_HOME/bin/impdp \
  userid=DEVAPPSDBA/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" \
  logfile=IMPDP-excludescbtrades_Network-$TARGET_SCHEMA_NAME.log \
  directory=$DATA_DIR \
  content=ALL \
  remap_schema=TDSUSER:$TARGET_SCHEMA_NAME \
  remap_tablespace=SCB_ARCH_DATA:TDS_DATA \
  dumpfile=expdp-prod-tdsuser-excludescbtrades-$DMPDATE.dmp \
  exclude=PASSWORD_HISTORY,INDEX,CONSTRAINT \
  TRANSFORM=oid:n table_exists_action=REPLACE $IMPORT_SUBSET $QUERY_PARAM2
else
  info "Not importing data"
fi

$ORACLE_HOME/bin/sqlplus DEVAPPSDBA/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" << EOF2
WHENEVER sqlerror EXIT sql.sqlcode
WHENEVER oserror EXIT failure
set serveroutput on
show user;
alter user $TARGET_SCHEMA_NAME account unlock;
exit;
EOF2

