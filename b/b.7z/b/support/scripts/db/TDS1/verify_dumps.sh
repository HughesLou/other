#!/bin/bash
echo "INFO: Checking if dump files are avaialble"
export ORACLE_HOME=/sabreadm/oracle/product/client11gR2
export LD_LIBRARY_PATH=/sabreadm/oracle/product/client11gR2/lib
export PATH=$PATH:$ORACLE_HOME/bin
found=0

FOUND_INCLUDETRADE=0
FOUND_EXCLUDETRADE=0


if [ "${DMPDATE}" == "" ]; then
  export DMPDATE=`date '+%d-%h-%Y'`
fi

DMPDATE=`echo $DMPDATE||sed 's/ //g'`

echo "DATA_DIR=$DATA_DIR"

echo $ORACLE_HOME/bin/impdp userid=DEVAPPSDBA/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" dumpfile=expdp-prod-tdsuser-scbtrades-$DMPDATE.dmp directory=$DATA_DIR sqlfile=validate_includescbtrades.sql
$ORACLE_HOME/bin/impdp userid=DEVAPPSDBA/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" dumpfile=expdp-prod-tdsuser-scbtrades-$DMPDATE.dmp directory=$DATA_DIR sqlfile=validate_includescbtrades.sql


if [ $? -eq 0 ]
then
  FOUND_INCLUDETRADE=1
fi

echo $ORACLE_HOME/bin/impdp userid=DEVAPPSDBA/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" dumpfile=expdp-prod-tdsuser-excludescbtrades-$DMPDATE.dmp directory=$DATA_DIR sqlfile=validate_excludescbtrades.sql
$ORACLE_HOME/bin/impdp userid=DEVAPPSDBA/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" dumpfile=expdp-prod-tdsuser-excludescbtrades-$DMPDATE.dmp directory=$DATA_DIR sqlfile=validate_excludescbtrades.sql

if [ $? -eq 0 ]
then
    FOUND_EXCLUDETRADE=1
fi


if [[ ($FOUND_INCLUDETRADE == 1) && ($FOUND_EXCLUDETRADE -eq 1) ]]
then
   echo 'Successful'
   found=1
   exit 0
else
   echo "failure"
   found=0
   exit 1
fi

