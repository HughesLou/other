#!/bin/bash
export ORACLE_HOME=/sabreadm/oracle/product/client11gR2
export LD_LIBRARY_PATH=/sabreadm/oracle/product/client11gR2/lib
export PATH=$PATH:$ORACLE_HOME/bin

if [ "${DMPDATE}" == "" ]; then
  export DMPDATE=`date '+%d-%h-%Y'`
fi

export IMPDATE=`date '+%d-%h-%Y'`

echo "Creating db_information table"

$ORACLE_HOME/bin/sqlplus -s DEVAPPSDBA[$TARGET_SCHEMA_NAME]/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" << EOF1
create table db_information
(
 db_type varchar2(10),
 dump_date date,
 import_date date,
 refresh_date date default sysdate,
 jenkins_job varchar2(30),
 jenkins_build_number number
);

insert into db_information (db_type, dump_date, import_date, jenkins_job, jenkins_build_number)
values ('TDS1', '$DMPDATE', '$IMPDATE', '$JOB_NAME', $BUILD_NUMBER);

EOF1
