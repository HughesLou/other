#!/bin/bash
export ORACLE_HOME=/sabreadm/oracle/product/client11gR2
export LD_LIBRARY_PATH=/sabreadm/oracle/product/client11gR2/lib
export PATH=$PATH:$ORACLE_HOME/bin

$ORACLE_HOME/bin/sqlplus DEVAPPSDBA[$TARGET_SCHEMA_NAME]/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" << EOF5
WHENEVER oserror EXIT failure
set serveroutput on

alter trigger scbtradesaqtrigger disable;

alter trigger scbtradestagaqtrigger disable;

alter trigger scbtradestateaqtrigger disable;

exit;
EOF5

$ORACLE_HOME/bin/sqlplus DEVAPPSDBA/"$DEVAPPSDBA_PASSWORD"@"$TARGET_DATABASE" << EOF3
WHENEVER oserror EXIT failure
set serveroutput on

PROMPT "Re Compiling Target Schema Objects"
EXEC DBMS_UTILITY.compile_schema(schema => '$TARGET_SCHEMA_NAME');

PROMPT "List Of Invalid DB Objects On Target Schema"
select object_name, object_type from all_objects where owner='$TARGET_SCHEMA_NAME' and status='INVALID';

PROMPT "This import disables the following trigger on DEV/TDS TDSUSER :-"
PROMPT "(01)scbtradesaqtrigger                "
PROMPT "(02)scbtradestagaqtrigger             "
PROMPT "(03)scbtradestateaqtrigger            "

PROMPT "This import excludes the following list of tables from TDSUSER prod cut :-"
PROMPT "(01)  SCB_TRADES_INTERIM               "
PROMPT "(02)  SCB_TRADES_TABLE_CM400206        "
PROMPT "(03)  SCB_LIFECYCLE_EX_BCK_1           "
PROMPT "(04)  SCB_LIFECYCLE_BCK_1              "
PROMPT "(05)  SCB_MAPPING_BKP_090811           "
PROMPT "(06)  SCB_PORTFOLIO_LIST               "
PROMPT "(07)  SCB_PORTFOLIO_LIST_1             "
PROMPT "(08)  SCB_PORTFOLIO_LIST_2              "
PROMPT "(09)  SCB_PORTFOLIO_LIST_3              "
PROMPT "(10)  SCB_PORTFOLIO_LIST_4              "
PROMPT "(11)  SCB_PORTFOLIO_LIST_5              "
PROMPT "(12)  SCB_PORTFOLIO_LIST_6              "
PROMPT "(13)  SCB_PORTFOLIO_LIST_7              "
PROMPT "(14)  SCB_PORTFOLIO_LIST_8              "
PROMPT "(15)  SCB_PORTFOLIO_LIST_9              "
PROMPT "(16)  SCB_PORTFOLIO_LIST_10             "
PROMPT "(17)  SCB_PORTFOLIO_LIST_11             "
PROMPT "(18)  SCB_PORTFOLIO_LIST_12             "
PROMPT "(19)  SCB_PORTFOLIO_LIST_13             "
PROMPT "(20)  SCB_PORTFOLIO_LIST_14             "
PROMPT "(21)  SCB_PORTFOLIO_LIST_15             "
PROMPT "(22)  SCB_PORTFOLIO_LIST_16             "
PROMPT "(23)  SCB_PORTFOLIO_LIST_17             "
exit;
EOF3
