# Support scripts

## Stash maintenance

The script **stashstat.py** used for:

* Finding repository directory based on repository name
* Finding repository name based on repository directory
* Query license information
* Find users that recorded in Stash, but not associated with projects and repositories
* Remove users not accociated with projects and repositories

Only members of stash-admin group can run this script

### Finding repository directory based on repository name

This mode is useful for finding location of repository in Stash storage

Usage:
> python stashstat.py --user USER --pass PASS **repos** --reponame NAME

This will print a number that is a directory name in stash storage

### Finding repository name based on repository directory

This mode is useful to find repository name if it is noticed that Git operation on Stash box 
consumes too much resources

Usage:
> python stashstat.py --user USER --pass PASS **repos** --reponum NUMBER

This will print repository name

### Query license information

This mode is useful to find licence information from command line

Usage:
> python stashstat.py --user USER --pass PASS **license** | python -m json.tool

This will print JSON with license information which looks like this:

    {
        "creationDate": 1424005200000,
        "expiryDate": null,
        "gracePeriodEndDate": null,
        "license": "AAABUQ0ODAoPeNpNUF1vgjAUfe+...",
        "maintenanceExpiryDate": 1454158800000,
        "maximumNumberOfUsers": 500,
        "numberOfDaysBeforeExpiry": 2147483647,
        "numberOfDaysBeforeGracePeriodExpiry": 2147483647,
        "numberOfDaysBeforeMaintenanceExpiry": 278,
        "purchaseDate": 1435586400000,
        "serverId": "BL2V-SXJZ-OM9R-H1Z0",
        "status": {
            "currentNumberOfUsers": 407,
            "serverId": "BL2V-SXJZ-OM9R-H1Z0"
        },
        "supportEntitlementNumber": "SEN-2687302",
        "unlimitedNumberOfUsers": false
    }

### Find users not associated with Stash projects and repositories

This mode will scan all projects and repositories. 

Usage:
> python stashstat.py --user USER --pass PASS **users** --findinactive

This will output the list of inactive users to stdout. It will report it's
progress to stderr. This list can be used to remove users from Stash (see below).

Usage:
> python stashstat.py --user USER --pass PASS **users** --findinactive

This will output all users registered with Stash

Usage:
> python stashstat.py --user USER --pass PASS **users** --findinactive --onlycount

This will output only total number of inactive users

### Remove users not accociated with projects and repositories

This mode is used to remove inactive users from Stash.

Usage:
> python stashstat.py --user USER --pass PASS **cleanusers** --diff PATH

*--diff* parameter is a path to a file, that have eash users' name per line. This file can be generated
**users** mode described above.

**Note:** you must remove users with human readable names from that list.

**Note:** you must restart Stash after cleanup command.




 
