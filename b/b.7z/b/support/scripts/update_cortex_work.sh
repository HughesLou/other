#!/bin/bash

if [ -z "$1" ]; then
   echo "Usage: $0 CORTEX_VERSION CORTEX_URL"
   exit 1
fi

MINSPACEKB=250000
TARGETPATH="/sabrebuild/cortex"


CORTEX_UPDATE_LOG=$TARGETPATH/cortex_update.log
PROXY="--proxy http://10.192.126.40:8080"
export http_proxy="http://10.192.126.40:8080"

function info() {
    echo "$(date +%Y-%m-%d_%H:%M:%S_%Z) INFO: $1" | tee -a $CORTEX_UPDATE_LOG
}

function error() {
    echo "$(date +%Y-%m-%d_%H:%M:%S_%Z) ERROR: $1" | tee -a $CORTEX_UPDATE_LOG
}

function dl_windows() {
    info "Downloading WIN32 version"
    curl -s $PROXY -o $UNPACKPATH/Cortex-$CORTEXVERSION-slimline.exe $DOWNLOADURL_WIN32_SLIM
    curl -s $PROXY -o $UNPACKPATH/Cortex-$CORTEXVERSION.exe $DOWNLOADURL_WIN32_FULL
    curl -s $PROXY -o $UNPACKPATH/Cortex-$CORTEXVERSION.zip $DOWNLOADURL_WIN32_ZIP

    info "Creating symlinks for WIN32 binaries"
    ln -s $UNPACKPATH/Cortex-$CORTEXVERSION-slimline.exe Cortex-$CORTEXVERSION-slimline.exe
    ln -s $UNPACKPATH/Cortex-$CORTEXVERSION.exe Cortex-$CORTEXVERSION.exe
    ln -s $UNPACKPATH/Cortex-$CORTEXVERSION.zip Cortex-$CORTEXVERSION.zip
}

function dl_rhel() {
    cd $TARGETPATH
    info "Downloading and unpacking RHEL version"
    wget -O $CORTEXVERSION.tar.gz $DOWNLOADURL
    tar xzfv $CORTEXVERSION.tar.gz
    ln -fs $UNPACKPATH $TARGETPATH/latest_version_mig
}

function dl_sdk() {
    cd $TARGETPATH
    info "Downloading and unpacking SDK"
    wget -O $CORTEXVERSION-SDK.tar.gz $DOWNLOADURL_SDK
    cd $CORTEXVERSION
    tar xzfv ../$CORTEXVERSION-SDK.tar.gz
    cd ..
}

function publish_to_nexus() {
    info "Publishing to Nexus"
    /shared/opt/tools/apache-maven-3.0.3/bin/mvn deploy:deploy-file -Durl=http://sabrebuild1.uk.standardchartered.com:8081/nexus/content/repositories/releases -DrepositoryId=nexus-releases -DgroupId=com.scb -DartifactId=cortex -Dversion=$CORTEXVERSION -Dpackaging=jar -Dfile=$CORTEXVERSION/linux.gcc.release.x86_64/Cortex.jar| tee -a $CORTEX_UPDATE_LOG
}

CORTEXURL=${2:-"http://cortexinstall.gdc.standardchartered.com/releases"}

CORTEXVERSION=$1
if [[ "$CORTEXVERSION" == "NONE" ]]; then
    unset CORTEXVERSION
    info "Cortex version is not specified" | tee -a $CORTEX_UPDATE_LOG
    info "Checking http://cortexinstall.gdc.standardchartered.com/releases/latest_version" | tee -a $CORTEX_UPDATE_LOG
    CORTEXVERSION=$(curl -s $PROXY -f http://cortexinstall.gdc.standardchartered.com/releases/latest_version)
    if [[ -z "$CORTEXVERSION" ]]; then
        error "Not found: http://cortexinstall.gdc.standardchartered.com/releases/latest_version" | tee -a $CORTEX_UPDATE_LOG
        exit 1
    fi
fi

if echo "$CORTEXURL" | grep -q "ProdVer"; then
    CV=${CORTEXVERSION/-*/}
    CORTEXVERSION_SUFFIX=${CORTEXVERSION/$CV-/-}
    CORTEXVERSION=$CV
fi

UNPACKPATH=$TARGETPATH/$CORTEXVERSION

DOWNLOADURL=$CORTEXURL/${CORTEXVERSION}${CORTEXVERSION_SUFFIX}/rh5x/$CORTEXVERSION.tar.gz
DOWNLOADURL_SDK=$CORTEXURL/${CORTEXVERSION}${CORTEXVERSION_SUFFIX}/rh5x/$CORTEXVERSION-SDK.tar.gz
DOWNLOADURL_WIN32_SLIM=$CORTEXURL/$CORTEXVERSION${CORTEXVERSION_SUFFIX}/win32/Cortex-$CORTEXVERSION-slimline.exe
DOWNLOADURL_WIN32_FULL=$CORTEXURL/$CORTEXVERSION${CORTEXVERSION_SUFFIX}/win32/Cortex-$CORTEXVERSION.exe
DOWNLOADURL_WIN32_ZIP=$CORTEXURL/$CORTEXVERSION${CORTEXVERSION_SUFFIX}/win32/Cortex-$CORTEXVERSION.zip


info "Installing Cortex $CORTEXVERSION from $CORTEXURL"
info "Checking Cortex release site $CORTEXURL/$CORTEXVERSION${CORTEXVERSION_SUFFIX}"
curl -s -f $PROXY $CORTEXURL/$CORTEXVERSION${CORTEXVERSION_SUFFIX} > /dev/null
if [ $? -ne 0 ]; then
   error "URL $CORTEXURL/$CORTEXVERSION${CORTEXVERSION_SUFFIX} does not exist"
   exit 1
fi
info "Checking if available disk space is more than $MINSPACEKB KB"

test $(df -k $TARGETPATH | sed -n '3p' | awk '{print $3}') -ge $MINSPACEKB && info "ENOUGH SPACE" || exit 1;

echo "CORTEXVERSION=$CORTEXVERSION" > cortex.properties

if [[ -d $UNPACKPATH ]]; then
    info "$CORTEXVERSION exists in $UNPACKPATH, checking Nexus"
    curl -s -f http://sabrebuild1.uk.standardchartered.com:8081/nexus/content/repositories/releases/com/scb/cortex/$CORTEXVERSION/ > /dev/null
    if [ $? -ne 0 ]; then
        info "INFO: $CORTEXVERSION not in Nexus. Uploading"
        publish_to_nexus
    else
        info "$CORTEXVERSION is in Nexus"
    fi
    if [ ! -f $UNPACKPATH/Cortex-$CORTEXVERSION-slimline.exe ]; then
        dl_windows
    else
        info "Windows binaries already downloaded"
    fi
    if [ ! -f $UNPACKPATH/$CORTEXVERSION/sdk ]; then
        dl_sdk
    else
        info "SDK already downloaded"
    fi
else
    info "$CORTEXVERSION does not exist, downloading and unpacking from $DOWNLOADURL"

    dl_rhel
    dl_sdk
    dl_windows

    publish_to_nexus
fi
info "Finished Cortex $CORTEXVERSION update"

