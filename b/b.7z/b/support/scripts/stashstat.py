"""
Usage:
    stashstats.py --user USER --pass PASS [--stash URL] [--ldap ADDR] repos
                  [(--reponum NN | --reponame NAME)]
    stashstats.py --user USER --pass PASS [--stash URL] [--ldap ADDR] users
                  [--findinactive] [--onlycount] [--checkldap]
    stashstats.py --user USER --pass PASS [--stash URL] [--ldap ADDR]
                  cleanusers [--diff PATH] [--checkldap] [--dry-run]
    stashstats.py --user USER --pass PASS [--stash URL] [--ldap ADDR] license

Options:
    --user USER         Stash user name
    --pass PASS         Stash user password
    --stash URL         Stash URL
                        [default: http://stash.uk.standardchartered.com:7990]
    --ldap ADDR         LDAP server address
                        [default: 10.20.195.58]
    --reponum NN        Repository number to resolve to repo name
    --reponame NAME     Repository name to resolve to repo number
    --diff PATH         File with accounts not in LDAP
    --findinactive      Find and report inactive users
    --onlycount         Print only current count of users
    --dry-run           Don't delete users
"""
from collections import defaultdict
from docopt import docopt
import sys
import json
import re
import requests
import logging
from time import sleep
from requests.auth import HTTPBasicAuth

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.WARNING,
                    format='%(asctime)s %(filename)s[line:%(lineno)d] '
                    '%(levelname)s %(message)s',
                    datefmt='%a, %d %b %Y %H:%M:%S')
ldap_available = False
try:
    import ldap
    ldap_available = True
except:
    logger.error('Python-ldap is not installed. '
                 'LDAP functions are not available')

ldap_server = ''


class Unbuffered(object):
    """
    Implements unbuffered output.
    """
    def __init__(self, stream):
        self.stream = stream

    def write(self, data):
        self.stream.write(data)
        self.stream.flush()

    def __getattr__(self, attr):
        return getattr(self.stream, attr)


def stash_api(endpoint, return_values_only=True):
    url = baseurl + endpoint + base_limit
    r = requests.get(url, auth=base_auth)
    if r.status_code == 200:
        ret_val = json.loads(r.text)
        if return_values_only:
            return ret_val['values']
        else:
            return ret_val
    else:
        print 'Error calling Stash API at %s' % url
        print r.text
        sys.exit(1)


def st_projects():
    return stash_api('/projects')


def st_project_repos(key):
    return stash_api('/projects/%s/repos' % key)


def st_project_users(key):
    return stash_api('/projects/%s/permissions/users' % key)


def st_all_users():
    return stash_api('/admin/users')


def st_repo_users(project_key, repo_slug):
    return stash_api('/projects/%s/repos/%s/permissions/users'
                     % (project_key, repo_slug))


def check_ldap_users(ldap_server, usernames):
    print 'Checking LDAP...'
    print ('Each request is done with 200msec delay. '
           'It will take at least %s seconds(not counting LDAP timings).'
           % (len(usernames) * 200 / 1000))
    print ('For each found user . will be printed, for each not found - !')
    confirmed_ldap_users = set()
    try:
        ldap_service = ldap.open(ldap_server)
        ldap_service.protocol_version = ldap.VERSION3
        searchScope = ldap.SCOPE_ONELEVEL
        retrieveAttributes = None
        sys.stdout = Unbuffered(sys.stdout)
        for username in usernames:
            # first you must open a connection to the server
            try:
                searchFilter = 'cn={username}'.format(username=username)
                ldap_result_id = ldap_service.search(baseDN,
                                                     searchScope,
                                                     searchFilter,
                                                     retrieveAttributes)
                result_type, result_data = ldap_service.result(
                    ldap_result_id, 0)
                if result_data and result_type == ldap.RES_SEARCH_ENTRY:
                    confirmed_ldap_users.add(username)
                    sys.stdout.write('.')
                else:
                    sys.stdout.write('!')
                sleep(0.2)
            except ldap.LDAPError, e:
                logger.error('LDAP Error: %s', e)
    except ldap.LDAPError, e:
        logger.error('LDAP Error: %s', e)
    print ''
    return confirmed_ldap_users


def find_assigned_users():
    p_users = set()
    all_projects = st_projects()
    for prj in all_projects:
        pp_users = set()
        all_prj_users = st_project_users(prj['key'])
        print >> sys.stderr, prj['key'], len(all_prj_users)
        for user in all_prj_users:
            pp_users.add(user['user']['name'])

        p_repos = st_project_repos(prj['key'])
        for repo in p_repos:
            repo_users = st_repo_users(prj['key'], repo['slug'])
            print >> sys.stderr, '    ', repo['slug'], len(repo_users)

            for user in repo_users:
                pp_users.add(user['user']['name'])

        print >> sys.stderr, '-- This project users:', len(pp_users)
        p_users = p_users.union(pp_users)
        print >> sys.stderr, '<< Total accounted users so far: ', \
            len(p_users)
    return p_users


def calculate_users(args, all_users):
    usernames = set()
    users_in_project = set()
    in_project_in_ldap = set()
    in_project_not_in_ldap = set()

    usernames = set([user['name'] for user in all_users])
    users_in_project = find_assigned_users()
    if args['--checkldap']:
        if ldap_available:
            in_project_in_ldap = check_ldap_users(
                args['--ldap'], sorted(users_in_project)
            )
        else:
            logger.warning('Failed to check ldap, '
                           'because no python ldap installed')

    in_project_not_in_ldap = sorted(users_in_project - in_project_in_ldap)
    unassigned_users = sorted(usernames - users_in_project)

    print 'Total number of users (licenses used): %s' % len(all_users)
    print ('Number of users associated with projects: %s'
           % len(users_in_project))
    print ('Number of users NOT associated with any projects: %s'
           % len(unassigned_users))
    print ('Number of users associated with projects and NOT in LDAP: %s'
           % len(in_project_not_in_ldap))
    print ('-----')
    print ('TOTAL number of users to be kept: %s'
           % len(in_project_in_ldap))

    to_remove = sorted(in_project_not_in_ldap + unassigned_users)
    print ('TOTAL number of users to be removed: %s'
           % len(to_remove))

    return to_remove

if __name__ == '__main__':
    args = docopt(__doc__)
    baseurl = args['--stash'] + '/rest/api/1.0'
    baseDN = 'OU=users, O=standardchartered'
    # Total number of licenses
    base_limit = '?limit=1000'
    base_auth = HTTPBasicAuth(args['--user'], args['--pass'])

    if args['repos']:
        all_projects = st_projects()

        project_repos = defaultdict(dict)
        for project in all_projects:
            key = project['key']
            repos = st_project_repos(key)

            for repo in repos:
                project_repos[key].update({repo['name']: repo['id']})
                if not any([args['--reponum'], args['--reponame']]):
                    print '%s: %s -> %s' % (key, repo['name'], repo['id'])
                elif args['--reponum']:
                    if repo['id'] == int(args['--reponum']):
                        print '%s: %s -> %s' % (key, repo['name'], repo['id'])
                        sys.exit()
                elif args['--reponame']:
                    if repo['name'] == args['--reponame']:
                        print '%s: %s -> %s' % (key, repo['name'], repo['id'])
                        sys.exit()

    elif args['users']:
        all_users = st_all_users()
        p = re.compile('^[0-9]{7}$')
        if not args['--findinactive']:
            if args['--onlycount']:
                print 'Total Number of users: %s' % len(all_users)
            else:
                for user in all_users:
                    print user['name']
        else:
            to_remove = calculate_users(args, all_users)
            if not args['--onlycount']:
                print 'To be removed: '
                for user in to_remove:
                    if not p.match(user.strip()):
                        continue
                    print user

                print 'Special users to be kept'
                count = 0
                for user in to_remove:
                    if not p.match(user.strip()):
                        print user
                        count += 1
                print 'Number of special users: %s' % count

    elif args['cleanusers']:
        to_remove = set()
        # for deletions - we only need to remove bankid users
        p = re.compile('^[0-9]{7}$')
        if args['--diff']:
            with open(args['--diff'], 'r') as user_file:
                to_remove = list(user_file)
        else:
            all_users = st_all_users()
            to_remove = calculate_users(args, all_users)

        special = []
        for bankid in sorted(to_remove):
            # skip non bankid users
            if not p.match(bankid.strip()):
                special.append(bankid.strip())
                continue
            # Just show deletions for dry-run
            if args['--dry-run']:
                print 'User %s will be deleted'
                continue

            url = baseurl + '/admin/users?name=' + bankid.strip()
            r = requests.delete(url, auth=base_auth)
            if r.status_code != 200:
                print 'User %s was not deleted' % bankid
            else:
                print 'User %s was deleted' % bankid
            sleep(0.2)

        print '%s Special users were not removed:' & len(special)
        for user in special:
            print user

    elif args['license']:
        print json.dumps(stash_api('/admin/license', False))
