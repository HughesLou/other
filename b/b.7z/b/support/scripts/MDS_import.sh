#!/bin/bash

## ================
TO_SCHEMA=MDS02
DATAPUMP_DIR=ORA_TOY
EXP_DATE=31Jul2014
## ================

ORACLE_HOME=/u01/app/oracle/product/db/11.2.0.3.0; export ORACLE_HOME
LD_LIBRARY_PATH=$ORACLE_HOME/lib; export LD_LIBRARY_PATH
PATH=$ORACLE_HOME/bin:/bin:/usr/bin:/usr/sbin:/etc:/usr/local/bin:/sbin:$PATH:; export PATH

SID=$(ps -ef | grep ora_smon_ | grep -v "grep" | grep -i "DOUK1TOY" | awk '{ print substr($8,10,13)}')
readonly ORACLE_SID=$SID; export ORACLE_SID

DUMP_DIR=$(echo $(sqlplus -s "/as sysdba" << EOF
set heading off
select DIRECTORY_PATH from dba_directories where DIRECTORY_NAME='${DATAPUMP_DIR}';
EOF) | sed 's/\n//g')

impdp "'/ as sysdba'" directory=${DATAPUMP_DIR} remap_schema=MDSUSER:${TO_SCHEMA} table_exists_action=REPLACE exclude=OBJECT_GRANT dumpfile=mds_oneoff_MDS_FULL_SCHEMA_METADATA_${EXP_DATE}.dmp logfile=imp_${TO_SCHEMA}_MDS_FULL_SCHEMA_METADATA_${EXP_DATE}.log
impdp "'/ as sysdba'" directory=${DATAPUMP_DIR} remap_schema=MDSUSER:${TO_SCHEMA} table_exists_action=REPLACE exclude=OBJECT_GRANT dumpfile=mds_oneoff_EXPDP-STATIC-ONEOFF-01_${EXP_DATE}.dmp logfile=imp_${TO_SCHEMA}_EXPDP-STATIC-ONEOFF-01_${EXP_DATE}.log
impdp "'/ as sysdba'" directory=${DATAPUMP_DIR} remap_schema=MDSUSER:${TO_SCHEMA} table_exists_action=REPLACE exclude=OBJECT_GRANT dumpfile=mds_oneoff_EXPDP-STATIC-ONEOFF-02_${EXP_DATE}.dmp logfile=imp_${TO_SCHEMA}_EXPDP-STATIC-ONEOFF-02_${EXP_DATE}.log
for dmp in $DUMP_DIR/*.dmp
do
   rev=""
   #reverse the full dmp file name path
   for ((i=${#dmp}-1;i>=0;i--)); do rev="$rev${dmp:$i:1}"; done
   #remove leading substring up to {date}
   pos=`expr index "$rev" \_`
   trimmed=${rev:pos}
   #remove trailing substring from "ffoeno" to the end
   trimmed_rev=${trimmed%\_ffo*}
   rev=""
   #reverse back and get table name
   for ((i=${#trimmed_rev}-1;i>=0;i--)); do rev="$rev${trimmed_rev:$i:1}"; done
   TABLE_NAME=$rev
   impdp "'/ as sysdba'" directory=${DATAPUMP_DIR} remap_schema=MDSUSER:${TO_SCHEMA} table_exists_action=REPLACE tables=MDSUSER.${TABLE_NAME} dumpfile=mds_oneoff_${TABLE_NAME}_${EXP_DATE}.dmp logfile=imp_${TO_SCHEMA}_${TABLE_NAME}_${EXP_DATE}.log
done

echo "**************************************************************************************************************"
echo "*************** All Imports Complete at `date '+%d-%b-%Y %r'`, Please verify the import logs ***************"
echo "**************************************************************************************************************"

