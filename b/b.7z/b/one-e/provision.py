from requests import Request, Session
import json

import logging

# these two lines enable debugging at httplib level (requests->urllib3->httplib)
# you will see the REQUEST, including HEADERS and DATA, and RESPONSE with HEADERS but without DATA.
# the only thing missing will be the response.body which is not logged.
import httplib
httplib.HTTPConnection.debuglevel = 1

class JsonBackedObject(object):
    def from_json(self, json):
        pass

    def to_json(self):
        pass

class Disk(JsonBackedObject):
    def __init__(self, size=50):
        self.size = size

    def from_json(self, json):
        self.size = int(json['size'])
        return self

    def to_json(self):
        return {'Size': self.size}
    

class StoreFront(JsonBackedObject):
    def __init__(self, data_centre='West', environment='Test', 
            template_id='c9d64d46-63b5-41ec-a3f2-5e463e477b19'):
        self.data_centre=data_centre
        self.environment=environment
        self.template_id = template_id

    def to_json(self):
        return {'StoreFront.DataCentre': self.data_centre,
                'StoreFront.Environment': self.environment,
                'StoreFront.TemplateId': self.template_id}

    def from_json(self, json):
        self.data_centre = json['StoreFront.DataCentre']
        self.environment = json['StoreFront.Environment']
        self.template_id = json['StoreFront.TemplateId']
        return self


class Machine(JsonBackedObject):
    def __init__(self, storefront=None, 
            template_id='c9d64d46-63b5-41ec-a3f2-5e463e477b19',
            disk_sizes=None):
        self.service_grouping_id = 1
        self.storefront = StoreFront() if not storefront else storefront
        self.template_id = template_id
        if disk_sizes:
            if isinstance(disk_sizes, list):
                self.disk_sizes = disk_sizes
            elif isinstance(disk_sizes, str):
                self.disk_sizes = disk_sizes.split(', ')
            else:
                raise Exception('"disk_sizes" param must be a list or comma-space separated string')

    def to_json(self):
        out_return = {'serviceGroupingId': self.service_grouping_id,
                'VirtualMachineProperties': self.storefront.to_json(),
                'TemplateId': self.template_id}
        for idx, disk_size in enumerate(self.disk_sizes):
            disk_name = 'VirtualMachine.Disk%s.Size' % idx
            out_return.update({disk_name: disk_size})
        return out_return

    def from_json(self, json):
        assert isinstance(json, Machine)
        self.service_grouping_id = json['serviceGroupingId']
        self.storefront = StoreFront().from_json(json['VirtualMachineProperties'])
        self.template_id = json['TemplateId']
        self.disk_sizes = []
        for disk_num in range(0, 99):
            size = json.get('VirtualMachine.Disk%s.Size' % disk_num, None)
            if size:
                self.disk_sizes.append(Disk(size))
            else:
                break

        return self
    
class SabreEnvironment(JsonBackedObject):
    def __init__(self, number_of_machines):
        self.application_name = 'SABREAPI'
        self.project_id = 'SABRE'
        self.cost_centre = '100000001'
        self.number_of_machines = number_of_machines
        self.machines = []
        for idx in range(0, number_of_machines):
            self.machines.append(Machine(disk_sizes='50, 50'))

    def from_json(self, json):
        machines = json['VirtualMachines']
        self.number_of_machines = len(machines)
        for machine in machines:
            self.machines.append(Machine().from_json(machine))
        self.application_name = json['application_name']
        self.project_id = json['project_id_and_name']
        self.cost_centre = json['cost_centre']
        return self

    def to_json(self):
        out = {'environment': {'VirtualMachines': [machine.to_json() for 
                                    machine in self.machines]},
               'application_name': self.application_name,
               'project_id_and_name': self.project_id,
               'cost_centre': self.cost_centre}
        return out 

class SabreJsonEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, JsonBackedObject):
            return obj.to_json()
        else:
            return JSONEncoder.default(self, obj)

class SabreJsonDecoder(json.JSONDecoder):
    def decode(self, json):
        return SabreEnvironment().from_json(json)

def create_request():
    machine = {
                'serviceGroupingId': 1,
                'VirtualMachineProperties': {
                    'Storefront.DataCentre': 'West',
                    'Storefront.Environment': 'Test',
                    'Storefront.TemplateId': 'c9d64d46-63b5-41ec-a3f2-5e463e477b19', 
                    'TemplateId': 'c9d64d46-63b5-41ec-a3f2-5e463e477b19',
                    'VirtualMachine.Disk0.Size': '50',
                    'VirtualMachine.Disk1.Size': '50'
                    }
              }
    req = {'environment': {
                'VirtualMachines': []
            },
            'application_name': 'SABREAPI',
            'project_id_and_name': 'SABRE',
            'cost_centre': '100000001'
          }

    for x in range(1, num_machines):
        req['environment']['VirtualMachines'].append(machine)
    
    return json.dumps(req)

logging.basicConfig() # you need to initialize logging, otherwise you will not see anything from requests
logging.getLogger().setLevel(logging.DEBUG)
requests_log = logging.getLogger("requests.packages.urllib3")
requests_log.setLevel(logging.DEBUG)
requests_log.propagate = True

onee_url = 'http://store.one-e.standardchartered.com/'
login_url = onee_url + 'accounts/sign_in'
environments_url = onee_url + 'environments'

login_data = 'account[domain]=ZONE1-SCBNET&account[username]=1478209&account[password]=J1mmc1v3r'

session = Session()
prepped = Request('POST', login_url, data=login_data).prepare()

# r = session.send(prepped)
r = session.post(login_url, data=login_data)

if r.status_code == 200:
    env = SabreEnvironment(number_of_machines=1)
    data = json.dumps(env, cls=SabreJsonEncoder)
    print data

    # r = session.post(environments_url, data=data, headers={'Accept': 'application/json', 'Content-type': 'application/json'})
print r.status_code
