class Test(object):
    def __init__(self, param):
        print '__init__'

    def mtd(self, param):
        print 'mtd(param=%s)' % param

call = getattr(Test(123), 'mtd')
call('hohoho')
