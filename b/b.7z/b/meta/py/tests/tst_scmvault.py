import os
import random
from os.path import join as jp
import shutil
import tempfile
import requests
from unittest import TestCase
from scmvault import SCMVault
from nose.tools import nottest

@nottest
class ScmVaultTest(TestCase):

    @classmethod
    def setup_class(cls):
        print '=== Setup class start ===='
        cls._temp_dir_1 = tempfile.mkdtemp(prefix='scmvault_test_1_')

    @classmethod
    def teardown_class(cls):
        print '== Tear down class start ==='
        if os.path.exists(cls._temp_dir_1):
            shutil.rmtree(cls._temp_dir_1)

    def setUp(self):
        self._valid_config_path = jp(self._temp_dir_1, 'config.yaml')
        valid_config = '''
---
svn:
  url: 'http://dbvdev4001.uk.standardchartered.com/svn/algo/TOYOTA/SabreFMSDSupport/testing'
  tag_url: 'http://dbvdev4001.uk.standardchartered.com/svn/algo/TOYOTA/SabreFMSDSupport/testing/tags'
mapping:
  CRT: 'CRT'
  SDF-APPS: 'SDF-APPS'
dod:
  approver: 'Janefer Yamat'
'''
        with open(self._valid_config_path, 'w+') as v:
            v.write(valid_config)

    def test_missing_config(self):
        with self.assertRaises(Exception) as ex:
            SCMVault('/', 'TEST', '1.0',
                    'http://cortexinstall.gdc.standardchartered.com/releases/20140126/rh5x/20140126-SDK.tar.gz',
                     None, 'aleksey', 'testpass',
                     'CR001', 'aleksey@scb', 'aleksey@scb')
        self.assertEquals(ex.exception.message,
                          '/dod_config.yaml does not exist')

    def test_empty_config(self):
        _invalid_config_path = jp(self._temp_dir_1, 'config.yaml')
        invalid_config = '''
---
'''
        with open(_invalid_config_path, 'w+') as v:
            v.write(invalid_config)

        with self.assertRaises(Exception) as ex:
            SCMVault(_invalid_config_path, 'TEST', '1.0',
                     'http://sabrebuild1/scratch',
                     'files.txt', 'aleksey', 'testpass',
                     'CR001', 'aleksey@scb', 'aleksey@scb')
        self.assertEquals(ex.exception.message,
                          '"svn" is not present in %s' % _invalid_config_path)

    def test_valid_config(self):
        SCMVault(self._valid_config_path, 'CRT', '1.0',
                 'http://sabrebuild1/scratch',
                 'files.txt', 'aleksey', 'testpass',
                 'CR001', 'aleksey@scb', 'aleksey@scb')

    @nottest
    def test_download(self):
        v = SCMVault(self._valid_config_path, 'CRT', '1.0',
                     'http://cortexinstall.gdc.standardchartered.com/releases/20140126/rh5x/20140126-SDK.tar.gz',
                     None, 'aleksey', 'testpass',
                     'CR001', 'aleksey@scb', 'aleksey@scb')
        dl_file = v.download_file()
        self.assertIsInstance(dl_file, str)

    @nottest
    def test_svn_vaulting_from_url(self):
        self._valid_config_path = jp(self._temp_dir_1, 'config.yaml')
        valid_config = '''
---
svn:
  url: 'http://dbvdev4001.uk.standardchartered.com/svn/algo/TOYOTA/SabreFMSDSupport/scm_test'
  tag_url: 'http://dbvdev4001.uk.standardchartered.com/svn/algo/TOYOTA/SabreFMSDSupport/scm_test/tags'
mapping:
  SCM: 'SCM_TEST'
  SDF-APPS: 'SDF-APPS'
dod:
  approver: 'test'
'''
        with open(self._valid_config_path, 'w+') as v:
            v.write(valid_config)
        version = '%s.%s' % (random.randint(1, 100), random.randint(0, 100))
        cr = 'CR0000%s' % random.randint(100, 1000)
        vault = SCMVault(config=self._valid_config_path,
                         project='jenkins',
                         version=version,
                         url='http://dbvdev4001.uk.standardchartered.com/' +
                             'svn/algo/TOYOTA/SabreFMSDSupport/jenkins/' +
                             'logparser_clean.conf',
                         binaries_dir=None,
                         username='1459847',
                         password='',
                         cr_number=cr,
                         email='aleksey@scb',
                         cc_email='aleksey@scb')
        vault.vault_to_svn()

        svn_url = 'http://dbvdev4001.uk.standardchartered.com/svn/algo' + \
                  '/TOYOTA/SabreFMSDSupport/scm_test/jenkins/{}/' + \
                  'logparser_clean.conf'
        svn_url = svn_url.format(version)
        svn_tag_url = 'http://dbvdev4001.uk.standardchartered.com/svn' + \
                      '/algo/TOYOTA/SabreFMSDSupport/scm_test/tags/{}'
        svn_tag_url = svn_tag_url.format(cr)

        self.assertNotEquals(requests.get(svn_url).status_code, 404)
        self.assertNotEquals(requests.get(svn_tag_url).status_code, 404)

    @nottest
    def test_svn_vaulting_multiple_binaries(self):
        self._valid_config_path = jp(self._temp_dir_1, 'config.yaml')
        valid_config = '''
---
svn:
  url: 'http://dbvdev4001.uk.standardchartered.com/svn/algo/TOYOTA/SabreFMSDSupport/scm_test'
  tag_url: 'http://dbvdev4001.uk.standardchartered.com/svn/algo/TOYOTA/SabreFMSDSupport/scm_test/tags'
mapping:
  SCM: 'SCM_TEST'
  SDF-APPS: 'SDF-APPS'
dod:
  approver: 'test'
'''
        version = '%s.%s' % (random.randint(1, 100), random.randint(0, 100))
        with open(self._valid_config_path, 'w+') as v:
            v.write(valid_config)

        temp_dir = tempfile.mkdtemp(prefix='test_')
        with open(jp(temp_dir, 'file1'), 'w+') as tmp_file:
            tmp_file.write('Temp file 1 for testing version: %s' % version)
        with open(jp(temp_dir, 'file2'), 'w+') as tmp_file:
            tmp_file.write('Temp file 2 for testing version: %s' % version)
        with open(jp(temp_dir, 'file3'), 'w+') as tmp_file:
            tmp_file.write('Temp file 3 for testing version: %s' % version)

        cr = 'CR0000%s' % random.randint(100, 1000)
        vault = SCMVault(config=self._valid_config_path,
                         project='jenkins',
                         version=version,
                         url=None,
                         binaries_dir=temp_dir,
                         username='1459847',
                         password='',
                         cr_number=cr,
                         email='aleksey@scb',
                         cc_email='aleksey@scb')
        vault.vault_to_svn()

        svn_url = 'http://dbvdev4001.uk.standardchartered.com/svn/algo' + \
                  '/TOYOTA/SabreFMSDSupport/scm_test/jenkins/{}/' + \
                  'logparser_clean.conf'
        svn_url = svn_url.format(version)
        svn_tag_url = 'http://dbvdev4001.uk.standardchartered.com/svn' + \
                      '/algo/TOYOTA/SabreFMSDSupport/scm_test/tags/{}'
        svn_tag_url = svn_tag_url.format(cr)

        self.assertNotEquals(requests.get(svn_url).status_code, 404)
        self.assertNotEquals(requests.get(svn_tag_url).status_code, 404)
