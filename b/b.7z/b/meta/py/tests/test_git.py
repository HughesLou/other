import os
import tempfile
import shutil
import unittest
import subprocess

import mock

import subprocess_helper
from data_object.project import Project
from git_utils.git_command import GitCommand


class test_git(unittest.TestCase):
    class OdCommand(subprocess_helper.SubprocessHelper):
        """Class to find and execute Ant"""

        def __init__(self, tmp_dir="/tmp", git_home=''):
            self.git_home = git_home
            subprocess_helper.SubprocessHelper.__init__(self)
            self.tmp_dir = tmp_dir

        def _find_executable(self):
            git_locations = ['/usr/bin/od']
            # Keep env_ as last in list, or the error handling will break

            for git_path in git_locations:
                if os.path.exists(git_path):
                    return git_path

            raise Exception("Could not find od in any of the locations: " +
                            str(git_locations))

        def run(self, args=(), async=False, msg=None, cmd_msg=None,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE):
            params = [self._executable_path]
            for arg in args:
                params.append(arg)
            return self._run(params, async, msg, cmd_msg,
                             stdout=stdout, stderr=stderr)

    TEST_REPO_URL = 'ssh://git@stash/cd/test.git'
    TMP_REPO_PATH = '/tmp/custom_git'

    @classmethod
    def setup_class(cls):
        print '=== Setup class start ===='
        cls.TMP_REPO_PATH = tempfile.mkdtemp(prefix='test_git_')
        cls.git = GitCommand()
        cls.git.run(args=['clone', cls.TEST_REPO_URL,
                          cls.TMP_REPO_PATH], stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE)
        cls.saved_path = os.getcwd()
        os.chdir(cls.TMP_REPO_PATH)
        print '=== Setup class end ===='

    def setUp(self):
        print '=== Setup start ===='
        _, self.TMP_NOTES_FILE = tempfile.mkstemp(prefix='notes_')
        print '=== Setup end ===='

    def tearDown(self):
        print '== Tear down start ==='
        self._git(['checkout', 'unit_tests'])
        self._git(['reset', '--hard', 'd6376ce'])
        self._git(['push', '--force', 'origin', 'unit_tests'])
        self._git(['checkout', 'master'])
        self._git(['branch', '-D', 'unit_tests'])
        self._git(['reset', '--hard', 'd6376ce'])
        self._git(['push', '--force', 'origin', 'master'])
        branches = self._git(['branch'])[0].split('\n')
        branches = [name[2:] for name in branches]
        if 'merge_test' in branches:
            self._git(['branch', '-D', 'merge_test'])
            self._git(['push', 'origin', ':merge_test'])

        if os.path.exists(self.TMP_NOTES_FILE):
            os.remove(self.TMP_NOTES_FILE)

        print '== Tear down end ==='

    @classmethod
    def teardown_class(cls):
        if os.path.exists('/tmp/rebase_history'):
            os.remove('/tmp/rebase_history')
        if os.path.exists(cls.TMP_REPO_PATH):
            shutil.rmtree(cls.TMP_REPO_PATH)
        os.chdir(cls.saved_path)
        print '== Tear down class end ==='

    def _git(self, args):
        return self.git.run(args=args, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE)

    def _random_commit(self, branch_name, file_name='random.txt'):
        self._git(['checkout', branch_name])

        od = self.OdCommand()
        out, __ = od.run(['-An', '-N2', '-i', '/dev/random'])
        with open(file_name, 'w+') as f:
            f.write(out)
        out, err = self._git(['add', file_name])
        out, err = self._git(['commit', '-m',
                              '%s: Random commit' % branch_name])
        lines = out.split('\n')
        commit = lines[0].split(' ')[1][:-1]
        return commit

    def _log(self):
        out, err = self._git(['log', '--pretty=oneline', '--abbrev-commit'])
        messages = []
        for line in out.split('\n'):
            commit_sha = line[:6]
            commit_msg = line[8:]
            print '%s %s' % (commit_sha, commit_msg)
            messages.append(commit_msg)

        return messages

    def test_rebase_no_master_repo(self):
        def vanilla_conf():
            project = Project(**{'repository': {'git-data': {'url': 'foo'}}})
            return project

        git = vanilla_conf().repository.git_data
        with self.assertRaises(Exception) as ar:
            git.rebase(build_id='unittest',
                       branch_regex='not_used_here')

        self.assertEquals(ar.exception.message,
                          'Cannot do git operations. project'
                          '.repository.git_data.master_repo is not '
                          'set')

    def test__custom_git_empty_ops(self):
        def vanilla_conf():
            project = Project(**{'repository': {'git-data': {'url': 'foo',
                                                             'master-repo':
                                                             '/master_repo'
            }}})
            return project.repository.git_data

        git = vanilla_conf()

        with self.assertRaises(Exception):
            git._custom_git('test')

    def test__custom_git_simple_ops(self):
        def vanilla_conf():
            project = Project(**{'repository':
                                     {'git-data':
                                          {'url': self.TEST_REPO_URL,
                                           'master-repo': self.TMP_REPO_PATH
                                          }}})
            return project.repository.git_data

        git = vanilla_conf()

        self.assertTrue(git._custom_git('master', {'clean': None}))

    def test__custom_git_rebase(self):
        def vanilla_conf():
            project = Project(**{'repository':
                                     {'git-data':
                                          {'url': self.TEST_REPO_URL,
                                           'master-repo': self.TMP_REPO_PATH
                                          }}})
            return project.repository.git_data

        git = vanilla_conf()

        self._random_commit('master')
        self._git(['push', 'origin', 'master'])

        op = {'rebase': {'build_id': 'unittest'}}
        self.assertTrue(git._custom_git('unit_tests', op))

        messages = self._log()
        self.assertEquals(messages[0], 'master: Random commit')
        self.assertEquals(messages[1],
                          'FMSDCD-29 Added line to test JIRA integration')

    def test__custom_git_undo_rebase(self):
        def vanilla_conf():
            project = Project(**{'repository':
                                     {'git-data':
                                          {'url': self.TEST_REPO_URL,
                                           'master-repo': self.TMP_REPO_PATH
                                          }}})
            return project.repository.git_data

        git = vanilla_conf()

        self._random_commit('unit_tests', 'unit_tests_random.txt')
        self._git(['push', 'origin', 'unit_tests'])
        master_commit = self._random_commit('master')
        self._git(['push', 'origin', 'master'])

        op = {'rebase': {'build_id': 'unittest'}}
        self.assertTrue(git._custom_git('unit_tests', op))
        op = {'undo_rebase': {'build_id': 'unittest'}}
        self.assertTrue(git._custom_git('unit_tests', op))

        out, __ = self._git(['merge-base', 'unit_tests', 'master'])
        merge_base = out[:7]
        self.assertNotEquals(merge_base, master_commit)
        self.assertEquals(merge_base, 'd6376ce')

        messages = self._log()
        self.assertEquals(messages[0], 'unit_tests: Random commit')
        self.assertEquals(messages[1],
                          'FMSDCD-29 Added line to test JIRA integration')

    def test_rebase_all(self):
        def vanilla_conf():
            project = Project(**{'repository':
                                     {'git-data':
                                          {'url': self.TEST_REPO_URL,
                                           'master-repo': self.TMP_REPO_PATH
                                          }}})
            return project.repository.git_data

        git = vanilla_conf()

        master_commit = self._random_commit('master')
        self._git(['push', 'origin', 'master'])

        # import pdb; pdb.set_trace()
        self.assertTrue(git.rebase(build_id='unittest',
                                   branch_regex='unit_tests',
                                   do_push=False))
        # import pdb; pdb.set_trace()

        out, __ = self._git(['merge-base', 'unit_tests', 'master'])
        merge_base = out[:7]
        self.assertEquals(merge_base, master_commit)

        messages = self._log()
        self.assertEquals(messages[0], 'master: Random commit')
        self.assertEquals(messages[1],
                          'FMSDCD-29 Added line to test JIRA integration')

    def test_rebase_all_undo(self):
        def vanilla_conf():
            project = Project(**{'repository':
                                     {'git-data':
                                          {'url': self.TEST_REPO_URL,
                                           'master-repo': self.TMP_REPO_PATH
                                          }}})
            return project.repository.git_data

        git = vanilla_conf()

        master_commit = self._random_commit('master')
        self._git(['push', 'origin', 'master'])

        self.assertTrue(git.rebase(build_id='unittest',
                                   branch_regex='unit_tests',
                                   do_push=False))
        self.assertTrue(git.rebase(build_id='unittest',
                                   branch_regex='unit_tests',
                                   do_push=False,
                                   undo_rebase=True))

        out, __ = self._git(['merge-base', 'unit_tests', 'master'])
        merge_base = out[:7]
        self.assertNotEquals(merge_base, master_commit)
        self.assertEquals(merge_base, 'd6376ce')

        messages = self._log()
        self.assertEquals(messages[0],
                          'FMSDCD-29 Added line to test JIRA integration')

    def test_merge(self):
        def vanilla_conf():
            project = Project(**{'controlled-branches-regex': 'merge_test',
                                 'repository':
                                     {'git-data':
                                          {'url': self.TEST_REPO_URL,
                                           'master-repo': self.TMP_REPO_PATH
                                          }}})
            return project

        project = vanilla_conf()
        git = project.repository.git_data

        self._git(['checkout', '-b', 'merge_test'])
        self._random_commit('merge_test')
        self._random_commit('merge_test')
        self._random_commit('merge_test')
        self._git(['push', 'origin', 'merge_test'])
        self._git(['checkout', 'master'])
        self._git(['branch', '-D', 'merge_test'])

        with open(self.TMP_NOTES_FILE, 'w+') as f:
            f.write('This is a line 1 of notes for merge '
                    'from branch merge_branch\n')
            f.write('This is a line 2 of notes for merge '
                    'from branch merge_branch\n')
            f.write('This is a line 3 of notes for merge '
                    'from branch merge_branch\n')

        # import pdb; pdb.set_trace()
        git.merge(branch_name='merge_test',
                  notes_path=self.TMP_NOTES_FILE)

        self._git(['checkout', 'unit_tests'])
        self._git(['branch', '-D', 'master'])
        self._git(['checkout', '-b', 'master', 'origin/master'])

        messages = self._log()
        self.assertEquals(messages[0],
                          'merge_test: merging branch to master')
        self.assertEquals(messages[1],
                          'FMSDCD-29 Added line to test JIRA integration')

        out, err = self._git(['branch', '-a'])
        self.assertIn('merge_test', [b.strip() for b in out.split('\n')])

        commit_lines = []
        out, __ = self._git('log')
        for i, line in enumerate(out.split('\n')):
            if i == 11:
                break
            commit_lines.append(line)

        self.assertEquals(commit_lines[4],
                          '    merge_test: merging branch to master')
        self.assertEquals(commit_lines[5], '')
        self.assertEquals(commit_lines[6], 'Notes:')
        self.assertEquals(commit_lines[7],
                          '    This is a line 1 of notes for merge '
                          'from branch merge_branch')
        self.assertEquals(commit_lines[8],
                          '    This is a line 2 of notes for merge '
                          'from branch merge_branch')
        self.assertEquals(commit_lines[9],
                          '    This is a line 3 of notes for merge '
                          'from branch merge_branch')
        self.assertEquals(commit_lines[10], '')

    def test_merge_and_close(self):
        def vanilla_conf():
            project = Project(**{'controlled-branches-regex': 'merge_test',
                                 'repository':
                                     {'git-data':
                                          {'url': self.TEST_REPO_URL,
                                           'master-repo': self.TMP_REPO_PATH
                                          }}})
            return project

        project = vanilla_conf()
        git = project.repository.git_data

        self._git(['checkout', '-b', 'merge_test'])
        self._random_commit('merge_test')
        self._random_commit('merge_test')
        self._random_commit('merge_test')
        self._git(['push', 'origin', 'merge_test'])
        self._git(['checkout', 'master'])
        self._git(['branch', '-D', 'merge_test'])

        with open(self.TMP_NOTES_FILE, 'w+') as f:
            f.write('This is a line 1 of notes for merge '
                    'from branch merge_branch\n')
            f.write('This is a line 2 of notes for merge '
                    'from branch merge_branch\n')
            f.write('This is a line 3 of notes for merge '
                    'from branch merge_branch\n')

        # import pdb; pdb.set_trace()
        git.merge_close(branch_name='merge_test',
                            notes_path=self.TMP_NOTES_FILE)

        self._git(['checkout', 'unit_tests'])
        self._git(['branch', '-D', 'master'])
        self._git(['checkout', '-b', 'master', 'origin/master'])

        messages = self._log()
        self.assertEquals(messages[0],
                          'merge_test: merging and closing branch')
        self.assertEquals(messages[1],
                          'FMSDCD-29 Added line to test JIRA integration')

        out, err = self._git(['branch', '-a'])
        self.assertNotIn('merge_test', [b.strip() for b in out.split('\n')])

        commit_lines = []
        out, __ = self._git('log')
        for i, line in enumerate(out.split('\n')):
            if i == 11:
                break
            commit_lines.append(line)

        self.assertEquals(commit_lines[4],
                          '    merge_test: merging and closing branch')
        self.assertEquals(commit_lines[5], '')
        self.assertEquals(commit_lines[6], 'Notes:')
        self.assertEquals(commit_lines[7],
                          '    This is a line 1 of notes for merge '
                          'from branch merge_branch')
        self.assertEquals(commit_lines[8],
                          '    This is a line 2 of notes for merge '
                          'from branch merge_branch')
        self.assertEquals(commit_lines[9],
                          '    This is a line 3 of notes for merge '
                          'from branch merge_branch')
        self.assertEquals(commit_lines[10], '')

    def test_undo_merge(self):
        def vanilla_conf():
            project = Project(**{'controlled-branches-regex': 'merge_test',
                                 'repository':
                                     {'git-data':
                                          {'url': self.TEST_REPO_URL,
                                           'master-repo': self.TMP_REPO_PATH
                                          }}})
            return project

        self._git(['checkout', '-b', 'merge_test'])
        self._random_commit('merge_test')
        self._random_commit('merge_test')
        self._random_commit('merge_test')
        self._git(['push', 'origin', 'merge_test'])
        self._git(['checkout', 'master'])
        self._git(['branch', '-D', 'merge_test'])

        with open(self.TMP_NOTES_FILE, 'w+') as f:
            f.write('This is a line 1 of notes for merge '
                    'from branch merge_branch\n')
            f.write('This is a line 2 of notes for merge '
                    'from branch merge_branch\n')
            f.write('This is a line 3 of notes for merge '
                    'from branch merge_branch\n')

        git = vanilla_conf().repository.git_data

        # import pdb; pdb.set_trace()
        git.merge(branch_name='merge_test',
                  notes_path=self.TMP_NOTES_FILE)

        self._git(['checkout', 'unit_tests'])
        self._git(['branch', '-D', 'master'])
        self._git(['checkout', '-b', 'master', 'origin/master'])

        git.undo_merge(branch_name='merge_test')

        messages = self._log()
        self.assertEquals(messages[0],
                          'FMSDCD-29 Added line to test JIRA integration')

        out, err = self._git(['branch', '-l'])
        self.assertIn('merge_test', [b.strip() for b in out.split('\n')])

        out, __ = self._git(['show-ref', 'refs/closed/merge_test'])
        self.assertEquals(out.strip(), '')

        out, __ = self._git(['show-ref',
                             'refs/premerge/master/merge_test'])
        self.assertEquals(out.strip(), '')

    def test_undo_merge_master_repo_not_set(self):
        def vanilla_conf():
            project = Project(**{'controlled-branches-regex': 'merge_test',
                                 'repository':
                                     {'git-data':
                                          {'url': self.TEST_REPO_URL
                                          }}})
            return project

        git = vanilla_conf().repository.git_data

        with self.assertRaises(Exception) as ex:
            git.undo_merge(branch_name='merge_test')

    def test_undo_merge_and_close(self):
        def vanilla_conf():
            project = Project(**{'controlled-branches-regex': 'merge_test',
                                 'repository':
                                     {'git-data':
                                          {'url': self.TEST_REPO_URL,
                                           'master-repo': self.TMP_REPO_PATH
                                          }}})
            return project

        self._git(['checkout', '-b', 'merge_test'])
        self._random_commit('merge_test')
        self._random_commit('merge_test')
        self._random_commit('merge_test')
        self._git(['push', 'origin', 'merge_test'])
        self._git(['checkout', 'master'])
        self._git(['branch', '-D', 'merge_test'])

        with open(self.TMP_NOTES_FILE, 'w+') as f:
            f.write('This is a line 1 of notes for merge '
                    'from branch merge_branch\n')
            f.write('This is a line 2 of notes for merge '
                    'from branch merge_branch\n')
            f.write('This is a line 3 of notes for merge '
                    'from branch merge_branch\n')

        git = vanilla_conf().repository.git_data

        # import pdb; pdb.set_trace()
        git.merge_close(branch_name='merge_test',
                            notes_path=self.TMP_NOTES_FILE)

        self._git(['checkout', 'unit_tests'])
        self._git(['branch', '-D', 'master'])
        self._git(['checkout', '-b', 'master', 'origin/master'])

        git.undo_merge_close(branch_name='merge_test')

        messages = self._log()
        self.assertEquals(messages[0],
                          'FMSDCD-29 Added line to test JIRA integration')

        out, err = self._git(['branch', '-l'])
        self.assertIn('merge_test', [b.strip() for b in out.split('\n')])

        out, __ = self._git(['show-ref', 'refs/closed/merge_test'])
        self.assertEquals(out.strip(), '')

        out, __ = self._git(['show-ref',
                             'refs/premerge/master/merge_test'])
        self.assertEquals(out.strip(), '')


class BranchesTest(unittest.TestCase):
    TEST_REPO_URL = 'ssh://git@stash/cd/test.git'
    TMP_REPO_PATH = '/tmp/custom_git'

    def setUp(self):
        print '=== Setup start ===='
        self.return_value = (
            '19d6b8e94c231720c3121b8413c64fb4b24dca50         '
            'HEAD\n'
            '19d6b8e94c231720c3121b8413c64fb4b24dca50         '
            'refs/heads/TEST-1\n'
            '19d6b8e94c231720c3121b8413c64fb4b24dca50         '
            'refs/heads/TEST-2-no-rebase\n'
            '19d6b8e94c231720c3121b8413c64fb4b24dca50         '
            'refs/heads/12-34-1\n'
            '19d6b8e94c231720c3121b8413c64fb4b24dca50         '
            'refs/heads/master\n',
            None)
        print '=== Setup end ===='

    def vanilla_conf(self):
        jobs_regex = '^[A-Z]*-\d{1,5}.*$|master'
        project = Project(**{'controlled-branches-regex': jobs_regex,
                             'all-branches-regex': '^[A-Z]*-\d{1,5}$',
                             'branch-strategy': 'feature-branches',
                             'repository':
                                 {'git-data':
                                      {'url': self.TEST_REPO_URL,
                                       'master-repo': self.TMP_REPO_PATH
                                      }}})

        return project

    @mock.patch.object(GitCommand, 'run')
    def test_branches_all(self, _run):
        _run.return_value = self.return_value
        project = self.vanilla_conf()
        git = project.repository.git_data
        branches = git.branch_names('.*')
        self.assertTrue(isinstance(branches, list))
        self.assertIn('TEST-1', branches)
        self.assertIn('12-34-1', branches)
        self.assertIn('master', branches)

    @mock.patch.object(GitCommand, 'run')
    def test_branches_regex_from_projectjobs(self, _run):
        _run.return_value = self.return_value
        project = self.vanilla_conf()
        git = project.repository.git_data
        branches = git.branch_names(project.controlled_branches_regex)
        self.assertTrue(isinstance(branches, list))
        self.assertIn('TEST-1', branches)
        self.assertIn('TEST-2-no-rebase', branches)
        self.assertNotIn('12-34-1', branches)
        self.assertIn('master', branches)

    @mock.patch.object(GitCommand, 'run')
    def test_branches_regex_from_basejobs(self, _run):
        _run.return_value = self.return_value
        project = self.vanilla_conf()
        git = project.repository.git_data
        branches = git.branch_names(project.all_branches_regex)
        self.assertTrue(isinstance(branches, list))
        self.assertIn('TEST-1', branches)
        self.assertNotIn('TEST-2-no-rebase', branches)
        self.assertNotIn('12-34-1', branches)
        self.assertNotIn('master', branches)

# TODO: AM@20131017 - not sure if we need those tests now. Leaving them
# commented out
#    @mock.patch.object(GitCommand, 'run')
#    def test_branches_dict_all(self, _run):
#        _run.return_value = self.return_value
#        project = self.vanilla_conf()
#        git = project.repository.git_data
#        branches = git.branches_dict(branch_regex='.*')
#        self.assertTrue(isinstance(branches, dict))
#        self.assertIn('TEST-1', branches)
#        self.assertIn('TEST-2-no-rebase', branches)
#        self.assertIn('12-34-1', branches)
#        self.assertIn('master', branches)
#
#    @mock.patch.object(GitCommand, 'run')
#    def test_branches_dict_base(self, _run):
#        _run.return_value = self.return_value
#        project = self.vanilla_conf()
#        git = project.repository.git_data
#
#        branches = git.branches_dict(branch_regex=project
#        .controlled_branches_regex)
#        self.assertTrue(isinstance(branches, dict))
#        self.assertIn('TEST-1', branches)
#        self.assertNotIn('TEST-2-no-rebase', branches)
#        self.assertNotIn('12-34-1', branches)
#        self.assertNotIn('master', branches)
