import logging
import time
from unittest import TestCase
from data_object.project import Project
from orc import Orchestrator
from data_object.basejobsbuilder import BaseJobsBuilder
from data_object.gitdata import GitData
from jenkinsapi.exceptions import JenkinsAPIException


class OrchestratorTest(TestCase):

    def _remove_job(self, job_name):
        if job_name in self.jenkins_api:
            self.jenkins_api.delete_job(job_name)
        else:
            print 'Job "%s" is not in Jenkins' % job_name

    def _remove_view(self, view_path):
        view_url = "%s/%s" % (self.orc.project.jenkins.url, view_path)
        try:
            if self.jenkins_api.get_view_by_url(view_url):
                self.jenkins_api.delete_view_by_url(view_url)
        except JenkinsAPIException:
            return

    def setUp(self):
        urllib3_logger = logging.getLogger('requests.packages.urllib3')
        urllib3_logger.setLevel(logging.CRITICAL)
        self.config_file = 'data/project_config_sample.yaml'
        self.orc = Orchestrator('helloworld', 'devlocal')
        self.jenkins_api = self.orc.project.jenkins.api()

    def views_jobs_tearDown(self):
        self.jenkins_api.poll()
        self._remove_job('helloworld_create-jobs')
        self._remove_job('helloworld_master-clone')
        self._remove_job('helloworld_onpush')
        self._remove_job('helloworld_rebase')
        self._remove_job('helloworld_rebase-check')
        self._remove_job('helloworld_rebase-undo')
        self._remove_job('helloworld_1-prepare_master')
        self._remove_view('view/helloworld/view/helloworld-repository/')
        self._remove_view('view/helloworld/view/helloworld-branches/view/master/')
        self._remove_view('view/helloworld/view/helloworld-branches/')
        self._remove_view('view/helloworld/')

    def test_to_load_project_setting_when_initialize(self):
        orc = self.orc

        self.assertIsInstance(orc.project, Project)
        self.assertEquals(orc.project.all_branches_regex, '.*')
        self.assertEquals(orc.project.jenkins.user_name, 'maleksey')
        # Next line tests instance override
        self.assertEquals(orc.project.jenkins.url,
                          'http://sabrebuild1.uk.standardchartered.com:8180/')
        self.assertIsInstance(orc.project.jenkins.views.jenkins_nested_view
                              .views[0].builder,
                              BaseJobsBuilder)
        self.assertEquals(orc.project.jenkins.views.jenkins_nested_view
        .views[0].name, 'helloworld-repository')
        self.assertIsInstance(orc.project.repository.git_data,
                              GitData)
        self.assertIsInstance(orc.project.repository.git_data.top_project,
                              Project)
        self.assertEquals(orc.project.repository.git_data.top_project.
                          find_child('project.name'), 'helloworld')
        self.assertEquals(orc.project.repository.git_data.top_project.
                          find_child('project.jenkins.url'),
                          'http://sabrebuild1.uk.standardchartered.com:8180/')

    def test_create_jobs_and_views(self):
        self.orc.update_jenkins()

        jenkins = self.orc.project.jenkins.api()
        jenkins.poll()
        self.assertIn('helloworld_create-jobs', jenkins)
        self.assertIn('helloworld_master-clone', jenkins)
        self.assertIn('helloworld_onpush', jenkins)
        self.assertIn('helloworld_rebase', jenkins)
        self.assertIn('helloworld_rebase-check', jenkins)
        self.assertIn('helloworld_rebase-undo', jenkins)
        self.assertIn('helloworld', jenkins.views)
        view = jenkins.views['helloworld']
        self.assertIn('helloworld-branches', view.views)
        self.assertIn('helloworld-repository', view.views)
        view = view.views['helloworld-branches']
        self.assertIn('master', view.views)

        self.views_jobs_tearDown()

    def test_clean_jobs_and_views(self):
        self.orc.update_jenkins()
        self.orc.clean_jenkins()

        jenkins = self.orc.project.jenkins.api()
        time.sleep(1)
        jenkins.poll()
        self.assertNotIn('helloworld_create-jobs', jenkins)
        self.assertNotIn('helloworld_master-clone', jenkins)
        self.assertNotIn('helloworld_onpush', jenkins)
        self.assertNotIn('helloworld_rebase', jenkins)
        self.assertNotIn('helloworld_rebase-check', jenkins)
        self.assertNotIn('helloworld_rebase-undo', jenkins)
        self.assertNotIn('helloworld', jenkins.views.keys())
