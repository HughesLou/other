from unittest import TestCase
from attribute_dictionary import AttributeDictionary


class AttributeDictionaryTest(TestCase):

    def setUp(self):
        self.attr_dict = AttributeDictionary(a = 1, b = 2)

    def test_to_get_all_keys(self):
        self.assertEquals(['a', 'b'], self.attr_dict.keys())

    def test_to_get_all_values(self):
        self.assertEquals([1, 2], self.attr_dict.values())

    def test_to_get_all_items(self):
        self.assertEquals([('a', 1), ('b', 2)], self.attr_dict.items())

    def test_to_fetch_value(self):
        value = self.attr_dict.pop('b')

        self.assertEquals(2, value)
        self.assertEquals([('a', 1)], self.attr_dict.items())

    def test_to_get_value(self):
        value = self.attr_dict.get('b')

        self.assertEquals(2, value)
        self.assertEquals([('a', 1), ('b', 2)], self.attr_dict.items())

    def test_to_set_value_as_objects_attr(self):
        self.attr_dict.c = 3

        self.assertEquals(3, self.attr_dict.c)

    def test_to_get_internal_attr(self):
        self.assertEquals({'a': 1, 'b': 2}, self.attr_dict._dict)

    def test_to_throw_exception_when_try_to_get_non_existed_attr(self):
        self.assertRaises(AttributeError, self.attr_dict.__getattr__, 'c')

    def test_to_update_value(self):
        self.attr_dict.update({'b': 3})

        self.assertEquals([('a', 1), ('b', 3)], self.attr_dict.items())

    def test_to_copy_object_itself(self):
        other = self.attr_dict.copy()
        self.attr_dict.update({'b': 3})

        self.assertEquals([('a', 1), ('b', 2)], other.items())
