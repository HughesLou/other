import os
import shutil
import unittest
import subprocess
import tempfile
from subprocess_helper import SubProcessException
import subprocess_helper

from git_utils.git_command import GitCommand
from git_utils.custom_git import CustomGit


class test_custom_git(unittest.TestCase):
    class OdCommand(subprocess_helper.SubprocessHelper):
        def __init__(self, tmp_dir="/tmp", git_home=''):
            self.git_home = git_home
            subprocess_helper.SubprocessHelper.__init__(self)
            self.tmp_dir = tmp_dir

        def _find_executable(self):
            git_locations = ['/usr/bin/od']
            # Keep env_ as last in list, or the error handling will break

            for git_path in git_locations:
                if os.path.exists(git_path):
                    return git_path

            raise Exception("Could not find od in any of the locations: " +
                            str(git_locations))

        def run(self, args=(), async=False, msg=None, cmd_msg=None,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE):
            params = [self._executable_path]
            for arg in args:
                params.append(arg)
            return self._run(params, async, msg, cmd_msg='',
                             stdout=stdout, stderr=stderr, silent_out=True,
                             silent_errors=True)

    @classmethod
    def setup_class(cls):
        print '=== Setup class start ===='
        cls._temp_dir = tempfile.mkdtemp(prefix='custom_git_')
        cls._rebase_history = tempfile.mkdtemp(prefix='rebase_history_')
        _, cls._notes_file = tempfile.mkstemp(prefix='notes_')
        cls.git = GitCommand()
        cls.git.run(args=['clone', 'ssh://git@stash/cd/test.git',
                    cls._temp_dir], stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE)
        cls.saved_path = os.getcwd()
        os.chdir(cls._temp_dir)
        print '=== Setup class end ===='

    @classmethod
    def teardown_class(cls):
        print '== Tear down class start ==='
        if os.path.isfile(cls._notes_file):
            os.remove(cls._notes_file)

        os.chdir(cls.saved_path)
        if os.path.exists(cls._temp_dir):
            shutil.rmtree(cls._temp_dir)
        if os.path.exists(cls._rebase_history):
            shutil.rmtree(cls._rebase_history)
        print '== Tear down end ==='

    def tearDown(self):
        print '== Tear down start ==='
        self._git(['checkout', '-q', 'unit_tests'])
        self._git(['reset', '--hard', 'd6376ce'])
        self._git(['push', '--force', 'origin', 'unit_tests'])
        self._git(['checkout', '-q', 'master'])
        self._git(['branch', '-D', 'unit_tests'])
        self._git(['reset', '--hard', 'd6376ce'])
        self._git(['push', '--force', 'origin', 'master'])
        branches = self._git(['branch'])[0].split('\n')
        branches = [name[2:] for name in branches]
        if 'merge_test' in branches:
            self._git(['branch', '-D', 'merge_test'])
            self._git(['push', 'origin', ':merge_test'])
        remote_refs, _ = self._git(['ls-remote',
                                    'ssh://git@stash/cd/test.git',
                                    'merge_test'])
        if remote_refs.strip() != '':
            remote_refs = [ref.split('\t')[1]
                           for ref in remote_refs.split('\n')
                           if ref.strip() != '']
            for ref in remote_refs:
                self._git(['push', 'origin', ':%s' % ref])
        print '== Tear down end ==='

    def _git(self, args):
        return self.git.run(args=args, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE)

    def _random_commit(self, branch_name, file_name='random.txt'):
        self._git(['checkout', '-q', branch_name])

        od = self.OdCommand()
        out, __ = od.run(['-An', '-N2', '-i', '/dev/random'])
        with open(file_name, 'w+') as f:
            f.write(out)
        out, err = self._git(['add', file_name])
        out, err = self._git(['commit', '-m', '%s: Random commit' % branch_name])
        lines = out.split('\n')
        commit = lines[0].split(' ')[1][:-1]
        return commit

    def _log(self):
        out, err = self._git(['log', '--pretty=oneline', '--abbrev-commit'])
        messages = []
        for line in out.split('\n'):
            commit_sha = line[:6]
            commit_msg = line[8:]
            print '%s %s' % (commit_sha, commit_msg)
            messages.append(commit_msg)

        return messages

    def test_init(self):
        print 'Start test_init'
        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path=self._temp_dir,
                       branch='master')

        out, err = self._git('status')
        self.assertEquals(out, '# On branch master\nnothing to commit (working directory clean)\n')
        print 'End test_init'

    def test_init_no_local_branch(self):
        print 'Start test_init_no_local_branch'
        self._git(['checkout', '-q', '-b', 'unit_tests', 'origin/unit_tests'])
        self._random_commit('unit_tests')
        self._git(['push', 'origin', 'unit_tests'])
        self._git(['checkout', '-q', 'master'])
        self._git(['branch', '-D', 'unit_tests'])

        out, __ = self._git(['branch'])
        for line in out.split('\n'):
            if line:
                print 'branch: ', line
                self.assertNotIn(line, 'unit_tests')

        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path=self._temp_dir,
                       branch='unit_tests')

        out, __ = self._git(['branch'])
        for line in out.split('\n'):
            print 'branch: ', line
            star = line[0]
            if star == '*':
                self.assertEquals(line[2:], 'unit_tests')
                break

        messages = self._log()
        self.assertEquals(messages[0], 'unit_tests: Random commit')
        print 'End test_init_no_local_branch'

    def test_init_notsync_local_branch(self):
        print 'Start test_init_notsync_local_branch'
        self.git = GitCommand()
        self.git.run(args=['clone', 'ssh://git@stash/cd/test.git',
                     'self._temp_dir2'], stdout=subprocess.PIPE,
                     stderr=subprocess.PIPE)
        saved_path = os.getcwd()
        os.chdir('self._temp_dir2')
        self._git(['checkout', '-q', '-b', 'unit_tests', 'origin/unit_tests'])
        self._random_commit('unit_tests')
        self._git(['push', 'origin', 'unit_tests'])
        os.chdir(saved_path)
        shutil.rmtree('self._temp_dir2')

        print 'Back to original repo'
        self._git(['checkout', '-q', 'unit_tests'])
        out, __ = self._git('status')
        print out
        messages = self._log()
        self.assertEquals(messages[0], 'FMSDCD-29 Added line to test JIRA integration')

        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path=self._temp_dir,
                       branch='unit_tests')

        out, __ = self._git(['branch'])
        for line in out.split('\n'):
            print 'branch: ', line
            star = line[0]
            if star == '*':
                self.assertEquals(line[2:], 'unit_tests')
                break

        messages = self._log()
        self.assertEquals(messages[0], 'unit_tests: Random commit')
        self.assertEquals(messages[1], 'FMSDCD-29 Added line to test JIRA integration')
        print 'End test_init_notsync_local_branch'

    def test_clean_untracked_files(self):
        print 'Start test_clean_untracked_files'
        od = self.OdCommand()
        out, __ = od.run(['-An', '-N2', '-i', '/dev/random'])
        with open('untracked_file.txt', 'w+') as f:
            f.write(out)

        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path=self._temp_dir,
                       branch='unit_tests')
        cg.git_clean('unit_tests')

        out, err = self._git('status')
        self.assertEquals(out, '# On branch unit_tests\nnothing to commit (working directory clean)\n')
        print 'End test_clean_untracked_files'

    def test_clean_comitted_files(self):
        print 'Start test_clean_comitted_files'
        self._random_commit('unit_tests')

        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path=self._temp_dir,
                       branch='unit_tests')
        print 'Log before clean'
        self._log()

        cg.git_clean('unit_tests')

        out, err = self._git('status')
        self.assertEquals(out, '# On branch unit_tests\nnothing to commit (working directory clean)\n')
        print 'Log after clean'
        messages = self._log()
        for line in messages:
            self.assertNotIn('Random commit', line)
        print 'End test_clean_comitted_files'

    def test_create_new_local_branch(self):
        print 'Start test_create_new_local_branch'
        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path=self._temp_dir,
                       branch='master')
        cg.git_create_new_local_branch('branch1')

        out, err = self._git(['branch'])
        self.assertEquals(out, '* branch1\n  master\n')
        print 'End test_create_new_local_branch'

    def test_rebase_one_branch(self):
        print 'Start test_rebase_one_branch'
        self._random_commit('unit_tests', 'unit_tests_random.txt')
        self._git(['push', 'origin', 'unit_tests'])
        master_commit = self._random_commit('master')
        self._git(['push', 'origin', 'master'])

        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path=self._temp_dir,
                       branch='unit_tests')

        cg.rebase('unit_run')

        messages = self._log()
        self.assertEquals(messages[0], 'unit_tests: Random commit')
        self.assertEquals(messages[1], 'master: Random commit')
        self.assertEquals(messages[2], 'FMSDCD-29 Added line to test JIRA integration')

        # import pdb; pdb.set_trace()
        out, __ = self._git(['merge-base', 'unit_tests', 'master'])
        merge_base = out[:7]
        self.assertEquals(merge_base, master_commit)

        out, __ = self._git(['show-ref', 'refs/tags/rebase/unit_run/unit_tests'])
        self.assertNotEquals(out.strip(), '')
        print 'End test_rebase_one_branch'

    def test_rebase_undo_one_branch(self):
        print 'Start test_rebase_undo_one_branch'
        self._random_commit('unit_tests', 'unit_tests_random.txt')
        self._git(['push', 'origin', 'unit_tests'])
        master_commit = self._random_commit('master')
        self._git(['push', 'origin', 'master'])

        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path=self._temp_dir,
                       branch='unit_tests')

        cg.rebase('unit_run')
        cg.undo_rebase('unit_run')

        out, __ = self._git(['merge-base', 'unit_tests', 'master'])
        merge_base = out[:7]
        self.assertNotEquals(merge_base, master_commit)
        self.assertEquals(merge_base, 'd6376ce')

        messages = self._log()
        self.assertEquals(messages[0], 'unit_tests: Random commit')
        self.assertEquals(messages[1], 'FMSDCD-29 Added line to test JIRA integration')

        out, __ = self._git(['show-ref', 'refs/tags/rebase/unit_run/unit_tests'])
        self.assertEquals(out.strip(), '')
        print 'End test_rebase_undo_one_branch'

    def test_rebase_undo_rebase_inexistent_build(self):
        print 'Start test_rebase_undo_rebase_inexistent_build'
        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path=self._temp_dir,
                       branch='unit_tests')

        self.assertFalse(cg.undo_rebase(build_id='notbuilt'))
        print 'End test_rebase_undo_rebase_inexistent_build'

    def test_rebase_undo_rebase_inexistent_branch(self):
        print 'Start test_rebase_undo_rebase_inexistent_branch'
        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path=self._temp_dir,
                       branch='master')

        self.assertFalse(cg.undo_rebase(branch_name='notexist',
                                        build_id='notbuilt'))
        print 'End test_rebase_undo_rebase_inexistent_branch'

    #def test_rebase_merge_conflict(self):
    #    self._random_commit('unit_tests', 'somefile.txt')
    #    self._git(['push', 'origin', 'unit_tests'])
    #    master_commit = self._random_commit('master', 'somefile.txt')
    #    self._git(['push', 'origin', 'master'])
    #
    #    cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
    #                   repo_path=self._temp_dir,
    #                   branch='unit_tests')
    #
    #    rebase_result = cg.rebase('unit_run')
    #
    #    self.assertFalse(rebase_result)
    #
    #    messages = self._log()
    #    self.assertEquals(messages[0], 'unit_tests: Random commit')
    #    self.assertEquals(messages[1], 'FMSDCD-29 Added line to test JIRA integration')
    #
    #    # import pdb; pdb.set_trace()
    #    out, __ = self._git(['merge-base', 'unit_tests', 'master'])
    #    merge_base = out[:7]
    #    self.assertNotEquals(merge_base, master_commit)
    #
    #    with self.assertRaises(SubProcessException) as se:
    #        out, __ = self._git(['show-ref', 'refs/tags/rebase/unit_run/unit_tests'])

    def test_push(self):
        print 'Start test_push'
        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path=self._temp_dir,
                       branch='unit_tests')

        self._random_commit('unit_tests')
        messages = self._log()
        self.assertEquals(messages[0], 'unit_tests: Random commit')

        cg.push()

        self._git(['checkout', '-q', 'master'])
        self._git(['branch', '-D', 'unit_tests'])
        self._git(['checkout', '-q', '-b', 'unit_tests', 'origin/unit_tests'])

        messages = self._log()
        self.assertEquals(messages[0], 'unit_tests: Random commit')
        self.assertEquals(messages[1], 'FMSDCD-29 Added line to test JIRA integration')
        print 'End test_push'

    def test_close_branch(self):
        print 'Start test_close_branch'
        self._git(['checkout', '-q', '-b', 'merge_test'])
        self._random_commit('merge_test')
        self._random_commit('merge_test')
        self._random_commit('merge_test')
        self._git(['push', 'origin', 'merge_test'])
        self._git(['checkout', '-q', 'master'])
        self._git(['branch', '-D', 'merge_test'])

        with open(self._notes_file, 'w+') as f:
            f.write('This is a line 1 of notes for merge from branch merge_branch\n')
            f.write('This is a line 2 of notes for merge from branch merge_branch\n')
            f.write('This is a line 3 of notes for merge from branch merge_branch\n')

        self.assertTrue(os.path.isfile(self._notes_file))

        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path=self._temp_dir,
                       branch='merge_test')

        cg.merge_and_close(self._notes_file)

        self._git(['checkout', '-q', 'unit_tests'])
        self._git(['branch', '-D', 'master'])
        self._git(['checkout', '-q', '-b', 'master', 'origin/master'])

        # import pdb; pdb.set_trace()
        messages = self._log()
        self.assertEquals(messages[0], 'merge_test: merging and closing branch')
        self.assertEquals(messages[1], 'FMSDCD-29 Added line to test JIRA integration')

        out, err = self._git(['branch', '-a'])
        for line in out.split('\n'):
            self.assertNotIn('merge_test', line)

        commit_lines = []
        out, __ = self._git('log')
        for i, line in enumerate(out.split('\n')):
            if i == 11:
                break
            commit_lines.append(line)

        self.assertEquals(commit_lines[4], '    merge_test: merging and closing branch')
        self.assertEquals(commit_lines[5], '')
        self.assertEquals(commit_lines[6], 'Notes:')
        self.assertEquals(commit_lines[7], '    This is a line 1 of notes for merge from branch merge_branch')
        self.assertEquals(commit_lines[8], '    This is a line 2 of notes for merge from branch merge_branch')
        self.assertEquals(commit_lines[9], '    This is a line 3 of notes for merge from branch merge_branch')
        self.assertEquals(commit_lines[10], '')

        out, __ = self._git(['show-ref', 'refs/tags/closed/merge_test'])
        self.assertNotEquals(out.strip(), '')
        print 'End test_close_branch'

    def test_undo_close_branch(self):
        print 'Start test_undo_close_branch'
        self._git(['checkout', '-q', '-b', 'merge_test'])
        self._random_commit('merge_test')
        self._random_commit('merge_test')
        self._random_commit('merge_test')
        self._git(['push', 'origin', 'merge_test'])
        self._git(['checkout', '-q', 'master'])
        self._git(['branch', '-D', 'merge_test'])

        with open(self._notes_file, 'w+') as f:
            f.write('This is a line 1 of notes for merge from branch merge_branch\n')
            f.write('This is a line 2 of notes for merge from branch merge_branch\n')
            f.write('This is a line 3 of notes for merge from branch merge_branch\n')

        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path=self._temp_dir,
                       branch='merge_test')

        cg.merge_and_close(self._notes_file)

        self._git(['checkout', '-q', 'unit_tests'])
        self._git(['branch', '-D', 'master'])
        self._git(['checkout', '-q', '-b', 'master', 'origin/master'])

        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path=self._temp_dir,
                       branch='master')
        cg.undo_close('merge_test')

        # import pdb; pdb.set_trace()
        messages = self._log()
        self.assertEquals(messages[0], 'merge_test: merging and closing branch')
        self.assertEquals(messages[1], 'FMSDCD-29 Added line to test JIRA integration')

        out, err = self._git(['branch', '-l'])
        self.assertIn('merge_test', [b.strip() for b in out.split('\n')])

        out, __ = self._git(['show-ref', 'refs/tags/closed/merge_test'])
        self.assertEquals(out.strip(), '')
        print 'End test_undo_close_branch'

    def test_undo_merge_branch(self):
        print 'Start test_undo_merge_branch'
        self._git(['checkout', '-q', '-b', 'merge_test'])
        self._random_commit('merge_test')
        self._random_commit('merge_test')
        self._random_commit('merge_test')
        self._git(['push', 'origin', 'merge_test'])
        self._git(['checkout', '-q', 'master'])
        self._git(['branch', '-D', 'merge_test'])

        with open(self._notes_file, 'w+') as f:
            f.write('This is a line 1 of notes for merge from branch merge_branch\n')
            f.write('This is a line 2 of notes for merge from branch merge_branch\n')
            f.write('This is a line 3 of notes for merge from branch merge_branch\n')

        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path=self._temp_dir,
                       branch='merge_test')

        cg.merge_and_close(self._notes_file)
        cg.push('master')

        self._git(['checkout', '-q', 'unit_tests'])
        self._git(['branch', '-D', 'master'])
        self._git(['checkout', '-q', '-b', 'master', 'origin/master'])

        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path=self._temp_dir,
                       branch='master')
        cg.undo_merge_and_close('merge_test')

        # import pdb; pdb.set_trace()
        messages = self._log()
        self.assertEquals(messages[0], 'FMSDCD-29 Added line to test JIRA integration')

        out, err = self._git(['branch', '-l'])
        self.assertIn('merge_test', [b.strip() for b in out.split('\n')])

        out, __ = self._git(['show-ref', 'refs/tags/closed/merge_test'])
        self.assertEquals(out.strip(), '')

        out, __ = self._git(['show-ref', 'refs/tags/premerge/master/merge_test'])
        self.assertEquals(out.strip(), '')

        print 'End test_undo_merge_branch'

    def test_undo_inexistant_merge(self):
        print 'Start test_undo_inexistant_merge'
        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path=self._temp_dir,
                       branch='master')
        with self.assertRaises(Exception) as me:
            cg.undo_merge_and_close('merge_test')

        self.assertEquals(me.exception.message,
                          'Branch "merge_test" does not have reference to restore')
        print 'End test_undo_inexistant_merge'

    def test_undo_close_inexistant_branch(self):
        print 'Start test_undo_close_inexistant_branch'
        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path=self._temp_dir,
                       branch='master')
        with self.assertRaises(Exception) as ex:
            cg.undo_merge_and_close('notexists')

        self.assertEquals(ex.exception.message,
                          'Branch "notexists" does not have reference to restore')
        print 'End test_undo_close_inexistant_branch'

    def test_close_branch_no_notes(self):
        print 'Start test_close_branch_no_notes'
        self._git(['checkout', '-q', '-b', 'merge_test'])
        self._random_commit('merge_test')
        self._random_commit('merge_test')
        self._random_commit('merge_test')
        self._git(['push', 'origin', 'merge_test'])
        self._git(['checkout', '-q', 'master'])
        self._git(['branch', '-D', 'merge_test'])

        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path=self._temp_dir,
                       branch='merge_test')

        with self.assertRaises(Exception) as ex:
            cg.merge_and_close('this_will_be_notes.txt')
        print 'End test_close_branch_no_notes'

    def test_close_branch_empty_notes(self):
        print 'Start test_close_branch_empty_notes'
        self._git(['checkout', '-q', '-b', 'merge_test'])
        self._random_commit('merge_test')
        self._random_commit('merge_test')
        self._random_commit('merge_test')
        self._git(['push', 'origin', 'merge_test'])
        self._git(['checkout', '-q', 'master'])
        self._git(['branch', '-D', 'merge_test'])

        with open(self._notes_file, 'w+') as f:
            pass

        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path=self._temp_dir,
                       branch='merge_test')

        with self.assertRaises(Exception) as ex:
            cg.merge_and_close(self._notes_file)
        print 'End test_close_branch_empty_notes'

    def test_close_not_rebased_branch(self):
        print 'Start test_close_not_rebased_branch'
        self._git(['checkout', '-q', '-b', 'merge_test'])
        self._random_commit('merge_test')
        self._random_commit('merge_test')
        self._random_commit('merge_test')
        self._git(['push', 'origin', 'merge_test'])
        self._git(['checkout', '-q', 'master'])
        self._git(['branch', '-D', 'merge_test'])
        master_commit = self._random_commit('master')
        self._git(['push', 'origin', 'master'])

        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path=self._temp_dir,
                       branch='merge_test')

        with self.assertRaises(Exception) as ex:
            cg.merge_and_close(self._notes_file)
        print 'End test_close_not_rebased_branch'

    def test_list_updated_files(self):
        self._git(['checkout', '-q', '-b', 'merge_test'])
        orig_rev = self._git(['rev-parse', 'HEAD'])[0][0:7]
        self._random_commit('merge_test', 'file1.txt')
        self._random_commit('merge_test', 'file2.txt')
        last_rev = self._random_commit('merge_test', 'file3.txt')
        self._git(['push', 'origin', 'merge_test'])

        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path=self._temp_dir,
                       branch='merge_test')

        changed_files = cg.list_updated_files('merge_test',
                                              orig_rev, last_rev)
        self.assertEquals(len(changed_files), 3)
        self.assertListEqual(changed_files, ['file1.txt',
                                             'file2.txt', 'file3.txt'])

