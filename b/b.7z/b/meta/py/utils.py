import os
import sys
from os.path import join as jp


def import_file(path_to_module):
    """
    Note: path to module must be a relative path
    starting from a directory in sys.path
    """
    module_dir, module_file = os.path.split(path_to_module)
    # if not os.path.exists(path_to_module):
    #     raise Exception("File %s doesn't exist in %s" % (module_file,
    #                                                      module_dir))
    module_name, _module_ext = os.path.splitext(module_file)
    module_package = ".".join(module_dir.split(os.path.sep)) +\
                     '.' + module_name

    module_obj = __import__(module_package, fromlist=['*'])
    module_obj.__file__ = path_to_module
    return module_obj


def import_project(project_name):
    print 'DEBUG: import_project.project_name=', project_name
    return import_file(jp(project_name, 'config.py'))


def data_class(module_name, class_name):
    '''
    Loads data_object class

    :param module_name: module where class can be found, usually *data_object.
        class_name*
    :param class_name: class which needs to be loaded
    :returns: class definition
    :rtype: class
    :raises: ImportError if module cannot be found
    :raises: AttributeError if class cannot be found
    '''
    # print 'DEBUG: importing ', module_name
    __import__(module_name, {}, {}, level=-1)
    m = sys.modules[module_name]
#    m = importlib.import_module(module_name)
    c = getattr(m, class_name)
    return c
