from os.path import join as jp
from collections import OrderedDict
from utils import import_project


class KnownProjects(object):
    def __init__(self, base=None):
        self.project_names = ['ADMIN', 'CRT', 'SIDR-DC']
        self._projects = OrderedDict()

        for project_name in self.project_names:
            if base:
                self._projects[project_name] = import_project(jp(base,
                                                                 project_name))
            else:
                self._projects[project_name] = import_project(project_name)

    def get_environment(self, project_name, environment_name):
        ''' returns Project object for specific project and environment '''
        project = self._projects[project_name]
        return project.conf(project.efac.env_or_group(environment_name))

    def iter_all_environments(self, project_list=None,
                              decrypt_error_warn_only=False):
        ''' Generator for all Project objects in a list of projects.
        If project_list is empty - yields all environments for all projects '''
        if not project_list:
            project_list = self.project_names

        for project_name in project_list:
            project_module = self._projects[project_name]
            for current_environment in project_module.all_envs():
                yield project_module.conf(current_environment.name)

    def iter_all_environments_defs(self, project_list=None):
        ''' Generator for all Env objects in a list of projects.
        If project_list is empty - yields all environments for all projects '''
        if not project_list:
            project_list = self.project_names

        for project_name in project_list:
            project_module = self._projects[project_name]
            for current_environment in project_module.all_envs():
                yield current_environment
