import requests
from HTMLParser import HTMLParser


def get_last_version(repo_url):
    # create a subclass and override the handler methods
    class MyHTMLParser(HTMLParser):
        in_row = False
        in_cell = False
        cell_num = 0
        versions = []

        def handle_starttag(self, tag, attrs):
            if tag == 'tr':
                self.in_row = True
            elif self.in_row and tag == 'td':
                self.cell_num += 1

        def handle_endtag(self, tag):
            if tag == 'tr':
                self.in_row = False
                self.in_cell = False
                self.cell_num = 0

        def handle_data(self, data):
            if self.in_row and self.cell_num == 2:
                self.versions.append(data[:-1].encode('ascii', 'ignore'))
                self.in_cell = False

        def get_versions(self):
            self.versions = self.versions[1:-1]
            self.versions.sort(key=lambda s: map(int, s.split('.')))
            return self.versions

    resp = requests.get(repo_url)
    parser = MyHTMLParser()
    parser.feed(resp.text)

    return parser.get_versions()[-1]


def wget(url, version):
    out = []
    out.append('wget -r -nH --cut-dirs=2 --no-parent --reject "index.html*" ')
    out.append(url)
    out.append(version)
    out.append('/')

    return ''.join(out)

components = [
    {
        'name': 'SDF',
        'url': 'http://sglpaptoy03b.sg.standardchartered.com/Framework/',
        'scm_path': 'SDF'
    },
    {
        'name': 'Cortex',
        'url': 'http://sglpaptoy03b.sg.standardchartered.com/Applications/Cortex/',
        'scm_path': 'Cortex'
    },
    {
        'name': 'EventDiary',
        'url': 'http://sglpaptoy03b.sg.standardchartered.com/Applications/EventDiary/',
        'scm_path': 'Event\ Diary'
    },
    {
        'name': 'RiskViewer',
        'url': 'http://sglpaptoy03b.sg.standardchartered.com/Applications/RiskViewer/',
        'scm_path': 'RiskViewer'
    },
    {
        'name': 'Trade Blotter',
        'url': 'http://sglpaptoy03b.sg.standardchartered.com/Applications/TradeBlotter/',
        'scm_path': 'Trade\ Blotter'
    },
    {
        'name': 'Trade Validator',
        'url': 'http://sglpaptoy03b.sg.standardchartered.com/Applications/TradeValidator/',
        'scm_path': 'Trade\ Validator'
    },

    ]

for component in components:
    version = get_last_version(component['url'])
    print "mkdir -p " + component['scm_path'] + '/' + version
    print "cd " + component['scm_path']
    print wget(component['url'], version)
    print "cd -"
