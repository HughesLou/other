import sys
import subprocess


def quote_if_whitespace(string):
    if not ' ' in string:
        return string
    return '"' + string + '"'


def hide_passwd(msg):
    pwd_pos = msg.find('password=')
    if pwd_pos != -1:
        pwd_pos = pwd_pos + len('password=')
        pwd = msg[pwd_pos:msg.find(' ', pwd_pos)]
        msg = msg.replace(pwd, '*' * len(pwd))
    return msg


class SubProcessException(Exception):
    def __init__(self, message, stdout, stderr):
        super(SubProcessException, self).__init__(message)
        self.stdout = stdout
        self.stderr = stderr


class SubprocessCmd(object):
    def __init__(self, subp, cmd_msg, ignored_return_codes,
                 ignored_errors_messages):
        self.subp = subp
        self.cmd_msg = cmd_msg
        self.ignored_return_codes = ignored_return_codes
        self.ignored_errors_messages = ignored_errors_messages

    def __repr__(self):
        ignored_rc = ", ignored_return_codes=" +\
            repr(self.ignored_return_codes)\
            if self.ignored_return_codes else ""
        ignored_err_msg = ", ignored_errors_messages=" +\
            repr(self.ignored_errors_messages)\
            if self.ignored_errors_messages else ""
        return self.__class__.__name__, ":",\
            str(self.cmd_msg), ignored_rc, ignored_err_msg

    def check_result(self, silent_out=False, silent_errors=False):
        out, err = self.subp.communicate()
        # print 'check_result out=%s, err=%s' % (out, err)
        rc = self.subp.returncode
        # print self.__repr__()
        if out and not silent_out:
            print 'Checkresut out=', out

        if err and not silent_errors:
            print >> sys.stderr, err

        if rc:
            if not rc in self.ignored_return_codes:
                raise SubProcessException(self.cmd_msg +
                                          " failed, returncode: " +
                                          str(rc), out, err)
            emessage = self.ignored_errors_messages.get(rc)
            emessage = ": '" + emessage + "'" if emessage else ""
            print self.cmd_msg + " finished, ignoring returncode: " +\
                str(rc) + emessage

        return out, err


class SubprocessHelper(object):
    '''Class to find and execute external executable'''
    def __init__(self, ignored_errors_messages=None, dry_run=False):
        self._executable_path = self._find_executable()
        self.ignored_errors_messages = {} if ignored_errors_messages is None \
            else ignored_errors_messages
        self.dry_run = dry_run

    def _find_executable(self):
        raise Exception("'_find_executable' must be overridden and return \
                full path to the binary to be executed")

    def _run(self, params, async, msg, cmd_msg=None, stdin=None,
             stdout=None, stderr=None, dry_run=False, ignored_return_codes=(),
             silent_out=True, silent_errors=False):
        """ Tun run completely silent set msg to None, cmd_msg to ""
        and silent_out and silent_errors to True """
        try:
            if cmd_msg != "":
                cmd_msg = cmd_msg if cmd_msg else \
                    ' '.join(map(quote_if_whitespace, params))
            msg = hide_passwd(msg + '\n' + cmd_msg if msg else cmd_msg)

            if self.dry_run or dry_run:
                return None

            if msg:
                print msg
            sys.stdout.flush()
        except:
            raise

        # print 'DEBUG: _run.params ', params
        mp = SubprocessCmd(subprocess.Popen(params, stdin=stdin,
                                            stdout=stdout, stderr=stderr), msg,
                           ignored_return_codes=ignored_return_codes,
                           ignored_errors_messages=
                           self.ignored_errors_messages)
        if not async:
            return mp.check_result(silent_out=silent_out,
                                   silent_errors=silent_errors)
        return mp

    def run_commandline(self, commandline, async=False, msg=None,
                        cmd_msg=None, stdin=None, stdout=None, stderr=None,
                        dry_run=False):
        params = [self._executable_path]
        # TODO this needs to take quoting into account
        params.extend(commandline.split(' '))
        return self._run(params, async, msg, cmd_msg, stdin, stdout, stderr,
                         dry_run)
