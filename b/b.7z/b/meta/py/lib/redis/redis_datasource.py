import redis
from redis_collections import Dict

REDIS_HOST = 'uklpadsab04a.gdc.standardchartered.com'
REDIS_PORT = 6588
class RedisDatasource():
    def __init__(self, redis_key, default_value=None):
        r = redis.StrictRedis(host=REDIS_HOST,
                          port=REDIS_PORT, db=0)
        self.stats = Dict(redis=r, key=redis_key)
        self.default_value = default_value

    def update(self, key, value):
        current_value = self.get(key)
        if self.default_value:
            new_value = self.default_value.copy()
            new_value.update(current_value)
            tmp_set = set(value.keys())
            if tmp_set.issubset(self.default_value.keys()):
                new_value.update(value)
            else:
                raise Exception('The set %s not subset of default set %s'
                    % (value.keys(), self.default_value.keys()))
            self.stats[key] = new_value
        else:
            self.stats[key] = value

    def get(self, key):
        return self.stats.setdefault(key, self.default_value)

if __name__ == '__main__':
    datasource = RedisDatasource(redis_key='SCM_WEBHOOK_TRANSITIONS',
                                     default_value={'DOD': None, 'CR': None, 'Version': None, 'binaries':None})
    datasource.update('Test2', {'DOD': 'TEST_DOD',
                               'CR': 'TEST_CR'})

    print datasource.get('Test2')