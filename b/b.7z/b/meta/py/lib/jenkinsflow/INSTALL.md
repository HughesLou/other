Installation
------------

1. Install jenkinsapi python library.

git clone https://github.com/salimfadhley/jenkinsapi.git
sudo python ./setup.py install

# NOTE: As of 2013-05-15 jenkinsapi available via pip/easyinstall does not work with newer versions of jenkins!

2. Copy jenkinsflow files to your jenkins/hudson installation

3. All set! You can now create jobs with python execution step, which will use this library.
