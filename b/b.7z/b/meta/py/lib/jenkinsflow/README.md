jenkinsflow
===========

Python API with high level build flow constructs for jenkins/hudson.
See demo/... for usage some examples.

Requires the jenkinsapi package