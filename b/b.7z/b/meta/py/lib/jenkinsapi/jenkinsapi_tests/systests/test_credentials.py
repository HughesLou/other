'''
System tests for `jenkinsapi.jenkins` module.
'''
import logging
import unittest
from jenkinsapi_tests.systests.base import BaseSystemTest
from jenkinsapi_tests.test_utils.random_strings import random_string

log = logging.getLogger(__name__)


class TestCredentials(BaseSystemTest):

    def test_create_credentials(self):
        cred_name = random_string()
        self.jenkins.credentials[cred_name] = ('username', 'password')
        self.assertTrue(cred_name in self.jenkins.credentials)

        del self.jenkins.credentials[cred_name]
        self.assertFalse(cred_name in self.jenkins.credentials)

    def test_update_credentials(self):
        cred_name = random_string()
        self.jenkins.credentials[cred_name] = ('username', 'password')
        self.assertTrue(cred_name in self.jenkins.credentials)

        # call same thing again - shall not fail
        self.jenkins.credentials[cred_name] = ('username1', 'password1')
        self.assertTrue(cred_name in self.jenkins.credentials)

        del self.jenkins.credentials[cred_name]
        self.assertFalse(cred_name in self.jenkins.credentials)

if __name__ == '__main__':
    logging.basicConfig()
    unittest.main()
