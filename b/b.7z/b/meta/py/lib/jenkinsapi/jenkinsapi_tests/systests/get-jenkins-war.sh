#!/bin/sh
JENKINS_WAR_URL="http://mirrors.jenkins-ci.org/war/latest/jenkins.war"
wget $JENKINS_WAR_URL
