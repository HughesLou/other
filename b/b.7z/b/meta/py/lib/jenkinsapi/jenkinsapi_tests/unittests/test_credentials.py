import mock
import unittest

from jenkinsapi.jenkins import Jenkins
from jenkinsapi.credentials import Credentials
from jenkinsapi.credential import Credential


class TestNode(unittest.TestCase):

    DATA0 = {
        'assignedLabels': [{}],
        'description': None,
        'jobs': [],
        'mode': 'NORMAL',
        'nodeDescription': 'the master Jenkins node',
        'nodeName': '',
        'numExecutors': 2,
        'overallLoad': {},
        'primaryView': {'name': 'All', 'url': 'http://halob:8080/'},
        'quietingDown': False,
        'slaveAgentPort': 0,
        'unlabeledLoad': {},
        'useCrumbs': False,
        'useSecurity': False,
        'views': [
            {'name': 'All', 'url': 'http://halob:8080/'},
            {'name': 'FodFanFo', 'url': 'http://halob:8080/view/FodFanFo/'}
        ]
    }

    DATA1 = {
        "credentials": {
            "79972988-efd6-49f0-b14e-d341251d8d7b": {
                "description": "test username and password",
                "displayName": "test/****** (test username and password)",
                "fullName": "credential-store/_/79972988-efd6-49f0-b14e-d341251d8d7b",
                "typeName": "Username with password"
            },
            "6e4f5dbf-3d14-4407-8ffe-d3301fb00cfd": {
                "description": "test2",
                "displayName": "test2/****** (test2)",
                "fullName": "credential-store/_/6e4f5dbf-3d14-4407-8ffe-d3301fb00cfd",
                "typeName": "Username with password"
            },
            "987e8c63-46c7-4b62-8d03-a50df4357024": {
                "description": "test3",
                "displayName": "test3/****** (test3)",
                "fullName": "credential-store/_/987e8c63-46c7-4b62-8d03-a50df4357024",
                "typeName": "Username with password"
            }
        },
        "description": "All credentials that are not bound to a specific domain.",
        "displayName": "Global credentials",
        "fullDisplayName": "Credentials \xc2 Global credentials",
        "fullName": "credential-store/_",
        "global": True,
        "urlName": "_"
    }

    @mock.patch.object(Jenkins, '_poll')
    @mock.patch.object(Credentials, '_poll')
    def setUp(self, _poll_credentials, _poll_jenkins):
        _poll_jenkins.return_value = self.DATA0
        _poll_credentials.return_value = self.DATA1

        self.J = Jenkins('http://localhost:8080')
        self.creds = self.J.get_credentials()

    def testRepr(self):
        # Can we produce a repr string for this object
        repr(self.creds)

    def test_length(self):
        self.assertTrue(len(self.creds), 3)

    def test_contains(self):
        self.assertTrue('test3' in self.creds)

    def test_get_credential(self):
        self.assertIsInstance(self.creds['test3'], Credential)
        self.assertEquals(self.creds['test3'].description, 'test3')

if __name__ == '__main__':
    unittest.main()
