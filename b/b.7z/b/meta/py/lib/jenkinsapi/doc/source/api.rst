User API
========

.. automodule:: jenkinsapi.api
   :members: