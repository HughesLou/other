Artifact
========

.. automodule:: jenkinsapi.artifact
   :members: