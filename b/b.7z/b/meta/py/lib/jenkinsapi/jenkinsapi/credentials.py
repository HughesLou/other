"""
This module implements the Credentials class, which is intended to be a
container-like interface for all of the Global credentials defined on a single
Jenkins node.
"""
import logging
import urllib
from jenkinsapi.credential import Credential
from jenkinsapi.jenkinsbase import JenkinsBase
from jenkinsapi.custom_exceptions import AlreadyExists, JenkinsAPIException

log = logging.getLogger(__name__)


class Credentials(JenkinsBase):
    """
    This class provides a container-like API which gives
    access to all global credentials on a Jenkins node.

    Returns a list of Credential Objects.
    """
    def __init__(self, baseurl, jenkins_obj):
        self.baseurl = baseurl
        self.jenkins = jenkins_obj
        JenkinsBase.__init__(self, baseurl)
        self.credentials = self._data['credentials']

    def _poll(self):
        return self.get_data(self.baseurl)

    def __str__(self):
        return 'Global Credentials @ %s' % self.baseurl

    def get_jenkins_obj(self):
        return self.jenkins

    def __iter__(self):
        for cr_id, cred in self.credentials.iteritems():
            yield Credential(credential_id=cr_id,
                             description=cred['description'],
                             fullname=cred['fullName'],
                             typename=cred['typeName'])

    def __contains__(self, description):
        return description in self.keys()

    def iterkeys(self):
        for cr_id, item in self.credentials.iteritems():
            yield item['description']

    def keys(self):
        return list(self.iterkeys())

    def iteritems(self):
        for cr_id, cred in self.credentials.iteritems():
            yield cred['description'], \
                Credential(credential_id=cr_id,
                           description=cred['description'],
                           fullname=cred['fullName'],
                           typename=cred['typeName'])

    def __getitem__(self, description):
        if description in self:
            cr_id, raw_cred = filter(lambda c: c[1]['description'] == description,
                                     self.credentials.iteritems())[0]
            return Credential(credential_id=cr_id,
                              description=raw_cred['description'],
                              fullname=raw_cred['fullName'],
                              typename=raw_cred['typeName'])

    def __len__(self):
        return len(self.keys())

    def __setitem__(self, description, credentials_tuple):
        if description not in self:
            username, password = credentials_tuple

            params = {
                'stapler-class': 'com.cloudbees.plugins.credentials.impl.CertificateCredentialsImpl',
                '_.id': '',
                'keyStoreSource': '0',
                '_.keyStoreFile': '',
                'stapler-class': 'com.cloudbees.plugins.credentials.impl.CertificateCredentialsImpl%24FileOnMasterKeyStoreSource',
                '_.uploadedKeystore': ' ',
                'stapler-class': 'com.cloudbees.plugins.credentials.impl.CertificateCredentialsImpl%24UploadedKeyStoreSource',
                '_.password': ' ',
                '_.description': ' ',
                'stapler-class': 'com.cloudbees.jenkins.plugins.sshcredentials.impl.BasicSSHUserPassword',
                '_.id': ' ',
                '_.username': username,
                '_.password': password,
                '_.description': description,
                'stapler-class': 'com.cloudbees.jenkins.plugins.sshcredentials.impl.BasicSSHUserPrivateKey',
                'stapler-class': 'com.cloudbees.plugins.credentials.impl.UsernamePasswordCredentialsImpl',
                'Submit': 'OK',
                'json': {
                    "": "1",
                    "credentials": {
                        "stapler-class": "com.cloudbees.plugins.credentials.impl.UsernamePasswordCredentialsImpl",
                        "id": "",
                        "username": username,
                        "password": password,
                        "description": description
                    }}
                }
            url = '%s/credential-store/domain/_/createCredentials' % self.jenkins.baseurl
        else:
            # update existing credentials
            cred = self[description]
            username, password = credentials_tuple
            params = {
                'stapler-class': 'com.cloudbees.plugins.credentials.impl.UsernamePasswordCredentialsImpl',
                '_.id': cred.credential_id,
                '_.username': username,
                '_.password': password,
                '_.description': description,
                'json': {
                    "stapler-class": "com.cloudbees.plugins.credentials.impl.UsernamePasswordCredentialsImpl",
                    "id": cred.credential_id,
                    "username": username,
                    "password": password,
                    "description": description
                },
                'Submit': 'Save'
            }
            url = '%s/credential-store/domain/_/credential/%s/updateSubmit' \
                % (self.jenkins.baseurl, cred.credential_id)


        try:
            self.jenkins.requester.post_and_confirm_status(url, params={}, data=urllib.urlencode(params))
        except HTTPError:
            raise JenkinsAPIException('Latest version of Credentials '
                                      'required to be able to create/update '
                                      'credentials')
        self.poll()
        self.credentials = self._data['credentials']
        if description not in self:
            raise JenkinsAPIException('Problem creating/updating credential.')

    def get(self, item, default):
        return self[item] if item in self else default

    def __delitem__(self, item):
        if item in self:

            params = {
                'Submit': 'OK',
                'json': {}
                }
            url = '%s/credential-store/domain/_/credential/%s/doDelete' % (self.jenkins.baseurl, self[item].credential_id)
            try:
                self.jenkins.requester.post_and_confirm_status(url, params={}, data=urllib.urlencode(params))
            except HTTPError:
                raise JenkinsAPIException('Latest version of Credentials '
                                          'required to be able to create '
                                          'credentials')
            self.poll()
            self.credentials = self._data['credentials']
            if item in self:
                raise JenkinsAPIException('Problem creating new credential.')
