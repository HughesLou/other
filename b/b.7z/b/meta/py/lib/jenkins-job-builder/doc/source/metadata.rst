.. _metadata:

Metadata
==========

.. automodule:: metadata
   :members:
