# Jenkins Job Builder Examples #

These examples demonstrate the use of particular features of Jenkins
Job Builder that can be used as starting points for new projects.

These examples are also used in the test framework - if you add a new
example here, please ensure that it can be processed by Jenkins Job
Builder.
