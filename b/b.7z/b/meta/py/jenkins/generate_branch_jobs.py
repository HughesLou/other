import yaml
import git
import os
import shutil
import re
import argparse
from os.path import join as jp
# import pprint
from jenkins_jobs import builder
from jenkinsapi import jenkins
from jenkinsapi.exceptions import UnknownJob
import logging
import tenjin
from tenjin.helpers import *

logger = None


def get_engine(engine_type='tenjin'):
    if engine_type == 'tenjin':
        class NoShellVarSubstTemplate(tenjin.Template):
            """
            Same as standard replacemt except that we ignore
            patters like this: ${...}"""
            s = '(?:\{.*?\}.*?)*'
            EXPR_PATTERN = re.compile(r'#\{(.*?' + s
                                      + r')\}|\{=(?:=(.*?)=|(.*?))=\}', re.S)
            del s

            def __init__(self, filename=None, encoding=None, iinput=None,
                         escapefunc=None, tostrfunc=None, indent=None,
                         preamble=None, postamble=None, smarttrim=None,
                         trace=None):
                tenjin.Template.__init__(self, filename, encoding, iinput,
                                         escapefunc, tostrfunc, indent,
                                         preamble, postamble, smarttrim, trace)

            def expr_pattern(self):
                return self.EXPR_PATTERN

            def get_expr_and_flags(self, match):
                expr1, expr2, expr3 = match.groups()
                if expr1:
                    return expr1, (False, True)   # not escape,  call to_str
                if expr2:
                    return expr2, (False, True)   # not escape,  call to_str
                if expr3:
                    return expr3, (True,  True)   # call escape, call to_str

        print "\n-- Create new tenjin engine --"
        return tenjin.Engine(cache=False,
                             templateclass=NoShellVarSubstTemplate)
#        return tenjin.Engine(cache=False, trace=True)


def render_file(engine, context, src_file, dest_file):
    if not engine:
        engine = get_engine()
    print "Expanding template:", src_file, '->', dest_file
    new_content = engine.render(src_file, context)
    with open(dest_file, 'w') as ff:
        ff.write(new_content)
    shutil.copymode(src_file, dest_file)


def generate_jobs(out_branches, project_folder, jenkins_url, jenkins_user,
                  jenkins_password, command):

    jj_builder = builder.Builder(jenkins_url, jenkins_user,
                                 jenkins_password, [])
    if command == 'updatejobs':
        jj_builder.update_job(project_folder)
    else:
        raise Exception('Delete is not implemented yet')
        # jj_builder.delete_jobs(project_folder)
#    jj_builder.update_job('./CRT/', '', output_dir='/tmp/jjb1')


def create_view_in_parent(api, parent, view_name, jobs):
    save_url = api.baseurl

    # TODO - check if parent exists
    api.baseurl = '%s/%s/' % (api.baseurl, parent)
    view_obj = api.views().create(view_name)
    if view_obj is not None:
        for job_name in jobs:
            job = None
            try:
                # Following will fail to find jobs since we changed baseurl
                # So we reset it back here
                api.baseurl = save_url
                api.poll()
                job = api.get_job(job_name)
            except UnknownJob:
                logger.warn('Job %s does not exist' % job_name)
                pass
            if job:
                view_obj.add_job('', job)

    # Restore Jenkins url and refresh Jenkins object
    api.baseurl = save_url
    api.poll()


def generate_views(branches, project, jenkins_url, jenkins_user,
                   jenkins_password):
    logging.debug('Connecting to Jenkins API')
    logging.debug('jenkins_url=%s' % jenkins_url)
    api = jenkins.Jenkins(jenkins_url, username=jenkins_user,
                          password=jenkins_password)
    logging.debug('Connected to Jenkins. Creating views...')
    # TODO: how to deal with job creator, which parses all yaml files
    views = yaml.load(open('%s/views.yaaml' % project))
    logging.debug('Views from yaml: %s' % views)
    for branch in branches:
        jobs = [job.replace('{branch}', branch) for job in views['jobs']]
        create_view_in_parent(api,
                              views['parent'],
                              '%s-%s' % (project, branch),
                              jobs)


def delete_obsolete_jenkins_jobs(api, project):
    os_parser = builder.YamlParser()
    files_to_process = [os.path.join(project, f)
                        for f in os.listdir(project)
                        if (f.endswith('.yml') or f.endswith('.yaml'))]

    for in_file in files_to_process:
        logger.debug("Parsing YAML file {0}".format(in_file))
        os_parser.parse(in_file)

    # pp = pprint.PrettyPrinter(indent=2)
    os_parser.generateXML()

    os_parser.jobs.sort(lambda a, b: cmp(a.name, b.name))

    all_jenkins_jobs = api.get_jobs_list()
    all_jenkins_jobs.sort(lambda a, b: cmp(a, b))
    all_jenkins_jobs = set(all_jenkins_jobs)
    # logger.debug('\nAll Jenkins jobs: %s' % all_jenkins_jobs)
    project_jenkins_jobs = [job_name for job_name in all_jenkins_jobs
                            if job_name.startswith(project)]
    project_jenkins_jobs.sort(lambda a, b: cmp(a, b))
    project_jenkins_jobs = set(project_jenkins_jobs)
    # logger.debug('\nProject jobs: %s' % project_jenkins_jobs)
    new_jobs = set(job.name for job in os_parser.jobs)
    # logger.debug('\nNew jobs: %s' % new_jobs)
    delete_jobs = project_jenkins_jobs.difference(new_jobs)
    # delete_jobs = [job.name for job in os_parser.jobs if job.name \
    #       not in project_jenkins_jobs]
    # Filter delete_jobs: we are deleting branch based jobs only
    # logger.info('\nDeleting jobs: %s' % delete_jobs)
    rg = re.compile('[A-Z]{1,5}-\d{1,5}$')
    delete_jobs = [job_name for job_name in delete_jobs
                   if rg.findall(job_name)]

    # logger.info('\nDeleting jobs: %s' % delete_jobs)
    views = yaml.load(open('%s/views.yaaml' % project))
    for job_name in delete_jobs:
        logger.info('Deleting job %s' % job_name)
        api.delete_job(job_name)
        job_parse = job_name.split('-')
        # HACK: This is hack, may not work for other project
        branch = '%s-%s-%s' % (project, job_parse[2], job_parse[3])
        view_url = '%s/%s/view/%s' % (api.baseurl, views['parent'], branch)
        logger.info('Deleting view %s' % view_url)
        try:
            api.delete_view_by_url(view_url)
        except:
            pass


def main(command,
         jenkins_url, jenkins_user, jenkins_password, project_folder,
         git_repo_folder=None, use_env_var=None):

    if not jenkins_url:
        jenkins_url = 'http://sabrebuild1.uk.standardchartered.com:8080'

    if not jenkins_user:
        jenkins_user = 'jenkins'

    if not jenkins_password:
        jenkins_password = '8e59d14fd18134a02d17a0703ca90e88'

    out_branches = []

    # Delete cache folder
    if os.path.exists(os.path.expanduser('~/.cache')):
        logger.debug('Clearing cache in %s' % os.path.expanduser('~/.cache'))
        shutil.rmtree(os.path.expanduser('~/.cache'))

    if not use_env_var:
        rg = re.compile('^[A-Z]*-\d{1,5}$')

        repo = git.Repo(git_repo_folder)

        branches = repo.git.branch('-a').split('\n')
        for branch in branches:
            branch_loc = branch.strip().split('/')
            if not len(branch_loc) == 3:
                continue

            if rg.match(branch_loc[2]):
                out_branches.append(branch_loc[2])
            # FIXME: this needs to be defined properly
            elif branch_loc[2] == 'master':
                out_branches.append('master')
    else:
        out_branches = [os.environ[use_env_var]]

    api = jenkins.Jenkins(jenkins_url,
                          username=jenkins_user,
                          password=jenkins_password)

    context = {'branches': out_branches}
    render_file(engine=None, context=context,
                src_file=jp('bootstrap', project_folder,
                            'project.yaml.template'),
                dest_file=jp('bootstrap', project_folder,
                             'project.yaml'))

    if command == 'updatejobs':
        delete_obsolete_jenkins_jobs(api, jp('bootstrap', project_folder))
        generate_jobs(out_branches, jp('bootstrap', project_folder),
                      jenkins_url, jenkins_user,
                      jenkins_password, command)
    elif command == 'createviews':
        generate_views(out_branches, jp('bootstrap', project_folder),
                       jenkins_url, jenkins_user,
                       jenkins_password)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Generate feature \
                                     branch Jenkins pipelines')
    parser.add_argument('-j', '--jenkinsurl',
                        help='Jenkins URL', required=False)
    parser.add_argument('-u', '--jenkinsuser',
                        help='User to connect to Jenkins',
                        default='', required=False)
    parser.add_argument('-p', '--jenkinspassword',
                        help='Jenkins user password',
                        default='', required=False)
    parser.add_argument('-f', '--folder',
                        help='Project subfolder', required=True)
    parser.add_argument('-g', '--gitrepo',
                        help='Path to git repo', required=False)
    parser.add_argument('-l', '--loglevel',
                        help='Logging level', default='INFO', required=False)
    parser.add_argument('-e', '--useenvvar',
                        help='Use variable for branch names', required=False)
    parser.add_argument('command',
                        help='Command to execute',
                        choices=['updatejobs', 'createviews'])

    args = parser.parse_args()

    args.loglevel = getattr(logging, args.loglevel.upper(), logging.INFO)
    logging.basicConfig(level=args.loglevel)
    logger = logging.getLogger()

    # 'http://sabrebuild1.uk.standardchartered.com:8180/'
    # '/shared/jenkins/jobs/CRT-branch-build/workspace'
    main(args.command, args.jenkinsurl, args.jenkinsuser, args.jenkinspassword,
         args.folder, args.gitrepo, args.useenvvar)
