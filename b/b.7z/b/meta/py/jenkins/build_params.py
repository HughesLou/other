"""Get build parameters and output them to stdout

Usage:
    build_params.py params --buildurl URL --user NAME --password PWD
    build_params.py artefact --buildurl URL --user NAME --password PWD --artefact FILE

--buildurl URL          URL of the build to get parameters from
--user NAME             Jenkins user name
--password PWD          Jenkins user password
--artefact FILE         Use artefact file
"""
from jenkinsapi.jenkins import Jenkins
import ast


def build_params(url, user, pwd):
    j = Jenkins(url, user, pwd)
    r = j.requester
    tree_params = {'tree': 'actions[parameters[name,value]]'}
    result = r.get_url(url + '/api/python',
                       tree_params)
    if result.status_code != 200:
        raise Exception('Jenkins returned HTTP code %s' % result.status_code)

    tree = ast.literal_eval(result.content)
    params = [el for el in tree['actions']
              if el.get('parameters') is not None][0]['parameters']
    for param in params:
        if param.get('value') is not None:
            print '%s=%s' % (param['name'], param['value'])


def build_artefacts(url, user, pwd, artefact):
    j = Jenkins(url, user, pwd)
    r = j.requester
    result = r.get_url(url + '/artifact/%s' % artefact)
    if result.status_code != 200:
        raise Exception('Jenkins returned HTTP code %s' % result.status_code)

    print result.text


if __name__ == "__main__":
    from docopt import docopt
    args = docopt(__doc__)

    if args['params']:
        build_params(url=args['--buildurl'],
                     user=args['--user'],
                     pwd=args['--password'])
    else:
        build_artefacts(url=args['--buildurl'],
                        user=args['--user'],
                        pwd=args['--password'],
                        artefact=args['--artefact'])
