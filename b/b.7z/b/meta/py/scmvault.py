"""
Usage:
    scmvault.py --comp COMPONENT --version VER --cr NUMBER --url URL --username NAME --password PASS [--config PATH] [--loglevel LEVEL] [--urlloglevel LEVEL] [--tagonly BOOL]

--comp COMPONENT            Sabre component name
--version VER               Component version
--cr NUMBER                 CR number
--username USER             Username of user, who can submit to SCM SVN
--password PASS             Password for user
--url URL                   Location of component binaries to be vaulted
--config PATH               Path to dod_config.yaml [default: bootstrap/meta/projects/BASE/dod_config.yaml]
--tagonly BOOL              Do tagging only [default: False]
--loglevel LEVEL            Logging level for this script [default: INFO]
--urlloglevel LEVEL         Logging level for HTTP work [default: CRITICAL]
"""
import os
import sys
from docopt import docopt
from os.path import join as jp
import datetime
import time
import logging
import requests
import urlparse
import tempfile
import yaml
from git_utils.svn_command import SvnCommand
from lib.redis.redis_datasource import RedisDatasource
from scm_dod_maker import DodMaker

logger = logging.getLogger()


# config.yaml:
# ---
# svn:
#   checkout_dir: '/sabrebuild/scm/SABRE'
#   url: http://10.128.77.82/svn/sabresrv/branches/sabre_r1.0_pd/SABRE
#   tag_url: http://10.128.77.82/svn/sabresrv/tags/
#   username: 'user'
#   password: 'pass'
# mapping:
#   CRT: 'CRT'
#   SDF-APPS: 'SDF-APPS'
# dod:
#   approver: 'Janefer Yamat'
#   username: '1459847'
#   password: 'password'
#
class SCMVault(object):
    def __init__(self, config, project, version, url,
                 username, password, cr_number, tagonly=False):
        self.project = project
        self.version = version
        self.urls = url.split(',')
        self.temp_dir = tempfile.mkdtemp(prefix='scmvault_')
        self.cr_number = cr_number
        self.svn_tag = self.cr_number
        self.username = username
        self.password = password
        self.tagonly = tagonly.lower() in ['yes', 'true']

        self.config_path = os.path.expanduser(config)
        if os.path.isdir(config):
            self.config_path = jp(config, 'dod_config.yaml')
        if os.path.isfile(self.config_path):
            with open(self.config_path, 'r') as stream:
                cfg = yaml.load(stream)
        else:
            logging.error('%s does not exist' % self.config_path)
            exit(1)

        if not cfg:
            logging.error('Invalid config file')
            exit(1)

        if not cfg.get('svn', False):
            logging.error('"svn" is not present in %s' % self.config_path)
            exit(1)
        self.svn_url = '%s/%s' % (cfg['svn'].get('url'), self.project)
        self.svn_tag_url = '%s/%s/SABRE/%s' % (cfg['svn']['tag_url'],
                                               self.svn_tag,
                                               project)
        self.redis = cfg['redis']

        if not cfg.get('dod', False):
            logging.error('"dod" is not present in %s' % self.config_path)
            exit(1)

        if not cfg.get('mapping', False):
            raise Exception('"mapping" is not present in %s'
                            % self.config_path)
        self.project_mapping = cfg['mapping']
        self.scm_revision = None
        self.svn = SvnCommand()

    def download_files(self):
        def dl_one_file(url):
            location = jp(self.temp_dir,
                          os.path.basename(urlparse.urlparse(url).path))
            r = requests.get(url, stream=True)
            if r.status_code != 200:
                logger.error('HTTP Error %s' % r.status_code)
                exit(1)

            if 'content-length' in r.headers:
                file_length = int(r.headers['content-length'])
            else:
                file_length = 0

            with open(location, 'wb') as f:
                for chunk in r.iter_content(chunk_size=10240):
                    if chunk:  # filter out keep-alive new chunks
                        sys.stdout.write('#')
                        f.write(chunk)
                        f.flush()
            downloaded_length = os.stat(location).st_size
            if file_length != 0 and downloaded_length != file_length:
                logger.error('Downloaded file size mismatch. '
                             'Supposed to be %s, got %s' %
                             (file_length, downloaded_length))
                exit(1)

            logger.info('\n\nDownloaded %s bytes.' % downloaded_length)
            return location

        def check_for_dir(url_to_check):
            '''
            Check if URL points to a HTML directory
            '''
            r = requests.get(url_to_check, stream=True)
            if r.status_code != 200:
                logger.error('HTTP Error %s at %s' % (r.status_code,
                                                      url_to_check))
                exit(1)
            for chunk in r.iter_content(chunk_size=1024):
                if '<h2>Revision' in chunk or 'Sonatype' in chunk:
                    return True
                else:
                    return False

        for url in self.urls:
            logger.info('Downloading from %s' % url)
            location = []
            r = None

            if check_for_dir(url):
                # This looks like a directory, we add trailing slash to url
                # if it is missing and continue getting files
                if not url.endswith('/'):
                    url = url + '/'
                r = requests.get(url)
                if r.status_code != 200:
                    logger.error('HTTP Error %s at %s' % (r.status_code, url))
                    exit(1)

                bin_names = []
                nexus_mode = 'nexus' in url
                svn_mode = 'svn/algo' in url

                html = r.content
                for line in html.split('\n'):
                    line = line.strip()
                    if line:
                        if svn_mode and '<title>' in line \
                                and 'Revision' not in line:
                            logger.error('URL does not point to SVN repo, '
                                         'can not download binaries '
                                         'from this URL')
                            exit(1)
                        if svn_mode and '<li>' in line:
                            # We're making assumption here that the line will
                            # look like this:
                            # <li><a href="download.sh">download.sh</a></li>
                            # so we split it on quote marks and get file name
                            bin_name = line.split('"')[1]
                            if not bin_name.endswith('/'):
                                bin_names.append(bin_name)
                            else:
                                if '..' not in bin_name:
                                    logger.error('Found subfolders'
                                                 'in SVN URL %s. '
                                                 'Please package component '
                                                 'into single file and '
                                                 're-run the job' % url)
                                    exit(1)
                        elif nexus_mode and '<a href' in line:
                            bin_name = line.split('>')[1].split('<')[0]
                            if bin_name.endswith('/'):
                                logger.warning('Found subfolder %s'
                                               'Subfolders will be skipped'
                                               % bin_name)
                            elif 'Parent' in bin_name:
                                continue
                            else:
                                bin_names.append(bin_name)

                for bin_file in bin_names:
                    logger.info('Downloading %s' % bin_file)
                    location.append(dl_one_file(url + bin_file))
            else:
                # URL points to a file
                location = [dl_one_file(url)]

        return location

    def vault_to_svn(self):
        '''
        Puts binary file(s) into SCM svn repo and tags it
        '''
        if not self.tagonly:
            if self.urls:
                binaries = self.download_files()

        today = datetime.datetime.fromtimestamp(time.time())
        today = today.strftime('%Y%m%d-%H%M')
        message = '%s v.%s vaulted at %s' % (self.project, self.version,
                                             today)
        versioned_url_binaries = []
        try:
            if not self.tagonly:
                # First check if target svn path exists
                try:
                    logging.info('Checking if component svn path exists')
                    out, _err = self.svn.run([
                        '--non-interactive',
                        '--username', self.username,
                        '--password', self.password,
                        'ls', self.svn_url
                    ])
                except:
                    # and if it is not - create it
                    logging.info('Created component folder in svn')
                    out, _err = self.svn.run([
                        '--non-interactive',
                        '--username', self.username,
                        '--password', self.password,
                        'mkdir', '--parents',
                        self.svn_url,
                        '--message', 'Created new dir'
                    ])

                save_cwd = os.getcwd()
                os.chdir(self.temp_dir)

                for bin in binaries:
                    bin = os.path.basename(bin)
                    logger.info('Adding %s to svn repo' % bin)
                    versioned_url = self.svn_url + '/' + str(self.version) + \
                        '/' + bin
                    out, _err = self.svn.run([
                        '--non-interactive',
                        '--username', self.username,
                        '--password', self.password,
                        'import', bin,
                        versioned_url,
                        '--message', message
                    ])

                    committed_line = [line.split()[2][:-1]
                                      for line in out.split('\n')
                                      if 'Committed' in line]
                    if committed_line:
                        revision = committed_line[0]
                        logger.info('Committed revision %s' % revision)
                        versioned_url_binaries.append(versioned_url)

                os.chdir(save_cwd)
                logger.info('Comitted all files')

            versioned_url = self.svn_url + '/' + str(self.version) + '/'
            out, _err = self.svn.run(['cp',
                                      '--non-interactive',
                                      '--parents',
                                      '--username', self.username,
                                      '--password', self.password,
                                      '--message', message,
                                      versioned_url,
                                      self.svn_tag_url])
            logger.info('Created tag %s' % self.svn_tag)

            try:
                datasource = RedisDatasource(
                    redis_key=self.redis['redis_scm_key'],
                    default_value=self.redis['scm_data'])
                datasource.update(
                    self.project,
                    {'binaries': '\n'.join(versioned_url_binaries),
                     'CR': self.cr_number,
                     'Version': self.version})

                logger.info('Update scm data(%s) for %s in redis' %
                            (datasource.get(self.project), self.project))
            except Exception as ex:
                logger.warning('Cannot connect to redis: %s' % str(ex))

            if _err:
                logger.error(_err)
                exit(1)
        except Exception as ex:
            logger.error('Can\'t commit: %s' % str(ex))
            exit(1)

    def make_dod(self):
        '''
        Creates DOD request for uploaded binaries
        '''
        logger.info('Submitting DOD')

        dod = DodMaker(self.config_path)
        dod.create_dod(username=self.username,
                       userpass=self.password,
                       project=self.project,
                       cr_number=self.cr_number,
                       svn_tag=self.svn_tag)
        logger.info('Submitted DOD #%s' % dod)
        return dod


if __name__ == '__main__':
    args = docopt(__doc__)

    args.loglevel = getattr(logging, args['--loglevel'].upper(), logging.INFO)
    logging.basicConfig(format='%(levelname)s: %(message)s',
                        level=args.loglevel)
    logger = logging.getLogger()

    urllib3_logger = logging.getLogger('requests.packages.urllib3')
    urllib3_logger.setLevel(args['--urlloglevel'].upper())

    vault = SCMVault(args['--config'], args['--comp'],
                     args['--version'], args['--url'],
                     args['--username'], args['--password'], args['--cr'],
                     args['--tagonly'])

    vault.vault_to_svn()
