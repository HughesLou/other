import argparse
import logging
import sys

import os
from os.path import join as jp
import os.path

logger = logging.getLogger()

bootstrap_path = jp(os.path.normpath(os.path.dirname(
                    os.path.abspath(__file__))),
                    '../..')
code_path = jp(bootstrap_path, 'meta', 'py')
libs_path = jp(bootstrap_path, 'meta', 'py', 'lib')
jjb_path = jp(libs_path, 'jenkins-job-builder')
japi_path = jp(libs_path, 'jenkinsapi')
multiconf_path = libs_path
sys.path = [bootstrap_path, code_path, jjb_path,
            japi_path, multiconf_path] + sys.path
# print sys.path

from utils import import_file


class Builder(object):
    def __init__(self, project_name, env='dev', stop_after_config=False):
        config = import_file(jp('meta/projects', project_name, 'config.py'))
        self.project = config.conf(env)
        logger.debug('Project config: %s' % self.project)
        if stop_after_config:
            print self.project
            os.exit(0)

    def update_jenkins(self, showdelete=False):
        if showdelete:
            to_delete = self.project.jenkins.find_jobs_to_delete([
                self.project.basejenkinsbuilder,
                self.project.projectjenkinsbuilder])
            print 'Jobs to be deleted: {}'.format(to_delete)
        else:
            self.project.jenkins.update_all_jobs([
                self.project.basejenkinsbuilder,
                self.project.projectjenkinsbuilder],
                do_delete=True)
            self.project.jenkins.update_views()

    def undo_rebase(self, do_push=True, build=None):
        if build is None or build == '':
            raise Exception('Build must be set')

        branch_regex = self.project.basejenkinsbuilder.branch_regex
        self.project.git.rebase_all(do_push=True,
                                    build_id=build,
                                    undo_rebase=True,
                                    branch_regex=branch_regex)

    def rebase(self, do_push=False):
        build_id = os.environ.get('BUILD_ID', 'not_jenkins')
        branch_regex = self.project.basejenkinsbuilder.branch_regex
        if not self.project.git.rebase_all(do_push=do_push,
                                           build_id=build_id,
                                           branch_regex=branch_regex):
            sys.exit(1)
        else:
            sys.exit(0)

    def merge(self, branch_name, notes_path, do_push=False,
              undo=False, restore_branch=False):
        branch_regex = self.project.projectjenkinsbuilder.branch_regex
        if not undo:
            if not self.project.git.merge(branch_name=branch_name,
                                          branch_regex=branch_regex,
                                          notes_path=notes_path):
                sys.exit(1)
            else:
                sys.exit(0)
        else:
            if not self.project.git.undo_merge(do_push=do_push,
                                               branch_name=branch_name,
                                               branch_regex=branch_regex):
                sys.exit(1)
            else:
                sys.exit(0)

    def clean_jenkins(self):
        self.project.jenkins.remove_jobs(self.project.basejenkinsbuilder)
        self.project.jenkins.remove_jobs(self.project.projectjenkinsbuilder)
        self.project.jenkins.remove_views()

    def on_push(self, branch, from_hash, to_hash):
        self.project.git.branch_model.onpush(branch, from_hash, to_hash)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Project/Jenkins helper')
    parser.add_argument('-p', '--project',
                        help='Project to work on', required=True)
    parser.add_argument('-e', '--env',
                        help='Project environment to startup. \
                                Default is "devlocal"',
                        default='devlocal', required=False)
    parser.add_argument('-l', '--loglevel',
                        help='Logging level', default='INFO', required=False)
    parser.add_argument('--urlloglevel',
                        help='Logging level for urllib3. \
                                Default is CRITICAL (stay silent)',
                        default='CRITICAL', required=False)
    parser.add_argument('--printconfig',
                        help='Print multiconf configuration and stop',
                        default=False,
                        required=False)

    subparsers = parser.add_subparsers(help='Available commands',
                                       dest='commands')

    jenkins_parser = subparsers. add_parser('jenkins',
                                            help=
                                            'Update Jenkins jobs and views')
    jenkins_parser.add_argument('--clean',
                                default=False,
                                action='store_true',
                                help='Remove Jenkins jobs and views')
    jenkins_parser.add_argument('--showdelete',
                                default=False,
                                action='store_true',
                                help='Show jobs that will be deleted by '
                                     '"jenkins" command')

    rebase_parser = subparsers.add_parser('rebase',
                                          help='Rebase all project \
                                                branches on top of master')
    rebase_parser.add_argument('--push',
                               default=False,
                               action='store_true',
                               help='Do push after rebase')
    rebase_parser.add_argument('--undo',
                               default=False,
                               required=False,
                               action='store_true',
                               help='Undo previous rebase')
    rebase_parser.add_argument('--build',
                               help='BUILD_ID from rebase job')

    merge_parser = subparsers.add_parser('merge',
                                         help='Merge branch to master')
    merge_parser.add_argument('-b', '--branch',
                              required=True,
                              help='Branch to merge')
    merge_parser.add_argument('-n', '--notes',
                              required=True,
                              help='Path to notes to be attached '
                                   'to master commit')
    merge_parser.add_argument('--undo',
                              default=False,
                              required=False,
                              action='store_true',
                              help='Undo previous merge')
    merge_parser.add_argument('--restorebranch',
                              default=False,
                              required=False,
                              action='store_true',
                              help='Restore branch when undoing merge')
    merge_parser.add_argument('--push',
                              default=False,
                              action='store_true',
                              help='Do push after merge')

    onpush_parser = subparsers.add_parser('onpush',
                                          help='On push handler')
    onpush_parser.add_argument('--branch',
                               help='which branch has been changed')
    onpush_parser.add_argument('--from_hash',
                               help='Originating hash')
    onpush_parser.add_argument('--to_hash',
                               help='Resulting hash')
    args = parser.parse_args()

    args.loglevel = getattr(logging, args.loglevel.upper(), logging.INFO)
    logging.basicConfig(format='%(levelname)s:%(message)s',
                        level=args.loglevel)
    logger = logging.getLogger()

    urllib3_logger = logging.getLogger('requests.packages.urllib3')
    urllib3_logger.setLevel(args.urlloglevel)

    builder = Builder(args.project, env=args.env,
                      stop_after_config=args.printconfig)
    if args.commands == 'rebase':
        if args.undo:
            builder.undo_rebase(do_push=args.push, build=args.build)
        else:
            builder.rebase(do_push=args.push)
    elif args.commands == 'merge':
        builder.merge(args.branch, args.notes, do_push=args.push,
                      undo=args.undo, restore_branch=args.restorebranch)
    elif args.commands == 'jenkins':
        if not args.clean:
            builder.update_jenkins(showdelete=args.showdelete)
        else:
            builder.clean_jenkins()
    elif args.commands == 'onpush':
        builder.on_push(branch=args.branch, from_hash=args.from_hash,
                        to_hash=args.to_hash)
