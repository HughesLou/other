import argparse
import logging
import os
import sys
import json
from data_object.base import BootstrapBase
from git_utils.yaml import parse_yaml_file

logger = logging.getLogger()


class Orchestrator(object):
    KEY_PROJECT = 'project'

    def __init__(self, project_name, env_name):
        # This is done so we can override location of the files
        # this used on Jenkins for running branch unit tests
        project_path = os.environ.get('PROJECT_PATH', 'bootstrap')
        self.base_project_path = '{0:s}/meta/projects/BASE/project.yaml' \
            .format(project_path)
        data = parse_yaml_file(self.base_project_path)
        self.base = BootstrapBase(**data['bootstrap-base']['bootstrap'])
        self.project = self.base.load_project_and_environment(project_name,
                                                              env_name)
        # Master clone of the repo is required. We always check if it is cloned
        self.project.repository.checkout()

    def update_jenkins(self, showdelete=False):
        if showdelete:
            to_delete = self.project.jenkins.find_jobs_to_delete([
                self.project.basejenkinsbuilder,
                self.project.projectjenkinsbuilder])
            logger.info('Jobs to be deleted: {}'.format(to_delete))
        else:
            self.project.jenkins.prerequisite()

    def rebase(self, do_push=False):
        branch_regex = self.project.controlled_branches_regex
        build_id = os.environ.get('BUILD_ID', 'not_jenkins')
        rebase_result = self.project.branch_strategy.rebase(build_id,
                                                            branch_regex,
                                                            do_push)
        if rebase_result:
            logger.info("git rebased successfully "
                        "[build_id=%s, branch_regex=%s, do_push=%s]" %
                        (build_id, branch_regex, do_push))
        else:
            sys.exit(1)

    def undo_rebase(self, do_push=False, build=None):
        branch_regex = self.project.controlled_branches_regex
        assert build
        self.project.branch_strategy.undo_rebase(build_id=build,
                                                 branch_regex=branch_regex,
                                                 do_push=do_push)

    # TODO: (AM) - master is not a good default, needs to be changed
    def merge(self, branch_name, notes_path, to_branch_name='master'):
        branch_regex = self.project.controlled_branches_regex
        self.project.branch_strategy.merge(branch_name, branch_regex,
                                           notes_path, to_branch_name)

    # TODO: (AM) - master is not a good default, needs to be changed
    def undo_merge(self, branch_name, from_branch='master'):
        branch_regex = self.project.controlled_branches_regex
        self.project.branch_strategy.undo_merge(branch_name, branch_regex,
                                                from_branch)

    def on_push(self, branch_name, from_hash, to_hash):
        self.project.branch_strategy.on_push(branch_name, from_hash, to_hash)

    def clean_jenkins(self):
        self.project.jenkins.clear()

    def checkout(self):
        self.project.branch_strategy.checkout()

    def make_cr(self, location, var_mask):
        cr_dyn = self.project.remedy_cr.dynamic_fields
        for idx in range(0, 100):
            env_var = os.environ.get('%s%s' % (var_mask, idx), None)
            if not env_var:
                break
            dyn_value = cr_dyn[idx]
            dyn_value[dyn_value.keys()[0]] = env_var

        out_json = {}
        for kv_p in self.project.remedy_cr.static_fields:
            out_json.update(kv_p)
        for kv_p in self.project.remedy_cr.dynamic_fields:
            out_json.update(kv_p)

        with open(location, 'w+') as outfile:
            json.dump(out_json, outfile)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Project/Jenkins helper')
    parser.add_argument('-p', '--project',
                        help='Project to work on', required=True)
    parser.add_argument('-e', '--env',
                        help='Project environment to startup. \
                                Default is "devlocal"',
                        default='devlocal', required=False)
    parser.add_argument('-l', '--loglevel',
                        help='Logging level', default='INFO', required=False)
    parser.add_argument('--urlloglevel',
                        help='Logging level for urllib3. \
                                Default is CRITICAL (stay silent)',
                        default='CRITICAL', required=False)

    subparsers = parser.add_subparsers(help='Available commands',
                                       dest='commands')

    jenkins_parser = subparsers.add_parser('jenkins',
                                           help=
                                           'Update Jenkins jobs and views')
    jenkins_parser.add_argument('--clean',
                                default=False,
                                action='store_true',
                                help='Remove Jenkins jobs and views')
    jenkins_parser.add_argument('--showdelete',
                                default=False,
                                action='store_true',
                                help='Show jobs that will be deleted by '
                                     '"jenkins" command')

    rebase_parser = subparsers.add_parser('rebase',
                                          help='Rebase all project \
                                                branches on top of master')
    rebase_parser.add_argument('--push',
                               default=False,
                               action='store_true',
                               help='Do push after rebase')
    rebase_parser.add_argument('--undo',
                               default=False,
                               required=False,
                               action='store_true',
                               help='Undo previous rebase')
    rebase_parser.add_argument('--build',
                               help='BUILD_ID from rebase job')

    merge_parser = subparsers.add_parser('merge',
                                         help='Merge branch to master')
    merge_parser.add_argument('-b', '--branch',
                              required=True,
                              help='Branch to merge')
    merge_parser.add_argument('-n', '--notes',
                              required=True,
                              help='Path to notes to be attached '
                                   'to master commit')
    merge_parser.add_argument('--undo',
                              default=False,
                              required=False,
                              action='store_true',
                              help='Undo previous merge')
    merge_parser.add_argument('--restorebranch',
                              default=False,
                              required=False,
                              action='store_true',
                              help='Restore branch when undoing merge')
    merge_parser.add_argument('--push',
                              default=False,
                              action='store_true',
                              help='Do push after merge')

    onpush_parser = subparsers.add_parser('onpush',
                                          help='On push handler')
    onpush_parser.add_argument('-b', '--branch',
                               help='which branch has been changed')
    onpush_parser.add_argument('--from_hash',
                               help='Originating hash')
    onpush_parser.add_argument('--to_hash',
                               help='Resulting hash')

    jenkins_parser = subparsers.add_parser('makecr',
                                           help=
                                           'Create CR submission template')
    jenkins_parser.add_argument('--location',
                                help='Location for CR JSON file',
                                default='./CR.json')
    jenkins_parser.add_argument('--varmask',
                                required=True,
                                help='Variable name mask to get values from'
                                     'Default: CR_FIELD for variables like '
                                     'CR_FIELD0, CR_FIELD1, etc.')

    args = parser.parse_args()

    args.loglevel = getattr(logging, args.loglevel.upper(), logging.INFO)
    fmt = '%(asctime)s %(levelname)s: %(message)s'
    if args.loglevel == logging.DEBUG:
        fmt = '%(asctime)s %(name)s@%(lineno)d %(levelname)s: %(message)s'

    logging.basicConfig(format=fmt, level=args.loglevel)
    logger = logging.getLogger()

    urllib3_logger = logging.getLogger('requests.packages.urllib3')
    urllib3_logger.setLevel(args.urlloglevel)

    japi_logger = logging.getLogger('jenkinsapi')
    japi_logger.setLevel(logging.CRITICAL)

    builder = Orchestrator(args.project, env_name=args.env)
    if args.commands == 'rebase':
        if args.undo:
            builder.undo_rebase(do_push=args.push, build=args.build)
        else:
            builder.rebase(do_push=args.push)
    elif args.commands == 'merge':
        builder.merge(args.branch, args.notes)
    elif args.commands == 'jenkins':
        if not args.clean:
            builder.update_jenkins(showdelete=args.showdelete)
        else:
            builder.clean_jenkins()
    elif args.commands == 'onpush':
        builder.on_push(args.branch, args.from_hash, args.to_hash)
    elif args.commands == 'makecr':
        builder.make_cr(args.location, args.varmask)
