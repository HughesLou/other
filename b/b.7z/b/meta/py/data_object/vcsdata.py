import logging

from data_object.dynamicbase import DynamicBase

logger = logging.getLogger(__name__)


class VcsData(DynamicBase):

    def rebase(self, build_id, branch_regex, do_push=False, undo_rebase=False):
        pass

    def merge(self, branch_name, notes_path, to_branch='master'):
        pass

    def merge_close(self, branch_name, notes_path):
        pass

    def undo_merge_close(self, branch_name):
        pass

    def undo_merge(self, branch_name, from_branch='master'):
        pass

    def branches(self, branch_regex):
        pass

    def branch_names(self, branch_regex):
        pass

    def checkout(self):
        pass

    def checkout_branch(self, branch_name):
        pass

    def vcs_type(self):
        return None
