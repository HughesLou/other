from data_object.dynamicbase import DynamicBase


class Slaves(DynamicBase):
    def __init__(self, **kwargs):
        super(Slaves, self).__init__(**kwargs)