from data_object.jenkins_view import JenkinsView
from data_object.dynamicbase import resolve, require


@require(['name'])
@resolve(['name'])
class JenkinsNestedView(JenkinsView):

    def __init__(self, **kwargs):
        self.views = []
        super(JenkinsNestedView, self).__init__(**kwargs)
        self.view_type = 'hudson.plugins.nested_view.NestedView'

    def remove(self):
        super(JenkinsNestedView, self).remove()
