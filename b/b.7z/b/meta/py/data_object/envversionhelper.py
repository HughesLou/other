import os
from os.path import join as jp
from xml.etree import ElementTree as et
from data_object.dynamicbase import DynamicBase, resolve, require


@require(['variable'])
class EnvVersionHelper(DynamicBase):
    '''
    Class used to hold extract version from Maven pom.xml
    '''
    def __init__(self, **kwargs):
        super(EnvVersionHelper, self).__init__(**kwargs)

    @property
    def value(self):
        return os.environ.get(self.variable, 'variable %s not found in environment' % self.variable)

