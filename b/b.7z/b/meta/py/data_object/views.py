from data_object.dynamicbase import DynamicBase
from data_object.jenkins_view import JenkinsView


class Views(DynamicBase):
    def __init__(self, **kwargs):
        self.views = []
        super(Views, self).__init__(**kwargs)

        # FIXME: We declared for now that only one top view is supported,
        # but we need to support other configurations. This hack is to get
        # top view accessible by views attribute.
        if not self.views:
            for attr in self._dyn_attrs:
                attr_value = getattr(self, attr)
                if isinstance(attr_value, JenkinsView):
                    self.views.append(attr_value)

    def __getitem__(self, view_index):
        assert isinstance(view_index, int) and 0 <= view_index < len(self.views)
        return self.views[view_index]
