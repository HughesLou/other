from data_object.dynamicbase import DynamicBase
from data_object.gitdata import GitData


class Env(DynamicBase):
    '''
    All environments configured for a project
    '''
    def __init__(self, **kwargs):
        super(Env, self).__init__(**kwargs)

    def _load_bootstrapgitdata(self, value):
        return GitData(**value)