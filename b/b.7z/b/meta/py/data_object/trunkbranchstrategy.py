from collections import OrderedDict
from functools import partial
from data_object.branchstrategy import BranchStrategy
import logging


logger = logging.getLogger(__name__)


class TrunkBranchStrategy(BranchStrategy):

    def __init__(self, project):
        self.project = project

    def on_push(self, branch_name, from_hash, to_hash):
        """
        This what happens on push
        1. master changed
          a. run master build
          b. if master build is ok - run rebase (controlled by jenkinsflow)
        2. branch changed
          a. trigger job for that branch
        3. branch created/deleted
          a. run jenkins update
        """
        if branch_name is None:
            return

        branch_name = self.clean_branch_name(branch_name)
        jobs_invoke = self.project.jenkins.invoke
        logger.info("on pushing branch: %s" % branch_name)
        pipeline_job = '%s_%s_%s' % (self.project.name,
                                     self.project.pipeline_build_name,
                                     branch_name)

        # project.wait-on-push determines if onpush job will wait for builds
        # to complete before letting another commit to be built
        wait_for_jobs = self.project.wait_for_jobs
        # We curry function parameter, so we don't have to repeat it everywhere
        jobs_invoke = partial(jobs_invoke, wait_for_jobs=wait_for_jobs)

        if branch_name == 'master' or branch_name == 'trunk':
            logger.info('Change in master has been detected. '
                        'Building master and if successful will do rebase')
            # Instead of running all of this here, we will trigger jobs
            # This is done for visibility only
            jobs = OrderedDict()
            jobs[pipeline_job] = None
            jobs_invoke(jobs)
        else:
            branch_regex = self.project.all_branches_regex
            if branch_name in self.project.repository.git_data.branch_names(
                    branch_regex):
                if from_hash == '0000000000000000000000000000000000000000':
                    # New branch has been created
                    jobs = OrderedDict()
                    jobs['%s_create-jobs' % self.project.name] = None
                    jobs_invoke(jobs)

                jobs = OrderedDict()
                jobs[pipeline_job] = None
                jobs_invoke(jobs)
            else:
                # Branch has been deleted
                if to_hash == '0000000000000000000000000000000000000000':
                    jobs_invoke({'%s_create-jobs' % self.project.name: None})
                else:
                    logger.warn('Branch %s is not being monitored' %
                                branch_name)

    def rebase(self, build_id, branch_regex, do_push=False, undo_rebase=False):
        pass

    def merge(self, branch_name, branch_regex, notes_path):
        pass

    def undo_merge(self, branch_name, branch_regex):
        pass

    def undo_rebase(self, build_id, branch_regex, do_push=False):
        pass
