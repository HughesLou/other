from data_object.dynamicbase import DynamicBase


class JobGroups(DynamicBase):
    '''
    Job grouping
    '''
    def __init__(self, **kwargs):
        self.filters = kwargs
        super(JobGroups, self).__init__(**kwargs)

