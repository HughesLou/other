import logging
from data_object.dynamicbase import DynamicBase, require, resolve
from git_utils.custom_url import url_concat
from jenkinsapi.view import View


logger = logging.getLogger()


@resolve(['name'])
@require(['name'])
class JenkinsView(DynamicBase):

    def __init__(self, **kwargs):
        super(JenkinsView, self).__init__(**kwargs)
        self.jenkins_view = None
        self.path = getattr(self, 'parent_path', '') + '/view/' + self.name

    def resolve_vars(self):
        super(JenkinsView, self).resolve_vars()
        self.path = getattr(self, 'parent_path', '') + '/view/' + self.name

    # DynamicBase for updating attributes.
    # But the update method in JenkinsView express the different function
    # with the same name. This is improper.
    def update_view(self, parent_path=None):
        self._build_myself(parent_path)

        for view in self.views:
            view.update_view(self.path)

    def remove(self):
        def delete_subview(jenkins, view, parent_view):
            # print 'In delete_view. view=%s, parent_view=%s' %\
            #   (view, parent_view)
            assert isinstance(view, View)
            logger.debug('Start delete_subview, view=%s' % view.name)
            sub_views = view.views
            logger.debug('delete_subview.sub_views=%s' % sub_views.keys())
            # print 'sub_views=', sub_views.keys()
            for sub_view_name, sub_view in sub_views.iteritems():
                # print 'Calling recursive for sub_view=', sub_view_name
                delete_subview(jenkins, sub_view, view)

            logger.info('Looking for jobs in %s' % view.name)
            jobs = view.get_job_dict().keys()
            for job in jobs:
                logger.debug('Removing job %s from view %s' % (job,
                                                               view.name))
                jenkins.delete_job(job)

            logger.debug('Before removing view. Parent view: %s, '
                         'subviews: %s' % (parent_view.name,
                                           parent_view.views.keys()))
            del parent_view.views[view.name]

        logger.info('Removing view %s' % self.name)
        jenkins = self.top_project.jenkins
        j_path = '%s%s%s' % (jenkins.url, self.parent_path, self.path)
        logger.debug('j_path=%s' % j_path)
        top_view = jenkins.api().get_view_by_url(j_path)
        top_sub_views = top_view.views
        logger.debug('top_sub_views = %s' % top_sub_views.keys())

        # print top_sub_views.keys()
        # print top_sub_views[self.name]
        # print top_sub_views[self.name].baseurl
        # print top_view.get_jenkins_obj_from_url(top_sub_views[self.name].baseurl).\
        #   views().keys()
        for sub_view_name, sub_view in top_sub_views.iteritems():
            logger.debug('Before removal of subview %s' % sub_view_name)
            delete_subview(self.top_project.jenkins.api(),
                           sub_view,
                           top_view)
        logger.debug('All subviews removed')

    def _build_myself(self, parent_path=None):
        logger.info('Creating jobs/views in view "%s"' % self.name)
        if parent_path:
            self.parent_path = parent_path

        #self.resolve_vars()

        j_conf = self.top_project.find_child('project.jenkins')
        j_path = url_concat(j_conf.url, self.parent_path)
        logger.debug('before api init, j_path=%s' % j_path)
        j = j_conf.api(j_path)
        existing_views = j.views
        if self.name in existing_views:
            # View already exists
            logger.debug('View %s already exists' % self.name)
            self.jenkins_view = existing_views[self.name]
        else:
            try:
                self.jenkins_view = existing_views.create(self.name, self.view_type)
            except Exception as ex:
                # View exists
                self.jenkins_view = existing_views[self.name]

        return self.jenkins_view


class JenkinsViewGroup(JenkinsView):

    def __init__(self, **kwargs):
        self.views = []
        super(JenkinsViewGroup, self).__init__(**kwargs)

    def __getitem__(self, view_index):
        assert isinstance(view_index, int) and 0 <= view_index < len(self.views)
        return self.views[view_index]
