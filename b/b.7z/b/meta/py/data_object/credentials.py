from data_object.dynamicbase import DynamicBase, resolve, require


@require(['description'])
class Credentials(DynamicBase):
    '''
    Class used to hold Credential configuration
    '''
    def __init__(self, **kwargs):
        super(Credentials, self).__init__(**kwargs)
