import calendar
from datetime import datetime
from data_object.dynamicbase import DynamicBase, resolve, require


class EpochVersionHelper(DynamicBase):
    '''
    Class used to hold extract version from Maven pom.xml
    '''
    def __init__(self, **kwargs):
        super(EpochVersionHelper, self).__init__(**kwargs)

    @property
    def value(self):
        return '%s' % calendar.timegm(datetime.utcnow().utctimetuple())
