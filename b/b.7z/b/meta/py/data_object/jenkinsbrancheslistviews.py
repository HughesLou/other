import logging
import yaml
from data_object.dynamicbase import _DynamicList
from data_object.jenkins_jobs_builder import JenkinsJobs
from jenkins_view import JenkinsView

logger = logging.getLogger()


class JenkinsBranchesListViews(JenkinsView):
    '''
    Used to define and create set of Jenkins list views for each branch
    '''
    def __init__(self, **kwargs):
        super(JenkinsBranchesListViews, self).__init__(**kwargs)
        for attr in self._dyn_attrs:
            attr_value = getattr(self, attr)
            if isinstance(attr_value, JenkinsJobs):
                self.builder = attr_value
        self.views = []
        self._views_dict = {}

    def _load_builder(self, definition):
        if isinstance(definition, basestring) or isinstance(definition, JenkinsJobs):
            return definition
        else:
            raise ValueError('View %s: jobs_builder should be a string or '
                             'instance of JenkinsJobs, got %s' %
                             ('JenkinsBrancesListViews', type(definition)))

    def _build_myself(self, parent_path=None):
        project = self.top_project
        parent_jenkins_view = self.parent.jenkins_view
        if parent_jenkins_view is None:
            raise Exception('View %s was not created' % self.name)
        # Only do this if there are jobs attached to a view
        branches = project.repository.branches(project.all_branches_regex)

        # FIXME: this only work for job in current branch
        #all_job_names = self.builder.job_names()
        for branch in branches:
#                branch_jobs = [job_name for job_name in all_job_names
#                               if branch in job_name]
            branch_view = parent_jenkins_view.views.create(branch)
            self.views.append(branch_view)
            self._views_dict[branch] = branch_view
#                for branch_job in branch_jobs:
#                    branch_view.add_job(branch_job)

        to_delete = set(parent_jenkins_view.views.keys()) - set(branches)
        logger.info('Views to be removed: %s' % to_delete)
        for obsolete_view in to_delete:
            del parent_jenkins_view.views[obsolete_view]

    def update_view(self, parent_path=None):
        self._build_myself(parent_path)

        project = self.top_project
        empty_views = []
        for branch, view_def in self._views_dict.iteritems():
            remove_obsolete_jobs = True
            try:
                logger.info('Generating jobs for branch %s' % branch)
                branch_jobs = self.project_jobs_builder.generate_jobs(branch)
            except IndexError as ie:
                logger.error("jobs.yaml in branch %s is invalid. "
                             "Skipping jobs creation" % branch)
                # We don't want to remove existing jobs when we fail
                # to parse yaml
                remove_obsolete_jobs = False
            except yaml.scanner.ScannerError as se:
                logger.error("jobs.yaml in branch %s is invalid: "
                             "%s"
                             " Skipping jobs creation" % (branch, str(se)))
                # We don't want to remove existing jobs when we fail
                # to parse yaml
                remove_obsolete_jobs = False

            jobs_to_remove = set(view_def.keys()) - set(branch_jobs)
            if branch_jobs:
                for job in branch_jobs:
                    view_def.add_job(job)
            elif remove_obsolete_jobs:
                # The branch doesn't have jobs defined
                # and remove_obsolete_jobs flag indicates that this
                # condition happened not because we can't parse yaml
                # so we need to remove that view
                empty_views.append(view_def)
                # and need to remove jobs that view has
                for job in jobs_to_remove:
                    self.top_project.jenkins.api().delete_job(job)

        if empty_views:
            for view in list(empty_views):
                    logger.info('Removing empty view "%s"' % view.name)
                    del self.parent.jenkins_view.views[view.name]
