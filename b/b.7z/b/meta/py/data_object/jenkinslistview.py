import logging
from data_object.jenkins_view import JenkinsView
from data_object.jenkins_jobs_builder import JenkinsJobs

log = logging.getLogger()


class JenkinsListView(JenkinsView):
    '''
    Used to define and create Jenkins list view
    '''
    def __init__(self, **kwargs):
        super(JenkinsListView, self).__init__(**kwargs)
        # self.jobs = self._load_jobs(jobs) if jobs else None
        # self.builder = self._load_builder(builder) if builder else None
        self.view_type = 'hudson.model.ListView'
        self.views = []

        for attr in self._dyn_attrs:
            attr_val = getattr(self, attr)
            if isinstance(attr_val, JenkinsJobs):
                self.builder = attr_val

    def _load_builder(self, definition):
        if isinstance(definition, basestring) or isinstance(definition,
                                                            JenkinsJobs):
            self.builder = definition
            return definition
        else:
            raise ValueError('View %s: jobs_builder should be a string or '
                             'instance of JenkinsJobs, got %s' %
                             (self.name, type(definition)))

    def _load_views(self, definition):
        raise ValueError('JenkinsListView must not contain any other views.')

    def _build_myself(self, parent_path=None):
        myself = super(JenkinsListView, self)._build_myself(parent_path)
        log.debug('JenkinsListView myself=%s' % myself)

        return myself

    def update_view(self, parent_path=None):
        myself = self._build_myself(parent_path)

        # TODO: AM/20130107 this may cause a problem when used to
        # generate list view for different purpose than original
        # needs to be attended when this problem arises
        # for now I am setting it always use 'master' branch
        jobs = self.builder.generate_jobs('master')
        self.top_project.repository.git_data.set_branch('master')
        if jobs:
            for job in jobs:
                if job not in myself.keys():
                    myself.add_job(job)
