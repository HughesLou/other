from data_object.branchstrategy import BranchStrategy
import logging


logger = logging.getLogger(__name__)


class GitBranchStrategy(BranchStrategy):
    def rebase(self, build_id, branch_regex, do_push=False, undo_rebase=False):
        return super(GitBranchStrategy, self).rebase(build_id, branch_regex,
                                                     do_push, undo_rebase)

    def on_push(self, branch_name, from_hash, to_hash):
        super(GitBranchStrategy, self).on_push(branch_name, from_hash, to_hash)

    def undo_merge(self, branch_name, branch_regex, from_branch='master'):
        return super(GitBranchStrategy, self).undo_merge(branch_name,
                                                         branch_regex,
                                                         from_branch)

    def undo_rebase(self, build_id, branch_regex, do_push=False):
        super(GitBranchStrategy, self).undo_rebase(build_id, branch_regex,
                                                   do_push)

    def merge(self, branch_name, branch_regex, notes_path, to_branch='master'):
        return super(GitBranchStrategy, self).merge(branch_name, branch_regex,
                                                    notes_path, to_branch)
