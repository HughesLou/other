import os
from os.path import join as jp
from xml.etree import ElementTree as et
from data_object.dynamicbase import DynamicBase, resolve, require


@require(['pom_location', 'element'])
class MavenVersionHelper(DynamicBase):
    '''
    Class used to hold extract version from Maven pom.xml
    '''
    def __init__(self, **kwargs):
        super(MavenVersionHelper, self).__init__(**kwargs)

    @property
    def value(self):
        pr = self.top_project
        location = jp(pr.repository.expanded_master_repo,
                      self.pom_location)
        if os.path.exists(location):
            ns = 'http://maven.apache.org/POM/4.0.0'
            tree = et.ElementTree()
            tree.parse(location)
            version = tree.getroot().find('{%s}%s' % (ns, self.element)).text
            return version

