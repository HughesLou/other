import logging
from utils import data_class


logger = logging.getLogger()


class DynamicBase(object):
    '''
    Class that creates instance attributes based on parameters passed to
    constructor

    Call validate() to check if all required parameters are passed
    '''
    CLASS_PACKAGE = 'data_object'

    def __init__(self, **kwargs):
        self._dyn_none_attrs = set()
        self._dyn_attrs = set()
        self._dyn_child_objects = set()
        self.set_parent(None)

        for arg, value in kwargs.iteritems():
            self._add_attribute(arg, value)

    def set_parent(self, parent_obj):
        self._dyn_parent = parent_obj

    @property
    def parent(self):
        return self._dyn_parent

    def children_module_name(self, class_name):
        return '{}.{}'.format(DynamicBase.CLASS_PACKAGE, class_name.lower())

    def find_child(self, child_path):
        crumbs = child_path.split('.')
        if len(crumbs) > 1:
            if crumbs[1] in self.__dict__:
                field = self.__dict__[crumbs[1]]
            else:
                raise ValueError("Object {} does not contain field '{}'."
                                 .format(self.__class__, crumbs[1]))

            if len(crumbs) > 2:
                field = field.find_child('.'.join(crumbs[1:]))

            return field
        else:
            raise ValueError('You should find child with subject.')

    @property
    def top_project(self):
        if self.__class__.__name__ == 'Project':
            return self
        else:
            if self.parent is None:
                return self.project
            else:
                return self.parent.top_project

    def __getitem__(self, item):
        if item in self.__dict__:
            return self.__dict__[item]

    @property
    def get_attrs_with_values(self):
        return self._dyn_attrs - self._dyn_none_attrs

    def update(self, obj):
        '''
        Updates instance with attributes of another instance

        We are going to update only attributes that we don't have
        or we have them and they set to empty string
        This allows us to add more details to on later stages
        For this we find which attrs are set to None in self
        Then we get non None attrs from incoming
        Then we calc the difference and set/create attrs in self
        '''
        self._validate_before_update(obj)

        for new_attr in obj.get_attrs_with_values:
            if not hasattr(self, new_attr):
                self._update_dyn_attr(new_attr, getattr(obj, new_attr))
            elif getattr(self, new_attr) == '':
                self._update_dyn_attr(new_attr, getattr(obj, new_attr))
            elif isinstance(self.__dict__[new_attr], DynamicBase):
                self.__dict__[new_attr].update(getattr(obj, new_attr))
            elif isinstance(self.__dict__[new_attr], _DynamicList):
                self.__dict__[new_attr].update(getattr(obj, new_attr))

    def forced_update(self, obj):
        self._validate_before_update(obj)

        for new_attr in obj.get_attrs_with_values:
            if hasattr(self, new_attr) and isinstance(self.__dict__[new_attr],
                                                      DynamicBase):
                self.__dict__[new_attr].forced_update(getattr(obj, new_attr))
            else:
                self._update_dyn_attr(new_attr, getattr(obj, new_attr))

    def has_dyn_attr(self, attr_name):
        return attr_name in self._dyn_attrs

    def _add_attribute(self, key, value):
        '''
        Creates attribute named as key and with value of value

        If type of value is str, None or 'none' - uses that value
        If type of value is dict - tries to instantiate
            data_object.key.key class and passes value to it's constructor
        If child object has _load_<object_name> method - it will be called

        :param key: Name of the attribute to be created
        :param value: Value for attribute
        '''
        norm_key = key.replace('-', '_')
        instance = None
        if value is None:
            self._dyn_none_attrs.add(norm_key)
        else:
            self_loader = getattr(self, self._get_loader_name(key), None)
            if self_loader:
                instance = self_loader(value)
                if isinstance(instance, DynamicBase):
                    instance.set_parent(self)
            else:
                if isinstance(value, basestring):
                    if value.strip().lower() == 'none':
                        self._dyn_none_attrs.add(norm_key)
                    else:
                        instance = value
                elif self._is_numeric(value):
                    instance = value
                else:
                    logger.debug('instance=%s, field=%s, value=%s'
                                 % (self.__class__, key, value))
                    instance = self._build_instance(key, value)
                    instance.set_parent(self)
                    self._dyn_child_objects.add(norm_key)

        self.__dict__[norm_key] = instance
        self._dyn_attrs.add(norm_key)

    def _validate_before_update(self, obj):
        assert isinstance(obj, DynamicBase)
        # import pudb; pu.db
        assert self.__class__ == obj.__class__

    def _update_dyn_attr(self, attr_name, attr_value):
        self.__dict__[attr_name] = attr_value
        if isinstance(attr_value, DynamicBase):
            attr_value.set_parent(self)
            self._dyn_child_objects.add(attr_name)
        elif isinstance(attr_value, _DynamicList):
            attr_value.update_parent_ref_of_each_item(self)
            self._dyn_child_objects.add(attr_name)
        self._dyn_attrs.add(attr_name)

    def _build_instance(self, class_name, value):
        if isinstance(value, dict):
            return self._build_instance_with_arg_dict(class_name, value)
        elif isinstance(value, list):
            return self._build_instance_as_list(value)
        elif isinstance(value, DynamicBase):
            return value
        else:
            return self._build_instance_with_simple_value(class_name, value)

    def _build_instance_with_arg_dict(self, class_name, value):
        norm_class_name = self._get_class_name(class_name)
        module_name = self.children_module_name(norm_class_name)
        cls = data_class(module_name, norm_class_name)
        return cls(**value)

    def _build_instance_with_simple_value(self, class_name, value):
        norm_class_name = self._get_class_name(class_name)
        module_name = self.children_module_name(norm_class_name)
        cls = data_class(module_name, norm_class_name)
        return cls(value)

    def _build_instance_as_list(self, values):
        result = _DynamicList()
        result.set_parent(self)
        for entry in values:
            for class_name, _value in entry.items():
                instance = self._build_instance(class_name, _value)
                instance.set_parent(self)
                result.append(instance)
        return result

    def _is_numeric(self, value):
        return isinstance(value, int) or isinstance(value, long) \
            or isinstance(value, float)

    def _get_class_name(self, raw_class_name):
        return ''.join([c.capitalize() for c in raw_class_name.split('-')])

    def _get_loader_name(self, raw_class_name):
        class_name = ''.join([c.capitalize()
                     for c in raw_class_name.split('-')])
        return '_load_{}'.format(class_name.lower())

    def validate(self):
        try:
            if self._required is None:
                return
        except AttributeError:
            return

        for attr in self._required:
            if getattr(self, attr, None) is None:
                raise Exception('{}: Mandatory attribute "{}" is not defined'
                                .format(self.__class__.__name__, attr))

        for child in self._dyn_child_objects:
            dyn_obj = getattr(self, child)
            dyn_obj.validate()

    def _dyn_resolve_vars(self, key):
        def resolve(what, key):
            if isinstance(what, str):
                unresolved = what.replace('project.', '')
                try:
                    resolved = unresolved.format(**self.top_project.__dict__)
                except KeyError as ke:
                    raise KeyError('Variable "%s" in %s->%s: %s cannot be '
                                   'resolved. Please '
                                   'check project.yaml and jobs.yaml.' %
                                   (ke.message, self.__class__.__name__, key,
                                    unresolved))
                return resolved
            elif isinstance(what, list):
                for item in what:
                    item = resolve(item, key)
                return what
            elif isinstance(what, dict):
                for k, v in what.iteritems():
                    what[k] = resolve(v, key)
                return what
            else:
                return what

        if hasattr(self, '_dyn_resolve') and key in self._dyn_resolve:
            unresolved = self.__dict__[key]
            self.__dict__[key] = resolve(unresolved, key)

    def resolve_vars(self):
        for attr in self._dyn_attrs:
            self._dyn_resolve_vars(attr)
        for child in self._dyn_child_objects:
            dyn_obj = getattr(self, child)
            dyn_obj.resolve_vars()


class _DynamicList(list):

    def __init__(self):
        self.set_parent(None)

    def set_parent(self, parent_obj):
        self._dyn_parent = parent_obj

    @property
    def top_project(self):
        if self.__class__.__name__ == 'Project':
            return self
        else:
            return self._dyn_parent.top_project

    @property
    def parent(self):
        return self._dyn_parent

    def update(self, other_list):
        assert isinstance(other_list, list)

        for index, other_item in enumerate(other_list):
            if index < len(self):
                item = self[index]
                if not hasattr(item, 'update'):
                    continue
                # Lists may have items of different types
                # when we encounter this - we will replace current member
                # with incoming
                if item.__class__ == other_item.__class__:
                    item.update(other_item)
                else:
                    item = other_item
            else:
                self._add(other_item)

    def update_parent_ref_of_each_item(self, parent):
        for item in self:
            if not hasattr(item, 'set_parent'):
                continue
            item.set_parent(parent)

    def _add(self, item):
        self.append(item)
        if hasattr(item, 'set_parent'):
            item.set_parent(self.parent)

        # so we could get list_config_item['text']
        # TODO: AM add here ability to return object by object.name

    def resolve_vars(self):
        for item in self:
            if isinstance(item, DynamicBase):
                item.resolve_vars()

    def validate(self):
        for item in self:
            if isinstance(item, DynamicBase):
                item.validate()


def require(attr_list):
    def decorate(obj):
        setattr(obj, '_required', attr_list)
        setattr(obj, '_dyn_resolve', attr_list)
        return obj

    return decorate


def resolve(attr_list):
    def decorate(obj):
        setattr(obj, '_dyn_resolve', attr_list)
        return obj

    return decorate
