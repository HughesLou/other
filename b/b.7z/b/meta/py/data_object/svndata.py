import os

from data_object.vcsdata import VcsData


class SvnData(VcsData):

    def __init__(self, **kwargs):
        super(SvnData, self).__init__(**kwargs)
        self.master_repo = self._expanded(self.master_repo)

    def _expanded(self, repo):
        return os.path.expanduser(repo) if repo is not None else None

    def branches(self, branch_regex):
        # TODO(AM): return real svn revision here
        return {'trunk': 'svn_revision'}

    def branch_names(self, branch_regex):
        return ['trunk']

    def vcc_type(self):
        return 'svn'

    def checkout_branch(self, branch_name):
        pass
