from data_object.dynamicbase import DynamicBase


class Environments(DynamicBase):
    '''
    All environments configured for a project
    '''
    def __init__(self, **kwargs):
        super(Environments, self).__init__(**kwargs)

    def __getitem__(self, environment_name):
        for env in self.envs:
            if environment_name == env.name:
                return env
        return None

    def __iter__(self):
        return iter(self.envs)

    def keys(self):
        return [env.name for env in self.envs]

    def __contains__(self, env_name):
        return env_name in self.keys()
