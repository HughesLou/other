import importlib


def key2property(key):
    return key.replace('-', '_')


def keys2property(_dict, level=999):
    level -= 1
    if level < 0:
        return _dict
    else:
        new_dict = dict()
        for key, value in _dict.iteritems():
            new_key = key2property(key)
            new_dict[new_key] = keys2property(value, level) if isinstance(value, dict) else value
        return new_dict


def key2object(key, sub_module_name, definition):
    assert isinstance(definition, dict)
    classname = key2classname(key)
    cls = _data_class('data_object.{}'.format(sub_module_name), classname)
    return cls.load(definition)


def key2classname(key):
    return ''.join([c.capitalize() for c in key.split('-')])


def _data_class(module_name, class_name):
    '''
    Loads data_object class

    :param module_name: module where class can be found, usually *data_object.
        class_name*
    :param class_name: class which needs to be loaded
    :returns: class definition
    :rtype: class
    :raises: ImportError if module cannot be found
    :raises: AttributeError if class cannot be found
    '''
    m = importlib.import_module(module_name)
    c = getattr(m, class_name)
    return c

