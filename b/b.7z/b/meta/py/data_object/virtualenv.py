from multiconf import ConfigItem
from multiconf.decorators import named_as


@named_as('virtualenv')
# @nested_repeatables('domains, database_services, os_user_group, os_users,
# loadbalancer, hudson_jobs, config_parameters, db_users')
class VirtualEnv(ConfigItem):
    """Multiconf root object. Holds overall project properties
    """
    def __init__(self, home, python_path):
        super(VirtualEnv, self).__init__(home=home,
                                         python_path=python_path,
                                         name='virtualenv')
