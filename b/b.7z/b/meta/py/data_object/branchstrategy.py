from abc import ABCMeta, abstractmethod


class BranchStrategy(object):

    __metaclass__ = ABCMeta

    def __init__(self, project):
        self.project = project

    def clean_branch_name(self, branch_name):
        branch = branch_name.split('/')
        if len(branch) == 1:
            branch_name = branch[0]
        elif len(branch) == 3:
            branch_name = branch[2]
        else:
            raise Exception('Unknown branch name "%s"' % branch_name)
        return branch_name

    @abstractmethod
    def merge(self, branch_name, branch_regex, notes_path, to_branch='master'):
        if getattr(self.project.repository, 'git_data', None) is None:
            raise Exception('Merge only supported for Git based projects')

    @abstractmethod
    def undo_merge(self, branch_name, branch_regex, from_branch='master'):
        if getattr(self.project.repository, 'git_data', None) is None:
            raise Exception('Merge only supported for Git based projects')

    @abstractmethod
    def rebase(self, build_id, branch_regex, do_push=False, undo_rebase=False):
        if getattr(self.project.repository, 'git_data', None) is None:
            raise Exception('Rebase only supported for Git based projects')

    @abstractmethod
    def undo_rebase(self, build_id, branch_regex, do_push=False):
        self.rebase(build_id, branch_regex, do_push, undo_rebase=True)

    @abstractmethod
    def on_push(self, branch_name, from_hash, to_hash):
        pass
