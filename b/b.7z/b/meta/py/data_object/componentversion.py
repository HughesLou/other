from data_object.dynamicbase import DynamicBase, resolve, require


class ComponentVersion(DynamicBase):
    '''
    Class used to hold ComponentVersion value
    '''
    def __init__(self, **kwargs):
        super(ComponentVersion, self).__init__(**kwargs)

    def get_full_version(self, **kwargs):
        if self.full_version:
            ver = self.full_version.format(**self.top_project.__dict__)
        else:
            ver = ''
        return ver

    def get_release_version(self, **kwargs):
        if self.full_version:
            ver = self.release_version.format(**self.top_project.__dict__)
        else:
            ver = ''
        return ver

    @property
    def full_version_string(self):
        return self.get_full_version()
