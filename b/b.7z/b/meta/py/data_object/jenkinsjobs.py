from os.path import join as jp

from multiconf import ConfigItem
from multiconf.decorators import named_as, required

from jenkins_jobs.builder import YamlParser

import pprint
pp = pprint.PrettyPrinter(indent=2)


# @nested_repeatables('domains, database_services, os_user_group, os_users,
# loadbalancer, hudson_jobs, config_parameters, db_users')
@required('jobs_path')
class JenkinsJobs(ConfigItem):
    def __init__(self, jobs_path, branch_regex):
        super(JenkinsJobs, self).__init__(jobs_path=jobs_path,
                                          branch_regex=branch_regex)
        self._parser = None
        self._job_names = []

    def get_parser(self):
        pass

    def set_project_parameters(self, parser_project):
        assert(isinstance(parser_project, dict))
        project = self.find_contained_in('project')

        parser_project['config'] = project
        parser_project['node'] = project.jenkins.node
        parser_project['bootstrapgit'] = project.bootstrapgit.url
        parser_project['bootstraplogfile'] = project.bootstrap_log_file
        parser_project['bootstrapgit-branch'] = project.bootstrapgit.branch
        parser_project['master-repo'] = project.git.master_repo
        parser_project['git-url'] = project.git.url
        parser_project['jenkins-url'] = project.jenkins.url
        parser_project['jenkins-user'] = project.jenkins.user_name
        parser_project['jenkins-password'] = project.jenkins.user_password
        parser_project['master-workspace'] = project.jenkins.master_workspace
        parser_project['virtualenv'] = project.virtualenv.home
        parser_project['pythonpath'] = project.virtualenv.python_path
        parser_project['jobs'] = ['jobs']
        parser_project['name'] = project.name
        parser_project['env'] = project.env.name

        return parser_project

    def job_names(self):
        if self._parser is None:
            self.parser = self.get_parser()
        if self._parser:
            # print 'parser.data=', pp.pprint(parser.data)
            if not self._job_names:
                self._parser.generateXML()
                self._job_names = [job.name for job in self._parser.jobs]
            return self._job_names
        else:
            return []


@named_as('basejenkinsbuilder')
class BaseJenkinsJobs(JenkinsJobs):
    """Multiconf root object. Holds overall project properties
    """
    def __init__(self, jobs_path='bootstrap/meta', branch_regex=''):
        super(BaseJenkinsJobs, self).__init__(jobs_path=jobs_path,
                                              branch_regex=branch_regex)
        self._parser = None

    def get_parser(self):
        if not self._parser:
            project = self.find_contained_in('project')

            jobs_def = {}
            jobs_def['project'] = {}
            prj = jobs_def['project'][project.name] = {}
            prj = self.set_project_parameters(prj)
            parser = YamlParser()
            parser.data = jobs_def
            parser.parse(jp(self.jobs_path, 'basejobs.yaml'))
            self._parser = parser

        return self._parser


@named_as('projectjenkinsbuilder')
class ProjectJenkinsJobs(BaseJenkinsJobs):
    def __init__(self, jobs_path, use_shallow_clone=False,
                 pipeline_build_name='build', branch_regex=''):
        super(ProjectJenkinsJobs, self).__init__(jobs_path=jobs_path,
                                                 branch_regex=branch_regex)
        self.use_shallow_clone = use_shallow_clone
        self.pipeline_build_name = pipeline_build_name

    def get_parser(self):
        if not self._parser:
            project = self.find_contained_in('project')

            parser = YamlParser()
            parser.parse(jp(self.jobs_path, 'defaults.yaml'))

            if project.git:
                branches = project.git.branches(self.branch_regex)

                parser.parse(jp(self.jobs_path, 'project.yaml'))
                # Inject other parameters
                parser_project = parser.data['project'][project.name]
                parser_project = self.set_project_parameters(parser_project)
                parser_project['branch'] = branches
                # If shallow clone is set, there is no reason to point
                # all jobs to one location
                if self.use_shallow_clone and project.jenkins.version == 'new':
                    pass
                else:
                    parser_project['workspace'] = project.jenkins.workspace \
                        if project.jenkins.workspace is not None else ''
                parser_project['shallow-clone'] = \
                    str(self.use_shallow_clone).lower()
            else:
                parser.parse(jp(self.jobs_path, 'project.yaml'))

            # print 'parser.data=', pp.pprint(parser.data)
            # raise Exception('STOP')
            parser.parse(jp(self.jobs_path, 'jobs.yaml'))
            self._parser = parser

        return self._parser
