from data_object.dynamicbase import DynamicBase
from data_object.vcsdata import VcsData


class Repository(DynamicBase):
    '''
    Holds list of project VCS repositories
    '''
    def __init__(self, **kwargs):
        self.skip_getattr = True
        super(Repository, self).__init__(**kwargs)
        self.skip_getattr = False

    def __getattr__(self, item):
        if not self.skip_getattr:
            # AM: we making assumtion that Repository will have only one child
            real_repo = getattr(self, list(self._dyn_attrs)[0], None)
            if real_repo is None:
                raise AttributeError('Repository requires to have '
                                     'Git or Svn repo')
            if not isinstance(real_repo, VcsData):
                raise AttributeError('Repository is not VcsData')
            method = getattr(real_repo, item, None)
            if method is not None:
                return method
            else:
                raise AttributeError('Repository does not have method %s'
                                     % item)
