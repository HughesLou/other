from collections import OrderedDict
from functools import partial
from data_object.gitbranchstrategy import GitBranchStrategy
import logging


logger = logging.getLogger(__name__)


class FeatureBranchStrategy(GitBranchStrategy):

    def on_push(self, branch_name, from_hash, to_hash):
        """
        This what happens on push
        1. master changed
          a. run master build
          b. if master build is ok - run rebase (controlled by jenkinsflow)
        2. branch changed
          a. trigger job for that branch
        3. branch created/deleted
          a. run jenkins update
        """
        super(FeatureBranchStrategy, self).on_push(branch_name, from_hash,
                                                   to_hash)
        if branch_name is None:
            return
        elif 'refs/tags' in branch_name:
            logger.info('New tag have been pushed. Nothing to do.')
            return

        branch_name = self.clean_branch_name(branch_name)
        jobs_invoke_wait = self.project.jenkins.invoke

        logger.info("on pushing branch: %s" % branch_name)
        pipeline_job = '%s_%s' % (self.project.pipeline_build_name,
                                  branch_name)

        # project.wait-on-push determines if onpush job will wait for builds
        # to complete before letting another commit to be built
        try:
            wait_for_jobs = self.project.wait_for_jobs
        except Exception:
            wait_for_jobs = True
        # We curry function parameter, so we don't have to repeat it everywhere
        jobs_invoke = partial(jobs_invoke_wait, wait_for_jobs=wait_for_jobs)
        # irregardless of branch, if only '$jobs-path/jobs.yaml' has
        # changed - we don't need to rebuild all, just regenerate jobs
        # If branch is being deleted, we skip that check
        # if branch is created, we skip that check too because
        # jobs will be generated anyway
        if to_hash != '0000000000000000000000000000000000000000' \
                and from_hash != '0000000000000000000000000000000000000000':
            changed_file = self.project.repository.list_changed(branch_name,
                                                                from_hash,
                                                                to_hash)
            jobs_yaml = self.project.jobs_path + '/jobs.yaml'
            if jobs_yaml in changed_file:
                jobs = OrderedDict()
                jobs['%s_create-jobs' % self.project.name] = None
                jobs_invoke_wait(jobs)
                if not self.project.build_on_jobs_change:
                    if len(changed_file) == 1:
                        # Only jobs.yaml have been changed -
                        # no need to do anything else
                        return

        if branch_name == 'master':
            logger.info('Change in master has been detected. '
                        'Building master and if successful will do rebase')
            # Instead of running all of this here, we will trigger jobs
            # This is done for visibility only
            jobs = OrderedDict()
            jobs['%s_%s' % (self.project.name, pipeline_job)] = None
            jobs['%s_rebase' % self.project.name] = None
            jobs_invoke_wait(jobs)
        else:
            branch_regex = self.project.all_branches_regex
            if branch_name in self.project.repository.git_data.branch_names(
                    branch_regex):
                jobs = OrderedDict()
                if from_hash == '0000000000000000000000000000000000000000':
                    # New branch has been created
                    jobs['%s_create-jobs' % self.project.name] = {}
                    jobs_invoke_wait(jobs)

                jobs = {}
                jobs['%s_%s' % (self.project.name, pipeline_job)] = {}
                jobs_invoke_wait(jobs)
            else:
                # Branch has been deleted
                if to_hash == '0000000000000000000000000000000000000000':
                    jobs_invoke(OrderedDict({'%s_create-jobs' %
                                             self.project.name: {}}))
                else:
                    logger.warn('Branch %s is not being monitored' %
                                branch_name)

    def rebase(self, build_id, branch_regex, do_push=False, undo_rebase=False):
        """
        Does or un-does rebase of all feature branches on top on master

        :param build_id: Value used to remember rebase operation for
            future undo
        :type build_id: str
        :param branch_regex: Branch filtering regular expression
        :type branch_regex: str
        :param do_push: If True then push all changes to origin
        :type do_push: bool
        :param undo_rebase: If True then will use 'build_id' to undo previous
        :type undo_rebase: bool

        :return True if there were no errors
        :rtype bool
        """
        super(FeatureBranchStrategy, self).rebase(build_id, branch_regex,
                                                  do_push, undo_rebase)
        return self.project.repository.rebase(build_id, branch_regex,
                                              do_push, undo_rebase)

    def merge(self, branch_name, branch_regex, notes_path, to_branch):
        """
        Merges branch_name into master, attached notes to merge commit and
        removes branch_name

        :param branch_name: branch to merge to master
        :type branch_name: str
        :param branch_regex: branch regular expression. Used to check if that
            branch is one of the monitored branches.
        :type branch_name: str
        :param notes_path: Path to text file containing merge evidence.
            This file will be attached as commit notes
        :type notes_path: str

        :return None
        :raises Exception if master_repo is not set, merge fails,
            notes file is not found
        """
        super(FeatureBranchStrategy, self).merge(branch_name, branch_regex,
                                                 notes_path, to_branch)

        if branch_name in self.branch_names(branch_regex):
            return self.project.repository.merge_close(branch_name,
                                                       notes_path,
                                                       to_branch)

    def undo_merge(self, branch_name, branch_regex, from_branch):
        """
        Undoes previous merge: removes merge commit, re-creates deleted branch

        :param branch_name: branch to merge to master
        :type branch_name: str
        :param branch_regex: branch regular expression. Used to check if that
            branch is one of the monitored branches.
        :type branch_regex: str

        :return False if undo cannot be done
        :rtype bool

        :raises Exception if master_repo is not set
        """
        super(FeatureBranchStrategy, self).merge(branch_name, branch_regex,
                                                 from_branch)

        if branch_name in self.branch_names(branch_regex):
            return self.project.repository.undo_merge_close(branch_name)

    def undo_rebase(self, build_id, branch_regex, do_push):
        super(FeatureBranchStrategy, self).undo_rebase(build_id,
                                                       branch_regex,
                                                       do_push)
