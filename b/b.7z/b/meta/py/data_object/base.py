import os
from os.path import join as jp
from data_object.dynamicbase import DynamicBase, require
from data_object.environments import Environments
from data_object.gitdata import GitData
from data_object.project import Project
from git_utils.yaml import parse_yaml_file


@require(['project_config_path'])
class BootstrapBase(DynamicBase):
    '''
    Class that holds all environments and configuration for bootstrap itself

    Bootstrap configuration defines global defaults used by all projects:

    :bootstrap_git_data: Bootstrap git repository
    :jenkins: Jenkins instance
    :environments: Build environments
    '''

    def __init__(self, **kwargs):
        super(BootstrapBase, self).__init__(**kwargs)
        self._update_envs_with_global_settings()
#        self._remove_global_settings()

    def load_project_and_environment(self, project_name, env_name,
                                     project_data=None):
        if project_data is None:
            project_data = parse_yaml_file(self._config_path(project_name))

        project_name_from_data = project_data['project'].keys()[0]
        if project_name_from_data != project_name:
            raise Exception('Asked to load project "%s", but found '
                            'project "%s" '
                            'in project.yaml' % (project_name,
                                                 project_name_from_data))
        self.project = Project(**project_data['project'][project_name])
        self.project.env_name = env_name

        if not env_name in self.environments:
            raise Exception('Environment "%s" not found. Available are: %s'
                            % (env_name, self.environments.keys()))
        env = self.environments[env_name]
        self._update_project_template_with_env(env)

        self.project.update(self.project_template)
        setattr(self.project, 'bootstrap_git_data', env.bootstrap_git_data)
        setattr(self.project, 'bootstrap_log_file', self.bootstrap_log_file)
        self.project.validate()
        self.project.resolve_vars()

        return self.project

    def _update_project_template_with_env(self, env):
        self.project_template.jenkins.forced_update(env.jenkins)
        env_repository = getattr(env, 'repository', None)
        if env_repository is not None:
            self.project_template.repository.forced_update(env.repository)

    def _load_bootstrapgitdata(self, value):
        return GitData(**value)

    def _load_environments(self, value):
        return Environments(envs=value)

    def _load_projecttemplate(self, value):
        return Project(**value)

    def _config_path(self, project_name):
        self.project_config_path = os.environ.get('PROJECT_PATH',
                                                  self.project_config_path)
        if project_name == 'helloworld' \
           and 'meta/projects' not in self.project_config_path:
            self.project_config_path = jp(self.project_config_path,
                                          'meta/projects')
        return jp(self.project_config_path, project_name, 'project.yaml')

    def _update_envs_with_global_settings(self):
        global_jenkins = self.project_template.jenkins
        global_bootstrap_git_data = self.bootstrap_git_data \
            if 'bootstrap_git_data' in self.__dict__ else None
        for env in self.environments:
            if global_jenkins is not None:
                env.jenkins.update(global_jenkins)
            if global_bootstrap_git_data is not None:
                env.bootstrap_git_data.update(global_bootstrap_git_data)

    def _remove_global_settings(self):
        self._remove_attrs('jenkins', 'bootstrap_git_data',
                           'bootstrap_log_file')

    def _remove_attrs(self, *attr_names):
        for attr_name in attr_names:
            del self.__dict__[attr_name]
