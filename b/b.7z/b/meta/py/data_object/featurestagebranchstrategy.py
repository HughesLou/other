from collections import OrderedDict
from data_object.gitbranchstrategy import GitBranchStrategy
from os.path import join as jp
import logging
import os


logger = logging.getLogger(__name__)


class FeatureStageBranchStrategy(GitBranchStrategy):

    def __init__(self, project):
        self.project = project

    def on_push(self, branch_name, from_hash, to_hash):
        """
        This what happens on push
        1. Check if 'develop' changed
          a. Nothing - will be controlled by develop's build function
        2. Check if master changed
          a. Rebase all controlled branches
        2. branch changed
          a. trigger job for that branch
        """
        super(FeatureStageBranchStrategy, self).on_push(branch_name,
                                                        from_hash,
                                                        to_hash)
        if branch_name is None:
            return

        logger.info("on pushing branch: %s" % branch_name)

        branch_name = self.clean_branch_name(branch_name)
        jobs_invoke = self.project.jenkins.invoke

        pipeline_job = '%s_%s' % (self.project.pipeline_build_name,
                                  branch_name)

        if branch_name == 'master':
            logger.info('Change in master has been detected. '
                        'Building master and if successful will do rebase')
            # Instead of running all of this here, we will trigger jobs
            # This is done for visibility only
            jobs_invoke(['rebase'])
        elif branch_name == 'develop':
            # develop branch is managed by build_develop function
            # the reason we're not handling it here is that
            # we only want to build that branch on time and this is handled
            # by jenkins job
            pass
        else:
            branch_regex = self.project.all_branches_regex
            if branch_name in self.branch_names(branch_regex):
                if from_hash == '0000000000000000000000000000000000000000':
                    # New branch has been created
                    jobs_invoke(['create-jobs', pipeline_job])
                else:
                    jobs_invoke([pipeline_job])
            else:
                # Branch has been deleted
                if to_hash == '0000000000000000000000000000000000000000':
                    jobs_invoke(['create-jobs'])

    def rebase(self, build_id, branch_regex, do_push=False, undo_rebase=False):
        """
        Does or un-does rebase of all feature branches on top on master

        :param build_id: Value used to remember rebase operation for
            future undo
        :type build_id: str
        :param branch_regex: Branch filtering regular expression
        :type branch_regex: str
        :param do_push: If True then push all changes to origin
        :type do_push: bool
        :param undo_rebase: If True then will use 'build_id' to undo previous
        :type undo_rebase: bool

        :return True if there were no errors
        :rtype bool
        """
        super(FeatureStageBranchStrategy, self).rebase(build_id, branch_regex,
                                                  do_push, undo_rebase)
        return self.project.repository.rebase(build_id, branch_regex,
                                                       do_push, undo_rebase)

    def merge(self, branch_name, branch_regex, notes_path,
              to_branch='master'):
        """
        Merges branch_name into master, attached notes to merge commit and
        removes branch_name

        :param branch_name: branch to merge to master
        :type branch_name: str
        :param branch_regex: branch regular expression. Used to check if that
            branch is one of the monitored branches.
        :type branch_name: str
        :param notes_path: Path to text file containing merge evidence.
            This file will be attached as commit notes
        :type notes_path: str

        :return None
        :raises Exception if master_repo is not set, merge fails,
            notes file is not found
        """
        super(FeatureStageBranchStrategy, self).merge(branch_name,
                                                      branch_regex,
                                                      notes_path, to_branch)

        # TODO: (AM) - integration branch name must be a setting?
        if branch_name == 'develop' and to_branch == 'master':
            return self._handle_master_build(notes_path)

        if branch_name not in self.branch_names(branch_regex):
            raise Exception('Branch "%s" is not being monitored' % branch_name)

        pipeline_job = '%s_%s' % (self.project.pipeline_build_name,
                                  branch_name)
        build_status_ok = self.project.jenkins.last_build_status(pipeline_job)
        if build_status_ok:
            raise Exception('Last execution of "%s" job was not successfull. '
                            'Cannot merge branch "%s"' % (pipeline_job,
                                                          branch_name))

        built_sha = self.project.jenkins.last_build_revision(pipeline_job)
        branch_head = self.branches(branch_regex)[branch_name]
        if built_sha != branch_head:
            raise Exception('Last execution of "%s" job was '
                            'using revision "%s", but branch "%s"'
                            ' head is "%s". Cannot promote unbuilt branches' %
                            (pipeline_job, built_sha, branch_name,
                             branch_head))

        return self.project.repository.merge(branch_name, notes_path,
                                             to_branch)

    def undo_merge(self, branch_name, branch_regex, from_branch='master'):
        """
        Undoes previous merge: removes merge commit, re-creates deleted branch

        :param branch_name: branch to merge to master
        :type branch_name: str
        :param branch_regex: branch regular expression. Used to check if that
            branch is one of the monitored branches.
        :type branch_regex: str

        :return False if undo cannot be done
        :rtype bool

        :raises Exception if master_repo is not set
        """
        super(FeatureStageBranchStrategy, self).merge(branch_name,
                                                      branch_regex,
                                                      from_branch)

        if branch_name in self.branch_names(branch_regex):
            return self.project.repository.undo_merge(branch_name, from_branch)

    # TODO: (AM) decide how to handle develop build
    # Possible:
    #   do build after N pushes to develop
    #   do timed build - if last build on develop was X hours ago
    #       and there was at least one push, then build it
    def _build_develop(self, from_sha, to_sha):
        pass

    def _handle_master_build(self, notes_path):
        # TODO: create transient branch from master
        # TODO: merge 'develop' to transient branch
        # TODO: create jobs in Jenkins for that branch
        # TODO: execute branch pipeline
        # TODO: if pipeline successful - merge transient branch to master
        # TODO: delete trans. branch?
        pass

    def pull_request(self, from_branch, to_branch):
        pass
