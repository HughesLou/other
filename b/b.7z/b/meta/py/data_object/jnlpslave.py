from data_object.dynamicbase import DynamicBase, resolve, require


@require(['name'])
@resolve(['description', 'labels'])
class JnlpSlave(DynamicBase):
    '''
    Class used to hold UnixSlave configuration
    '''
    def __init__(self, **kwargs):
        super(JnlpSlave, self).__init__(**kwargs)
        self.credentials = None
