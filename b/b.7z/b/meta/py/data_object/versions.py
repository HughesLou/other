from multiconf import ConfigItem
from multiconf.decorators import named_as, nested_repeatables, repeat

import datetime
import logging

log = logging.getLogger(__name__)


@named_as('version')
@nested_repeatables('components')
class Version(ConfigItem):
    def __init__(self):
        super(Version, self).__init__()

    def get_version(self, **kwargs):
        oversion = []
        for component in self.components.values():
            oversion.append(component.get_version(**kwargs))

        return ''.join(oversion)


@named_as('components')
@repeat()
class StringVersionComponent(ConfigItem):
    def __init__(self, value):
        super(StringVersionComponent, self).__init__(value=value)

    def get_version(self, **kwargs):
        return self.value


class DateVersionComponent(StringVersionComponent):
    def __init__(self, date_format):
        super(DateVersionComponent, self).__init__(value=date_format)

    def get_version(self, **kwargs):
        return datetime.date.today().strftime(self.value)


@named_as('components')
@repeat()
class BranchNameVersionComponent(ConfigItem):
    def __init__(self):
        super(BranchNameVersionComponent, self).__init__()

    def get_version(self, branch):
        return branch


@named_as('components')
@repeat()
class GitHeadVersionComponent(ConfigItem):
    def __init__(self, hash_length=7):
        super(GitHeadVersionComponent, self).__init__(hash_length=hash_length)

    def get_version(self, branch='master'):
        project = self.find_contained_in('project')
        # TODO: AM add check for Git here
        # if not project['git']:
        #     raise Exception('Git is not defined for this project')
        return project.git.head_sha(branch)[:self.hash_length]
