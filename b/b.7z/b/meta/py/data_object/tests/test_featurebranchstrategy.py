from collections import OrderedDict
from unittest import TestCase
from data_object.base import BootstrapBase
from data_object.vcsdata import VcsData


class FeatureBranchStrategyTest(TestCase):

    def setUp(self):
        self._base_def = {
            'name': 'bootstrap',
            'project-config-path': 'bootstrap/meta/projects',
            'bootstrap-log-file': '/sabrebuild/bootstrap_logs/index.html',
            'bootstrap-git-data': {
                'url': 'ssh://git@stash/cd/bootstrap.git',
                'branch': 'move_to_yaml'
            },
            'project-template': {
                'all-branches-regex': '.*',
                'controlled-branches-regex': '^[A-Z]*-\d{1,5}$',
                'jenkins': {
                    'url': 'http://sabrebuild1.uk.standardchartered.com:8080/',
                    'virtualenv-home': '/home/sabredev/virtualenv/jenkins_bootstrap',
                    'virtualenv-python-home': 'bootstrap/meta/py/lib/jenkins-job-builder'
                },
                'repository': {
                    'git-data': {
                        'url': None
                    }
                }
            },
            'environments': [
                {
                    'env': {
                        'name': 'devlocal',
                        'jenkins': {
                            'url': 'http://sabrebuild1.uk.standardchartered.com:8180/',
                            'user-name': 'maleksey',
                            'user-token': '3d261f625cd6b0e5ed443aa36bf49ea7'
                        },
                        'bootstrap-git-data': {
                            'branch': 'develop'
                        }
                    }
                },
                {
                    'env': {
                        'name': 'dev',
                        'jenkins': {
                            'user-name': 'jenkins',
                            'user-token': '452c271c582c3dc8925ae320459c64da'
                        },
                        'bootstrap-git-data': {
                            'branch': 'delivery'
                        }
                    }
                }
            ]
        }
        self._project_def = {
            'project': {
                'helloworld': {
                    'name': 'helloworld',
                    'branch-strategy': 'feature-branches',
                    'pipeline-build-name': '1-build',
                    'jobs-path': 'src/jobs',
                    'wait-for-jobs': False,
                    'jenkins': {
                        'slaves': [{
                                       'unix-slave': {
                                           'name': 'uklpadsab05a.uk',
                                           'description': '{project.name} slave 1',
                                           'executors': 3,
                                           'remote-root': '/shared/opt/SCB/sabre/Jenkins',
                                           'labels': '{project.name}'
                                       }}
                        ]
                    },
                    'repository': {
                        'git-data': {
                            'url': 'ssh://git@stash/cd/helloworld.git',
                            'master_repo': '~/src/helloworld'
                        }
                    }
                }
            }}
        self.base = BootstrapBase(**self._base_def)
        self.project = self.base.load_project_and_environment('helloworld',
                                                              'devlocal',
                                                              self
                                                              ._project_def)

    def test_on_push_build_branch(self):
        class mock_git_data(VcsData):
            def branch_names(self, regex):
                return ['ABC-123']

            def list_changed(self, branch, from_hash, to_hash):
                return ['file1', 'file2']

        class mock_jenkins(object):
            def __init__(self):
                self.invoke_result = []

            def invoke(self, params, wait_for_jobs=True):
                self.invoke_result = params

        self.project.repository.git_data = mock_git_data()
        jenkins_mock = mock_jenkins()
        self.project.jenkins = jenkins_mock
        strategy = self.project.branch_strategy
        strategy.on_push('ABC-123', '11111', '22222')
        self.assertEquals(jenkins_mock.invoke_result.keys(),
                          ['helloworld_1-build_ABC-123'])

    def test_on_push_build_master(self):
        class mock_git_data(VcsData):
            def branch_names(self, regex):
                return ['ABC-123']

            def list_changed(self, branch, from_hash, to_hash):
                return ['file1', 'file2']

        class mock_jenkins(object):
            def __init__(self):
                self.invoke_result = []

            def invoke(self, params, wait_for_jobs=True):
                self.invoke_result = params

        self.project.repository.git_data = mock_git_data()
        jenkins_mock = mock_jenkins()
        self.project.jenkins = jenkins_mock
        strategy = self.project.branch_strategy
        strategy.on_push('master', '11111', '22222')
        result = OrderedDict()
        result['helloworld_1-build_master'] = None
        result['helloworld_rebase'] = None
        self.assertEquals(jenkins_mock.invoke_result,
                          result)

    def test_on_push_new_branch(self):
        class mock_git_data(VcsData):
            def branch_names(self, regex):
                return ['ABC-123']

            def list_changed(self, branch, from_hash, to_hash):
                return ['file1', 'file2']

        class mock_jenkins(object):
            def __init__(self):
                self.invoke_result = OrderedDict()

            def invoke(self, params, wait_for_jobs=True):
                self.invoke_result.update(params)

        self.project.repository.git_data = mock_git_data()
        jenkins_mock = mock_jenkins()
        self.project.jenkins = jenkins_mock
        strategy = self.project.branch_strategy
        strategy.on_push('ABC-123', '0000000000000000000000000000000000000000',
                         '22222')
        result = OrderedDict()
        result['helloworld_create-jobs'] = {}
        result['helloworld_1-build_ABC-123'] = {}
        self.assertItemsEqual(jenkins_mock.invoke_result, result)

    def test_on_push_delete_branch(self):
        class mock_git_data(VcsData):
            def branch_names(self, regex):
                return []

            def list_changed(self, branch, from_hash, to_hash):
                return ['file1', 'file2']

        class mock_jenkins(object):
            def __init__(self):
                self.invoke_result = []

            def invoke(self, params, wait_for_jobs=True):
                self.invoke_result = params

        self.project.repository.git_data = mock_git_data()
        jenkins_mock = mock_jenkins()
        self.project.jenkins = jenkins_mock
        strategy = self.project.branch_strategy
        strategy.on_push('ABC-123',
                         '12345',
                         '0000000000000000000000000000000000000000')
        self.assertEquals(jenkins_mock.invoke_result.keys(),
                          ['helloworld_create-jobs'])

    def test_on_push_only_jobs_yaml(self):
        class mock_git_data(VcsData):
            def branch_names(self, regex):
                return ['ABC-123']

            def list_changed(self, branch, from_hash, to_hash):
                return ['src/jobs/jobs.yaml']

        class mock_jenkins(object):
            def __init__(self):
                self.invoke_result = []

            def invoke(self, params, wait_for_jobs=True):
                self.invoke_result = params

        self.project.repository.git_data = mock_git_data()
        jenkins_mock = mock_jenkins()
        self.project.jenkins = jenkins_mock
        strategy = self.project.branch_strategy
        strategy.on_push('ABC-123', '11111', '22222')
        self.assertEquals(jenkins_mock.invoke_result.keys(),
                          ['helloworld_create-jobs'])

    def test_on_push_including_jobs_yaml(self):
        class mock_git_data(VcsData):
            def branch_names(self, regex):
                return ['ABC-123']

            def list_changed(self, branch, from_hash, to_hash):
                return ['src/jobs/jobs.yaml', 'file1']

        class mock_jenkins(object):
            def __init__(self):
                self.invoke_result = OrderedDict()

            def invoke(self, params, wait_for_jobs=True):
                self.invoke_result.update(params)

        self.project.repository.git_data = mock_git_data()
        jenkins_mock = mock_jenkins()
        self.project.jenkins = jenkins_mock
        strategy = self.project.branch_strategy
        strategy.on_push('ABC-123', '11111', '22222')
        result = OrderedDict()
        result['helloworld_create-jobs'] = {}
        result['helloworld_1-build_ABC-123'] = {}
        print 'DEBUG: jenkins_mock.invoke_result=', jenkins_mock.invoke_result
        self.assertItemsEqual(jenkins_mock.invoke_result, result)
