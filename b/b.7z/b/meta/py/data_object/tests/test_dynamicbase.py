from unittest import TestCase
from data_object.dynamicbase import DynamicBase, require


class DynamicBaseTest(TestCase):
    def test_to_create_object_with_null_field(self):
        obj = Guy(key=None)

        self.assertIsNone(obj.key)

    def test_to_create_object_without_required_field(self):
        with self.assertRaises(Exception):
            obj = GuyThatMustBeNamed()
            obj.validate()

    def test_to_build_object_with_string_field(self):
        bob = Guy(name='Bob', gender='None')

        self.assertEquals('Bob', bob.name)
        self.assertIsNone(bob.gender)

    def test_to_build_object_with_primitive_field(self):
        bob = Guy(name='Bob', age=18, stature=1.76)

        self.assertEquals('Bob', bob.name)
        self.assertEquals(18, bob.age)
        self.assertEquals(1.76, bob.stature)

    def test_to_build_object_with_itself_loading_function(self):
        jim = GuyWithSelfKnowledge(name=object(), brother={'name': 'Bob'})

        self.assertEquals('Jim', jim.name)
        self.assertEquals('Bob', jim.brother.name)

    def test_to_build_object_with_sub_object_that_is_built_by_single_value(
            self):
        mother = Mother(son=PersonName('Bob', "Robinson"))

        self.assertEquals('Bob Robinson', mother.son.name.value)

    def test_to_build_object_with_sub_object_that_is_built_by_dict(self):
        mother = Mother(
            daughter={'first-name': 'Katie', 'family-name': 'Robinson'})

        self.assertEquals('Katie Robinson', mother.daughter.name)

    def test_to_build_object_with_sub_object_lists_that_is_built_by_dict(self):
        mother = Mother(daughters=[
            {'daughter': {'first-name': 'Katie', 'family-name': 'Robinson'}},
            {'daughter': {'first-name': 'Julie', 'family-name': 'Robinson'}}])

        self.assertEquals(2, len(mother.daughters))
        self.assertEquals('Katie Robinson', mother.daughters[0].name)
        self.assertEquals('Julie Robinson', mother.daughters[1].name)

    def test_to_build_object_with_complicated_sub_objects(self):
        mother = Mother(
            daughter={'first-name': 'Katie', 'family-name': 'Robinson',
                      'brothers': [{'son': PersonName('Bob', "Robinson")},
                                   {'son': PersonName('Carl', "Robinson")}]})

        self.assertEquals('Katie Robinson', mother.daughter.name)
        self.assertEquals('Bob Robinson',
                          mother.daughter.brothers[0].name.value)
        self.assertEquals('Carl Robinson',
                          mother.daughter.brothers[1].name.value)

    def test_to_find_child_by_path(self):
        mother = Mother(
            daughter={'first-name': 'Katie', 'family-name': 'Robinson',
                      'son': PersonName('Bob', "Robinson")})

        self.assertEquals('Bob Robinson',
                          mother.find_child('mother.daughter.son').name.value)

    def test_to_find_field_by_path(self):
        bob = Guy(name='Bob')

        self.assertEquals('Bob', bob.find_child('bob.name'))

    def test_to_throw_exception_when_can_not_find_field(self):
        bob = Guy(name='Bob')

        self.assertRaises(ValueError, bob.find_child, 'bob.gender')

    def test_to_throw_exception_when_there_is_not_subject_to_find_child(self):
        bob = Guy(name='Bob')

        self.assertRaises(ValueError, bob.find_child, 'name')

    def test_to_assert_when_update_object_with_non_dynamic_one(self):
        bob = Guy(name='Bob')

        self.assertRaises(AssertionError, bob.update, object())

    def test_to_assert_when_update_object_with_different_type_one(self):
        bob = Guy(name='Bob')

        self.assertRaises(AssertionError, bob.update, GuyWithSelfKnowledge())

    def test_to_update_object_only_with_new_attributes(self):
        bob = Guy(name='Bob')
        bob_other_info = Guy(name='Alice', nickname='Little Lazy Cat')

        bob.update(bob_other_info)

        self.assertEquals('Bob', bob.name)
        self.assertEquals('Little Lazy Cat', bob.nickname)

    def test_to_update_object_when_its_attribute_is_sub_object(self):
        mother = Mother(daughter={'first-name': 'Katie'})
        other_info = Mother(daughter={'family-name': 'Robinson'})

        mother.update(other_info)

        self.assertEquals('Katie', mother.daughter.first_name)
        self.assertEquals('Robinson', mother.daughter.family_name)

    def test_to_update_list_attributes_in_object(self):
        mother = Mother(daughters=[{'daughter': {'first-name': 'Katie'}}])
        other_info = Mother(
            daughters=[{'daughter': {'family-name': 'Robinson'}}, {
            'daughter': {'first-name': 'Su', 'family-name': 'Robinson'}}])

        mother.update(other_info)

        self.assertEquals(2, len(mother.daughters))
        self.assertEquals('Katie Robinson', mother.daughters[0].name)
        self.assertEquals('Su Robinson', mother.daughters[1].name)
        self.assertIs(mother, mother.daughters[1].mother)

    def test_to_reset_parent_after_update_object(self):
        mother = Mother(daughter={'family-name': 'Robison'})
        other_info = Mother(daughter={'first-name': 'Katie', 'sisters': [
            {'daughter': {'first-name': 'Ann'}},
            {'daughter': {'first-name': 'Su'}}]})

        mother.update(other_info)

        self.assertIs(mother, mother.daughter.mother)
        self.assertIs(mother, mother.daughter.sisters[0].mother)
        self.assertIs(mother, mother.daughter.sisters[1].mother)

    def test_to_assert_when_forced_update_object_with_non_dynamic_one(self):
        bob = Guy(name='Bob')

        self.assertRaises(AssertionError, bob.forced_update, object())

    def test_to_assert_when_forced_update_object_with_different_type_one(self):
        bob = Guy(name='Bob')

        self.assertRaises(AssertionError, bob.forced_update,
                          GuyWithSelfKnowledge())

    def test_to_forced_update_object_with_all_attributes(self):
        bob = Guy(name='Bobi')
        bob_other_info = Guy(name='Bob', nickname='Little Lazy Cat')

        bob.forced_update(bob_other_info)

        self.assertEquals('Bob', bob.name)
        self.assertEquals('Little Lazy Cat', bob.nickname)

    def test_to_forced_update_object_when_its_attribute_is_sub_object(self):
        mother = Mother(name='Sonar', daughter={'first-name': 'Katie'})
        other_info = Mother(name='Barbara', daughter={'first-name': 'Anny',
                                                      'family-name': 'Robinson'})

        mother.forced_update(other_info)

        self.assertEquals('Barbara', mother.name)
        self.assertEquals('Anny', mother.daughter.first_name)
        self.assertEquals('Robinson', mother.daughter.family_name)

    def test_to_forced_update_list_attributes_in_object(self):
        mother = Mother(daughters=[{'daughter': {'first-name': 'Unknown'}}])
        other_info = Mother(daughters=[
            {'daughter': {'family-name': 'Robinson', 'first-name': 'Katie'}},
            {'daughter': {'first-name': 'Su', 'family-name': 'Robinson'}}])

        mother.forced_update(other_info)

        self.assertEquals(2, len(mother.daughters))
        self.assertEquals('Katie Robinson', mother.daughters[0].name)
        self.assertEquals('Su Robinson', mother.daughters[1].name)
        self.assertIs(mother, mother.daughters[0].mother)
        self.assertIs(mother, mother.daughters[1].mother)

    def test_to_reset_parent_after_forced_update_object(self):
        mother = Mother()
        other_info = Mother(daughter={'first-name': 'Katie', 'sisters': [
            {'daughter': {'first-name': 'Ann'}},
            {'daughter': {'first-name': 'Su'}}]})

        mother.forced_update(other_info)

        self.assertIs(mother, mother.daughter.mother)
        self.assertIs(mother, mother.daughter.sisters[0].mother)
        self.assertIs(mother, mother.daughter.sisters[1].mother)

    def test_to_have_dynamic_attribute(self):
        bob = Guy(name='Bob')

        self.assertTrue(bob.has_dyn_attr('name'))


class Guy(DynamicBase):
    def __init__(self, **kwargs):
        super(Guy, self).__init__(**kwargs)


@require(['name'])
class GuyThatMustBeNamed(DynamicBase):
    def __init__(self, **kwargs):
        super(GuyThatMustBeNamed, self).__init__(**kwargs)


class GuyWithSelfKnowledge(DynamicBase):
    def __init__(self, **kwargs):
        super(GuyWithSelfKnowledge, self).__init__(**kwargs)

    def _load_name(self, value):
        return 'Jim'

    def _load_brother(self, value):
        return Guy(**value)


class FamilyMember(DynamicBase):
    def __init__(self, **kwargs):
        super(FamilyMember, self).__init__(**kwargs)

    def children_module_name(self, class_name):
        return 'test_dynamicbase'

    @property
    def mother(self):
        if self.__class__.__name__ == 'Mother':
            return self
        else:
            return self.parent.mother


class Mother(FamilyMember):
    def __init__(self, **kwargs):
        super(Mother, self).__init__(**kwargs)


class Son(FamilyMember):
    def __init__(self, name):
        self.name = name


class Daughter(FamilyMember):
    def __init__(self, **kwargs):
        super(Daughter, self).__init__(**kwargs)

    @property
    def name(self):
        return '{} {}'.format(self.first_name, self.family_name)

    def _load_son(self, value):
        return Son(value)


class PersonName(object):
    def __init__(self, first_name, family_name):
        self.first_name = first_name
        self.family_name = family_name

    @property
    def value(self):
        return '{} {}'.format(self.first_name, self.family_name)


