from unittest import TestCase
from data_object.jenkins import Jenkins


class JenkinsTest(TestCase):

    def setUp(self):
        self.slaves_def = {
            'slaves': [
                {'unix-slave': {
                    'name': 'uklpadsab05a.uk',
                    'description': '{project.name} slave 1',
                    'executors': 3,
                    'remote-root': '/shared/opt/SCB/sabre/Jenkins',
                    'labels': '{project.name}'
                }}
            ]
        }

    def test_to_load_slaves_info(self):
        jenkins = Jenkins(**self.slaves_def)

        self.assertEquals(1, len(jenkins.slaves))
        self._assert_slave(self.slaves_def['slaves'][0], jenkins.slaves[0])

    def _assert_slave(self, expected_slave_definition, actual_slave):
        _def = expected_slave_definition['unix-slave']
        self.assertEquals(_def['name'], actual_slave.name)
        self.assertEquals(_def['description'], actual_slave.description)
        self.assertEquals(_def['executors'], actual_slave.executors)
        self.assertEquals(_def['remote-root'], actual_slave.remote_root)
        self.assertEquals(_def['labels'], actual_slave.labels)