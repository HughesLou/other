from data_object.base import BootstrapBase
from data_object.jenkinsbrancheslistviews import JenkinsBranchesListViews
from data_object.jenkinslistview import JenkinsListView
from data_object.jenkinsnestedview import JenkinsNestedView
from git_utils.yaml import parse_yaml_file
from os.path import join as jp
from unittest import TestCase
import os


class BootstrapBaseTest(TestCase):
    def setUp(self):
        self._def = {
            'name': 'bootstrap',
            'project-config-path': 'bootstrap/meta/projects',
            'bootstrap-log-file': '/sabrebuild/bootstrap_logs/index.html',
            'bootstrap-git-data': {
                'url': 'ssh://git@stash/cd/bootstrap.git',
                'branch': 'move_to_yaml',
                'master_repo': '/tmp'
            },
            #'branch-strategy': '',
            'project-template': {
                #'name': '',
                'all-branches-regex': '.*',
                'controlled-branches-regex': '^[A-Z]*-\d{1,5}$',
                'pipeline-build-name': '1-build',
                #'branch-strategy': '',
                'jenkins': {
                    #'url': '',
                    'virtualenv-home':
                        '/home/sabredev/virtualenv/jenkins',
                    'virtualenv-python-home':
                        'bootstrap/meta/py/lib/jenkins-job-builder',
                    #'user-name': '',
                    #'user-token': ''
                },
                'repository': {}
            },
            'environments': [
                {
                    'env': {
                        'name': 'devlocal',
                        'jenkins': {
                            'url': 'http://sabrebuild1.uk.standardchartered.com:8180/',
                            'user-name': 'maleksey',
                            'user-token': '3d261f625cd6b0e5ed443aa36bf49ea7'
                        },
                        'bootstrap-git-data': {
                            'branch': 'develop',
                            #'master-repo': '',
                            #'url': ''
                        }
                    }
                },
                {
                    'env': {
                        'name': 'dev',
                        'jenkins': {
                            'url': 'http://sabrebuild1.uk.standardchartered.com:8180/',
                            'user-name': 'jenkins',
                            'user-token': '452c271c582c3dc8925ae320459c64da'
                        },
                        'bootstrap-git-data': {
                            'branch': 'delivery',
                            #'master-repo': '',
                            #'url': ''
                        }
                    }
                }
            ]
        }
        self._project_def = {
            'project': {
                'helloworld': {
                    'name': 'helloworld',
                    'branch-strategy': 'feature-branches',
                    'jobs-path': 'src/jobs',
                    'pipeline-build-name': '1-build',
                    'jenkins': {
                        'slaves': [{
                           'unix-slave': {
                               'name': 'uklpadsab05a.uk',
                               'description': '{project.name} slave 1',
                               'executors': 3,
                               'remote-root': '/shared/opt/SCB/sabre/Jenkins',
                               'labels': '{project.name}'
                           }}
                        ]
                    },
                    'repository': {
                        'git-data': {
                            'url': 'ssh://git@stash/cd/helloworld.git',
                            'master-repo': '/tmp'
                        }
                    }
                }
            }}

    #def test_to_create_instance(self):
    #    definition = self._def
    #
    #    bootstrap = BootstrapBase(**definition)
    #
    #    self.assertEquals(definition['name'], bootstrap.name)
    #    self.assertEquals(definition['project-config-path'],
    #                      bootstrap.project_config_path)
    #    self.assertEquals(definition['bootstrap-log-file'],
    #                      bootstrap.bootstrap_log_file)
    #    self._assert_git(definition['bootstrap-git-data'],
    #                     bootstrap.bootstrap_git_data)
    #    self._assert_project(definition['project-template'],
    #                         bootstrap.project_template)
    #    self._assert_env(definition['environments'][0],
    #                     bootstrap.environments['devlocal'])
    #    self._assert_env(definition['environments'][1],
    #                     bootstrap.environments['dev'])

    def test_to_config_environment_with_global_settings(self):
        definition = self._def

        bootstrap = BootstrapBase(**definition)

        env_dev = bootstrap.environments['dev']
        self.assertEquals(definition['bootstrap-git-data']['url'],
                          env_dev.bootstrap_git_data.url)

    def test_to_update_project_settings_with_template(self):
        definition = self._base_configuration_data
        bootstrap = BootstrapBase(**definition)
        bootstrap.project_config_path = self._projects_path

        #project = bootstrap.load_project_and_environment('helloworld',
        #                                                 'aleksey')
        project = bootstrap.load_project_and_environment('helloworld',
                                                         'devlocal',
                                                         project_data=\
                                                             self._project_def)

        self.assertEquals('helloworld', project.name)
        self.assertEquals('.*', project.all_branches_regex)
        self.assertEquals('^[A-Z]*-\d{1,5}$',
                          project.controlled_branches_regex)
        self.assertEquals('1-build', project.pipeline_build_name)
        self._assert_jenkins(
            {'url': 'http://sabrebuild1.uk.standardchartered.com:8180/',
             'user-name': 'maleksey',
             'user-token': '3d261f625cd6b0e5ed443aa36bf49ea7',
             'virtualenv-home': '/home/sabredev/virtualenv/jenkins',
             'virtualenv-python-home': 'bootstrap/meta/py/lib/jenkins-job-builder'},
            project.jenkins)
        self._assert_git({'url': 'ssh://git@stash/cd/helloworld.git',
                          'master-repo': '/tmp'},
                         project.repository.git_data)
        self._assert_git({'url': 'ssh://git@stash/cd/bootstrap.git',
                          'branch': 'integration'}, project
                         .bootstrap_git_data)
        self._assert_nested_view({'name': 'helloworld', 'parent-path': ''},
                                 project.jenkins.root_view)
        self._assert_list_view({'name': 'helloworld-repository',
                                'parent-path': '',
                                'jobs-path': 'bootstrap/meta',
                                'branch-regex': '^[A-Z]*-\d{1,5}$'},
                               project.jenkins.root_view.views[0])
        self._assert_nested_view({'name': 'helloworld-branches',
                                  'parent-path': ''},
                                 project.jenkins.root_view.views[2])
        self._assert_branches_list_view({'name': 'helloworld-develop',
                                         'parent-path': '',
                                         'jobs-path': 'src/jobs',
                                         'branch-regex': '.*',
                                         'pipeline-build-name': '1-build',
                                         'use-shallow-clone': 'true'},
                                        project.jenkins.root_view.views[2].
                                        views[0])

    def _assert_branches_list_view(self, expected_view_definition,
                                   actual_view_obj):
        self.assertIsInstance(actual_view_obj, JenkinsBranchesListViews)
        self.assertEquals(expected_view_definition['name'],
                          actual_view_obj.name)
        self.assertEquals(expected_view_definition['parent-path'],
                          actual_view_obj.parent_path)
        self.assertEquals(expected_view_definition['jobs-path'],
                          actual_view_obj.project_jobs_builder.jobs_path)
        self.assertEquals(expected_view_definition['branch-regex'],
                          actual_view_obj.project_jobs_builder.branch_regex)
        self.assertEquals(expected_view_definition['pipeline-build-name'],
                          actual_view_obj.project_jobs_builder.pipeline_build_name)
        self.assertEquals(expected_view_definition['use-shallow-clone'],
                          actual_view_obj.project_jobs_builder.use_shallow_clone)

    def _assert_list_view(self, expected_view_definition, actual_view_obj):
        self.assertIsInstance(actual_view_obj, JenkinsListView)
        self.assertEquals(expected_view_definition['name'],
                          actual_view_obj.name)
        self.assertEquals(expected_view_definition['parent-path'],
                          actual_view_obj.parent_path)
        self.assertEquals(expected_view_definition['jobs-path'],
                          actual_view_obj.base_jobs_builder.jobs_path)
        self.assertEquals(expected_view_definition['branch-regex'],
                          actual_view_obj.base_jobs_builder.branch_regex)

    def _assert_nested_view(self, expected_view_definition, actual_view_obj):
        self.assertIsInstance(actual_view_obj, JenkinsNestedView)
        self.assertEquals(expected_view_definition['name'],
                          actual_view_obj.name)
        self.assertEquals(expected_view_definition['parent-path'],
                          actual_view_obj.parent_path)

    def _assert_jenkins(self, expected_jenkins_definition, actual_jenkins_obj):
        if 'url' in expected_jenkins_definition:
            self.assertEquals(expected_jenkins_definition['url'],
                              actual_jenkins_obj.url)
        self.assertEquals(expected_jenkins_definition['user-name'],
                          actual_jenkins_obj.user_name)
        self.assertEquals(expected_jenkins_definition['user-token'],
                          actual_jenkins_obj.user_token)
        if 'virtualenv-home' in expected_jenkins_definition:
            self.assertEquals(expected_jenkins_definition['virtualenv-home'],
                              actual_jenkins_obj.virtualenv_home)
        if 'virtualenv-python-home' in expected_jenkins_definition:
            self.assertEquals(
                expected_jenkins_definition['virtualenv-python-home'],
                actual_jenkins_obj.virtualenv_python_home)

    def _assert_git(self, expected_git_definition, actual_git_obj):
        if 'url' in expected_git_definition:
            self.assertEquals(expected_git_definition['url'],
                              actual_git_obj.url)
        if 'branch' in expected_git_definition:
            self.assertEquals(expected_git_definition['branch'],
                              actual_git_obj.branch)
        if 'master-repo' in expected_git_definition:
            self.assertEquals(os.path.expanduser(expected_git_definition[
                'master-repo']), actual_git_obj.expanded_master_repo)

    def _assert_env(self, expected_env_definition, actual_env):
        self._assert_jenkins(expected_env_definition['env']['jenkins'],
                             actual_env.jenkins)
        self._assert_git(expected_env_definition['env']['bootstrap-git-data'],
                         actual_env.bootstrap_git_data)

    def _assert_project(self, expected_project_definition, actual_project):
        self.assertEquals(expected_project_definition['all-branches-regex'],
                          actual_project.all_branches_regex)
        self.assertEquals(
            expected_project_definition['controlled-branches-regex'],
            actual_project.controlled_branches_regex)
        self.assertEquals(expected_project_definition['pipeline-build-name'],
                          actual_project.pipeline_build_name)
        jenkins = actual_project.jenkins
        self.assertEquals(expected_project_definition['jenkins']['url'],
                          jenkins.url)
        self.assertEquals(
            expected_project_definition['jenkins']['virtualenv-home'],
            jenkins.virtualenv_home)
        self.assertEquals(
            expected_project_definition['jenkins']['virtualenv-python-home'],
            jenkins.virtualenv_python_home)

    @property
    def _root_path(self):
        running_path = os.environ.get('PROJECT_PATH', os.getcwd())
        if not os.path.exists(jp(running_path, 'meta')):
            raise Exception('Either PROJECT_PATH env. variable needs to be '
                            'set or tests must be running from "bootstrap" '
                            'folder')
        return running_path

    @property
    def _projects_path(self):
        return jp(self._root_path, 'meta', 'projects')

    @property
    def _base_configuration_data(self):
        base_config_file = jp(self._root_path, 'meta', 'projects', 'BASE',
                              'project.yaml')
        data = parse_yaml_file(base_config_file)
        return data['bootstrap-base']['bootstrap']

