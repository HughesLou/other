from unittest import TestCase
from data_object.environments import Environments


class EnvironmentsTest(TestCase):

    def test_to_create_instance(self):
        definition = [
            {
                'env': {
                    'name': 'devlocal',
                    'jenkins': {
                        'url': 'http://sabrebuild1.uk.standardchartered.com:8180/',
                        'user-name': 'maleksey',
                        'user-token': '3d261f625cd6b0e5ed443aa36bf49ea7'
                    },
                    'bootstrap-git-data': {
                        'branch': 'develop'
                    }
                }
            }]

        env = Environments(envs=definition)['devlocal']

        env_def = definition[0]['env']
        self._assert_jenkins(env_def['jenkins'], env.jenkins)
        self._assert_git(env_def['bootstrap-git-data'], env.bootstrap_git_data)

    def _assert_jenkins(self, expected_jenkins_definition, actual_jenkins_obj):
        self.assertEquals(expected_jenkins_definition['url'], actual_jenkins_obj.url)
        self.assertEquals(expected_jenkins_definition['user-name'], actual_jenkins_obj.user_name)
        self.assertEquals(expected_jenkins_definition['user-token'], actual_jenkins_obj.user_token)

    def _assert_git(self, expected_git_definition, actual_git_obj):
        self.assertEquals(expected_git_definition['branch'], actual_git_obj.branch)