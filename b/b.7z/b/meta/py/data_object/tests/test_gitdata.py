from unittest import TestCase
from data_object.gitdata import GitData


class GitDataTest(TestCase):

    def test_to_create_instance(self):
        definition = {
            'url': 'ssh://git@stash/cd/helloworld.git',
            'branch': 'dev'
        }

        git_data = GitData(**definition)

        self.assertEquals(definition['url'], git_data.url)
        self.assertEquals(definition['branch'], git_data.branch)
