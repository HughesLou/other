from unittest import TestCase
from data_object.gitdata import GitData
from data_object.repository import Repository


class RepositoryTest(TestCase):

    def test_to_create_instance(self):
        git_definition = {'git-data': {
            'url': 'ssh://git@stash/sidr/sidr-dc.git',
            'master-repo': '/sabrebuild/jobs/SIDR-DC/git-repo'
        }}

        repo = Repository(**git_definition)

        self.assertEquals(git_definition['git-data']['url'],
                          repo.git_data.url)
        self.assertEquals(git_definition['git-data']['master-repo'],
                          repo.git_data.master_repo)

    def test_to_access_instance_through_repository(self):
        git_definition = {'git-data': {
            'url': 'ssh://git@stash/sidr/sidr-dc.git',
            'master-repo': '/sabrebuild/jobs/SIDR-DC/git-repo'
        }}

        repo = Repository(**git_definition)

        self.assertEquals(git_definition['git-data']['url'],
                          repo.url)
        self.assertEquals(git_definition['git-data']['master-repo'],
                          repo.master_repo)
