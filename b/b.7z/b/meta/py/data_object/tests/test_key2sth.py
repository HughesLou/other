from unittest import TestCase
from data_object.basejobsbuilder import BaseJobsBuilder
from data_object.key2sth import key2object, key2property, keys2property


class Key2SomethingTest(TestCase):

    def test_to_convert_key_to_property_foramt(self):
        _property = key2property('jobs-path')

        self.assertEquals('jobs_path', _property)

    def test_to_convert_keys_in_dict_with_single_level_to_property_format(self):
        _dict = {'jobs-path': 'bootstrap/meta', 'branch-regex': '^[A-Z]*-\d{1,5}$'}

        new_dict = keys2property(_dict)

        self.assertEquals(2, len(new_dict))
        self.assertEquals('bootstrap/meta', new_dict['jobs_path'])
        self.assertEquals('^[A-Z]*-\d{1,5}$', new_dict['branch_regex'])

    def test_to_convert_keys_in_dict_with_multi_levels_to_property_format(self):
        _dict = {'base-jobs-builder': {'jobs-path': 'bootstrap/meta', 'branch-regex': '^[A-Z]*-\d{1,5}$'}}

        new_dict = keys2property(_dict)

        self.assertTrue(new_dict.has_key('base_jobs_builder'))
        sub_dict = new_dict['base_jobs_builder']
        self.assertEquals('bootstrap/meta', sub_dict['jobs_path'])
        self.assertEquals('^[A-Z]*-\d{1,5}$', sub_dict['branch_regex'])

    def test_to_convert_keys_in_dict_and_reach_spec_level(self):
        _dict = {'base-jobs-builder': {'jobs-path': 'bootstrap/meta', 'branch-regex': '^[A-Z]*-\d{1,5}$'}}

        new_dict = keys2property(_dict, 1)

        self.assertTrue(new_dict.has_key('base_jobs_builder'))
        sub_dict = new_dict['base_jobs_builder']
        self.assertEquals('bootstrap/meta', sub_dict['jobs-path'])
        self.assertEquals('^[A-Z]*-\d{1,5}$', sub_dict['branch-regex'])

