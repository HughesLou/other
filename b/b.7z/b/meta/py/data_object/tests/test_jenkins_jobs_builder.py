import os
from os.path import join as jp
from unittest import TestCase
from data_object.basejobsbuilder import BaseJobsBuilder
from data_object.projectjobsbuilder import ProjectJobsBuilder
from git_utils.yaml import parse_yaml_file
from data_object.base import BootstrapBase
from jenkins_jobs.builder import YamlParser


class BaseJenkinsJobsTest(TestCase):

    def test_to_create_instance(self):
        branch_regex = '^[A-Z]*-\d{1,5}$'
        default_path = 'bootstrap/meta'

        builder = BaseJobsBuilder(branch_regex=branch_regex,
                                  jobs_path=default_path)

        self.assertEquals(default_path, builder.jobs_path)
        self.assertEquals(branch_regex, builder.branch_regex)

    def test_to_create_instance_with_dict_definition(self):
        definition = {'jobs_path': 'stash/meta', 'branch_regex': '^[A-Z]*-\d{1,5}$'}

        builder = BaseJobsBuilder(**definition)

        self.assertEquals(definition['jobs_path'], builder.jobs_path)
        self.assertEquals(definition['branch_regex'], builder.branch_regex)

    def test_to_load_instance_with_dict_definition(self):
        definition = {'jobs-path': 'stash/meta', 'branch-regex': '^[A-Z]*-\d{1,5}$'}

        builder = BaseJobsBuilder(**definition)

        self.assertEquals(definition['jobs-path'], builder.jobs_path)
        self.assertEquals(definition['branch-regex'], builder.branch_regex)

    def test_get_parser_default(self):
        base_project_path = '{0:s}/meta/projects/BASE/project.yaml' \
            .format(self._root_path)
        data = parse_yaml_file(base_project_path)
        base = BootstrapBase(**data['bootstrap-base']['bootstrap'])
        base.project_config_path = 'meta/projects'
        project = base.load_project_and_environment('helloworld',
                                                    'aleksey')
        # Master clone of the repo is required. We always check if it is cloned
        project.repository.checkout()

        base_builder = project.jenkins.views[0].views[0].builder
        self.assertIsInstance(base_builder,
                              BaseJobsBuilder)
        base_parser = base_builder.get_parser()
        self.assertIsInstance(base_parser, YamlParser)
        self.assertIsInstance(base_parser.data, dict)
        self.assertIn('{project.name}_onpush', base_parser.data['job-group']['jobs']['jobs'])

    def test_get_parser_override(self):
        base_project_path = '{0:s}/meta/projects/BASE/project.yaml' \
            .format(self._root_path)
        data = parse_yaml_file(base_project_path)
        base = BootstrapBase(**data['bootstrap-base']['bootstrap'])
        base.project_config_path = 'meta/projects'
        project = base.load_project_and_environment('helloworld',
                                                    'aleksey')
        # Master clone of the repo is required. We always check if it is cloned
        project.repository.checkout()

        base_builder = project.jenkins.views[0].views[0].builder
        self.assertIsInstance(base_builder,
                              BaseJobsBuilder)
        base_parser = base_builder.get_parser(branch_name='test_basejobs_override')
        self.assertIsInstance(base_parser, YamlParser)
        self.assertIsInstance(base_parser.data, dict)
        self.assertNotIn('{project.name}_onpush', base_parser.data['job-group']['jobs']['jobs'])
        self.assertIn('{project.name}_onpush_override', base_parser.data['job-group']['jobs']['jobs'])

    @property
    def _root_path(self):
        running_path = os.environ.get('PROJECT_PATH', os.getcwd())
        if not os.path.exists(jp(running_path, 'meta')):
            raise Exception('Either PROJECT_PATH env. variable needs to be '
                            'set or tests must be running from "bootstrap" '
                            'folder')
        return running_path


class ProjectJobsBuilderTest(TestCase):

    def test_to_create_instance(self):
        jobs_path = 'bootstrap/meta'
        branch_regex = '^[A-Z]*-\d{1,5}$'
        pipeline_build_name = '0-pipeline'

        builder = ProjectJobsBuilder(jobs_path=jobs_path, branch_regex=branch_regex, pipeline_build_name=pipeline_build_name)

        self.assertEquals(jobs_path, builder.jobs_path)
        self.assertEquals(branch_regex, builder.branch_regex)
        self.assertEquals(pipeline_build_name, builder.pipeline_build_name)

    def test_to_create_instance_with_dict_definition(self):
        definition = {'jobs_path': 'bootstrap/meta', 'branch_regex': '^[A-Z]*-\d{1,5}$', 'pipeline_build_name': '0-pipeline'}

        builder = ProjectJobsBuilder(**definition)

        self.assertEquals(definition['jobs_path'], builder.jobs_path)
        self.assertEquals(definition['branch_regex'], builder.branch_regex)
        self.assertEquals(definition['pipeline_build_name'], builder.pipeline_build_name)

    def test_to_load_instance_with_dict_definition(self):
        definition = {'jobs-path': 'bootstrap/meta', 'branch-regex': '^[A-Z]*-\d{1,5}$', 'pipeline-build-name': '0-pipeline'}

        builder = ProjectJobsBuilder(**definition)

        self.assertEquals(definition['jobs-path'], builder.jobs_path)
        self.assertEquals(definition['branch-regex'], builder.branch_regex)
        self.assertEquals(definition['pipeline-build-name'], builder.pipeline_build_name)
