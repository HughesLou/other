import os
import re
import logging
from os.path import join as jp
from jenkins_jobs.builder import YamlParser
from basejobsbuilder import BaseJobsBuilder
from dynamicbase import resolve

logger = logging.getLogger(__name__)


@resolve(['jobs_path', 'branch_regex', 'pipeline_build_name'])
class ProjectJobsBuilder(BaseJobsBuilder):
    def __init__(self, **kwargs):
        super(ProjectJobsBuilder, self).__init__(**kwargs)
        self._parser = None

    def get_parser(self, branch_name):
        project = self.top_project
        self.resolve_vars()
        full_jobs_path = jp(os.path.expanduser(project.repository.master_repo),
                            self.jobs_path)

        # Changing CWD because we need to read yaml files
        # and path to them is relative to project clone
        save_cwd = os.getcwd()
        # parser.parse(jp(self.jobs_path, 'defaults.yaml'))
        jobs_def = {'project': {}}
        parser_project = jobs_def['project'][project.name] = {}
        parser_project = self.set_project_parameters(parser_project)
        parser_project['project'].repository.branch = branch_name
        parser_project['branch'] = branch_name

        parser = YamlParser()
        parser.data = jobs_def

        if project.repository.vcs_type() == 'git':
            # parser.parse(jp(self.jobs_path, 'project.yaml'))
            # Inject other parameters
            # If shallow clone is set, there is no reason to point
            # all jobs to one location
            # parser_project['workspace'] = project.jenkins.workspace \
            #    if project.jenkins.workspace is not None else ''
            parser_project['shallow-clone'] = \
                str(self.use_shallow_clone).lower()

        # TODO git_data shall change path itself
        os.chdir(os.path.expanduser(project.repository.master_repo))
        project.repository.checkout_branch(branch_name)
        os.chdir(save_cwd)

        # For branches we want to have branch specific jobs definition
        # for master and develop branches we always use default
        # for all other branches, we first check if there is branch specific
        # build and fall back to default jobs definition
        if branch_name not in ['master', 'develop', 'trunk']:
            jobs_def_path = jp(full_jobs_path, branch_name, 'jobs.yaml')
            if not os.path.exists(jobs_def_path):
                jobs_def_path = jp(full_jobs_path, 'jobs.yaml')
            else:
                logger.warning('Branch %s have branch specific jobs'
                               '.yaml' % branch_name)
        else:
            jobs_def_path = jp(full_jobs_path, 'jobs.yaml')

        if os.path.exists(jobs_def_path):
            try:
                logger.debug('Reading %s' % jobs_def_path)
                parser.parse(jobs_def_path)

                job_group_name = ''

                job_groups = None
                try:
                    job_groups = project['job_groups']
                except KeyError:
                    pass

                if job_groups is None:
                    job_group_name = 'jobs'
                else:
                    for job_group_name, branch_regex in \
                            job_groups.filters.iteritems():
                        rg = re.compile(branch_regex)
                        if rg.match(branch_name) is not None:
                            break
                    else:
                        job_group_name = 'jobs'

                job_groups = parser.data.get('job-group', [])
                if len(job_groups) > 0:
                    if job_group_name not in job_groups:
                        raise Exception('There are no "job-group" named '
                            '%s in jobs.yaml, but branch %s refers to it via '
                            '"job-group" defined in project.yaml'
                            % (job_group_name, branch_name))
                    parser_project['jobs'] = \
                        parser.data['job-group'][job_group_name]['jobs']
                else:
                    raise Exception('There are no "job-group" sections'
                                    ' in jobs.yaml. If you there is no '
                                    '"job-group" section in project.yaml'
                                    ' you must have "job-group" section'
                                    ' with "jobs" group in your jobs.yaml')
            except Exception as ex:
                logger.error('Failed to parse jobs.yaml in branch "%s".'
                             ' Error message was: %s'
                             % (branch_name, str(ex)))
        else:
            logger.warning('Branch "%s" does not have %s. '
                           'Skipping jobs creation'
                           % (branch_name, jobs_def_path))
        self._parser = parser

        return self._parser
