from git_utils.custom_git import CustomGit
from git_utils.git_command import GitCommand
from subprocess import PIPE
import logging
import os
from os.path import join as jp
import re

from data_object.dynamicbase import require
from data_object.vcsdata import VcsData

logger = logging.getLogger(__name__)


@require(['url', 'master_repo'])
class GitData(VcsData):

    def __init__(self, **kwargs):
        super(GitData, self).__init__(**kwargs)
        self._branch_regex = ''
        self._branches = {}
        self._all_heads = None
        if 'branch' not in self.__dict__:
            self.branch = None
        self.cg = None
        self.sha = None

    def set_branch(self, branch):
        self.branch = branch
        self.cg = CustomGit(origin_url=self.url,
                            repo_path=self.expanded_master_repo,
                            branch=branch)
        self.sha = self.cg.sha

    @property
    def expanded_master_repo(self):
        return os.path.expanduser(self.master_repo) if hasattr(self,
                                                               'master_repo') \
            else None

    def rebase(self, build_id, branch_regex, do_push=False, undo_rebase=False):
        self._check_master_repo()
        errors = True
        for br in self.branches(branch_regex).iterkeys():
            cg = CustomGit(origin_url=self.url,
                           repo_path=self.expanded_master_repo,
                           branch=br)
            cg.git_clean(br)
            if undo_rebase:
                errors = errors and cg.undo_rebase(build_id, br)
            else:
                errors = errors and cg.rebase(build_id)
            if do_push:
                errors = errors and cg.push(br)

        return errors

    def merge(self, branch_name, notes_path, to_branch='master'):
        self._check_master_repo()
        cg = CustomGit(origin_url=self.url,
                       repo_path=self.expanded_master_repo,
                       branch=branch_name)
        cg.git_clean(branch_name)
        return cg.merge(notes_path, to_branch)

    def merge_close(self, branch_name, notes_path):
        self._check_master_repo()
        cg = CustomGit(origin_url=self.url,
                       repo_path=self.expanded_master_repo,
                       branch=branch_name)
        cg.git_clean(branch_name)
        return cg.merge_and_close(notes_path)

    def undo_merge_close(self, branch_name):
        self._check_master_repo()

        cg = CustomGit(origin_url=self.url,
                       repo_path=self.expanded_master_repo,
                       branch='master')
        cg.git_clean(branch_name='master')
        return cg.undo_merge_and_close(branch_name)

    def undo_merge(self, branch_name, from_branch='master'):
        # We're restoring deleted branch, which is not exists
        # Thus we ask CustomGit to start with master and
        # call undo with the branch name to restore
        cg = CustomGit(origin_url=self.url,
                       repo_path=self.expanded_master_repo,
                       branch='master')
        cg.git_clean(branch_name='master')
        return cg.undo_merge(branch_name=branch_name, from_branch=from_branch)

    def branches(self, branch_regex):
        """
        Returns dict of branches in current repository based on regex filter
        dict is structured like this {'branch-1', '<HEAD sha>'}

        :param branch_regex: branch filter regular expression
        :type branch_regex: str

        :returns: Dictionary of branches
        :rtype: dict
        """
        rg = re.compile(branch_regex)
        if not self._all_heads:
            git_cmd = GitCommand()
            out, _err = git_cmd.run(self.url,
                                    ['ls-remote', '--heads'],
                                    stdout=PIPE, stderr=PIPE)

            self._all_heads = out.split('\n')

        branches = {}
        for line in self._all_heads:
            sha = line[:7]
            line = line[41:].strip().split('/')
            if len(line) < 3:
                continue
            head = line[2]

            if rg.match(head) is not None:
                branches[head] = sha

        return branches

    def branch_names(self, branch_regex):
        """
        Returns list of branches in current repository based on regex filter

        :param branch_regex: branch filter regular expression
        :type branch_regex: str

        :returns: List of branches matching *branch_regex*
        :rtype: list
        """
        return self.branches(branch_regex).keys()

    def checkout(self):
        master_repo = self.expanded_master_repo
        if os.path.exists(master_repo) and os.path.exists(jp(master_repo,
                                                             '.git')):
                logger.info("Master repo folder '%s' does exist"
                            % master_repo)
                return
        git_cmd = GitCommand()
        out, _err = git_cmd.run(self.url,
                                ['clone', '--quiet', master_repo],
                                stdout=PIPE, stderr=PIPE)
        if _err.strip() == '':
            logger.info("Cloned to master repo: %s" % master_repo)
        else:
            raise Exception(_err)

    def checkout_branch(self, branch_name):
        if not self.cg:
            self.cg = CustomGit(origin_url=self.url,
                                repo_path=self.expanded_master_repo,
                                branch=branch_name)
        else:
            self.cg.safe_checkout(branch_name)
        self.cg.git_clean(branch_name=branch_name)

    def list_changed(self, branch, from_hash, to_hash):
        cg = CustomGit(origin_url=self.url,
                       repo_path=self.expanded_master_repo,
                       branch=branch)
        return cg.list_updated_files(branch, from_hash, to_hash)

    def _custom_git(self, branch, operations):
        """
        Invokes git operations on branch

        :param branch: branch to operate on
        :param operations: CustomGit function names and
            parameters
        :type operations: dict: {'func_name': {'param1': 'value'}}

        :returns: True if were no errors
        :rtype: bool
        """
        errors = False
        if not self.cg:
            self.cg = CustomGit(origin_url=self.url,
                                repo_path=self.expanded_master_repo,
                                branch=branch)
        else:
            self.cg.safe_checkout(branch)
        for op, params in operations.iteritems():
            cgit = getattr(self.cg, op)
            if not params:
                result = cgit()
            else:
                result = cgit(**params)
            if not result:
                errors = True

        return not errors

    def _check_master_repo(self):
        master_repo = self.expanded_master_repo
        if master_repo:
            if not os.path.exists(jp(master_repo, '.git')):
                self.checkout()
        else:
            raise Exception('Cannot do git operations. project'
                            '.repository.git_data.master_repo is not '
                            'set')

    def current_branch(self):
        return self.branch

    def vcs_type(self):
        return 'git'
