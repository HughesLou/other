import ast
import logging
import sys

from jenkinsapi.jenkins import Jenkins as JenkinsApi

from data_object.dynamicbase import DynamicBase, require
from data_object.jenkinslistview import JenkinsListView
sys.path = ['bootstrap/meta/py/lib/jenkins_job_builder'] + sys.path
from jenkins_jobs import builder as jjb
from jenkinsflow.jobcontrol import parallel, serial
from jenkinsflow.unbuffered import UnBuffered


# Unbuffered output does not work well in Jenkins/Hudson, so in case
# this is run from a jenkins/hudson job, we want unbuffered output
sys.stdout = UnBuffered(sys.stdout)

logger = logging.getLogger(__name__)


@require(['url', 'user_name', 'user_token'])
class Jenkins(DynamicBase):
    """
    Instance of Jenkins server
    """
    def __init__(self, **kwargs):
        """
        Constructor

        :param url: url of the server
        :param user_name: name to login to Jenkins
        :param user_token: password for user_name. Can be an API key.
        :param workspace: to be used by build jobs
        :param master_workspace: to be user for repository wide jobs
        :param node: default node to use
        """
        super(Jenkins, self).__init__(**kwargs)
        self._api = None
        self.jjbuilder = None

    def api(self, url=None):
        """
        Connects to Jenkins and returns Jenkins object
        """
        logger.debug('api(url=%s)' % url)
        if url:
            return JenkinsApi(url, self.user_name, self.user_token)
        else:
            return JenkinsApi(self.url, self.user_name, self.user_token)

    @property
    def jj_builder(self):
        """
        Creates an instance of Jenkins Job Builder
        """
        if not self.jjbuilder:
            try:
                self.jjbuilder = jjb.Builder(jenkins_url=self.url,
                                             jenkins_user=self.user_name,
                                             jenkins_password=self.user_token,
                                             jenkins=self.api(),
                                             flush_cache=True)
            except TypeError:
                # HACK: (AM) For some reason above doesn't work in Jenkins
                self.jjbuilder = jjb.Builder(jenkins_url=self.url,
                                             jenkins_user=self.user_name,
                                             jenkins_password=self.user_token,
                                             flush_cache=True)
        return self.jjbuilder

    @property
    def root_view(self):
        return self.views[0]

    def prerequisite(self):
        self.create_nodes()
        self.root_view.update_view()
        self.remove_obsolete_jobs()

    def remove_obsolete_jobs(self):
        jenkins = self.api()
        for job_name in self.find_jobs_to_delete():
            logger.info('Deleting obsolete job "%s"' % job_name)
            jenkins.delete_job(job_name)

    def clear(self):
        self.root_view.remove()
        del self.api().views[self.root_view.name]

    def find_jobs_to_delete(self):
        def job_filter(job_name, branches):
            for branch in branches:
                if branch in job_name:
                    return False

            return True

        def filter_special_jobs(job_list):
            """
            Filter jobs that are not branch based.
            This is needed because job_list have all projects jobs at
            that time and we don't want to delete non branch related
            jobs like onpush etc.
            """
            job_ns = []
            root_view = self.top_project.jenkins.root_view
            for view in root_view.views:
                if isinstance(view, JenkinsListView):
                    try:
                        job_ns.extend(view.builder.job_names('master'))
                    except Exception as ex:
                        logger.warning('Some yamls cannot be parsed in '
                                       ' jenkins.find_jobs_to_delete. '
                                       'Message is "%s"' % str(ex))

            return list(set(job_list) - set(job_ns))

        project = self.top_project
        branches = project.repository.branch_names(project.all_branches_regex)
        jenkins = self.api()
        r = jenkins.requester
        tree_params = {'tree': 'jobs[name]'}
        result = r.get_url(project.jenkins.url + '/api/python', tree_params)
        if result.status_code != 200:
            raise Exception('Jenkins returned HTTP code %s'
                            % result.status_code)
        all_jobs = ast.literal_eval(result.content)['jobs']
        existing_project_jobs = [job['name'] for job in all_jobs
                                 if job['name'].startswith(project.name)]
        existing_project_jobs = filter_special_jobs(existing_project_jobs)
        del_project_jobs = filter(lambda x: job_filter(x, branches),
                                  existing_project_jobs)
        return del_project_jobs

    def remove_jobs(self, jobbuilder):
        jobs = jobbuilder.job_names()
        j = self.api()
        for job_name in jobs:
            if job_name in j:
                logger.info('Removing job %s' % job_name)
                j.delete_job(job_name)

        self.jj_builder.invalidate_cache()

    def remove_views(self):
        top_view = list(self.views.itervalues())[0]
        top_view.remove()

    def update_views(self):
        for view in self.views.itervalues():
            view.update_view()

    def invoke(self, scheduled_jobs, invoke_serial=True, wait_for_jobs=True):
        # Unbuffered output does not work well in Jenkins/Hudson, so in case
        # this is run from a jenkins/hudson job, we want unbuffered output
        sys.stdout = UnBuffered(sys.stdout)

        j = self.api()
        if invoke_serial:
            with serial(j, timeout=0,
                        job_name_prefix='', report_interval=5) as ctrl1:
                for job in scheduled_jobs.keys():
                    logger.info('Invoking %s' % job)
                    if scheduled_jobs[job] is None:
                        if wait_for_jobs:
                            ctrl1.invoke(job)
                        else:
                            ctrl1.invoke_unchecked(job)
                    else:
                        if wait_for_jobs:
                            ctrl1.invoke(job, **scheduled_jobs[job])
                        else:
                            ctrl1.invoke_unchecked(job, **scheduled_jobs[job])

        else:
            with parallel(j, timeout=0,
                          job_name_prefix='', report_interval=5) as ctrl1:
                for job in scheduled_jobs:
                    logger.info('Invoking %s' % job)
                    if scheduled_jobs[job] is None:
                        if wait_for_jobs:
                            ctrl1.invoke(job)
                        else:
                            ctrl1.invoke_unchecked(job)
                    else:
                        if wait_for_jobs:
                            ctrl1.invoke(job, **scheduled_jobs[job])
                        else:
                            ctrl1.invoke_unchecked(job, **scheduled_jobs[job])

    def on_push(self, branch_name, from_hash, to_hash):
        self.top_project.branch_strategy.on_push(branch_name,
                                                 from_hash, to_hash,
                                                 self.invoke)

    def create_nodes(self):
        if not self.__dict__.get('slaves', None):
            # No slaves defined. Lets check if there are slaves belong to this
            # project and remove them all
            j = self.api()
            project_name = self.top_project.name
            existing_slaves = [slave for slave in j.get_nodes().keys()
                               if project_name in slave]
            for slave in existing_slaves:
                del j.nodes[slave]

            # We have nothing else to do here
            return

        # Create slaves
        j = self.api()
        for slave in self.slaves:
            sl_name = '%s_%s' % (self.top_project.name, slave.name)
            logger.info("Check to see if there is jenkins slave server [%s]"
                        % sl_name)
            if sl_name in j.get_nodes():
                logger.info("Slave [%s] already exists in Jenkins"
                            % sl_name)
                continue

            self._create_slave(j, slave)

        # Check which slaves we need to remove
        slaves_in_project = set(('%s_%s' % (self.top_project.name, slave.name)
                                for slave in self.slaves))
        slaves_in_jenkins = set(j.nodes.keys())
        diff = slaves_in_project - slaves_in_jenkins

        # remove them
        for slave in diff:
            del j.nodes[slave]

    def _create_slave(self, jenkins, slave):
        # when credentials are set in UnixSlave - we are creating SSH slave
        if slave.credentials:
            # Jenkinsapi will automatically create credentials
            # and update existing ones, so we are not checking them here
            description = '%s__%s' % (self.top_project.name,
                                      slave.credentials.description)
            jenkins.credentials[description] = (slave.credentials.username,
                                                slave.credentials.password)
            jenkins.create_node(name='%s_%s' % (self.top_project.name,
                                                slave.name),
                                num_executors=slave.executors,
                                node_description=slave.description,
                                remote_fs=slave.remote_root,
                                labels=slave.labels,
                                host=slave.host, port=slave.port,
                                credential_descr=description)
            logger.info('Created SSH slave "%s_%s"' % (self.top_project.name,
                                                       slave.name))
        else:
            # We usually use shared jnlp slaves, thus slave names is not
            # touched here
            jenkins.create_node(name=slave.name,
                                num_executors=slave.executors,
                                node_description=slave.description,
                                remote_fs=slave.remote_root,
                                labels=slave.labels)
            logger.info('Created JNLP slave "%s"' % slave.name)

    def last_build_status(self, job_name):
        return self.api()[job_name].get_last_build().is_good()

    def last_build_revision(self, job_name):
        return self.api()[job_name].get_last_build().get_revision()
