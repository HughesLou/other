from os.path import join as jp
from data_object.dynamicbase import DynamicBase, require

import json
import logging
import requests
import re
import time

class VirtualMachine:
    """
    Placeholder for mapping into or directly using One-E StoreFront
    representation of virtual machines and environments
    """
    def __init__(self):
        """Placeholder, raises NotImplementedError"""
        raise NotImplementedError

class StoreFrontClient:
    """
    Basic class for interacting with One-E StoreFront.
    Requires successful authentication.
    """
    def __init__(self, username, password, url = 'http://store.one-e.standardchartered.com/'):
        logging.getLogger(__name__)
        self.url = url
        self.url_login = self.url + 'accounts/sign_in'
        self.url_env = self.url + 'environments'
        self.username = username
        self.password = password
        self.login_data = 'account[domain]=ZONE1-SCBNET&account[username]=%s&account[password]=%s' % (self.username, self.password)
        self._session = requests.Session()
        logging.debug("event=login_start")
        login = self._session.post(self.url_login, data=self.login_data)
        f = re.search(r"Failed to Login",login.content)
        if f:
            logging.error("event=failed_login, username=%s", self.username)
            raise Exception("Failed to login")
        logging.debug("event=login_end")

    def getVirtualMachineDataList(self, from_file_name = None):
        """
        Retrieves environment page from One-E StoreFront or file_name,
        parses page content looking for virtualMachinesJSON,
        returns python list of dicts of virtualMachines Data
        or raises exception if virtualMachinesJSON not found
        """
        if from_file_name is not None:
            logging.info("Getting VM data from file %s" % (from_file_name))
            with open(from_file_name,'r') as from_file:
                content = from_file.read()
        else:
            logging.info("Getting VM data from StoreFront")
            response = self._session.get(self.url_env)
            content = response.content
        m = re.search(r"window.virtualMachinesJSON = (\[.*\]);",content)
        if m:
            # Returns list of dict VM properties
            vmdatalist = json.loads(m.group(1))
            logging.info("Received %d VMs in datalist" % (len(vmdatalist)))
            return vmdatalist
        else:
            raise Exception("Could not find virtualMachinesJSON \
                            in StoreFront response")

    def requestVirtualMachines(self, project_name = "SABREAPI", num_vms = 1):
        """Loads JSON template virtualMachine request for One-E StoreFront,
        prepares and submits request using supplied parameters,
        returns GUID for tracking requested virtualMachines"""
        request = json.loads('{"environment": {"application_name": "SABREAPI", "project_id_and_name":'
                             '"SABREAPI", "cost_centre": "100000001", "VirtualMachines": '
                             '[{"serviceGroupingId": 1, "VirtualMachineProperties": {"VirtualMachine.Disk1.Size": "50",'
                             '"VirtualMachine.Disk0.Size": "50", "Storefront.DataCentre": "West", "Storefront.Environment": "Test",'
                             '"Storefront.TemplateId": "c9d64d46-63b5-41ec-a3f2-5e463e477b19", '
                             '"TemplateId": "c9d64d46-63b5-41ec-a3f2-5e463e477b19",'
                             '"GroupId": "C8D21527-303E-4CFD-944B-BCA5A085A138"}}]}}')
        request['environment']['project_id_and_name'] = project_name
        for _ in range(1, num_vms):
            request['environment']['VirtualMachines'].append(request['environment']['VirtualMachines'][0])

        logging.info("Submitting request %s", request)
        response = self._session.post(self.url_env, data=json.dumps(request),
                                      headers={'Accept': 'application/json', 'Content-type': 'application/json'})
        objresponse = json.loads(response.content)
        logging.debug("Received response %s", objresponse)
        logging.info("RequestID = %s", objresponse["guid"])
        return objresponse["guid"]

    def getVirtualMachineDataListPolling(self, request_id, required_num_vms,
                                         required_state="On",
                                         time_limit_minutes=30):
        """Polls StoreFront every minute until timelimit (mins)
        or specified number of VMs are in specified state.
        Raises exception at timeout if request is not found,
        number or state of the VMs is not as expected"""
        logging.info("Starting polling for request_id=%s required_num_vms=%d" % (request_id,required_num_vms,))
        for idx in range(0, time_limit_minutes):
            vmdatalist = self.getVirtualMachineDataList()
            logging.info("Filtering by request_id=%s" % request_id)
            vmdatalist_by_request_id = [vmdata for vmdata in vmdatalist if str(vmdata['VirtualMachineProperties']['Storefront.EnvironmentID']) == request_id]
            for vmdata in vmdatalist_by_request_id:
                logging.info("Identified VM=%s in state=%s" % (vmdata['VirtualMachineName'], vmdata['VirtualMachineState']))

            vmdatalist_by_required_state = [vmdatabystate for vmdatabystate in vmdatalist_by_request_id if str(vmdata['VirtualMachineState']) == required_state]
            logging.info("Identified num_vms=%d matching required_state=%s" % (len(vmdatalist_by_required_state), required_state))
            if len(vmdatalist_by_required_state) <> required_num_vms:
                time.sleep(60)
            else:
                return vmdatalist_by_required_state

        raise Exception("Did not find required_num_vms=%d matching request_id=%s required_state=%s" % (required_num_vms, request_id, required_state))

