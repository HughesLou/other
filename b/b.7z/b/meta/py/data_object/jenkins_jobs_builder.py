from abc import ABCMeta, abstractmethod
from data_object.dynamicbase import DynamicBase, require, resolve
from jenkins_jobs import builder as jjb

@require(['jobs_path', 'branch_regex'])
@resolve(['jobs_path', 'branch_regex'])
class JenkinsJobs(DynamicBase):

    __metaclass__ = ABCMeta

    def __init__(self, **kwargs):
        super(JenkinsJobs, self).__init__(**kwargs)
        self._parser = None
        self.skip_incorrect_branches = []
        self._job_names = None


    @abstractmethod
    def get_parser(self, branch_name):
        '''
        Returns YamlParser. Overridden by subclasses.
        '''
        return None

    def set_project_parameters(self, parser_project):
        assert(isinstance(parser_project, dict))
        project = self.top_project

        parser_project['project'] = project
        parser_project['name'] = project.name
        # parser_project['node'] = getattr(project.jenkins, 'node', 'master')
        parser_project['git-url'] = project.repository.url

        return parser_project

    def job_names(self, branch_name):
        self.get_parser(branch_name)
        self._parser.generateXML()
        self._job_names = [job.name for job in self._parser.jobs]
        return self._job_names

    def generate_jobs(self, branch_name):
        #self.resolve_vars()

        if branch_name in self.skip_incorrect_branches:
            return []
        project = self.top_project
        jenkins = project.jenkins
        builder = jenkins.jj_builder
        # builder = jjb.Builder(jenkins_url=jenkins.url,
        #                       jenkins_user=jenkins.user_name,
        #                       jenkins_password=jenkins.user_token)
        # This call will set self._parser and generate job XMLs
        branch_jobs = self.job_names(branch_name)
        # This call will push jobs to Jenkins
        builder.update_jobs_from_parser(self._parser)
        return branch_jobs



