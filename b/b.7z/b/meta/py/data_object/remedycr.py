from data_object.dynamicbase import DynamicBase, resolve, require


@resolve(['jenkins_fields'])
class RemedyCr(DynamicBase):
    '''
    Class used to hold RemedyCr value
    '''
    def __init__(self, **kwargs):
        super(RemedyCr, self).__init__(**kwargs)

    def _load_staticfields(self, value):
        return value

    def _load_dynamicfields(self, value):
        return value

    def _load_jenkinsfields(self, value):
        return value

    @property
    def cr_dynamic_fields(self):
        params = []
        if getattr(self, 'dynamic_fields', None):
            for idx, field in enumerate(self.dynamic_fields):
                params.append({'text' if len(field.values()[0]) > 50 else 'string':
                              {'name': 'CR_FIELD_%s' % idx,
                               'description': field.keys()[0],
                               'default': field.values()[0]}})
        if getattr(self, 'jenkins_fields', None):
            for field in self.jenkins_fields:
                params.append({'string':
                              {'name': field['name'],
                               'description': field['description'],
                               'default': field['default']}})

        return params
