from data_object.dynamicbase import DynamicBase, require
from data_object.featurebranchstrategy import FeatureBranchStrategy
from data_object.passthroughbranchstrategy import PassthroughBranchStrategy
from data_object.trunkbranchstrategy import TrunkBranchStrategy


@require(['name', 'jenkins', 'repository', 'branch_strategy',
          'pipeline_build_name'])
class Project(DynamicBase):
    '''
    Project configuration items

    Required parameters:
    * name - project name
    * jenkins - Jenkins paramters
    * repo - List of VCS repositories

    Optional paramters can be passed and become object attributes
    '''
    def __init__(self, **kwargs):
        super(Project, self).__init__(**kwargs)
        self.env_name = ''

    # TODO: if we would have many more branching strategies
    #- this needs to be dynamic
    def _load_branchstrategy(self, value):
        value = value.lower()
        if value == 'feature-branches':
            return FeatureBranchStrategy(self)
        elif value == 'passthrough':
            return PassthroughBranchStrategy(self)
        elif value == 'trunk-based':
            return TrunkBranchStrategy(self)
        else:
            raise ValueError("Unknown strategy name: %s" % value)
