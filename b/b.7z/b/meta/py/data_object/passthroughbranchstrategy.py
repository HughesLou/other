from collections import OrderedDict
from data_object.branchstrategy import BranchStrategy
import logging

logger = logging.getLogger(__name__)


class PassthroughBranchStrategy(BranchStrategy):

    def __init__(self, project):
        self.project = project

    def on_push(self, branch_name, from_hash, to_hash):
        """
        This strategy will call build job with the same parameters it receives
        All work will be handled by pipeline jobs themselves
        """
        if branch_name is None:
            return

        branch_name = self.clean_branch_name(branch_name)
        jobs_invoke = self.project.jenkins.invoke
        logger.info("on push branch: %s" % branch_name)
        pipeline_job = '%s_%s_%s' % (self.project.name,
                                     self.project.pipeline_build_name,
                                     branch_name)

        jobs = OrderedDict()
        jobs[pipeline_job] = {'branch_name': branch_name,
                              'from_hash': from_hash,
                              'to_hash': to_hash}
        jobs_invoke(jobs, wait_for_jobs=False)

    def rebase(self, build_id, branch_regex, do_push=False, undo_rebase=False):
        logger.info('Rebase is not handled by passthrough strategy')
        return True

    def merge(self, branch_name, branch_regex, notes_path):
        logger.info('Merge is not handled by passthrough strategy')
        return True

    def undo_merge(self, branch_name, branch_regex):
        logger.info('undo_merge is not handled by passthrough strategy')
        return True

    def undo_rebase(self, build_id, branch_regex, do_push=False):
        logger.info('undo_rebase is not handled by passthrough strategy')
        return True
