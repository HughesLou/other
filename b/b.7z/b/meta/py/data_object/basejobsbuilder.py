import os
import logging
from os.path import join as jp
from jenkins_jobs.builder import YamlParser
from jenkins_jobs_builder import JenkinsJobs
from dynamicbase import resolve

log = logging.getLogger(__name__)

@resolve(['branch_regex'])
class BaseJobsBuilder(JenkinsJobs):
    def __init__(self, **kwargs):
        super(BaseJobsBuilder, self).__init__(**kwargs)
        self._parser = None

    def get_parser(self, branch_name='master'):
        project = self.top_project

        jobs_def = {'project': {}}
        prj = jobs_def['project'][project.name] = {}
        self.set_project_parameters(prj)
        parser = YamlParser()
        parser.data = jobs_def

        # Try to read basejobs.yaml from project's repo
        # if it is there - use it
        # if it is not - use one from bootstrap
        save_cwd = os.getcwd()
        os.chdir(project.repository.expanded_master_repo)
        project.repository.checkout_branch(branch_name)
        os.chdir(save_cwd)
        project_basejobs_path = jp(project.repository.expanded_master_repo,
                                   project.jobs_path,
                                   'basejobs.yaml')
        project_def_path = jp(self.jobs_path, 'projects/%s' % project.name)
        if os.path.exists(project_basejobs_path):
            log.warning("Using basejobs.yaml from project repository")
            parser.parse(project_basejobs_path)
            os.chdir(save_cwd)
        elif os.path.exists(jp(project_def_path, 'basejobs.yaml')):
            log.warning("Using basejobs.yaml from project configuration")
            parser.parse(jp(project_def_path, 'basejobs.yaml'))
        else:
            parser.parse(jp(self.jobs_path, 'basejobs.yaml'))

        prj['jobs'] = parser.data['job-group']

        self._parser = parser
        return parser
