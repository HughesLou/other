from jenkins_jobs.builder import YamlParser


def parse_yaml_file(file_name):
    parser = YamlParser()
    parser.parse(file_name)
    return parser.data