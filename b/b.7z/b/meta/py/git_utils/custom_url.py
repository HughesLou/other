

def url_concat(*args):
    if len(args) == 0:
        return ""

    parts = [_remove_suffix_slashes(args[0])]
    for arg in args[1:]:
        parts.append(_remove_slashes(arg))
    return '/'.join(parts)


def _remove_suffix_slashes(text):
    url = text
    while len(url) > 0:
        if url[len(url) - 1] == '/':
            url = url[0:len(url) - 1]
        else:
            break
    return url


def _remove_prefix_slashes(text):
    url = text
    while len(url) > 0:
        if url[0] == '/':
            url = url[1:len(url)]
        else:
            break
    return url


def _remove_slashes(text):
    text = _remove_prefix_slashes(text)
    return _remove_suffix_slashes(text)