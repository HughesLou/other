#!/bin/bash
set -a

BOOTSTRAP_GIT_UTILS_PATH=../bootstrap/meta/py/git_utils

# Reset repo
function reset_repo() {
    git checkout master
    git reset --hard d6376ce
    git branch -D branch1
    git push origin :branch1
    git branch -D branch2
    git push origin :branch2
    git branch -D branch3
    git push origin :branch3
    git push --force
    git --no-pager lol --all
}

function commit_and_push() {
    branch=$1

    git checkout $branch
    echo "Commit change on $branch and push it"
    od -An -N2 -i /dev/random >> random_$branch.txt
    git add random_$branch.txt
    git commit -m "Random commit on branch $branch"
    git push origin $branch
}

reset_repo

echo "-- TEST1"
echo "-- testing if custom_git will create local tracking branch"
echo "-- "
echo "Create branch1"
git checkout -b branch1 master
git --no-pager lol --all

echo "Commit change on branch1 and push it"
commit_and_push 'branch1'

echo "Commit and push on master"
commit_and_push 'master'

echo "Commit change on branch2 and push"
git checkout -b branch2 master
commit_and_push 'branch2'

echo "Removing local branch2"
git co master
git branch -D branch2
git --no-pager lol --all
echo "local branch2 has been deleted. Running python clean will create it."
read sss

python $BOOTSTRAP_GIT_UTILS_PATH/custom_git.py -b branch2 clean
git --no-pager lol --all
echo "branch2 local shall be present"
read sss

echo "-- TEST2"
echo "-- testing rebase for one branch"
echo "-- "
echo "Local commit in branch1"
git co branch1
echo "aaa" > file2_on_branch1 ; git add file2_on_branch1 ; git commit -m "2 added on branch1"
echo "History after local commit on branch1"
git --no-pager lol --all
read sss

echo "Running python: clean rebase push"
python $BOOTSTRAP_GIT_UTILS_PATH/custom_git.py -b branch1 clean rebase push
git --no-pager lol --all
echo "History after branch1 rebase: commit '2 added on branch1' should be gone"
echo "branch1 shall have commit '1 added on master' followed by '1 added on branch1'"
echo "remote/branch1 shall point to '1 added to branch1'"
read sss

echo "-- TEST3"
echo "-- testing rebase on already rebased branch"
echo "-- "
echo "Running rebase again to check that it will do nothing"
echo "Running python: clean rebase push"
python $BOOTSTRAP_GIT_UTILS_PATH/custom_git.py -b branch1 clean rebase push
git --no-pager lol --all
echo "History after branch1 rebase: commit '2 added on branch1' should be gone"
echo "branch1 shall have commit '1 added on master' followed by '1 added on branch1'"
echo "remote/branch1 shall point to '1 added to branch1'"
read sss

echo "-- TEST4"
echo "-- Testing branch closure"
echo "-- Creating branch branch2, comitting one change to it"
echo "-- Merging it to master"
echo "-- And deleting branch locally and on remote"
reset_repo

echo "Doing two commits in origin/branch1"
git checkout -b branch1
commit_and_push 'branch1'
commit_and_push 'branch1'
git --no-pager lol --all
echo "Shall have origin/branch1 with two commits"
read sss

echo "Running python and closing branch1"
python $BOOTSTRAP_GIT_UTILS_PATH/custom_git.py -b branch1 close
# git checkout master
# git branch -D branch1
# git pull
# git merge --no-commit --squash origin/branch1 
# git commit -m "branch1: merged"
git --no-pager lol --all
echo "Shall have commit from branch to in master"
echo "Shall not have origin/branch1"
echo "Shall have 'branch1: merged' commit in master"
read sss

reset_repo

echo "-- TEST5"
echo "-- Test of rebase from master on single branch where we have two commits"
echo "-- Result shall be branch with master commit and two of branch commits on top of it"
echo
echo "Doing commit on branch1 and push"
git checkout -b branch1
commit_and_push 'branch1'

echo "Doing commit on master and push"
commit_and_push 'master'

echo "Doing commit on barch1 and push"
commit_and_push 'branch1'

echo "Running python rebase on branch1"
python $BOOTSTRAP_GIT_UTILS_PATH/custom_git.py -b branch1 clean rebase
git --no-pager lol --all
echo "branch1 shall have commit 'file1 added on master' followed by two commits"
read sss

reset_repo

echo "-- TEST6"
echo "-- Test of rebase from master on multiple branches where we have two commits"
echo "-- Result shall be branch with master commit and two of branch commits on top of it"
echo
echo "Doing 2 commits on branch1 and push"
git checkout -b branch1 master
commit_and_push 'branch1'
commit_and_push 'branch1'

echo "Doing 2 commits on branch2 and push"
git checkout -b branch2 master
commit_and_push 'branch2'
commit_and_push 'branch2'

git checkout -b branch3 master
echo "Doing 2 commits on branch3 and push"
commit_and_push 'branch3'
commit_and_push 'branch3'

echo "Doing commit on master and push"
commit_and_push 'master'

echo "Doing commit on barch1 and push"
commit_and_push 'branch1'

git --no-pager lol --all
echo "Before running rebase for multiple branches"
read sss

echo "Running python rebase on ALL branches"
echo "python $BOOTSTRAP_GIT_UTILS_PATH/custom_git.py -b all clean rebase"
python $BOOTSTRAP_GIT_UTILS_PATH/custom_git.py -b all clean rebase push
git --no-pager lol --all
echo "branch1 shall have commit 'file1 added on master' followed by 3 commits"
echo "branch2 shall have commit 'file1 added on master' followed by two commits"
echo "branch3 shall have commit 'file1 added on master' followed by two commits"

echo "-- TEST7"
echo "-- Test of rebase from master on multiple branches where we have two commits"
echo "-- but now two branches are not locally exist before rebase"
echo "-- Result shall be branch with master commit and two of branch commits on top of it"
echo
echo "Doing 2 commits on branch1 and push"
git checkout -b branch1 master
commit_and_push 'branch1'
commit_and_push 'branch1'

echo "Doing 2 commits on branch2 and push"
git checkout -b branch2 master
commit_and_push 'branch2'
commit_and_push 'branch2'

git checkout -b branch3 master
echo "Doing 2 commits on branch3 and push"
commit_and_push 'branch3'
commit_and_push 'branch3'

echo "Doing commit on master and push"
commit_and_push 'master'

git branch -D branch2
git branch -D branch3

echo "Doing commit on barch1 and push"
commit_and_push 'branch1'

git --no-pager lol --all
echo "Before running rebase for multiple branches"
read sss

echo "Running python rebase on ALL branches"
echo "python $BOOTSTRAP_GIT_UTILS_PATH/custom_git.py -b all clean rebase push"
python $BOOTSTRAP_GIT_UTILS_PATH/custom_git.py -b all clean rebase push
git --no-pager lol --all
echo "branch1 shall have commit 'file1 added on master' followed by 3 commits"
echo "branch2 shall have commit 'file1 added on master' followed by two commits"
echo "branch3 shall have commit 'file1 added on master' followed by two commits"
