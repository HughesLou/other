import os
import subprocess
import subprocess_helper
import logging

log = logging.getLogger(__name__)


class SvnCommand(subprocess_helper.SubprocessHelper):
    '''Class to find and execute Svn'''

    def __init__(self, tmp_dir="/tmp", svn_home=''):
        self.svn_home = svn_home
        subprocess_helper.SubprocessHelper.__init__(self)
        self.tmp_dir = tmp_dir

    def _find_executable(self):
        svn_paths = self._svn_on_unix()
        # Keep env_ as last in list, or the error handling will break
        for svn_path in svn_paths:
            if os.path.exists(svn_path):
                return svn_path

        raise Exception("Could not find svn in any of the locations: " +
                        str(svn_path))

    def run(self, args, async=False, msg=None, cmd_msg=None,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE):
        if isinstance(args, str):
            args = [args]

        cmd_msg = None if os.environ.get('SVN_PYTHON_TRACE', 'false').lower() == 'true' else ''
        return self._svn_run(args, async, msg=None, cmd_msg=cmd_msg,
                             stdout=stdout, stderr=stderr)

    def _svn_run(self, args, async, msg, cmd_msg, stdout, stderr):
        params = [self._executable_path]
        for arg in args:
            params.append(arg)
        if cmd_msg is None:
            silent_errors = False
            silent_out = False
        else:
            silent_errors = True
            silent_out = True
        return self._run(params, async, msg, cmd_msg,
                         stdout=stdout, stderr=stderr, silent_out=silent_out,
                         silent_errors=silent_errors)

    def _svn_on_unix(self):
        return ['/shared/opt/tools/bin/svn', '/usr/bin/svn']
