import os
import subprocess_helper
import logging

log = logging.getLogger(__name__)


class GitCommand(subprocess_helper.SubprocessHelper):
    '''Class to find and execute Ant'''

    def __init__(self, tmp_dir="/tmp", git_home=''):
        self.git_home = git_home
        subprocess_helper.SubprocessHelper.__init__(self)
        self.tmp_dir = tmp_dir

    def _find_executable(self):
        git_locations = [self._git_on_unix(), self._git_on_windows()]
        # Keep env_ as last in list, or the error handling will break
        for git_path in git_locations:
            if os.path.exists(git_path):
                return git_path

        raise Exception("Could not find git in any of the locations: " +
                        str(git_locations))

    def run(self, url=None, args=(), async=False, msg=None, cmd_msg=None,
            stdout=None, stderr=None):
        if isinstance(args, str):
            args = [args]

        cmd_msg = None if os.environ.get('GIT_PYTHON_TRACE', 'false').lower() == 'true' else ''
        if url is not None:
            try:
                try_url = self._url_with_ssh_prefix(url)
                return self._git_run(try_url, args, async, msg,
                                     cmd_msg=cmd_msg,
                                     stdout=stdout, stderr=stderr)
            except subprocess_helper.SubProcessException:
                try_url = self._url_without_ssh_prefix(url)
                return self._git_run(try_url, args, async, msg,
                                     cmd_msg=cmd_msg,
                                     stdout=stdout, stderr=stderr)
        else:
            res = self._git_run(None, args, async, msg=None, cmd_msg=cmd_msg,
                                 stdout=stdout, stderr=stderr)
            return res

    def _git_run(self, url, args, async, msg, cmd_msg, stdout, stderr):
        params = [self._executable_path]
        for arg in args:
            params.append(arg)
        if url is not None:
            if 'clone' in params:
                path = params[2]
                params[2] = url
                params.append(path)
            else:
                params.append(url)
        if cmd_msg is None:
            silent_errors = False
            silent_out = False
        else:
            silent_errors = True
            silent_out = True

        out = err = ''
        try:
            out, err = self._run(params, async, msg, cmd_msg,
                                 stdout=stdout, stderr=stderr,
                                 silent_out=silent_out,
                                 silent_errors=silent_errors)
        except subprocess_helper.SubProcessException as se:
            log.warning('Error executing git %s \n'
                        'stdout: %s \n'
                        'stderr: %s' % (' '.join(params), se.stdout,
                                        se.stderr))
            return (se.stdout, se.stderr)

        return (out, err)

    def _url_with_ssh_prefix(self, url):
        url_prefixed = 'ssh://' in url
        return url if url_prefixed else 'ssh://' + url

    def _url_without_ssh_prefix(self, url):
        url_prefixed = 'ssh://' in url
        return url[6:] if url_prefixed else url

    def _git_on_unix(self):
        return '/usr/bin/git'

    def _git_on_windows(self):
        return self._resolve_command_path_on_windows('git')

    def _resolve_command_path_on_windows(self, executable):
        if os.path.sep in executable:
            raise ValueError("Invalid filename: %s" % executable)

        path = os.environ.get("PATH", "").split(os.pathsep)
        # PATHEXTS tells us which extensions an executable may have
        path_exts = os.environ.get("PATHEXTS", ".exe;.bat;.cmd").split(";")
        has_ext = os.path.splitext(executable)[1] in path_exts
        if not has_ext:
            exts = path_exts
        else:
            # Don't try to append any extensions
            exts = [""]

        for d in path:
            try:
                for ext in exts:
                    exepath = os.path.join(d, executable + ext)
                    if os.access(exepath, os.X_OK):
                        return exepath
            except OSError:
                pass

        return None
