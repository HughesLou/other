import os
import shutil
import mock
import unittest
import subprocess
import subprocess_helper

from git_utils.git_command import GitCommand
from git_utils.custom_git import CustomGit


class test_custom_git(unittest.TestCase):
    TEST_REPO_URL = 'ssh://git@stash/cd/test.git'
    TMP_REPO_PATH = '/tmp/custom_git'

    class OdCommand(subprocess_helper.SubprocessHelper):
        '''Class to find and execute Ant'''

        def __init__(self, tmp_dir="/tmp", git_home=''):
            self.git_home = git_home
            subprocess_helper.SubprocessHelper.__init__(self)
            self.tmp_dir = tmp_dir

        def _find_executable(self):
            git_locations = ['/usr/bin/od']
            # Keep env_ as last in list, or the error handling will break

            for git_path in git_locations:
                if os.path.exists(git_path):
                    return git_path

            raise Exception("Could not find od in any of the locations: " +
                            str(git_locations))

        def run(self, args=(), async=False, msg=None, cmd_msg=None,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE):
            params = [self._executable_path]
            for arg in args:
                params.append(arg)
            return self._run(params, async, msg, cmd_msg,
                             stdout=stdout, stderr=stderr)

    def setUp(self):
        print '=== Setup start ===='
        if os.path.exists(self.TMP_REPO_PATH):
            shutil.rmtree(self.TMP_REPO_PATH)
        self.git = GitCommand()
        self.git.run(args=['clone',
                           self.TEST_REPO_URL,
                           self.TMP_REPO_PATH],
                     stdout=subprocess.PIPE,
                     stderr=subprocess.PIPE)
        self.saved_path = os.getcwd()
        os.chdir('/tmp/custom_git')
        print '=== Setup end ===='

    def _git(self, args):
        return self.git.run(args=args, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE)

    def _random_commit(self, branch_name):
        self._git(['checkout', branch_name])

        od = self.OdCommand()
        out, __ = od.run(['-An', '-N2', '-i', '/dev/random'])
        with open('random.txt', 'w+') as f:
            f.write(out)
        out, err = self._git(['add', 'random.txt'])
        out, err = self._git(['commit', '-m', '%s: Random commit' % branch_name])

    def _log(self):
        out, err = self._git(['log', '--pretty=oneline', '--abbrev-commit'])
        messages = []
        for line in out.split('\n'):
            commit_sha = line[:6]
            commit_msg = line[8:]
            print '%s %s' % (commit_sha, commit_msg)
            messages.append(commit_msg)

        return messages

    def tearDown(self):
        print '== Tear down start ==='
        self._git(['checkout', 'unit_tests'])
        self._git(['reset', '--hard', 'd6376ce'])
        self._git(['push', '--force', 'origin', 'unit_tests'])
        self._git(['checkout', 'master'])
        self._git(['reset', '--hard', 'd6376ce'])
        self._git(['push', '--force', 'origin', 'master'])
        branches = self._git(['branch'])[0].split('\n')
        branches = [name[2:] for name in branches]
        if 'merge_test' in branches:
            self._git(['branch', '-D', 'merge_test'])
            self._git(['push', 'origin', ':merge_test'])
        os.chdir(self.saved_path)
        if os.path.exists('/tmp/this_will_be_notes.txt'):
            os.remove('/tmp/this_will_be_notes.txt')
        if os.path.exists(self.TMP_REPO_PATH):
            shutil.rmtree(self.TMP_REPO_PATH)
        print '== Tear down end ==='

    def test_init(self):
        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path='/tmp/custom_git',
                       branch='master')

        out, err = self._git('status')
        self.assertEquals(out, '# On branch master\nnothing to commit (working directory clean)\n')

    def test_init_no_local_branch(self):
        self._git(['checkout', '-b', 'unit_tests', 'origin/unit_tests'])
        self._random_commit('unit_tests')
        self._git(['push', 'origin', 'unit_tests'])
        self._git(['checkout', 'master'])
        self._git(['branch', '-D', 'unit_tests'])

        out, __ = self._git(['branch'])
        for line in out.split('\n'):
            if line:
                print 'branch: ', line
                self.assertNotIn(line, 'unit_tests')

        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path='/tmp/custom_git',
                       branch='unit_tests')

        out, __ = self._git(['branch'])
        for line in out.split('\n'):
            print 'branch: ', line
            star = line[0]
            if star == '*':
                self.assertEquals(line[2:], 'unit_tests')
                break

        messages = self._log()
        self.assertEquals(messages[0], 'unit_tests: Random commit')

    def test_init_notsync_local_branch(self):
        self.git = GitCommand()
        self.git.run(args=['clone', 'ssh://git@stash/cd/test.git',
                     '/tmp/custom_git2'], stdout=subprocess.PIPE,
                     stderr=subprocess.PIPE)
        saved_path = os.getcwd()
        os.chdir('/tmp/custom_git2')
        self._git(['checkout', '-b', 'unit_tests', 'origin/unit_tests'])
        self._random_commit('unit_tests')
        self._git(['push', 'origin', 'unit_tests'])
        os.chdir(saved_path)
        shutil.rmtree('/tmp/custom_git2')

        print 'Back to original repo'
        self._git(['checkout', 'unit_tests'])
        out, __ = self._git('status')
        print out
        messages = self._log()
        self.assertEquals(messages[0], 'FMSDCD-29 Added line to test JIRA integration')

        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path='/tmp/custom_git',
                       branch='unit_tests')

        out, __ = self._git(['branch'])
        for line in out.split('\n'):
            print 'branch: ', line
            star = line[0]
            if star == '*':
                self.assertEquals(line[2:], 'unit_tests')
                break

        messages = self._log()
        self.assertEquals(messages[0], 'unit_tests: Random commit')
        self.assertEquals(messages[1], 'FMSDCD-29 Added line to test JIRA integration')

    def test_clean_untracked_files(self):
        od = self.OdCommand()
        out, __ = od.run(['-An', '-N2', '-i', '/dev/random'])
        with open('untracked_file.txt', 'w+') as f:
            f.write(out)

        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path='/tmp/custom_git',
                       branch='unit_tests')
        cg.git_clean('unit_tests')

        out, err = self._git('status')
        self.assertEquals(out, '# On branch unit_tests\nnothing to commit (working directory clean)\n')

    def test_clean_comitted_files(self):
        self._random_commit('unit_tests')

        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path='/tmp/custom_git',
                       branch='unit_tests')
        print 'Log before clean'
        self._log()

        cg.git_clean('unit_tests')

        out, err = self._git('status')
        self.assertEquals(out, '# On branch unit_tests\nnothing to commit (working directory clean)\n')
        print 'Log after clean'
        messages = self._log()
        for line in messages:
            self.assertNotIn('Random commit', line)

    def test_create_new_local_branch(self):
        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path='/tmp/custom_git',
                       branch='master')
        cg.git_create_new_local_branch('branch1')

        out, err = self._git(['branch'])
        self.assertEquals(out, '* branch1\n  master\n')

    def test_rebase_one_branch(self):
        self._random_commit('master')
        self._git(['push', 'origin', 'master'])

        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path='/tmp/custom_git',
                       branch='unit_tests')

        cg.rebase(build_id='test_build')

        messages = self._log()
        self.assertEquals(messages[0], 'master: Random commit')
        self.assertEquals(messages[1], 'FMSDCD-29 Added line to test JIRA integration')

    def test_push(self):
        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path='/tmp/custom_git',
                       branch='unit_tests')

        self._random_commit('unit_tests')
        messages = self._log()
        self.assertEquals(messages[0], 'unit_tests: Random commit')

        cg.push()

        self._git(['checkout', 'master'])
        self._git(['branch', '-D', 'unit_tests'])
        self._git(['checkout', '-b', 'unit_tests', 'origin/unit_tests'])

        messages = self._log()
        self.assertEquals(messages[0], 'unit_tests: Random commit')
        self.assertEquals(messages[1], 'FMSDCD-29 Added line to test JIRA integration')

    def test_close_branch(self):
        self._git(['checkout', '-b', 'merge_test'])
        self._random_commit('merge_test')
        self._random_commit('merge_test')
        self._random_commit('merge_test')
        self._git(['push', 'origin', 'merge_test'])
        self._git(['checkout', 'master'])
        self._git(['branch', '-D', 'merge_test'])

        with open('/tmp/this_will_be_notes.txt', 'w+') as f:
            f.write('This is a line 1 of notes for merge from branch merge_branch\n')
            f.write('This is a line 2 of notes for merge from branch merge_branch\n')
            f.write('This is a line 3 of notes for merge from branch merge_branch\n')

        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path='/tmp/custom_git',
                       branch='merge_test')

        cg.merge_and_close('/tmp/this_will_be_notes.txt')

        self._git(['checkout', 'unit_tests'])
        self._git(['branch', '-D', 'master'])
        self._git(['checkout', '-b', 'master', 'origin/master'])

        # import pdb; pdb.set_trace()
        messages = self._log()
        self.assertEquals(messages[0], 'merge_test: merging and closing branch')
        self.assertEquals(messages[1], 'FMSDCD-29 Added line to test JIRA integration')

        out, err = self._git(['branch', '-a'])
        for line in out.split('\n'):
            self.assertNotIn('merge_test', line)

        commit_lines = []
        out, __ = self._git('log')
        for i, line in enumerate(out.split('\n')):
            if i == 11:
                break
            commit_lines.append(line)

        self.assertEquals(commit_lines[4], '    merge_test: merging and closing branch')
        self.assertEquals(commit_lines[5], '')
        self.assertEquals(commit_lines[6], 'Notes:')
        self.assertEquals(commit_lines[7], '    This is a line 1 of notes for merge from branch merge_branch')
        self.assertEquals(commit_lines[8], '    This is a line 2 of notes for merge from branch merge_branch')
        self.assertEquals(commit_lines[9], '    This is a line 3 of notes for merge from branch merge_branch')
        self.assertEquals(commit_lines[10], '')

    def test_close_branch_no_notes(self):
        self._git(['checkout', '-b', 'merge_test'])
        self._random_commit('merge_test')
        self._random_commit('merge_test')
        self._random_commit('merge_test')
        self._git(['push', 'origin', 'merge_test'])
        self._git(['checkout', 'master'])
        self._git(['branch', '-D', 'merge_test'])

        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path='/tmp/custom_git',
                       branch='merge_test')

        with self.assertRaises(Exception) as ex:
            cg.merge_and_close('this_will_be_notes.txt')

    def test_close_branch_empty_notes(self):
        self._git(['checkout', '-b', 'merge_test'])
        self._random_commit('merge_test')
        self._random_commit('merge_test')
        self._random_commit('merge_test')
        self._git(['push', 'origin', 'merge_test'])
        self._git(['checkout', 'master'])
        self._git(['branch', '-D', 'merge_test'])

        with open('/tmp/this_will_be_notes.txt', 'w+') as f:
            pass

        cg = CustomGit(origin_url='ssh://git@stash/cd/test.git',
                       repo_path='/tmp/custom_git',
                       branch='merge_test')

        with self.assertRaises(Exception) as ex:
            cg.merge_and_close('/tmp/this_will_be_notes.txt')
