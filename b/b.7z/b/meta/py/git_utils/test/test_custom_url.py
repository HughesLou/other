from unittest import TestCase
from git_utils.custom_url import url_concat


class CustomUrlTest(TestCase):

    def test_to_concat_parts_without_slash_to_url(self):
        url = url_concat('www.happy.com', 'index.html')

        self.assertEquals('www.happy.com/index.html', url)

    def test_to_concat_parts_that_the_first_one_suffix_with_slashes(self):
        url = url_concat('www.happy.com//', 'index.html')

        self.assertEquals('www.happy.com/index.html', url)

    def test_to_concat_parts_that_the_second_one_prefix_with_slashes(self):
        url = url_concat('www.happy.com', '//index.html')

        self.assertEquals('www.happy.com/index.html', url)

    def test_to_concat_parts_with_slashes(self):
        url = url_concat('www.happy.com/', '/index.html')

        self.assertEquals('www.happy.com/index.html', url)

    def test_to_remove_last_slash_when_only_one_item_do_concat(self):
        url = url_concat('www.happy.com/')

        self.assertEquals('www.happy.com', url)

    def test_to_return_empty_string_when_no_item_concat(self):
        url = url_concat()

        self.assertEquals("", url)