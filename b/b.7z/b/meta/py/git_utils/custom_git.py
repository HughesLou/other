import os
from os.path import join as jp
import logging
import subprocess
from subprocess_helper import SubProcessException

from git_utils.git_command import GitCommand

logger = logging.getLogger(__name__)


class CustomGit(object):
    def __init__(self, origin_url, repo_path='./', branch='master', sha=None):
        logger.debug('Git repo path is %s' % repo_path)
        self.repo_path = repo_path
        self.origin_heads_url = origin_url
        # import pudb;pu.db
        self.origin_heads = self._origin_branches()
        self.local_heads = self._local_branches()
        self.git_cmd = GitCommand()
        self.branch_name = branch
        self.git_fetch()
        if sha is None:
            self.long_sha = self.origin_heads[branch]
            self.sha = self.long_sha[:7]
        else:
            self.sha = sha
        # print 'DEBUG: finished getting sha for %s/head' % branch
        self.dont_push = False
        # print 'DEBUG: self.repo.heads = %s' % [self.local_heads.iterkeys()]
        self.safe_checkout(self.branch_name)

    def safe_checkout(self, branch_name):
        self.branch_name = branch_name
        if self.branch_name not in self.local_heads.iterkeys():
            logger.debug('no local branch %s' % branch_name)
            # There is no such local branch. We need to check if origin has it
            # and if origin doesn't - fail
            if self.branch_name not in self.origin_heads.iterkeys():
                raise Exception('Branch "%s" does not exist' %
                                self.branch_name)
            else:
                logger.info('Local branch "%s" doesn''t exist. Creating...' %
                            self.branch_name)
                # There is remote branch, so we need to create local
                # self.branch = Head.create(self.repo, branch,
                #                           self.origin_heads.
                #                           refs[self.branch_name].commit)
                self.git_create_local_branch()
                logger.debug('local branch %s created' % self.branch_name)
        else:
            # We can't fast forward current branch, so if we are on master
            # it is safe to pull it, but for other branches we switch to
            # master and fast forward them
            if self.branch_name == 'master':
                logger.debug(' Checkout master')
                self.git_checkout('master')
                if self.local_heads['master'] != self.origin_heads['master']:
                    logger.debug(' Pull master')
                    self._git(['pull', 'origin', 'master'])
            else:
                if self.local_heads[self.branch_name] != \
                        self.origin_heads[self.branch_name]:
                    logger.debug('Checkout master')
                    self.git_checkout('master')
                    logger.debug('Fast forwarding branch %s'
                                 % self.branch_name)
                    self.git_fast_forward_branch()
                logger.debug(' Checkout %s' % self.branch_name)
                self.git_checkout()

    def _git(self, args):
        saved_cwd = os.getcwd()
        os.chdir(self.repo_path)
        cmd = GitCommand()
        out, err = cmd.run(args=args,
                           stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE)
        os.chdir(saved_cwd)
        if err:
            if 'insufficient permissions' in err:
                logger.error('Insufficient permissions for "git %s": %s. '
                             'Skipping.'
                             % (' '.join(args), err))
        return out, err

    def git_clone(self, url, repo_location):
        if os.path.exists(repo_location) and os.path.exists(jp(repo_location,
                                                               '.git')):
            logger.debug("Master repo folder '%s' already exists. Not cloning."
                         % repo_location)
            return
        self._git(args=['clone', url, repo_location])

    def git_fetch(self):
        self._git(args=['fetch', 'origin'])

    def git_fast_forward_branch(self):
        self._git(args=['branch', '-l', '-f', self.branch_name,
                  '-t', 'origin/%s' % self.branch_name])

    def git_delete_branch(self, branch_name=None, del_remote=False):
        branch_name = self.branch_name if branch_name is None else branch_name
        self.git_checkout('master')
        self._git(args=['branch', '-D', branch_name])
        if del_remote:
            self._git(['push', 'origin', ':%s' % branch_name])

    def git_push(self, branch_name=None):
        branch_name = self.branch_name if branch_name is None else branch_name
        self._git(args=['push', '--force', 'origin', branch_name])

    def git_add_notes(self, notes_path):
        self._git(args=['notes', 'add', '-F', notes_path])

    def git_commit(self, msg):
        self._git(args=['commit', '-m', msg])

    def git_create_local_branch(self):
        self.git_clean('master')
        self._git(args=['checkout', '-q', '-b', self.branch_name,
                  'origin/%s' % self.branch_name])

    def git_create_new_local_branch(self, branch_name):
        self._git(args=['checkout', '-q', '-b', branch_name, 'master'])

    def git_checkout(self, branch_name=None):
        branch_name = self.branch_name if branch_name is None else branch_name
        self._git(args=['checkout', '-q', branch_name])

    def git_clean(self, branch_name):
        branch_name = self.branch_name if branch_name is None else branch_name
        self._git(args=['checkout', '-q', branch_name])
        self._git(args=['reset', '--hard', 'origin/%s' % branch_name])
        self._git(args=['clean', '-f', '-d'])

        return True

    def git_merge(self, branch_name, ff_only=True):
        branch_name = self.branch_name if branch_name is None else branch_name
        if ff_only:
            out, err = self._git(args=['merge', '--ff-only',
                                 '--squash', '--no-commit',
                                 'origin/%s' % branch_name])
        else:
            out, err = self._git(args=['merge'])

    def _clean_one(self, branch_name):
        self.git_clean(branch_name)
        return True

    def _clean_many(self, branch_list):
        for branch in branch_list:
            self._clean_one(branch)
        return True

    def clean_all(self):
        for branch in self.local_heads.iterkeys():
            self._clean_one(branch)
        return True

    def clean(self):
        logger.debug('Cleaning master and %s' % self.branch_name)
        self._git(['fetch'])
        # self.origin_heads.fetch()

        self._clean_many(['master', self.branch_name])
        return True

    def rebase(self, build_id, local_only=True):
        '''
        Checks if branch already rebased with origin/master/HEAD
        if it doesn't - it will rebase
        if there is a conflict - will abort rebase
        '''
        # print 'DEBUG: custom_git.rebase.checkout'

        self.git_checkout()
        # print 'DEBUG: custom_git.rebase.merge_base'
        merge_base, _ = self._git(['merge-base',
                                   self.branch_name,
                                   'origin/master'])
        master_head = self.origin_heads['master']
        # print 'DEBUG: %s: branch merge base(%s) \
# == master/HEAD(%s)' % (self.branch_name, merge_base[:8], master_head[:8])
        if merge_base != master_head:
            behind, __ = self._git(['rev-list', '--count',
                                   'refs/heads/%s..refs/remotes/origin/master'
                                    % self.branch_name])
            behind = int(behind)
            ahead, __ = self._git(['rev-list', '--count',
                                  'refs/remotes/origin/master..refs/heads/%s'
                                  % self.branch_name])
            ahead = int(ahead)
            if behind > 0:
                logger.info('Branch %s (%s) is %s commits '
                            'behind master (%s). Rebasing...' %
                            (self.branch_name, merge_base[:8],
                             behind, master_head[:8]))
                try:
                    out, err = self._git(['rebase', '-s', 'recursive',
                                         '-X', 'theirs', 'master'])
                    if err.strip() != '':
                        logger.debug('Git returned stdout="%s", stderr="%s"'
                                     % (out, err))
                        logger.warn("Merge conflict. Run rebase manually")
                        self._git(['rebase', '--abort'])
                        self.dont_push = True
                        return False

                    # import pdb; pdb.set_trace()
                    # Save reference to this rebase
                    self._git(['update-ref',
                               'refs/tags/rebase/%s/%s' %
                               (build_id, self.branch_name),
                               self.sha])
                    if not local_only:
                        self._git(['push', '--force', 'origin',
                                   'refs/tags/rebase/%s/%s' %
                                   (build_id, self.branch_name)])
                except SubProcessException:
                    logger.warn("Merge conflict. Run rebase manually")
                    self._git(['rebase', '--abort'])
                    self.dont_push = True
                    return False
            else:
                logger.info('Branch %s is already rebased' %
                            (self.branch_name))

        else:
            logger.info('%s is already rebased: branch merge base(%s) \
== master/HEAD(%s)' % (self.branch_name, merge_base[:8], master_head[:8]))
            self.dont_push = True

        return True

    def undo_rebase(self, build_id, branch_name=None, local_only=True):
        '''
        Checks if branch already rebased with origin/master/HEAD
        if it doesn't - it will rebase
        if there is a conflict - will abort rebase
        '''
        # print 'DEBUG: custom_git.rebase.checkout'

        branch_name = self.branch_name if branch_name is None else branch_name
        self.git_checkout(branch_name)
        ref_name = 'refs/tags/rebase/%s/%s' % (build_id, self.branch_name)
        if not local_only:
            self._git(['pull', 'origin', ref_name])

        out, __ = self._git(['show-ref', ref_name])
        if out.strip() == '':
            logger.warning('Ref %s for build "%s" does '
                           'not exist. \n'
                           'Either branch already rebased outside jenkins'
                           ' or something wrong with it. Check manually.' %
                           (ref_name, build_id))
            # raise Exception('Ref %s for build "%s" does '
            #                 'not exist. \n'
            #                 'Is it a correct build id or branch?' %
            #                 (ref_name, build_id))
            return False

        self._git(['reset', '--hard', ref_name])
        self._git(['update-ref', '-d', ref_name])
        if not local_only:
            out, err = self._git(['push', 'origin', ':%s' % ref_name])
            if err.strip() != '':
                logger.warning('Undo Rebase Push failed with %s' % err)
                return False

        return True

    def push(self, branch_name=None):
        branch_name = self.branch_name if branch_name is None else branch_name
        if self.dont_push:
            logger.debug('Push requested, but not pushing %s, '
                         'because previous operation instructed not to do so.'
                         % self.branch_name)
        else:
            logger.info('Pushing %s' % self.branch_name)
            self.git_push(branch_name)

        return True

    def merge(self, notes_path=None, to_branch='master'):
        '''
        Merges and closes branch. Automatically pushes result to origin.
        '''
        self.git_clean('master')
        merge_base, _ = self._git(['merge-base',
                                   self.branch_name,
                                   'origin/master'])
        master_head = self.origin_heads['master']
        # import pdb; pdb.set_trace()
        logger.debug('merg_b=%s, master_head=%s' % (merge_base, master_head))
        logger.debug('type merg_b=%s,'
                     ' type master_head=%s' % (type(merge_base),
                                               type(master_head)))
        if merge_base.strip() != master_head.strip():
            raise Exception('Branch %s(%s) is not based on current master '
                            'head(%s). Rebase has not been done properly.'
                            % (self.branch_name, merge_base[:7],
                               master_head[:7]))
        notes = None
        if notes_path is None:
            raise Exception('Cannot close branch w/o notes')
        try:
            # import pdb; pdb.set_trace()
            with open(notes_path, 'r') as f:
                notes = f.readlines()
        except IOError:
            raise Exception('Cannot read notes file "%s"' % notes_path)
        notes = ''.join(notes)
        # print 'DEBUG: type of notes is %s' % type(notes)
        # print 'DEBUG: notes are ', notes
        if not notes:
            raise Exception('Cannot use empty notes file "%s"' % notes_path)

        self.git_checkout(to_branch)
        out, __ = self._git(['rev-parse', 'HEAD'])
        current_master_sha = out.strip()
        self._git(['update-ref',
                   'refs/tags/premerge/%s/%s' % (to_branch, self.branch_name),
                   current_master_sha])
        self._git(['push', '--force', 'origin',
                   'refs/tags/premerge/%s/%s' % (to_branch, self.branch_name)])

        self.git_merge(self.branch_name)
        self.git_commit('%s: merging branch to %s' % (self.branch_name,
                                                      to_branch))
        self.git_add_notes(notes_path)
        self.git_push(to_branch)

        return True

    def merge_and_close(self, notes_path=None):
        '''
        Merges and closes branch. Automatically pushes result to origin.
        '''
        self.git_clean('master')
        merge_base, _ = self._git(['merge-base',
                                  self.branch_name,
                                  'origin/master'])
        master_head = self.origin_heads['master']
        # import pdb; pdb.set_trace()
        logger.debug('DEBUG: merg_b=%s, master_head=%s'
                     % (merge_base, master_head))
        if merge_base.strip() != master_head.strip():
            raise Exception('Branch %s(%s) is not based on current master '
                            'head(%s). Rebase has not been done properly.'
                            % (self.branch_name, merge_base[:7],
                               master_head[:7]))
        notes = None
        if notes_path is None:
            raise Exception('Cannot close branch w/o notes')
        try:
            # import pdb; pdb.set_trace()
            with open(notes_path, 'r') as f:
                notes = f.readlines()
        except IOError:
            raise Exception('Cannot read notes file "%s"' % notes_path)
        notes = ''.join(notes)
        # print 'DEBUG: type of notes is %s' % type(notes)
        # print 'DEBUG: notes are ', notes
        if not notes:
            raise Exception('Cannot use empty notes file "%s"' % notes_path)

        # Save reference to this branch
        self._git(['update-ref',
                   'refs/tags/closed/%s' % self.branch_name,
                   self.sha])
        self._git(['push', '--force', 'origin',
                   'refs/tags/closed/%s' % self.branch_name])

        self.git_checkout('master')
        out, __ = self._git(['rev-parse', 'HEAD'])
        current_master_sha = out.strip()
        self._git(['update-ref',
                   'refs/tags/premerge/master/%s' % self.branch_name,
                   current_master_sha])
        self._git(['push', '--force', 'origin',
                   'refs/tags/premerge/master/%s' % self.branch_name])

        self.git_merge(self.branch_name)
        self.git_commit('%s: merging and closing branch' % self.branch_name)
        self.git_add_notes(notes_path)
        self.git_push('master')
        self.git_delete_branch(del_remote=True)

        return True

    def undo_close(self, branch_name):
        try:
            out, __ = self._git(['fetch', 'origin',
                                 'refs/tags/closed/%s' % branch_name])
        except (SubProcessException):
            raise Exception('Branch "%s" does not have reference to restore' %
                            branch_name)

        self._git(['branch', branch_name, 'refs/tags/closed/%s' % branch_name])
        self._git(['update-ref', '-d',
                   'refs/tags/closed/%s' % branch_name])
        self._git(['push', 'origin',
                   ':refs/tags/closed/%s' % branch_name])
        self.git_push(branch_name)

    def undo_merge(self, branch_name, from_branch='master'):
        try:
            out, __ = self._git(['fetch', 'origin',
                                'refs/tags/premerge/%s/%s' % (from_branch,
                                                              branch_name)])
        except (SubProcessException):
            raise Exception('Branch "%s" does not have reference to restore'
                            % branch_name)

        self._git(['reset', '--hard', 'refs/tags/premerge/%s/%s' %
                  (from_branch, branch_name)])
        # import pdb; pdb.set_trace()
        self._git(['update-ref', '-d', 'refs/tags/premerge/%s/%s'
                   % (from_branch, branch_name)])
        self._git(['push', 'origin',
                   ':refs/tags/premerge/%s/%s' % (from_branch, branch_name)])
        self.git_push(from_branch)

    def undo_merge_and_close(self, branch_name):
        self.undo_close(branch_name)
        out, err = self._git(['fetch', 'origin',
                             'refs/tags/premerge/master/%s' % branch_name])
        if 'fatal' in err.strip():
            raise Exception('Branch "%s" does not have reference to restore'
                            % branch_name)

        self._git(['reset', '--hard', 'FETCH_HEAD'])
        # import pdb; pdb.set_trace()
        self._git(['update-ref', '-d', 'refs/tags/premerge/master/%s'
                   % branch_name])
        self._git(['push', 'origin',
                   ':refs/tags/premerge/master/%s' % branch_name])
        self.git_push('master')

    def create_pull_request(self, branch_name):
        tag_name = 'refs/tags/pull/%s' % branch_name
        out, __ = self._git(['update-ref', tag_name, 'HEAD'])
        out, __ = self._git(['push', 'origin', tag_name])

    def new_branch(self, branch_name, from_branch='origin/master'):
        self._git(['branch', branch_name, from_branch])

    def _origin_branches(self):
        return self._find_branches(remote=True)

    def _local_branches(self):
        return self._find_branches(remote=False)

    def _find_branches(self, remote=False):
        branches = {}
        commands = ['show-ref', '--heads']
        if remote:
            commands = ['ls-remote', '--heads']

        out, _err = self._git(commands)
        logger.debug(out)
        _all_heads = out.split('\n')

        for line in _all_heads:
            if not line.strip():
                continue
            logger.debug('Git.branches: line=%s' % line)

            sha, head = line.split()
            line = head.strip().split('/')
            logger.debug('Git.branches: line=%s' % line)
            if len(line) < 3:
                continue
            head = line[2]

            logger.debug('Git.branches: sha=%s, head=%s' % (sha, head))
            branches[head] = sha

        return branches

    def list_updated_files(self, branch, from_hash, to_hash):
        out, _err = self._git(['diff-tree', '--no-commit-id', '--name-only',
                               '-r', from_hash, to_hash])
        return out.strip().split('\n')
