"""SCM DOD Form maker
Usage:
    scm_dod_maker.py draft --user NAME --password PWD --project PROJECT
                     [--svntag TAG] --cr CR_NUMBER
                     [--config PATH] [--usertype USERTYPE]
                     [--loglevel LEVEL] [--urlloglevel ULEVEL]
    scm_dod_maker.py submit --user NAME --password PWD --project PROJECT
                     [--config PATH] --cr CR_NUMBER  --dod DOD_NUMBER
                     [--usertype USERTYPE] --appr APPROVER
                     [--loglevel LEVEL] --implement IMPL_DATETIME
                     [--urlloglevel ULEVEL] --evidence EVIDENCE

--help                     Shows this screen
--user USER                Bank ID for SCM user
--password PWD             Password for SCM user
--project PROJECT          Sabre component name
--cr CR_NUMBER             Remedy CR number
--evidence_url URL         URL to sign off evidence
--config PATH              Path to dod_config.yaml
                           [default: meta/projects/BASE/dod_config.yaml]
--dod DOD_NUMBER           SCM DOD draft number to submit(Draft DOD must exist)
--appr APPROVER            PSS Approver for DOD
--implement IMPL_DATETIME  implement datetime for CR
--loglevel LEVEL           Log level for output logging [default: INFO]
--urlloglevel ULEVEL       Log level for HTTP requests [default: CRITICAL]
--usertype USERTYPE        User type for login. There are two options( login as
                           "PSID Users" or "Other users").
                           Default means the script will try "PSID" login
                           and if that fails, will try "Other" login
                           [default: both]
--evidence EVIDENCE        file that needs to be uploaded to scm as an evidence
"""
import os
from os.path import join as jp
import time
import datetime
import logging
import traceback
import sys
import httplib

import requests
import shutil
import yaml

from lib.redis.redis_datasource import RedisDatasource
from lib import tempdir


logger = logging.getLogger()

PSID_USER = 'psid'
OTHER_USER = 'other'
JENKINS_DEFAULT_EVIDENCENAME = 'EVIDENCE'


class DodMaker(object):

    SCM_PHASE_SIT = "01"
    SCM_PHASE_UAT = "02"
    SCM_PHASE_OAT = "03"
    SCM_PHASE_DR = "05"
    SCM_PHASE_RETROFIT = "06"
    SCM_PHASE_PRD = "07"
    SCM_PHASE_AIG_ASRM = "08"
    SCM_PHASE_RETROFIT_PRD = "09"

    SCM_SEVERITY_EXCEPTION = "3"
    SCM_SEVERITY_STANDARD = "2"
    SCM_SEVERITY_EMERGENCY = "1"

    def __init__(self, config_path):
        config_path = os.path.expanduser(config_path)
        if os.path.isdir(config_path):
            config = jp(config_path, 'dod_config.yaml')
        if os.path.isfile(config_path):
            with open(config_path, 'r') as stream:
                cfg = yaml.load(stream)
        else:
            raise Exception('%s does not exists' % config_path)

        if not cfg.get('dod', False):
            raise Exception('"dod" is not present in %s' % config)

        self.user_agent = 'Mozilla/4.0 (compatible; MSIE 7.0; \
Windows NT 6.1; WOW64; Trident/4.0; chromeframe/24.0.1312.56; SLCC2; \
.NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET4.0C; \
.NET4.0E)'
        self.accept = 'application/x-ms-application, image/jpeg, \
application/xaml+xml, image/gif, image/pjpeg, application/x-ms-xbap, \
application/x-shockwave-flash, application/vnd.ms-excel, \
application/vnd.ms-powerpoint, application/msword, */*'
        # Read cfg dict to variables
        self.__dict__.update(cfg['dod'])
        # The dict contains following:
        #
        # self.approver = dod['approver']
        # self.submitter_email = dod['submitter_email']
        # self.cc_email = dod['cc_email']
        # self.vobname = dod['vobname']
        # self.viewname = dod['']
        self.req_session = None
        self.human_name = None
        self.sess_cookies = None
        self.headers = None
        self.userno = None
        self.dod_form = None
        self.cr_number = None
        self.redis = cfg['redis']

    def debug_html(self, request, cookie_jar, show_html=False):
        # print '--------- cookies before request'
        # print cookie_jar
        if show_html:
            print '--------- html ---------'
            print request.text
        # print '--------- cookies returned ---------'
        # print '--- Request:', r.cookies
        # print '--- Sessions:', s.cookies

    def update_cookies(self, old, new):
        if old:
            for cookie in new:
                old.set_cookie(cookie)
        else:
            old = new
        return old

    def find_value(self, string, substring):
        '''
        Finds the value after substring
        used to find form fields

        returns non-unicode str
        '''
        start = string.find(substring)
        if start < 0:
            return ''
        start = start + len(substring)
        quote = string[start:start+1]
        if quote == '"' or quote == '\'':
            start += 1
            end = string.find(quote, start)
        else:
            end = string.find(' ', start)
            # Perhaps we're searching urlstring...
            if end == -1:
                end = string.find('&', start)

        ret_val = string[start:end].encode('ascii', 'ignore')

        return ret_val

    def pre_process_dod_form(self, html):
        '''
        Extracts HTML FORM fields from DODREQUEST form

        returns: form fields dict
        '''
        in_form_fields = False
        params = {}
        for line in html.split('\n'):
            line = line.strip()
            if line:
                if in_form_fields:
                    if line and '<input' in line.lower():
                        name = self.find_value(line, 'name=')
                        value = self.find_value(line, 'value=')
                        # filter out wrong fields not actually used in post
                        if '=' not in name and '=' not in value:
                            params[name] = value
                else:
                    if 'dodrequest' in line.lower():
                        in_form_fields = True
                        continue

        return params

    def find_approver(self):
        approver_list = self.get('{}/DodReqLatest1.jsp?flagval=newrequest&'
                                 'viewname={}&reqno=&funvalue=8&phase=&'
                                 'vobname={}'.format(self.base_url,
                                                     self.viewname,
                                                     self.vobname),
                                 self.headers, self.sess_cookies)
        html = approver_list.text
        select = self.find_value(html, 'app=')
        options = [opt for opt in select.split('><')
                   if 'option' in opt and 'select' not in opt]
        for opt in options:
            name = opt[opt.find('>')+1:opt.find('<')]
            if name == self.approver:
                value = opt[opt.find('=')+1:opt.find('>')]
                return value
        raise Exception('There is no approver "%s"' % self.approver)

    def validate_sabre_module(self, module, dod_number=None):
        if dod_number:
            url = '{}/DodReqLatest1.jsp?flagval=modify&'\
                  'viewname={}&reqno={}&funvalue=8&'\
                  'vobname={}&phase=PRODUCTION'.format(self.base_url,
                                                       self.viewname,
                                                       dod_number,
                                                       self.vobname)
            fragment = 'cntry='
        else:
            url = '{}/DodReqLatest1.jsp?flagval=newrequest&'\
                  'viewname={}&reqno=&funvalue=getjoblist&'\
                  'vobname={}&phase=PRODUCTION'\
                .format(
                    self.base_url,
                    self.viewname,
                    self.vobname
                )
            fragment = 'msg2='
        module_list = self.get(url, self.headers, self.sess_cookies)
        html = module_list.text
        select = self.find_value(html, fragment)
        options = []
        for opt in select.split('><'):
            if 'type=checkbox' in opt and 'value=' in opt:
                start = opt.find('value=')+len('value=')
                end = opt.rfind(' ', start, opt.find('=', start))
                options.append(opt[start:end].lower().strip())
        if module.lower() in options:
            return module
        raise Exception('The requested module(%s) cannot be found '
                        'in the given module list(%s)' % (module,
                                                          ','.join(options)))

    def get(self, url, headers, cookies, show_html=False, sleep=None):
        r = requests.get(url, cookies=cookies, headers=headers)
        self.debug_html(r, r.cookies, show_html)
        if sleep:
            time.sleep(sleep)
        return r

    def post(self, url, params, headers, cookies, show_html=False, sleep=None,
             file_path=None):
        params = {'url': url, 'data': params, 'cookies': cookies,
                  'headers': headers}
        if file_path:
            if params['data'].get('extn'):
                filename = params['data']['extn']
            else:
                filename = 'evidence'
            params['files'] = [('selectedImage',
                                (filename, open(file_path, 'rb'),
                                 'text/plain'))]
        r = requests.post(**params)
        self.debug_html(r, r.cookies, show_html)
        if sleep:
            time.sleep(sleep)
        return r

    def parse_homepage(self, headers, r, s):
        s.cookies = self.update_cookies(s.cookies, r.cookies)
        sess_cookies = requests.utils.dict_from_cookiejar(r.cookies)
        sess_cookies.update({'sdmenu_my_menu': '001000000000000'})
        self.userno = self.find_value(r.text, 'userno=')
        # debug_html(r, s.cookies)
        s.cookies = self.update_cookies(s.cookies, r.cookies)
        r = s.get('{}/news.jsp'.format(self.base_url), cookies=sess_cookies)
        r = s.get('{}/home.jsp'.format(self.base_url), cookies=sess_cookies)
        r = s.get('{}/newwelcome.jsp'.format(self.base_url),
                  cookies=sess_cookies)
        human_name = None
        for line in r.text.split('\n'):
            if 'Welcome' in line:
                start_pos = line.index('Welcome :&nbsp;') + len(
                    'Welcome :&nbsp;')
                human_name = line[start_pos:]
                break
        if not human_name or human_name == 'null':
            raise Exception('Username not found in SCM page')
        r = s.get('{}/NewMenu.jsp'.format(self.base_url),
                  cookies=sess_cookies)
        r = s.get('{}/homepage.jsp'.format(self.base_url),
                  cookies=sess_cookies)
        # debug_html(r, s.cookies)
        s.cookies = self.update_cookies(s.cookies, r.cookies)
        self.req_session = s
        self.human_name = human_name
        self.sess_cookies = sess_cookies
        self.headers = headers

    def login_as_other(self, username, userpass):
        s = requests.Session()
        login_data = {
            'req': '21',
            'username': username,
            'loginvia': 'other'
        }
        headers = {
            'Host': 'scm.global.standardchartered.com',
            'User-Agent': self.user_agent,
            # 'x-requested-with': 'XMLHttpRequest',
            'Referer':
                '{}/vendorlogin.jsp?Login=Login&tbpwd={}&tbuname={}'.format(
                    self.base_url, userpass, username),
            'Content-Type': 'application/x-www-form-urlencoded'
            }
        logger.info('Logging in...')
        login_url = '{}/subfunction1.jsp'.format(self.base_url)
        r = s.post(login_url, login_data, headers=headers)
        self.parse_homepage(headers, r, s)

    def login_as_psid(self, username, userpass):
        s = requests.Session()
        login_data = {
            'AppId': 'thirdparty',
            'url': '{}/index.jsp'.format(self.base_url),
            'username': username,
            'password': userpass
            }
        headers = {'User-Agent': self.user_agent}

        logger.info('Logging in...')
        logger.debug('Initial POST to sso')
        sso_url = 'https://vip.intranet.standardchartered.com/sso/login.do'
        r = s.post(sso_url,
                   login_data, verify=False)
        s.cookies = self.update_cookies(s.cookies, r.cookies)

        if r.status_code != 200:
            raise Exception('Failed to connect to %s' % sso_url)

        logger.debug('Got result from SSO,trying to find if resubmit required')
        response = r.text
        for line in response.split('\n'):
            if 'ConcurrentUserLogin.jsp' in line:
                logger.info('Already logged in, resubmitting password...')
                login_data = {
                    'AppId': 'thirdparty',
                    'url': '{}/index.jsp'.format(self.base_url),
                    'noconcurrent': 'true',
                    'username': username,
                    'password': userpass
                    }
                r = s.post(sso_url,
                           login_data, verify=False, cookies=r.cookies)
                self.debug_html(r, s.cookies)
                if r.status_code != 200:
                    raise Exception('Failed to resubmit login %s' % sso_url)
                break
            elif 'Invalid password' in line:
                raise Exception('Invalid password')
            elif 'Login fail' in line:
                raise Exception('Login failure')

        logger.debug('Got following cookies from SSO: %s' % r.cookies)

        if 'ssosessionid' not in r.cookies:
            logger.error('SSO login failed. '
                         'Binaries were submitted, but DOD has not.'
                         'To retry DOD submission please ask '
                         'Sabre FMSD Support')
            exit(1)

        session_id = r.cookies['ssosessionid']
        post_data = {
            'session_id': session_id,
            'cname': username,
            'LOCATION': 'LON'
            }

        logger.info('Processing SCM initial pages...')
        # print '{}/index.jsp'
        r = s.post('{}/index.jsp'.format(self.base_url),
                   post_data,
                   cookies=s.cookies, headers=headers)
        self.debug_html(r, s.cookies)
        self.parse_homepage(headers, r, s)

    def submit_html_form(self, project, cr_number, dod_mode, short_dod='',
                         implement_datetime=None):
        # DOD submission date - have to be a timestamp
        today = datetime.datetime.fromtimestamp(time.time())
        dt = today.strftime('%Y-%m-%d %H:%M:%S')
        future = today + datetime.timedelta(days=2)
        # DOD completion date - uses different format and have to be in future
        try:
            if implement_datetime:
                implement = datetime.datetime.strptime(
                    implement_datetime, '%Y-%m-%dT%H:%M:%S')
                future_date = implement.strftime('%d-%m-%Y')
                future_time = implement.strftime('%H:30')
                logger.info('Implementation date is %s' % implement.strftime(
                    '%d-%m-%Y %H:30'))
            else:
                raise Exception('Implementation date is not set. '
                                'Default date (%s) will be set'
                                % future.strftime('%d-%m-%Y %H:30'))
        except Exception as err:
            logger.warning(err)
            future_date = future.strftime('%d-%m-%Y')
            future_time = future.strftime('%H:30')

        # Messages about this DOD
        message = "%s binaries for variance check (%s)" % (project, cr_number)
        # Get fields from DOD form
        dod_post_data = self.pre_process_dod_form(self.dod_form)

        if dod_mode == 'new_draft':
            logger.info('Preparing Draft DOD...')
            dod_post_data.update({
                "viewflag": "newrequest",
                "tbreqno": "",
                "tbreqno1": "",
                "tbdraft": 'draft',                      # How to save DOD
                # Can be: draft, new
                "stat": "New"         # if dod_mode == 'draft' else 'DRAFTED',
            })
        elif dod_mode == 'update_draft':
            logger.info('Updating Draft DOD...')
            dod_post_data.update({
                "viewflag": "modify",
                "tbreqno": short_dod,
                "tbreqno1": short_dod,
                "tbdraft": 'draft',                      # How to save DOD
                # Can be: draft, new
                "stat": 'DRAFTED'      # if dod_mode == 'draft' else 'DRAFTED',
            })
        elif dod_mode == 'submit':
            logger.info('Submitting DOD...')
            dod_post_data.update({
                "viewflag": "modify",
                "tbreqno": short_dod,
                "tbreqno1": short_dod,
                "tbdraft": 'new',                      # How to save DOD
                # Can be: draft, new
                "stat": 'DRAFTED'      # if dod_mode == 'draft' else 'DRAFTED',
            })

        dod_post_data.update({
            # "rolevalue": "APPLICATION TEAM USERS",
            # "updateflag": "",
            "StringBoxValues": self.sab_module,
            "countrycode1": self.sab_module,
            # "currentdate": "2014-1-24",
            "tbdofreq": dt,
            # "tbtype": "02",
            # "tbreqby": human_name,
            # "tblabelname1": "",
            # "tbNewrelverno1": "",
            # "usernovalue": "8037",
            # "server": "IN",
            # "getflag": "",
            # "statusval": "",
            # "assuserval1": "null",
            # "reqcountdetails": "0",
            # "dod_borrow": "modify_vob",
            # Fields filled by user
            "cosvobname": self.vobname,              # VOB name
            "cosviewname": self.viewname,            # View name
            "jobname": self.jobname,                 # Hardcoded by SCM
            "testingfor": self.phase,            # Phase
            # Phases are: 04 > ST, 03 > OAT, 02 > UAT, 01 > SIT,
            #             09 > Retrofit only for PRD, 08 > AIG_ASRM, 07 > PRD,
            #             06 > RETROFIT, 05 > DR
            "dodrequestfor": "01",                   # Release type
            # 02 - Incremental
            # 01 - Full build
            "tbchangeno": self.cr_number,            # Change No
            "cosseverity": self.severity,            # Severity
            # 3 - EXCEPTION, 2 - Standard, 1 - EMERGENCY
            "applndeveloped": "02",                  # AppIn.Owner
            # 02 - IN-HOUSE, 01 - VENDOR
            "ApproverName": self.approver_id,        # Approver
            # 7281 - Janefer Yamat
            "cosmode": "1",                          # Delivery Mode
            # 3 - CD/DVD, 1 - STAGING AREA
            "ImplementDate": future_date,                 # Implementation Date
            "ImplementTime": future_time,               # Implementation time
            "taLabelname": self.cr_number + ',',          # SVN label/revision
            # Must be finished with comma
            "tbdefectid": message,
            # Defect id
            "mailsubject": message,                  # Delivery mail subject
            "taDeploymentAgent": self.submitter_email,  # Submitter email
            "taMailcopyto": self.cc_email,          # Mail copy to
            "taInsDeploymentAgent": message,
            # Instructions to Deployment Agent
            "taInsscmteam": message,                # Build/SCM instructions
            "ImpofChanges": "",                     # Impact of changes
            "installPreRequirement": "",
            # Installation pre-requirement
            "PreImplemenActvities": "",
            # Pre-implementation activities
            "ImplemetorLogin": "",
            # ID/Login Access for Patch Implementation
            "Implementprocedure": "",               # Implementation Procedure
            "PostImplementVerification": "",
            # Post-Implementation Verification
            "FallBackProcedure": ""                 # Fall Back Procedure
        })

        headers = {
            'Host': 'scm.global.standardchartered.com',
            'User-Agent': self.user_agent,
            'Referer': '{}/DodReqIF.jsp'.format(self.base_url),
            'Content-Type': 'application/x-www-form-urlencoded',
            }

        logger.info('Submitting DOD...')
        r = self.req_session.post('{}/DodReqBL.jsp'.format(self.base_url),
                                  dod_post_data, headers=headers,
                                  cookies=self.sess_cookies,
                                  allow_redirects=False)

        if dod_mode == 'new_draft':
            try:
                final_url = r.headers['Location']
                # print 'final_url=', final_url
                DOD_number = self.find_value(final_url, 'tbdodreqno=')
                print 'DOD_NUMBER=%s' % DOD_number
            except Exception as ex:
                raise Exception('Something got wrong while submitting DOD. '
                                'Enable debug logging and try again (%s)'
                                % ex.message)
            return DOD_number
        else:
            logger.info('All done. DOD have been submitted.')
            return ''

    def change_svn_tag(self, project, short_dod, cr_number,
                       headers, sess_cookies, implement_datetime=None):
        logger.info('Changing SVN tag to match CR number')

        logging.getLogger('requests').setLevel('DEBUG')

        self.get('{}/addlabelsmodify.jsp?'
                 'Reqno={}&flag=modify_vob'.format(self.base_url, short_dod),
                 headers, sess_cookies)
        label_params = {
            'cblabelname': None,
            'cblabelname1': 'CR001',
            'tbcounter1': '1',
            'tbcounter': '0',
            'return_value': 'CR001,',
            'Reqno': short_dod,
            'flag': 'modify_vob'
        }
        self.post('{}/addlabelsmodify1.jsp?'
                  'type=remove'.format(self.base_url), label_params,
                  headers, sess_cookies)
        self.get('{}/addlabelsmodify.jsp?'
                 'test=2&Reqno={}&vobname=+&flag=modify_vob'
                 .format(self.base_url, short_dod),
                 headers, sess_cookies)
        label_params = {
            'cblabelname': cr_number,
            'tbcounter1': '0',
            'tbcounter': '0',
            'return_value': None,
            'Reqno': short_dod,
            'flag': 'modify_vob',
            'Test': '0'
        }
        self.post('{}/addlabelsmodify1.jsp?'
                  'type=add'.format(self.base_url), label_params,
                  headers, sess_cookies)
        label_params = {
            'cblabelname': cr_number,
            'tbcounter1': '0',
            'tbcounter': '0',
            'return_value': None,
            'Reqno': short_dod,
            'flag': 'modify_vob',
            'Test': '0',
            'Search': 'Add'
        }
        self.post('{}/addlabelsmodify1.jsp?'
                  'type=add'.format(self.base_url), label_params,
                  headers, sess_cookies)
        self.get('{}/addlabelsmodify.jsp?'
                 'test=1&Reqno={}&vobname=+&flag=modify_vob'
                 .format(self.base_url, short_dod),
                 headers, sess_cookies)
        label_params = {
            'cblabelname': None,
            'Cancel': 'Close',
            'tbcounter1': '1',
            'tbcounter': '0',
            'return_value': cr_number + ',',
            'Reqno': short_dod,
            'flag': 'modify_vob',
            'Test': '0'
        }
        self.post('{}/addlabelsmodify.jsp?'
                  'test=1&Reqno={}&vobname=+&flag=modify_vob'
                  .format(self.base_url, short_dod), label_params,
                  headers, sess_cookies)

        logger.info('Saving draft DOD with new SVN tag')
        self.submit_html_form(project, cr_number, 'update_draft',
                              implement_datetime=implement_datetime)
        logger.info('Done changing SVN tag')

    def submit_dod(self, username, userpass, project, cr_number, dod_number,
                   approver, user_type, implement, evidence):

        self.cr_number = cr_number
        self.login_scm(username=username, userpass=userpass,
                       usertype=user_type)

        # Taking class attributes to local variables - too much code changes
        # s = self.req_session # local variable is not used
        sess_cookies = self.sess_cookies
        # human_name = self.human_name # local variable is not used
        headers = self.headers
        # dod_mode = 'new' # local variable is not used

        # Extract number '345678' from 'DOD0000345678'
        short_dod = str(int(dod_number[3:]))

        headers.update({
            'Accept': self.accept,
            'Referer': '{}/NewMenu.jsp'.format(self.base_url),
            'Accept-Language': 'en-US',
            'User-Agent': self.user_agent,
            'Accept-Encoding': 'gzip, deflate',
            'Host': 'scm.global.standardchartered.com',
            'Proxy-Connection': 'Keep-Alive',
            })
        dod_form = self.get('{}/DodReqIF.jsp?'
                            'tbreqno={}'
                            '&viewflag=modify'.format(self.base_url,
                                                      short_dod),
                            headers,
                            sess_cookies)
        self.dod_form = dod_form.text
        headers.update({
            'Accept': self.accept,
            'Referer': '{}/DodReqIF.jsp'.format(self.base_url),
            'Accept-Language': 'en-US',
            'User-Agent': self.user_agent,
            'Accept-Encoding': 'gzip, deflate',
            'Host': 'scm.global.standardchartered.com',
            'Proxy-Connection': 'Keep-Alive',
            })
        self.get('{}/fileattachment1.jsp'.format(self.base_url), headers,
                 sess_cookies)

        headers.update({
            'Accept-Language': 'en-us',
            'Referer': '{}/DodReqIF.jsp?tbreqno={}&viewflag=modify'.format(
                self.base_url, short_dod),
            'x-requested-with': 'XMLHttpRequest',
            'Accept-Encoding': 'gzip, deflate',
            'User-Agent': self.user_agent,
            'Host': 'scm.global.standardchartered.com',
            'Content-Length': '0',
            'Proxy-Connection': 'Keep-Alive',
            'Pragma': 'no-cache',
            'Content-type': None
            })
        self.post('{}/DodReqLatest1.jsp?flagval=modify&getflag='
                  '&reqno={}&funvalue=18'.format(self.base_url, short_dod),
                  '', headers, sess_cookies)
        self.post('{}/DodReqLatest1.jsp?flagval=modify&reqno={}&'
                  'getflag=modify_vob&funvalue=15'.format(self.base_url,
                                                          short_dod),
                  '', headers, sess_cookies)
        self.post('{}/DodReqLatest1.jsp?flagval=modify&getflag=&'
                  'reqno={}&funvalue=16'.format(self.base_url, short_dod),
                  '', headers, sess_cookies)
        self.approver = approver
        self.approver_id = self.find_approver()
        logger.debug('Got approver id: %s...' % self.approver_id)
        self.sab_module = self.validate_sabre_module(project, short_dod)
        logger.debug('Sabre Module: %s' % self.sab_module)

        self.attach_file(
            headers=headers,
            sess_cookies=sess_cookies,
            evidence_name=evidence,
            cr_number=cr_number)

        # We must update Svn tag before we submit real dod
        self.change_svn_tag(project, short_dod, cr_number,
                            headers, sess_cookies,
                            implement_datetime=implement
                            )
        self.submit_html_form(project, cr_number, 'submit', short_dod,
                              implement_datetime=implement)

        try:
            datasource = RedisDatasource(redis_key=self.redis['redis_scm_key'],
                                         default_value=self.redis['scm_data'])
            datasource.update(project, {'DOD': dod_number,
                                        'CR': cr_number})
            logger.info(
                'Update scm data(%s) for %s in redis' %
                (datasource.get(project), project))
        except Exception as ex:
            logger.warning('Cannot connect to Redis: %s' % str(ex))

    def create_draft_dod(self, username, userpass, project, cr_number,
                         svn_tag, user_type, dod_mode='draft'):

        self.cr_number = cr_number

        self.login_scm(username=username, userpass=userpass,
                       usertype=user_type)

        # Taking class attributes to local variables - too much code changes
        # s = self.req_session # local variable is not used
        sess_cookies = self.sess_cookies
        # human_name = self.human_name # local variable is not used
        headers = self.headers

        headers.update({
            'Accept': self.accept,
            'Referer': '{}/NewMenu.jsp'.format(self.base_url),
            'Accept-Language': 'en-US',
            'User-Agent': self.user_agent,
            'Accept-Encoding': 'gzip, deflate',
            'Host': 'scm.global.standardchartered.com',
            'Proxy-Connection': 'Keep-Alive',
            })
        dod_form = self.get('{}/DodReqIF.jsp'.format(self.base_url), headers,
                            sess_cookies)
        self.dod_form = dod_form.text
        headers.update({
            'Accept': self.accept,
            'Referer': '{}/DodReqIF.jsp'.format(self.base_url),
            'Accept-Language': 'en-US',
            'User-Agent': self.user_agent,
            'Accept-Encoding': 'gzip, deflate',
            'Host': 'scm.global.standardchartered.com',
            'Proxy-Connection': 'Keep-Alive',
            })
        self.get('{}/fileattachment1.jsp'.format(self.base_url), headers,
                 sess_cookies)

        headers.update({
            'Accept': '*/*',
            'Accept-Language': 'en-us',
            'Referer': '{}/DodReqIF.jsp'.format(self.base_url),
            'x-requested-with': 'XMLHttpRequest',
            'Accept-Encoding': 'gzip, deflate',
            'User-Agent': self.user_agent,
            'Host': 'scm.global.standardchartered.com',
            'Content-Length': '0',
            'Proxy-Connection': 'Keep-Alive',
            'Pragma': 'no-cache',
            'Content-type': None
            })
        self.post('{}/DodReqLatest1.jsp?flagval=newrequest&getflag='
                  '&reqno=&funvalue=18'.format(self.base_url),
                  '', headers, sess_cookies)
        headers.update({
            'Accept': '*/*',
            'Accept-Language': 'en-us',
            'Referer': '{}/DodReqIF.jsp'.format(self.base_url),
            'x-requested-with': 'XMLHttpRequest',
            'Accept-Encoding': 'gzip, deflate',
            'User-Agent': self.user_agent,
            'Host': 'scm.global.standardchartered.com',
            'Content-Length': '0',
            'Proxy-Connection': 'Keep-Alive',
            'Pragma': 'no-cache',
            'Content-type': None
            })
        self.post('{}/DodReqLatest1.jsp?flagval=newrequest&reqno=&'
                  'getflag=modify_vob&funvalue=15'.format(self.base_url), '',
                  headers, sess_cookies)
        self.get('{}/DodReqLatest1.jsp?flagval=newrequest&getflag='
                 '&reqno=&funvalue=16'.format(self.base_url),
                 headers, sess_cookies)
        self.get('{}/DodReqLatest1.jsp?flagval=newrequest&userno={}&'
                 'reqno=&server=IN&funvalue=10'.format(self.base_url,
                                                       self.userno),
                 headers, sess_cookies)
        self.get('{}/DodReqLatest1.jsp?flagval=newrequest&userno={}&'
                 'vobname={}&reqno=&funvalue=7'.format(self.base_url,
                                                       self.userno,
                                                       self.vobname),
                 headers, sess_cookies)

        self.approver_id = self.find_approver()
        logger.info('Got approver id: %s...' % self.approver_id)
        self.sab_module = self.validate_sabre_module(project)
        logger.info('Sabre Module: %s' % self.sab_module)

        self.get('{}/DodReqLatest1.jsp?flagval=newrequest&userno={}&'
                 'viewname={}&reqno=&funvalue=20'
                 .format(self.base_url, self.userno, self.viewname),
                 headers, sess_cookies)
        self.get('{}/DodReqLatest1.jsp?flagval=newrequest&viewname={}&'
                 'phase=&funvalue=getjoblist&vobname={}&reqno='
                 .format(self.base_url, self.viewname, self.vobname),
                 headers, sess_cookies)
        self.get('{}/DodReqLatest1.jsp?flagval=newrequest&viewname={}'
                 '&phase=TESTING&funvalue=getjoblist&vobname={}&reqno='
                 .format(self.base_url, self.viewname, self.vobname),
                 headers, sess_cookies)

        self.get('{}/addlabel.jsp?Reqno=101'.format(self.base_url),
                 headers, sess_cookies)
        self.post('{}/addlabel1.jsp?type=2'.format(self.base_url),
                  'cblabelname=001&Search=Add&REQ-TYPE=&Reqno=101',
                  headers, sess_cookies)
        self.post('{}/addlabel1.jsp?type=2'.format(self.base_url),
                  'cblabelname=001&Search=Add&REQ-TYPE=&Reqno=101',
                  headers, sess_cookies)
        self.submit_html_form(project, cr_number, 'new_draft')

    def attach_file(self, headers, sess_cookies, evidence_name, cr_number):

        if not os.path.exists(evidence_name):
            err_msg = '[Evidence not found]: file name is %s' % evidence_name
            raise Exception(err_msg)
        with tempdir.TemporaryDirectory() as temp_dir:
            new_evidence_name = 'evidence_{cr_number}.msg'.format(
                cr_number=cr_number)
            new_evidence_path = os.path.join(temp_dir, new_evidence_name)
            logger.info('copy %s to %s' % (evidence_name,
                                           new_evidence_path))
            self.copy_file(evidence_name, new_evidence_path)
            headers['Referer'] = '{}/fileattachment1.jsp'.format(self.base_url)
            file_upload_url = '{base_url}/fileupload1.jsp'.format(
                base_url=self.base_url
            )
            logger.info('Attaching evidence %s' % new_evidence_name)
            response = self.post(file_upload_url,
                                 params={'extn': new_evidence_name},
                                 headers=headers,
                                 cookies=sess_cookies,
                                 file_path=new_evidence_path)
            if not response.ok:
                raise Exception('status_code:%s, reason:%s' % (
                    response.status_code, response.reason))
    def copy_file(self, source, dest, dry_run=False):
        if dry_run:
            print "cp " + source + " " + dest
        else:
            if os.path.exists(source) and os.path.isfile(source) \
                    and os.access(source, os.R_OK) and not os.path.exists(dest):
                shutil.copy2(source, dest)
                return True
            else:
                return False

    def login_scm(self, username, userpass, usertype):
        login_as = None
        if usertype == 'both':
            try:
                self.login_as_psid(username, userpass)
                login_as = PSID_USER
            except:
                # logger.debug(traceback.print_exc())
                logger.warning("Failed to login as psid user")
                logger.info("Try to login as Other user")
                try:
                    self.login_as_other(username, userpass)
                    login_as = OTHER_USER
                except:
                    logger.debug(traceback.print_exc())
        elif usertype.lower() == OTHER_USER:
            try:
                self.login_as_other(username, userpass)
                login_as = OTHER_USER
            except:
                logger.debug(traceback.print_exc())
        elif usertype.lower() == PSID_USER:
            try:
                self.login_as_psid(username, userpass)
                login_as = PSID_USER
            except:
                logger.debug(traceback.print_exc())
        else:
            logger.error("Need to login as 'Other User' or 'PSID User'. "
                         "The usertype of option is '%s' or '%s'" %
                         (OTHER_USER, PSID_USER))
            exit(1)

        if not login_as:
            logger.error("Failed to login as PSID User and Other User")
            exit(1)
        elif login_as.lower() == OTHER_USER:
            logger.info("Login as Other User")
        elif login_as.lower() == PSID_USER:
            logger.info("Login as PSID User")
        else:
            logger.error("Need to login as 'Other User' or 'PSID User'. "
                         "The usertype of option is '%s' or '%s'" %
                         (OTHER_USER, PSID_USER))
            exit(1)

if __name__ == "__main__":
    from docopt import docopt
    args = docopt(__doc__)

    loglevel = args['--loglevel'].upper()
    logging.basicConfig(format='%(levelname)s: %(message)s', level=loglevel)
    logger = logging.getLogger()

    urllib3_logger = logging.getLogger('requests.packages.urllib3')
    urllib3_logger.setLevel(args['--urlloglevel'])
    httplib.HTTPConnection.debuglevel = 0 \
        if args['--urlloglevel'].upper() == 'CRITICAL' else 1

    dod = DodMaker(args['--config'])
    try:
        if args['draft']:
            dod.create_draft_dod(username=args['--user'],
                                 userpass=args['--password'],
                                 project=args['--project'],
                                 cr_number=args['--cr'],
                                 svn_tag=args['--cr'],
                                 dod_mode='draft',
                                 user_type=args['--usertype'])
        elif args['submit']:
            if not os.path.exists(JENKINS_DEFAULT_EVIDENCENAME):
                raise Exception('[File Not Found] file %s is not copied '
                                'to %s' % (args['--evidence'],
                                           JENKINS_DEFAULT_EVIDENCENAME))
            dod.submit_dod(username=args['--user'],
                           userpass=args['--password'],
                           project=args['--project'],
                           cr_number=args['--cr'],
                           dod_number=args['--dod'],
                           approver=args['--appr'],
                           user_type=args['--usertype'],
                           implement=args['--implement'],
                           evidence=JENKINS_DEFAULT_EVIDENCENAME)
    except Exception as ex:
        logger.error(str(ex))
        sys.exit(1)
