from multiconf.envs import EnvFactory

from data_object.project import Project
from data_object.git_object import Git, BootstrapGit
from data_object.git_object import FeatureBranchingModel
from data_object.virtualenv import VirtualEnv
from data_object.jenkins import DefaultJenkins
from data_object.jenkinsjobs import BaseJenkinsJobs, ProjectJenkinsJobs
from data_object.jenkinsviews import JenkinsNestedView, JenkinsListView

ef = EnvFactory()

devlocal = ef.Env('devlocal')

def conf(env_name):
    env = ef.env(env_name)

    with Project(env, valid_envs=[devlocal], name='TEST') as project:
        base_jobs = BaseJenkinsJobs()
        project_jobs = ProjectJenkinsJobs()

        with DefaultJenkins(node='master') as jenkins:
            jenkins.setattr('workspace',
                    devlocal='/sabrebuild/jobs/TEST/git-repo')
            jenkins.setattr('url',
                    devlocal='http://sabrebuild1.uk.standardchartered.com:8180/')
            jenkins.setattr('user_name', devlocal='maleksey')
            jenkins.setattr('user_password',
                    devlocal='3d261f625cd6b0e5ed443aa36bf49ea7')

            with JenkinsNestedView('%s' % project.name) as top_view:
                JenkinsListView('%s-repository' % project.name, jobs=base_jobs)
                JenkinsNestedView('%s-branches' % project.name, jobs=project_jobs)

        BootstrapGit()

        with Git(url='ssh://git@stash/cd/test.git',
            branch_regex='^[A-Z]*-\d{1,5}$',
            master_repo=None) as git:
            git.setattr('master_repo', devlocal=jenkins.workspace)
            FeatureBranchingModel()

        VirtualEnv(home='/home/sabredev/virtualenv/jenkins_bootstrap',
                   python_path='bootstrap/meta/py/lib/jenkins-job-builder')

        return project

