import os
import sys
import unittest
from known_projects import KnownProjects


class test_projects(unittest.TestCase):

    def test_all(self):
        projects = KnownProjects(base=os.environ.get('PROJECT_PATH', None))

        for project_name in projects.project_names:
            print 'Project:', project_name
            envs = [e for e in projects.iter_all_environments([project_name])]
            for env_config in envs:
                sys.stdout.write('    %s: Checking...' % env_config.env.name)
                print 'passed'
